//var app = angular.module("App", ["ngLoadingSpinner", "angularUtils.directives.dirPagination", "ngTagsInput"]);
var app = angular.module("App", ["ngLoadingSpinner", "angularUtils.directives.dirPagination", "ngTagsInput", "ui.tree", "ngMask", 'ngclipboard']);

app.config(function(paginationTemplateProvider){
    paginationTemplateProvider.setPath(window.baseUrl + '/dirPagination'); // Set dir-pagination blade or html file path
});

/* Javascript Error log call function */
app.config(function($provide) {
    $provide.decorator("$exceptionHandler", function($delegate) {
        return function(exception, cause) {
            $delegate(exception, cause);
            OnError(exception.message,exception.fileName,exception.lineNumber, exception);
        };
    });
});

