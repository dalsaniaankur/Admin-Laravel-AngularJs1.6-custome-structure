app.controller('PagesController',function($scope,$http){
    $scope.PagesListURL = baseUrl+'/getpageslist';

    $scope.PagesList = [];
    $scope.ListModel = $.parseJSON($("#ListModel").val());

    $scope.ListPager = new PagerModule('DateFrom');
    $scope.PagesInfoList = function(){
        var pagermodel = {
            SearchParams: $scope.ListModel.backSearchModel,
            PageSize: $scope.ListPager.pageSize,
            PageIndex: $scope.ListPager.currentPage,
            SortIndex: $scope.ListPager.sortIndex,
            SortDirection: $scope.ListPager.sortDirection
        };
        var postData = {};
        postData.Data = $scope.PagesList;
        var jsonData = angular.toJson({ Data:pagermodel });
        AngularAjaxCall($http,$scope.PagesListURL,jsonData,'POST','json','application/json').success(function (response){
            if(response.IsSuccess){
                $scope.PagesList = response.Data.Items;
                if ($scope.PagesList.length == 0) {
                    $('#nodata').show();
                }else{
                    $('#nodata').hide();
                }
                $scope.ListPager.totalRecords = response.Data.TotalItems;
            }
        });
    };

    $scope.SearchPagesRecords = function () {
        CopyProperties($scope.ListModel.frontSearchModel, $scope.ListModel.backSearchModel);
        $scope.ListPager.currentPage = 1;
        $scope.PagesInfoList();
    };

    $scope.ListPager.getDataCallback = $scope.PagesInfoList;

    $scope.ListPager.getDataCallback();

});
