app.controller("BlogListController", function ($scope, $http) {
    $scope.BlogListURL = baseUrl + '/getdashboardbloglist'; // For URL
    $scope.DeleteBlogPostURL = baseUrl + '/deletepost';
    $scope.editBlog = baseUrl+'/editblog/';

    $scope.BlogList = []; //Define a blank Array
    $scope.ListModel = $.parseJSON($("#BlogListModel").val());

    $scope.ListPager = new PagerModule('ModifiedDate','Desc');//create a variable Listpager and set sortIndex userID by default into PagerModule function
    $scope.BlogInfoList = function (setHistoryData) {  //Create a new BlogListInfo function
        if (setHistoryData == undefined)
            setHistoryData = true;

        var pagermodel = { //Define and bind all value related to pagination,sorting and searching
            SearchParams: $scope.ListModel.backSearchModel,
            PageSize: $scope.ListPager.pageSize,
            PageIndex: $scope.ListPager.currentPage,
            SortIndex: $scope.ListPager.sortIndex,
            SortDirection: $scope.ListPager.sortDirection
        };
        var postData = {};
        postData.Data = $scope.BlogList;
        var jsonData = angular.toJson({Data: pagermodel});//default data bind with pagermodel
        AngularAjaxCall($http, $scope.BlogListURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
            if (response.IsSuccess) {
                $scope.BlogList = response.Data.Items;
                if ($scope.BlogList.length == 0) {
                    $('#nodata').show();
                } else {
                    $('#nodata').hide();
                }
                $scope.ListPager.totalRecords = response.Data.TotalItems; //bind total records into ListPager.totalRecords
                if (setHistoryData)
                    SetHistoryData(window.location.href, {
                        searchModel: $scope.ListModel.backSearchModel,
                        searchedCriteria: $scope.ListModel.backSearchModel,
                        pager: {
                            currentPage: $scope.ListPager.currentPage,
                            pageSize: $scope.ListPager.pageSize,
                            sortIndex: $scope.ListPager.sortIndex,
                            sortDirection: $scope.ListPager.sortDirection,
                            reverse: $scope.ListPager.reverse
                        },
                        setCriteria: 'SetCriteria'
                    }, document.title);
            }
        });
    };

    $scope.ListPager.getDataCallback = $scope.BlogInfoList; // call function BlogInfoList

    window.SetCriteria = function (data, pagerData) {
        if (pagerData != undefined) {
            $scope.ListPager.currentPage = pagerData.currentPage;
            $scope.ListPager.sortDirection = pagerData.sortDirection;
            $scope.ListPager.sortIndex = pagerData.sortIndex;
            $scope.ListPager.pageSize = pagerData.pageSize;
            $scope.ListPager.reverse = pagerData.reverse;
        }
        $scope.ListPager.getDataCallback(false);
    }

    if (window.History.getState().data.param != undefined) {
        SetParamData();
    }
    else {
        $scope.ListPager.getDataCallback(); // call getDataCallback function
    }
    /* Edit blog */
    $scope.EditBlog = function (blog) {
        location.href = $scope.editBlog + blog.encryptedBlogPostID;
    };

    /* Delete blog */
    $scope.DeleteBlogPost = function (blog) {
        var postData = {};
        postData.Data = blog.BlogPostID;
        var jsonData = angular.toJson(postData);
        ShowConfirm("this post ?", function () {
            AngularAjaxCall($http, $scope.DeleteBlogPostURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    ShowSuccessMessage(response.Message);
                    $scope.BlogInfoList();       // what if only one data in page ?
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        });
    }
});

/* Pages */
app.controller("pageListController", function ($scope, $http) {
    $scope.PageListURL = baseUrl + '/getdashboardpagelist'; // For URL
    $scope.EditPageURL = baseUrl + '/editpage/';
    $scope.DeletePageURL = baseUrl + '/deletepage';

    $scope.PageList = []; //Define a blank Array
    $scope.ListModel = $.parseJSON($("#PageListModel").val());

    $scope.ListPager = new PagerModule('ModifiedDate','Desc');//create a variable Listpager and set sortIndex userID by default into PagerModule function
    $scope.PageInfoList = function (setHistoryData) {  //Create a new PageListInfo function
        if (setHistoryData == undefined)
            setHistoryData = true;

        var pagermodel = { //Define and bind all value related to pagination,sorting and searching
            SearchParams: $scope.ListModel.backSearchModel,
            PageSize: $scope.ListPager.pageSize,
            PageIndex: $scope.ListPager.currentPage,
            SortIndex: $scope.ListPager.sortIndex,
            SortDirection: $scope.ListPager.sortDirection
        };
        var postData = {};
        postData.Data = $scope.PageList;
        var jsonData = angular.toJson({Data: pagermodel});//default data bind with pagermodel
        AngularAjaxCall($http, $scope.PageListURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
            if (response.IsSuccess) {
                $scope.PageList = response.Data.Items;
                if ($scope.PageList.length == 0) {
                    $('#nodata').show();
                } else {
                    $('#nodata').hide();
                }
                $scope.ListPager.totalRecords = response.Data.TotalItems; //bind total records into ListPager.totalRecords
                if (setHistoryData)
                    SetHistoryData(window.location.href, {
                        searchModel: $scope.ListModel.backSearchModel,
                        searchedCriteria: $scope.ListModel.backSearchModel,
                        pager: {
                            currentPage: $scope.ListPager.currentPage,
                            pageSize: $scope.ListPager.pageSize,
                            sortIndex: $scope.ListPager.sortIndex,
                            sortDirection: $scope.ListPager.sortDirection,
                            reverse: $scope.ListPager.reverse
                        },
                        setCriteria: 'SetCriteria'
                    }, document.title);
            }
        });
    };

    $scope.ListPager.getDataCallback = $scope.PageInfoList; // call function PageInfoList

    window.SetCriteria = function (data, pagerData) {
        if (pagerData != undefined) {
            $scope.ListPager.currentPage = pagerData.currentPage;
            $scope.ListPager.sortDirection = pagerData.sortDirection;
            $scope.ListPager.sortIndex = pagerData.sortIndex;
            $scope.ListPager.pageSize = pagerData.pageSize;
            $scope.ListPager.reverse = pagerData.reverse;
        }
        $scope.ListPager.getDataCallback(false);
    }

    if (window.History.getState().data.param != undefined) {
        SetParamData();
    }
    else {
        $scope.ListPager.getDataCallback(); // call getDataCallback function
    }

    /*Below code for edit page*/
    $scope.EditPage = function (page) {
        location.href = $scope.EditPageURL + page.encryptedPageID;
    };

    /* Delete page */
    $scope.DeletePage = function (page) {
        var postData = {};
        postData.Data = page.PageID;
        var jsonData = angular.toJson(postData);
        ShowConfirm("this page ?", function () {
            if (page.IsUsedInMenu == 1) {
                ShowConfirm("this page from navigation ?", function () {
                    AngularAjaxCall($http, $scope.DeletePageURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                        if (response.IsSuccess) {
                            ShowSuccessMessage(response.Message);
                            $scope.PageInfoList();       // what if only one data in page ?
                        } else {
                            ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                        }
                    });
                });
            } else {
                AngularAjaxCall($http,$scope.DeletePageURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                    if (response.IsSuccess) {
                        ShowSuccessMessage(response.Message);
                        $scope.PageInfoList();       // what if only one data in page ?
                    } else {
                        ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    }
                });
            }
        });
    };
});