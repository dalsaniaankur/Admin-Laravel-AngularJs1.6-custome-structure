app.controller('CacheController',function($scope,$http,$timeout) {
  
	$scope.ClearCacheURL = baseUrl+'/clearcache';
    $scope.ClearCache = function(data) {
            var postData = {};
            postData.Data = data;
            var jsonData = angular.toJson(postData);
            AngularAjaxCall($http,$scope.ClearCacheURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    ShowSuccessMessage(response.Message);
                }else{
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        
    }
   
});







