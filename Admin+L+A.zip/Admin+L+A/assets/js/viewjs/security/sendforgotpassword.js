app.controller('SecurityController',function($scope,$http){

    $scope.postSendResetPasswordEmailURL = baseUrl+'/sendresetpassword';
    $scope.SendVerificationCodeURL = baseUrl+'/verification';
    $scope.RedirectURL = baseUrl+'/';

    $scope.ResetPassword = function() {
        var postData = {};
        postData.Data = $scope.ResetPasswordModel;
        var jsonData = angular.toJson(postData);
        if ($scope.ResetPasswordForm.$valid) {
            AngularAjaxCall($http, $scope.postSendResetPasswordEmailURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {

                if (response.IsSuccess) {
                    ShowSuccessMessage(response.Message);
                }
                else if(response.Data.IsPending != undefined && response.Data.IsPending != '' && response.Data.PendingUserID !=undefined && response.Data.PendingUserID !='' ) {
                    $scope.ResetPasswordModel.IsPending = response.Data.IsPending;
                    $scope.ResetPasswordModel.PendingUserID = response.Data.PendingUserID;

                }else{
                    $scope.ResetPasswordModel.IsPendingSuccess =0;
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }
    }

    $scope.SendVerificationEmail = function() {
        var postData = {};
        postData.Data = $scope.ResetPasswordModel.PendingUserID;
        var jsonData = angular.toJson(postData);
        if ($scope.ResetPasswordForm.$valid) {
            AngularAjaxCall($http, $scope.SendVerificationCodeURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    if(response.Data.IsPendingSuccess != undefined){
                        $scope.ResetPasswordModel.IsPendingSuccess = response.Data.IsPendingSuccess;
                        $scope.ResetPasswordModel.IsPending = 0;
                    }
                }
                else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }
    }

});