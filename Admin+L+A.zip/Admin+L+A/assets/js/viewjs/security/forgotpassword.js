app.controller('SecurityController',function($scope,$http){
    $scope.postResetPasswordURL = baseUrl+'/postresetpassword';
    $scope.RedirectURL = baseUrl+'/';
    $scope.ForgotModel = $.parseJSON($("#ForgotModel").val());

    $scope.ResetPassword = function() {
        var postData = {};
        postData.Data = $scope.ForgotModel;
        var jsonData = angular.toJson(postData);
        if ($scope.ForgotForm.$valid) {
            AngularAjaxCall($http, $scope.postResetPasswordURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    SetMessageForPageLoad(response.Message);
                    location.href = baseUrl + '/';
                }
                else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }
    }

});