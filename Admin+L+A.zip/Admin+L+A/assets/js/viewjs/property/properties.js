app.controller("PropertyListController", function ($scope, $http) {
    $scope.PropertyListURL = baseUrl + '/getpropertylist'; // For URL
    $scope.EditPropertyURL = baseUrl + '/addlisting/';
    $scope.deleteListingURL = baseUrl + '/deleteproperty';
    $scope.PropertyList = []; //Define a blank Array

    $scope.ListModel = $.parseJSON($("#ListModel").val());

    $scope.RedirectToAdd = function () {
        location.href = $scope.EditPropertyURL + $scope.ListModel.encryptedSiteID;
    }

    $scope.ListPager = new PagerModule('ListingID','DESC');//create a variable Listpager and set sortIndex userID by default into PagerModule function

    $scope.PropertyInfoList = function (setHistoryData) { //Create a new UserListInfo function
        if (setHistoryData == undefined)
            setHistoryData = true;

        var pagermodel = { //Define and bind all value related to pagination,sorting and searching
            SearchParams: $scope.ListModel.backSearchModel,
            PageSize: $scope.ListPager.pageSize,
            PageIndex: $scope.ListPager.currentPage,
            SortIndex: $scope.ListPager.sortIndex,
            SortDirection: $scope.ListPager.sortDirection
        };
        var postData = {};
        postData.Data = $scope.PropertyList;
        var jsonData = angular.toJson({Data: pagermodel});//default data bind with pagermodel
        AngularAjaxCall($http, $scope.PropertyListURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
            if (response.IsSuccess) {
                $scope.PropertyList = response.Data.Items;
                if ($scope.PropertyList.length == 0) {
                    $('#nodata').show();
                } else {
                    $('#nodata').hide();
                }
                $scope.ListPager.totalRecords = response.Data.TotalItems; //bind total records into ListPager.totalRecords
                if (setHistoryData)
                    SetHistoryData(window.location.href, {
                        searchModel: $scope.ListModel.backSearchModel,
                        searchedCriteria: $scope.ListModel.backSearchModel,
                        pager: {
                            currentPage: $scope.ListPager.currentPage,
                            pageSize: $scope.ListPager.pageSize,
                            sortIndex: $scope.ListPager.sortIndex,
                            sortDirection: $scope.ListPager.sortDirection,
                            reverse: $scope.ListPager.reverse
                        },
                        setCriteria: 'SetCriteria'
                    }, document.title);
            }
        });
    };

    //For search records
    $scope.SearchPropertyRecords = function () {
        CopyProperties($scope.ListModel.frontSearchModel, $scope.ListModel.backSearchModel);
        $scope.ListPager.currentPage = 1;
        $scope.PropertyInfoList();
    };

    $scope.ListPager.getDataCallback = $scope.PropertyInfoList; // call function UserInfoList

    window.SetCriteria = function (data, pagerData) {

        $scope.ListModel.backSearchModel.AgentID = data.AgentID;
        $scope.ListModel.backSearchModel.IsFeatured = data.IsFeatured;
        $scope.ListModel.backSearchModel.IsHidden = data.IsHidden;
        $scope.ListModel.backSearchModel.MLSNo = data.MLSNo;
        $scope.ListModel.backSearchModel.SiteID = data.SiteID;
        $scope.ListModel.backSearchModel.StatusID = data.StatusID;
        $scope.ListModel.backSearchModel.City = data.City;
        $scope.ListModel.backSearchModel.ZipCode = data.ZipCode;
        $scope.ListModel.backSearchModel.Address = data.Address;

        CopyProperties($scope.ListModel.backSearchModel,$scope.ListModel.frontSearchModel);

        if (pagerData != undefined) {
            $scope.ListPager.currentPage = pagerData.currentPage;
            $scope.ListPager.sortDirection = pagerData.sortDirection;
            $scope.ListPager.sortIndex = pagerData.sortIndex;
            $scope.ListPager.pageSize = pagerData.pageSize;
            $scope.ListPager.reverse = pagerData.reverse;
        }
        $scope.ListPager.getDataCallback(false);
    }

    if (window.History.getState().data.param != undefined) {
        SetParamData();
    }
    else {
        $scope.ListPager.getDataCallback(); // call getDataCallback function
    }


    /* For Edit User Link set*/
    $scope.editProperty = function (Data) {
        location.href = $scope.EditPropertyURL + Data.EncryptedSiteListingID;
    };

    //DEV_AYS
    $scope.DeleteProperty = function(Data) {
        ShowConfirm("this listing?", function () {
            var postData = { Data: Data.ListingID };
            AngularAjaxCall($http,$scope.deleteListingURL,angular.toJson(postData), 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    //SetMessageForPageLoad(response.Message);
                    //window.location.href = response.RedirectUrl;
                    ShowSuccessMessage(response.Message);
                    $scope.PropertyInfoList();
                }else{
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }, 'Yes');
    }

});