app.controller('PropertyController',function($scope,$http,$timeout) {
    $scope.retsFlag = false;
    $scope.AddListingURL = baseUrl+'/savelisting';
    $scope.SearchMlsURL = baseUrl+'/searchmls';
    $scope.RedirectURL = baseUrl + '/listing/';
    $scope.DeleteFileURL = baseUrl + '/deletepropertyimage';
    $scope.deleteListingURL = baseUrl + '/deleteproperty';
    $scope.PropertyModel = $.parseJSON($("#PropertyModel").val());
    //$scope.futureYear = false;
    $scope.IsMlsSearched = false;
    $scope.PropertyModel.ListingModel.oldDevelopmentID =$scope.PropertyModel.ListingModel.DevelopmentID;
    
    /* File Upload & Remove Section Start*/
    $scope.Temp=1;
    $scope.PropertyModel.ListingModel.ImagesModel=[];
    $scope.PropertyModel.ListingModel.ImagesNameModel=[];
    $scope.PropertyModel.ImageExtensionType = ["jpg", "png", "gif", "JPG", "GIF", "PNG"];  // For image tye extensions.
    $scope.PropertyModel.maxFiles = 80; // For set how many file allowed to maximum upload
    $scope.PropertyModel.requestCounter = 0;
    $scope.PropertyModel.responseCounter = 0;
    $scope.PropertyModel.IsAllowSortable = 1;
    /*$scope.$watch('PropertyModel.ListingModel.BuiltYear',function(newVal){
       if(newVal != undefined) {
           newVal=newVal.toString();
           $scope.PropertyModel.ListingModel.BuiltYear = newVal.replace(/^0+/, '');
           if (newVal > new Date().getUTCFullYear()) {
               $scope.futureYear = true;
               $scope.PropertyForm.$valid=false;
               //$scope.PropertyForm.Year_Built.$error.required = true;
           }
           else {
               $scope.futureYear = false;
           }
       }
    });*/

    $scope.checkSave = function(yourForm) {
        checkValidationFocus(yourForm);
    };
    
    $scope.PushFilesToUploadArray = function(filename) {  //For Push added file into array.
        $scope.PropertyModel.ListingModel.ImagesModel.push(filename);
    };
    $scope.UploadComplete = true;  // for enable submit button and watching on request and response counter
    $scope.$watch('PropertyModel.requestCounter',function(newVal) { // for enable submit button and watching on request and response counter
        $scope.UploadComplete = newVal == $scope.PropertyModel.responseCounter;
    });
    $scope.$watch('PropertyModel.responseCounter',function(newVal) { // for enable submit button and watching on request and response counter
        $scope.UploadComplete = newVal == $scope.PropertyModel.requestCounter;
    });

    $scope.updateSortOrder = function(sourceIndex,newIndex){
        if( newIndex != sourceIndex ) {
            var target = $scope.PropertyModel.ListingModel.ImagesNameModel[sourceIndex];
            var increment = newIndex < sourceIndex ? -1 : 1;
            for(var k = sourceIndex; k != newIndex; k += increment){
                $scope.PropertyModel.ListingModel.ImagesNameModel[k] = $scope.PropertyModel.ListingModel.ImagesNameModel[k + increment];
            }
            $scope.PropertyModel.ListingModel.ImagesNameModel[newIndex] = target;
        }
        return $scope.PropertyModel.ListingModel.ImagesNameModel;
    };

    $scope.RemoveFile = function(file){
        var filename = file;
        if(filename){
            var fileToRemove = SearchArrayByPropertyValue($scope.PropertyModel.ListingModel.ImagesModel,filename); // Using given FILENAME search in array for  delete key find.
            if($scope.PropertyModel.ListingModel.ImagesModel[fileToRemove]){
                $scope.PropertyModel.ListingModel.FilePath = $scope.PropertyModel.ListingModel.ImagesModel[fileToRemove].FilePath;
                if($scope.PropertyModel.ListingModel.ImagesModel[fileToRemove].ImageID != undefined){
                    var ImageID = $scope.PropertyModel.ListingModel.ImagesModel[fileToRemove].ImageID;  // find the image id
                }
            }
            if(fileToRemove != -1) {
                AngularAjaxCall($http,$scope.DeleteFileURL, angular.toJson({ Data : {FilePath: $scope.PropertyModel.ListingModel.FilePath,ImageID:ImageID} }), 'POST', 'json', 'application/json').success(function (response) {
                    if (response.IsSuccess){
                        var index = undefined;
                        var filePath = undefined;
                        angular.forEach($scope.PropertyModel.ListingModel.ImagesModel, function (value, key) {
                            if(value.FilePath == filename){
                                index = key;
                                filePath = $scope.PropertyModel.ListingModel.ImagesModel[fileToRemove].FilePath;
                            }
                        });
                        if(filePath != undefined) {
                            var fname =  filePath.split("/").pop(-1);
                            var index = $scope.PropertyModel.ListingModel.ImagesNameModel.indexOf(fname);
                            if (index >= 0) {
                                $scope.PropertyModel.ListingModel.ImagesNameModel.splice(index,1);
                            }
                        }
                        $scope.PropertyModel.ListingModel.ImagesModel.splice(fileToRemove, 1); // After Delete image Remove the value from array using given KEY.
                        ShowSuccessMessage(response.Message);
                    } else {
                        ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    }
                });
            }else{
                return true;
            }
        }
    };
    /* File Upload & Remove Section End*/

    /* PROPERTY FEATURES Start */
    $scope.PropertyModel.ListingModel.ImagesModelOfPropertyFeatures = [];
    $scope.PropertyModel.ImageExtensionTypeOfPropertyFeatures = ["jpg", "png", "gif", "JPG", "GIF", "PNG"];  // For image tye extensions.
    $scope.PropertyModel.maxFilesOfPropertyFeatures = 10; // For set how many file allowed to maximum upload
    $scope.PropertyModel.requestCounterOfPropertyFeatures = 0;
    $scope.PropertyModel.responseCounterOfPropertyFeatures = 0;
    $scope.DeletePropertyFeaturesFileURL = baseUrl + '/deletepropertyfeacturesfiles';
    $scope.PropertyModel.ListingModel.PropertyImagesNameModel=[];
    $scope.PropertyModel.IsAllowStoreOrder=1;

    $scope.PushFilesToUploadArrayOfPropertyFeatures = function(filename) {//For Push added file into array.
        $scope.PropertyModel.ListingModel.ImagesModelOfPropertyFeatures.push(filename);
    };

    $scope.UploadCompleteOFPF = true;  // for enable submit button and watching on request and response counter
    $scope.$watch('PropertyModel.requestCounterOfPropertyFeatures',function(newVal) { // for enable submit button and watching on request and response counter
        $scope.UploadCompleteOFPF = newVal == $scope.PropertyModel.responseCounterOfPropertyFeatures;
    });

    $scope.$watch('PropertyModel.responseCounterOfPropertyFeatures',function(newVal) { // for enable submit button and watching on request and response counter
        $scope.UploadCompleteOFPF = newVal == $scope.PropertyModel.requestCounterOfPropertyFeatures;
    });

    checkValidation= function(ele){
        if($.trim($(ele).val()) == "" || $.trim($(ele).val()) == undefined){
            $(ele).parent().addClass("has-error");
            $(ele).parent().children(".validationMessage").show();
        }
        else{
            $(ele).parent().removeClass("has-error");
            $(ele).parent().children(".validationMessage").hide();
        }
    };
    $scope.ErrorArray = [];
    $scope.RemovePropertyFeaturesFiles = function(file){
        var filename = file.new_filename_search;
        if(filename){
            var fileToRemove = SearchArrayByPropertyValue($scope.PropertyModel.ListingModel.ImagesModelOfPropertyFeatures,filename); // Using given FILENAME search in array for  delete key find.
            if($scope.PropertyModel.ListingModel.ImagesModelOfPropertyFeatures[fileToRemove]){
                $scope.PropertyModel.FilePath = $scope.PropertyModel.ListingModel.ImagesModelOfPropertyFeatures[fileToRemove].FilePath;
                if($scope.PropertyModel.ListingModel.ImagesModelOfPropertyFeatures[fileToRemove].ID != undefined){
                    var ID = $scope.PropertyModel.ListingModel.ImagesModelOfPropertyFeatures[fileToRemove].ID;  // find the image id
                }
            }
            if(fileToRemove != -1) {
                AngularAjaxCall($http,$scope.DeletePropertyFeaturesFileURL, angular.toJson({ Data : {filePath: $scope.PropertyModel.FilePath,fileToRemoveKey: fileToRemove,ImageID:ID} }), 'POST', 'json', 'application/json').success(function (response) {
                    if (response.IsSuccess){
                        $scope.PropertyModel.ListingModel.ImagesModelOfPropertyFeatures.splice(response.Data.Key,1); // After Delete image Remove the value from array using given KEY.
                        ShowSuccessMessage(response.Message);
                        $scope.ErrorArray = [];
                    } else {
                        ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    }
                });
            }else{
                return true;
            }
        }
    };
    /* PROPERTY FEATURES End  */

    $scope.ShowKeywordsError = false;
    // Load keywords.
    $scope.loadKeywords = function($query) {
        return $scope.PropertyModel.Keywords.filter(function(Word) {
            return Word.Keyword.toLowerCase().indexOf($query.toLowerCase()) != -1;
        });

    };
    // Tag Validation.
    $(".ngTagsInput").focusout(function () {
        $scope.ShowKeywordsError = $scope.PropertyForm.$submitted && $scope.PropertyForm.$error.leftoverText != undefined && $scope.PropertyForm.$error.leftoverText.length > 0;

    });

    $scope.SearchMls = function(fromAdd) {
        if(fromAdd == false){
            $scope.IsMlsSearched = true;
        }
        else
            $scope.IsMlsSearched = false;
        $scope.retsFlag = true;
        if($scope.PropertyModel.ListingModel.MLSNo != '' && $scope.PropertyModel.ListingModel.MLSNo != null) {
            var postData = {};
            postData.Data = {};
            postData.Data.MLSNo = $scope.PropertyModel.ListingModel.MLSNo;
            postData.Data.fetchImage = $scope.PropertyModel.ListingModel.fetchImage;
            var jsonData = angular.toJson(postData);
            AngularAjaxCall($http, $scope.SearchMlsURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                $scope.retsFlag = false;
                if (response.IsSuccess) {
                    if($scope.IsMlsSearched == true) {
                        var previousImagesModel = $scope.PropertyModel.ListingModel.ImagesModel;
                        var previousImagesNameModel = $scope.PropertyModel.ListingModel.ImagesNameModel;

                        var previousPropertyFeatureImages = $scope.PropertyModel.ListingModel.ImagesModelOfPropertyFeatures;
                        var previousPropertyFeatureImageNames = $scope.PropertyModel.ListingModel.PropertyImagesNameModel;

                        $scope.PropertyModel.ListingModel = response.Data.ListingModel;
                        $scope.PropertyModel.ListingModel.ImagesModelOfPropertyFeatures = previousPropertyFeatureImages;
                        $scope.PropertyModel.ListingModel.PropertyImagesNameModel = previousPropertyFeatureImageNames;
                        if ($scope.PropertyModel.ListingModel.ImagesModel == undefined)
                            $scope.PropertyModel.ListingModel.ImagesModel = [];
                        angular.merge($scope.PropertyModel.ListingModel.ImagesModel, previousImagesModel);
                        $scope.PropertyModel.ListingModel.ImagesNameModel = previousImagesNameModel;
                        $scope.PropertyModel.IsShowUploadNote = response.Data.IsShowUploadNote;
                    }
                    else
                    {
                        $scope.SaveProperty();
                    }
                } else {
                    $scope.IsMlsSearched = false;
                    $scope.PropertyModel.ListingModel.MLSNo='';
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
            $scope.retsFlag = false;
        }
        else{
            $scope.retsFlag = true;
        }
    };

    $scope.SaveProperty = function(){
        $scope.IsMlsSearched = true;
        var postData = {};
        postData.Data = $scope.PropertyModel.ListingModel;
        var jsonData = angular.toJson(postData);
        AngularAjaxCall($http, $scope.AddListingURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
            if (response.IsSuccess) {
                $scope.ErrorArray = [];
                SetMessageForPageLoad(response.Message);
                window.location.href = response.RedirectUrl;
            } else {
                ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
            }
        });
    };

    $scope.AddListing = function() {
        $scope.ErrorArray = [];
        $scope.ShowKeywordsError = $scope.PropertyForm.$error.leftoverText != undefined && $scope.PropertyForm.$error.leftoverText.length > 0;
            $scope.retsFlag = false;
        if($scope.PropertyModel.ListingModel.ImagesModelOfPropertyFeatures) {
            for (var i = 0; i < $scope.PropertyModel.ListingModel.ImagesModelOfPropertyFeatures.length; i++) {
                var title = $scope.PropertyModel.ListingModel.ImagesModelOfPropertyFeatures[i].TitleClass;
                var description = $scope.PropertyModel.ListingModel.ImagesModelOfPropertyFeatures[i].DescriptionClass;
                if ($.trim($('.' + title).val()) == "" || $.trim($('.' + title).val()) == undefined) {
                    $('.' + title).parent().addClass("has-error");
                    $('.' + title).parent().children(".validationMessage").show();
                    $scope.ErrorArray.push(title);
                } else {
                    $('.' + title).parent().removeClass("has-error");
                    $('.' + title).parent().children(".validationMessage").hide();
                    $scope.PropertyModel.ListingModel.ImagesModelOfPropertyFeatures[i].Title = $('.' + title).val();
                }
                if ($('.' + description).val() == "" || $('.' + description).val() == undefined) {
                    $('.' + description).parent().addClass("has-error");
                    $('.' + description).parent().children(".validationMessage").show();
                    $scope.ErrorArray.push(description);
                } else {
                    $('.' + description).parent().removeClass("has-error");
                    $('.' + description).parent().children(".validationMessage").hide();
                    $scope.PropertyModel.ListingModel.ImagesModelOfPropertyFeatures[i].Description = $('.' + description).val();
                }
            }
        }
        if($scope.ErrorArray.length > 0){
            return false;
        }else{
            $scope.Temp=0;
            if ($scope.PropertyForm.$valid) {
                $scope.ErrorArray = [];
                if ($scope.PropertyModel.ListingModel.MLSNo != '' && $scope.PropertyModel.ListingModel.MLSNo != null && $scope.IsMlsSearched == false && $scope.PropertyModel.ListingModel.ListingID <= 0) {
                    $scope.save = $scope.SearchMls(true);

                }else{
                    $scope.SaveProperty();
                }
            }else{
                $timeout(function() {
                    openErrorPortlets();
                });
            }
        }
    };

    $(document).ready(function() {
        window.onbeforeunload = function () {
            var showMessage =0;
            for (i = 0; i < $scope.PropertyModel.ListingModel.ImagesModel.length; ++i) {
                if($scope.PropertyModel.ListingModel.ImagesModel[i].IsSavedInDB == 0){
                    showMessage = 1;
                }
            }
            var showMessageForProperty;
            for (i = 0; i < $scope.PropertyModel.ListingModel.ImagesModelOfPropertyFeatures.length; ++i) {
                if($scope.PropertyModel.ListingModel.ImagesModelOfPropertyFeatures[i].IsSavedInDB == 0){
                    showMessageForProperty = 1;
                }
            }
            if($scope.Temp==1 && (showMessage==1 || showMessageForProperty==1)){
                return "Do you want to save the uploaded files?";
            }
        };
        window.onunload = function () {
            if($scope.PropertyModel.responseCounter != $scope.PropertyModel.requestCounter){
                $('.uploadInProgress').click();
            }
        };
    });

    $scope.Cancel = function(){
        window.history.back();
    };

    $scope.DeleteProperty = function() {
        ShowConfirm("this listing?", function () {
            var postData = { Data: $scope.PropertyModel.ListingModel.ListingID };
            AngularAjaxCall($http,$scope.deleteListingURL,angular.toJson(postData), 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    SetMessageForPageLoad(response.Message);
                    window.location.href = response.RedirectUrl;
                }else{
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }, 'Yes');
    }
});







