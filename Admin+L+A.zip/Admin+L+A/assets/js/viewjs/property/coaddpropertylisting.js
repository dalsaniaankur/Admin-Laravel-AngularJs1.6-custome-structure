/**
 * Created by kajal on 22-Oct-16.
 */
app.controller('PropertyController',function($scope,$http,$timeout) {
    $scope.retsFlag = false;
    $scope.PropertyModel = $.parseJSON($("#PropertyModel").val());
    if($scope.PropertyModel.ListingModel.ClassID=='' || $scope.PropertyModel.ListingModel.ClassID==null || $scope.PropertyModel.ListingModel.ClassID==undefined)
        $scope.PropertyModel.ListingModel.ClassID = $scope.PropertyModel.Classes[0].ClassID;
    $scope.AddListingURL = baseUrl+'/savelisting';
    $scope.SearchMlsURL = baseUrl+'/searchmls';
    $scope.UpdateListingData = baseUrl+'/updateclassdata';
    $scope.DeleteFileURL = baseUrl + '/deletepropertyimage';
    $scope.deleteListingURL = baseUrl + '/deleteproperty';

    /* File Upload & Remove Section Start*/
    $scope.Temp=1;
    $scope.PropertyModel.ListingModel.ImagesModel=[];
    $scope.PropertyModel.ListingModel.ImagesNameModel=[];
    $scope.PropertyModel.ImageExtensionType = ["jpg", "png", "gif", "JPG", "GIF", "PNG"];  // For image tye extensions.
    $scope.PropertyModel.maxFiles = 80; // For set how many file allowed to maximum upload
    $scope.PropertyModel.requestCounter = 0;
    $scope.PropertyModel.responseCounter = 0;
    $scope.PropertyModel.IsAllowSortable = 1;
    /*$scope.$watch('PropertyModel.ListingModel.YearBuilt',function(newVal){
        if(newVal != undefined) {
            newVal=newVal.toString();
            $scope.PropertyModel.ListingModel.YearBuilt = newVal.replace(/^0+/, '');
            if (newVal > new Date().getUTCFullYear()) {
                $scope.futureYear = true;
                $scope.PropertyForm.$valid=false;
            }
            else
                $scope.futureYear = false;

            if ($scope.PropertyModel.ListingModel.YearRemodeled >0 && ($scope.PropertyModel.ListingModel.YearRemodeled > new Date().getUTCFullYear() || parseInt($scope.PropertyModel.ListingModel.YearRemodeled) < parseInt($scope.PropertyModel.ListingModel.YearBuilt))) {
                $scope.InvalidYear = true;
                $scope.PropertyForm.$valid=false;
            }
            else
                $scope.InvalidYear = false;
        }
    });*/

    /*$scope.$watch('PropertyModel.ListingModel.YearRemodeled',function(newVal){
        if(newVal != undefined) {
            newVal=newVal.toString();
            $scope.PropertyModel.ListingModel.YearRemodeled = newVal.replace(/^0+/, '');
            if (newVal>0 && (newVal > new Date().getUTCFullYear() || ($scope.PropertyModel.ListingModel.YearBuilt == '' || parseInt(newVal) < parseInt($scope.PropertyModel.ListingModel.YearBuilt)))) {
                $scope.InvalidYear = true;
            //    $scope.PropertyForm.$valid=false;
            }
            else
                $scope.InvalidYear = false;

            if ($scope.PropertyModel.ListingModel.YearBuilt > new Date().getUTCFullYear()) {
                $scope.futureYear = true;
            //    $scope.PropertyForm.$valid=false;
            }
            else
                $scope.futureYear = false;
        }
    });*/

    $scope.checkSave = function(yourForm) {
        checkValidationFocus(yourForm);
    };

    $scope.PushFilesToUploadArray = function(filename) {  //For Push added file into array.
        $scope.PropertyModel.ListingModel.ImagesModel.push(filename);
    };
    $scope.UploadComplete = true;  // for enable submit button and watching on request and response counter
    $scope.$watch('PropertyModel.requestCounter',function(newVal) { // for enable submit button and watching on request and response counter
        $scope.UploadComplete = newVal == $scope.PropertyModel.responseCounter;
    });
    $scope.$watch('PropertyModel.responseCounter',function(newVal) { // for enable submit button and watching on request and response counter
        $scope.UploadComplete = newVal == $scope.PropertyModel.requestCounter;
    });

    $scope.updateSortOrder = function(sourceIndex,newIndex){
        if( newIndex != sourceIndex ) {
            var target = $scope.PropertyModel.ListingModel.ImagesNameModel[sourceIndex];
            var increment = newIndex < sourceIndex ? -1 : 1;
            for(var k = sourceIndex; k != newIndex; k += increment){
                $scope.PropertyModel.ListingModel.ImagesNameModel[k] = $scope.PropertyModel.ListingModel.ImagesNameModel[k + increment];
            }
            $scope.PropertyModel.ListingModel.ImagesNameModel[newIndex] = target;
        }
        return $scope.PropertyModel.ListingModel.ImagesNameModel;
    };

    $scope.RemoveFile = function(file){
        var filename = file;
        if(filename){
            var fileToRemove = SearchArrayByPropertyValue($scope.PropertyModel.ListingModel.ImagesModel,filename); // Using given FILENAME search in array for  delete key find.
            if($scope.PropertyModel.ListingModel.ImagesModel[fileToRemove]){
                $scope.PropertyModel.ListingModel.FilePath = $scope.PropertyModel.ListingModel.ImagesModel[fileToRemove].FilePath;
                if($scope.PropertyModel.ListingModel.ImagesModel[fileToRemove].ImageID != undefined){
                    var ImageID = $scope.PropertyModel.ListingModel.ImagesModel[fileToRemove].ImageID;  // find the image id
                }
            }
            if(fileToRemove != -1) {
                AngularAjaxCall($http,$scope.DeleteFileURL, angular.toJson({ Data : {FilePath: $scope.PropertyModel.ListingModel.FilePath,ImageID:ImageID} }), 'POST', 'json', 'application/json').success(function (response) {
                    if (response.IsSuccess){
                        var index = undefined;
                        var filePath = undefined;
                        angular.forEach($scope.PropertyModel.ListingModel.ImagesModel, function (value, key) {
                            if(value.FilePath == filename){
                                index = key;
                                filePath = $scope.PropertyModel.ListingModel.ImagesModel[fileToRemove].FilePath;
                            }
                        });
                        if(filePath != undefined) {
                            var fname =  filePath.split("/").pop(-1);
                            var index = $scope.PropertyModel.ListingModel.ImagesNameModel.indexOf(fname);
                            if (index >= 0) {
                                $scope.PropertyModel.ListingModel.ImagesNameModel.splice(index,1);
                            }
                        }
                        $scope.PropertyModel.ListingModel.ImagesModel.splice(fileToRemove, 1); // After Delete image Remove the value from array using given KEY.
                        ShowSuccessMessage(response.Message);
                    } else {
                        ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    }
                });
            }else{
                return true;
            }
        }
    };
    /* File Upload & Remove Section End*/

    // For updating fields value on change of class
    $scope.GetClassFields= function() {
        var postData = {};
        postData.Data = {};
        postData.Data.ClassID = $scope.PropertyModel.ListingModel.ClassID;
        var jsonData = angular.toJson(postData);        AngularAjaxCall($http, $scope.UpdateListingData, jsonData, 'POST', 'json', 'application/json').success(function (response) {
            var arr = $scope.PropertyModel;
            var check = response.Data.PropertyModel;
            for (key in check) {
                if (key){
                    if(key!='ListingModel') {
                        if (arr.hasOwnProperty(key)) {
                            arr[key] = check[key];
                        }
                    }
                }
            }
            var AnotherArr=$scope.PropertyModel.ListingModel;
            var AnotherCheck=response.Data.PropertyModel.ListingModel;
            for (key in AnotherCheck) {
                if(key=='StateID') {
                    if (AnotherArr.hasOwnProperty(key)) {
                        AnotherArr[key] = AnotherCheck[key];
                    }
                }
            }
        });
        jQuery(".additional-data div.clearboth").remove();
        $timeout(function () {
            jQuery('.additional-data .form-group:nth-child(4n)').after('<div class="clearboth"></div>');
        },1000);
    }

    // update other fields index as per class changes
    $scope.GetUpdateValue =function(model,idz,field){
        var Water=$scope.PropertyModel[model];
        var i=0;
        var index;
        for(key in Water) {
            if(Water[key][field]=='Other') {
                index=i;
                break;
            }
            i++;
        }
        if(index) {
            return $scope.PropertyModel[model][index][idz];
        }
        else {
            return null;
        }
    }

    // for go button click
    $scope.SearchMls = function(fromAdd) {
        if (fromAdd == false) {
            $scope.IsMlsSearched = true;
        }
        else
            $scope.IsMlsSearched = false;
        $scope.retsFlag = true;
        if($scope.PropertyModel.ListingModel.MLSNo != '' && $scope.PropertyModel.ListingModel.MLSNo != null) {
            var postData = {};
            postData.Data = {};
            postData.Data.MLSNo = $scope.PropertyModel.ListingModel.MLSNo;
            postData.Data.ClassID = $scope.PropertyModel.ListingModel.ClassID;
            postData.Data.fetchImage = $scope.PropertyModel.ListingModel.fetchImage;
            var jsonData = angular.toJson(postData);
            AngularAjaxCall($http, $scope.SearchMlsURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                $scope.retsFlag = false;
                if (response.IsSuccess) {
                    if($scope.IsMlsSearched == true) {
                        var previousImagesModel = $scope.PropertyModel.ListingModel.ImagesModel;
                        var previousImagesNameModel = $scope.PropertyModel.ListingModel.ImagesNameModel;

                        $scope.PropertyModel.ListingModel = response.Data.ListingModel;
                        if ($scope.PropertyModel.ListingModel.ImagesModel == undefined)
                            $scope.PropertyModel.ListingModel.ImagesModel = [];
                        angular.merge($scope.PropertyModel.ListingModel.ImagesModel, previousImagesModel);
                        $scope.PropertyModel.ListingModel.ImagesNameModel = previousImagesNameModel;
                        $scope.PropertyModel.IsShowUploadNote = response.Data.IsShowUploadNote;
                    }
                    else
                    {
                        $scope.SaveProperty();
                    }
                } else {
                    $scope.IsMlsSearched = false;
                    $scope.PropertyModel.ListingModel.MLSNo='';
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }

            });
        }
    }

    // showing fields in proper format in addition features section
    jQuery(document).ready(function(){
        jQuery('.additional-data .form-group:nth-child(4n)').after('<div class="clearboth"></div>');
    })


    $scope.SaveProperty = function(){
        $scope.IsMlsSearched = true;
        var postData = {};
        postData.Data = $scope.PropertyModel.ListingModel;
        var jsonData = angular.toJson(postData);
        AngularAjaxCall($http, $scope.AddListingURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
            if (response.IsSuccess) {
                $scope.ErrorArray = [];
                SetMessageForPageLoad(response.Message);
                window.location.href = response.RedirectUrl;
            } else {
                ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
            }
        });
    };

    $scope.AddListing = function() { 
        $scope.ErrorArray = [];
        $scope.retsFlag = false;

        if($scope.ErrorArray.length > 0){
            return false;
        }else{
            $scope.Temp=0;
            if ($scope.PropertyForm.$valid) {
                $scope.ErrorArray = [];
                if ($scope.PropertyModel.ListingModel.MLSNo != '' && $scope.PropertyModel.ListingModel.MLSNo != null && $scope.IsMlsSearched == false && $scope.PropertyModel.ListingModel.ListingID <= 0) {
                    $scope.save = $scope.SearchMls(true);

                }else{
                    $scope.SaveProperty();
                }
            }else{
                $timeout(function() {
                    openErrorPortlets();
                });
            }
        }
    };

    $scope.Cancel = function(){
        window.history.back();
    };

    $scope.DeleteProperty = function() {
        ShowConfirm("this listing?", function () {
            var postData = { Data: $scope.PropertyModel.ListingModel.CoListingID };
            AngularAjaxCall($http,$scope.deleteListingURL,angular.toJson(postData), 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    SetMessageForPageLoad(response.Message);
                    window.location.href = response.RedirectUrl;
                }else{
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }, 'Yes');
    }
});