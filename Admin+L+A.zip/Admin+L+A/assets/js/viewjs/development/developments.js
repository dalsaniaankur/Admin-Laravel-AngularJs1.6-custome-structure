app.controller("DevelopmentListController",function($scope,$http){
    $scope.DevelopmentListURL = baseUrl+'/getdevelopmentlist';
    $scope.EditDevelopmentURL = baseUrl+'/adddevelopment/';
    $scope.DevelopmentList = []; //Define a blank Array
    $scope.ListModel = $.parseJSON($("#ListModel").val());
    $scope.ListModel.NoImagePath = window.NoImagePath;

    $scope.ListPager = new PagerModule("Name");//create a variable Listpager and set sortIndex DevelopmentID by default into PagerModule function

    $scope.DevelopmentInfoList = function(setHistoryData){ //Create a new DevelopmentListInfo function
        if (setHistoryData == undefined)
            setHistoryData = true;

        var pagermodel = { //Define and bind all value related to pagination,sorting and searching
            SearchParams: $scope.ListModel.backSearchModel,
            PageSize: $scope.ListPager.pageSize,
            PageIndex: $scope.ListPager.currentPage,
            SortIndex: $scope.ListPager.sortIndex,
            SortDirection: $scope.ListPager.sortDirection
        };
        var postData = {};
        postData.Data = $scope.DevelopmentList;
        var jsonData = angular.toJson({Data:pagermodel});//default data bind with pagermodel
        AngularAjaxCall($http, $scope.DevelopmentListURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
            if (response.IsSuccess) {
                $scope.DevelopmentList = response.Data.Items;
                if ($scope.DevelopmentList.length == 0){
                    $('#nodata').show();
                }else{
                    $('#nodata').hide();
                }
                $scope.ListPager.totalRecords = response.Data.TotalItems; //bind total records into ListPager.totalRecords
                if (setHistoryData)
                    SetHistoryData(window.location.href, {
                        searchModel: $scope.ListModel.backSearchModel,
                        searchedCriteria: $scope.ListModel.backSearchModel,
                        pager: {
                            currentPage: $scope.ListPager.currentPage,
                            pageSize: $scope.ListPager.pageSize,
                            sortIndex: $scope.ListPager.sortIndex,
                            sortDirection: $scope.ListPager.sortDirection,
                            reverse: $scope.ListPager.reverse
                        },
                        setCriteria: 'SetCriteria'
                    }, document.title);
            }
        });
    };

    //For search records
    $scope.SearchDevelopmentRecords = function () {
        CopyProperties($scope.ListModel.frontSearchModel, $scope.ListModel.backSearchModel);
        $scope.ListPager.currentPage = 1;
        $scope.DevelopmentInfoList();
    };

    $scope.ListPager.getDataCallback = $scope.DevelopmentInfoList; // call function DevelopmentInfoList

    window.SetCriteria = function (data, pagerData) {

        $scope.ListModel.backSearchModel.Name = data.Name;
        $scope.ListModel.frontSearchModel.Name = data.Name;

        if (pagerData != undefined) {
            $scope.ListPager.currentPage = pagerData.currentPage;
            $scope.ListPager.sortDirection = pagerData.sortDirection;
            $scope.ListPager.sortIndex = pagerData.sortIndex;
            $scope.ListPager.pageSize = pagerData.pageSize;
            $scope.ListPager.reverse = pagerData.reverse;
        }
        $scope.ListPager.getDataCallback(false);

    }

    if (window.History.getState().data.param != undefined) {
        SetParamData();
    }
    else {
        $scope.ListPager.getDataCallback(); // call getDataCallback function
    }

    /* For Delete Development */
    $scope.deleteDevelopmentURL = baseUrl+'/deletedevelopment'; // For URL
    $scope.DeleteDevelopment = function(data) {
        ShowConfirm("this Development?", function () {
            var postData = { Data: data.DevelopmentID};
            if (data.IsUsedInMenu == 1) {
                

                AngularAjaxCall($http,$scope.deleteDevelopmentURL,angular.toJson(postData), 'POST', 'json', 'application/json').success(function (response) {
                    if(response.IsSuccess){
                        ShowSuccessMessage(response.Message);
                        $scope.DevelopmentInfoList();
                    }else{
                        ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    }
                });
            }else{
                AngularAjaxCall($http,$scope.deleteDevelopmentURL,angular.toJson(postData), 'POST', 'json', 'application/json').success(function (response) {
                    if(response.IsSuccess){
                        ShowSuccessMessage(response.Message);
                        $scope.DevelopmentInfoList();
                    }else{
                        ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    }
                });
            }
        });
    }

    /* For Edit Development Link set*/
    $scope.EditDevelopment = function(Data) {
        location.href =  $scope.EditDevelopmentURL+Data.EncryptedSiteDevelopmentID;
    }

});