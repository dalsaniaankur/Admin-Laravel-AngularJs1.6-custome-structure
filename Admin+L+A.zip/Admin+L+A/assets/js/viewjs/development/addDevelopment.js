app.controller("DevelopmentController",function($scope,$http,$timeout){
    $scope.addDevelopment = baseUrl+'/savedevelopment';
    $scope.RedirectURL = baseUrl+'/developments/';
    $scope.deleteFile = baseUrl+'/deleteimage';
    $scope.editURL = baseUrl+'/adddevelopment/';
    $scope.GetDevelopmentImageUrl = baseUrl+'/getdevelopmentimage';
    $scope.DisableButtons = false;
    $scope.DevelopmentModel = $.parseJSON($("#DevelopmentModel").val());
    $scope.DevelopmentModel = $scope.DevelopmentModel.DevDetails;

    $scope.DevelopmentModel.NoImagePath = window.NoImagePath;
    $scope.AwsUploadBaseURL = $scope.DevelopmentModel.FileUploadSettings.url;

    $scope.checkSave = function(yourForm) {
        checkValidationFocus(yourForm);
    };

    /* Recommended dimensions set */
    if((Window.ImageResitrictions[$scope.DevelopmentModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.DevelopmentModel.SiteID]['DevelopmentTopImages']['Height'] != undefined){
        $scope.AllowedFixHeight = Window.ImageResitrictions[$scope.DevelopmentModel.SiteID]['DevelopmentTopImages']['Height'];
    }
    if((Window.ImageResitrictions[$scope.DevelopmentModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.DevelopmentModel.SiteID]['DevelopmentTopImages']['Width'] != undefined){
        $scope.AllowedFixWidth = Window.ImageResitrictions[$scope.DevelopmentModel.SiteID]['DevelopmentTopImages']['Width'];
    }
    if(($scope.AllowedFixHeight != undefined && $scope.AllowedFixHeight != '' && $scope.AllowedFixHeight != null && $scope.AllowedFixHeight != 0) && ($scope.AllowedFixHeight != undefined && $scope.AllowedFixHeight !='' && $scope.AllowedFixHeight !=null && $scope.AllowedFixHeight != 0)){
        $scope.CheckDimensionValidation = 1;
    }else{
        $scope.CheckDimensionValidation = 0;
    }

    /* Related to File Upload & Remove  Start */
        $scope.DevelopmentModel.UploadFilesArray=[];
        $scope.DevelopmentModel.ImagesNameModel=[];
        $scope.DevelopmentModel.IsAllowStoreOrder=1;
        $scope.DevelopmentModel.ImageExtensionType = ["jpg", "png", "gif", "JPG", "GIF", "PNG"];  // For image tye extensions.
        $scope.DevelopmentModel.maxFiles = 5; // For set how many file allowed to maximum upload
        $scope.DevelopmentModel.requestCounter = 0;
        $scope.DevelopmentModel.responseCounter = 0;

        $scope.PushFilesToUploadArray = function(filename) {  //For Push added file into array.
            $scope.DevelopmentModel.UploadFilesArray.push(filename);
        }

        $scope.UploadComplete = true;  // for enable submit button and watching on request and response counter
        $scope.$watch('DevelopmentModel.requestCounter',function(newVal) { // for enable submit button and watching on request and response counter
            $scope.UploadComplete = newVal == $scope.DevelopmentModel.responseCounter;
        });

        $scope.$watch('DevelopmentModel.responseCounter',function(newVal) { // for enable submit button and watching on request and response counter
            $scope.UploadComplete = newVal == $scope.DevelopmentModel.requestCounter;
        });

        $scope.RemoveFile = function(file){

            var filename= file;

           if(filename){
               var fileToRemove = SearchArrayByPropertyValue($scope.DevelopmentModel.UploadFilesArray,filename); // Using given FILENAME search in array for  delete key find.
               if($scope.DevelopmentModel.UploadFilesArray[fileToRemove]){
                   $scope.DevelopmentModel.FilePath = $scope.DevelopmentModel.UploadFilesArray[fileToRemove].FilePath;
                   if($scope.DevelopmentModel.UploadFilesArray[fileToRemove].ImageID != undefined){
                       var ImageID = $scope.DevelopmentModel.UploadFilesArray[fileToRemove].ImageID;  // find the image id
                   }
               }

               if(fileToRemove != -1) {
               AngularAjaxCall($http,$scope.deleteFile, angular.toJson({ Data : {filePath: $scope.DevelopmentModel.FilePath,fileToRemoveKey: fileToRemove,ImageID:ImageID,IsDefaultImage: $scope.DevelopmentModel.IsDefaultImage} }), 'POST', 'json', 'application/json').success(function (response) {
                   if (response.IsSuccess){
                       $scope.DevelopmentModel.UploadFilesArray.splice(response.Data.Key,1); // After Delete image Remove the value from array using given KEY.

                       if(response.Data.IsDeleteDefaultImages != undefined && response.Data.IsDeleteDefaultImages==1){ // Set IsDefaultImage to NULL if User delete the Default selected image.
                           $scope.DevelopmentModel.IsDefaultImage='';
                       }
                       ShowSuccessMessage(response.Message);
                   } else {
                       ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                   }
               });
               }else{
                   return true;
               }
           }
        }


    // Below two fun'c used for Default image selection in add and edit page.
        $scope.OnFileAdded = function(filedata){
            $(filedata.FileData.previewElement).find(".IsDefaultImage").val(filedata.new_filename);
            $(".IsDefaultImage").click(function(){
                $scope.DevelopmentModel.IsDefaultImage = $(this).val();
            })
        }

        $scope.OnDefaultFileLoad = function(file){
            $(file.previewElement).find(".IsDefaultImage").val(file.new_filename);
            if(file.IsDefaultImage=="1") {
                $(file.previewElement).find(".IsDefaultImage").prop('checked', true);
                $scope.DevelopmentModel.IsDefaultImage = file.new_filename;
            }
        }
    /* Related to File Upload & Remove  End */

    /* For Delete Development */
    $scope.deleteDevelopmentURL = baseUrl+'/deletedevelopment'; // For URL
    $scope.DeleteDevelopment = function() {
        ShowConfirm("this Development?", function () {
            var postData = { Data: $scope.DevelopmentModel.DevelopmentID };
            if ($scope.DevelopmentModel.IsUsedInMenu > 0) {
                ShowConfirm("this page from navigation ?", function () {
                AngularAjaxCall($http,$scope.deleteDevelopmentURL,angular.toJson(postData), 'POST', 'json', 'application/json').success(function (response) {
                    if(response.IsSuccess){
                        SetMessageForPageLoad(response.Message);
                        window.location.href = $scope.RedirectURL.concat(response.Data);
                    }else{
                        ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    }
                });
                });
            }else{
                AngularAjaxCall($http,$scope.deleteDevelopmentURL,angular.toJson(postData), 'POST', 'json', 'application/json').success(function (response) {
                    if(response.IsSuccess){
                        SetMessageForPageLoad(response.Message);
                        window.location.href = $scope.RedirectURL.concat(response.Data);
                    }else{
                        ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    }
                });
            }
        });
    }

    /* On Cancel button click redirect to userList page */
    $scope.Cancel = function(){
        window.history.back();

    }
    $scope.SaveDevelopment = function () {
        var postData = {};
        postData.Data = $scope.DevelopmentModel;
        postData.Data.DevelopmentFeatures = $scope.DevelopmentModel.ListingModel.ImagesModelOfDevelopmentFeatures;
        var jsonData = angular.toJson(postData);

        if($scope.DevelopmentModel.UploadFilesArray.length == 0){ // For Required validations of image
            ShowAlertMessage(window.DevelopmentImage, 'error', window.ConfirmDialogSomethingWrong);
        }else if($scope.DevelopmentModel.IsDefaultImage == undefined || $scope.DevelopmentModel.IsDefaultImage == '') { // For default image selection validations required.
            ShowAlertMessage(window.DefaultDevelopmentImage, 'error', window.ConfirmDialogSomethingWrong);
        }else{
            $scope.DisableButtons = true;
            AngularAjaxCall($http, $scope.addDevelopment, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess){
                    if($scope.DevelopmentModel.DevelopmentID > 0){
                        ShowSuccessMessage(response.Message);
                    }else{
                        $scope.DevelopmentModel.UploadFilesArray = [];
                        SetMessageForPageLoad(response.Message);
                        window.location.href = $scope.editURL.concat(response.Data.encryptedDevlopmentSiteID);
                    }
                    $scope.Temp = 0;
                    $scope.DisableButtons = false;
                    $scope.ErrorArray = [];
                } else {
                    $scope.DisableButtons = false;
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }
    }
    

    $scope.Save = function() {
        $scope.ErrorArray = [];
        $scope.ShowKeywordsError = $scope.DevelopmentForm.$error.leftoverText != undefined && $scope.DevelopmentForm.$error.leftoverText.length > 0;
        if($scope.DevelopmentModel.ListingModel.ImagesModelOfDevelopmentFeatures) {
            for (var i = 0; i < $scope.DevelopmentModel.ListingModel.ImagesModelOfDevelopmentFeatures.length; i++) {
                var title = $scope.DevelopmentModel.ListingModel.ImagesModelOfDevelopmentFeatures[i].TitleClass;
                var description = $scope.DevelopmentModel.ListingModel.ImagesModelOfDevelopmentFeatures[i].DescriptionClass;
                if ($.trim($('.' + title).val()) == "" || $.trim($('.' + title).val()) == undefined) {
                    $('.' + title).parent().addClass("has-error");
                    $('.' + title).parent().children(".validationMessage").show();
                    $scope.ErrorArray.push(title);
                } else {
                    $('.' + title).parent().removeClass("has-error");
                    $('.' + title).parent().children(".validationMessage").hide();
                    $scope.DevelopmentModel.ListingModel.ImagesModelOfDevelopmentFeatures[i].Title = $('.' + title).val();
                }
                if ($('.' + description).val() == "" || $('.' + description).val() == undefined) {
                    $('.' + description).parent().addClass("has-error");
                    $('.' + description).parent().children(".validationMessage").show();
                    $scope.ErrorArray.push(description);
                } else {
                    $('.' + description).parent().removeClass("has-error");
                    $('.' + description).parent().children(".validationMessage").hide();
                    $scope.DevelopmentModel.ListingModel.ImagesModelOfDevelopmentFeatures[i].Description = $('.' + description).val();
                }
            }
        }
        if($scope.ErrorArray.length > 0){
            return false;
        }else{
            $scope.Temp=0;
            if ($scope.DevelopmentForm.$valid) {
             $scope.SaveDevelopment();

            }else{
                $timeout(function() {
                    openErrorPortlets();
                });
            }
        }
    };

    function showMessageOfLeave(){
        var showMessage = 0;
        for (i = 0; i < $scope.DevelopmentModel.UploadFilesArray.length; ++i) {
            if($scope.DevelopmentModel.UploadFilesArray[i].IsSavedInDB == 0){
                showMessage = 1;
            }
        }
        return showMessage;
    }

    /* Tab */
    $scope.Temp = 1;
    $scope.getTab = function(data,$event) {
        if(data==1){
            $scope.Temp = 1;
        }
        if(data==0 && $scope.Temp==1){
            var showMessage = showMessageOfLeave();
            if(showMessage == 1 || ($scope.DevelopmentModel.responseCounter != $scope.DevelopmentModel.requestCounter)){
                var r = confirm("Do you want to save the uploaded files?");
                if (r == true) {
                    $event.stopPropagation();
                }else{
                    $('.uploadInProgress').click();
                    $scope.Temp = 0;
                }
            }
        }
    }

    $(document).ready(function() {   // To do set common functions for this functions.
        window.onbeforeunload = function () {
            var showMessage = showMessageOfLeave();
            if(showMessage==1 && $scope.Temp==1){
                return "Do you want to save the uploaded files?";
            }
        };
        window.onunload = function () {
            if($scope.DevelopmentModel.responseCounter != $scope.DevelopmentModel.requestCounter){
                $('.uploadInProgress').click();
            }

        };
    });

    /*Development Feature */
    if($scope.DevelopmentModel.ListingModel == undefined){
        $scope.DevelopmentModel.ListingModel = [];
    }
    $scope.DevelopmentModel.ListingModel.ImagesModelOfDevelopmentFeatures = [];
    $scope.DevelopmentModel.ImageExtensionTypeOfDevelopmentFeatures = ["jpg", "png", "gif", "JPG", "GIF", "PNG"];  // For image tye extensions.
    $scope.DevelopmentModel.maxFilesOfDevelopmentFeatures = 10; // For set how many file allowed to maximum upload
    $scope.DevelopmentModel.requestCounterOfDevelopmentFeatures = 0;
    $scope.DevelopmentModel.responseCounterOfDevelopmentFeatures = 0;
    $scope.DeleteDevelopmentFeaturesFileURL = baseUrl + '/deletedevelopmentfeacturesfiles';
    $scope.DevelopmentModel.ListingModel.DevelopmentImagesNameModel=[];
    $scope.DevelopmentModel.IsAllowStoreOrder = 1;

    $scope.PushFilesToUploadArrayOfDevelopmentFeatures = function(filename) { //For Push added file into array.
        $scope.DevelopmentModel.ListingModel.ImagesModelOfDevelopmentFeatures.push(filename);
    };

    $scope.RemoveDevelopmentFeaturesFiles = function(filename) {//For Push added file into array.
        $scope.DevelopmentModel.ListingModel.ImagesModelOfDevelopmentFeatures.push(filename);
    };

    $scope.UploadCompleteOFPF = true;  // for enable submit button and watching on request and response counter
    $scope.$watch('DevelopmentModel.requestCounterOfDevelopmentFeatures',function(newVal) { // for enable submit button and watching on request and response counter
        $scope.UploadCompleteOFPF = newVal == $scope.DevelopmentModel.responseCounterOfDevelopmentFeatures;
    });

    $scope.$watch('DevelopmentModel.responseCounterOfDevelopmentFeatures',function(newVal) { // for enable submit button and watching on request and response counter
        $scope.UploadCompleteOFPF = newVal == $scope.DevelopmentModel.requestCounterOfDevelopmentFeatures;
    });

    checkValidation= function(ele){
        if($.trim($(ele).val()) == "" || $.trim($(ele).val()) == undefined){
            $(ele).parent().addClass("has-error");
            $(ele).parent().children(".validationMessage").show();
        }
        else{
            $(ele).parent().removeClass("has-error");
            $(ele).parent().children(".validationMessage").hide();
        }
    };
    $scope.ErrorArray = [];
    $scope.RemoveDevelopmentFeaturesFiles = function(file){
        var filename = file.new_filename_search;
        if(filename){
            var fileToRemove = SearchArrayByPropertyValue($scope.DevelopmentModel.ListingModel.ImagesModelOfDevelopmentFeatures,filename); // Using given FILENAME search in array for  delete key find.
            if($scope.DevelopmentModel.ListingModel.ImagesModelOfDevelopmentFeatures[fileToRemove]){
                $scope.DevelopmentModel.FilePath = $scope.DevelopmentModel.ListingModel.ImagesModelOfDevelopmentFeatures[fileToRemove].FilePath;
                if($scope.DevelopmentModel.ListingModel.ImagesModelOfDevelopmentFeatures[fileToRemove].ID != undefined){
                    var ID = $scope.DevelopmentModel.ListingModel.ImagesModelOfDevelopmentFeatures[fileToRemove].ID;  // find the image id
                }
            }
            if(fileToRemove != -1) {
                AngularAjaxCall($http,$scope.DeleteDevelopmentFeaturesFileURL, angular.toJson({ Data : {filePath: $scope.DevelopmentModel.FilePath,fileToRemoveKey: fileToRemove,ImageID:ID} }), 'POST', 'json', 'application/json').success(function (response) {
                    if (response.IsSuccess){
                        $scope.DevelopmentModel.ListingModel.ImagesModelOfDevelopmentFeatures.splice(response.Data.Key,1); // After Delete image Remove the value from array using given KEY.
                        ShowSuccessMessage(response.Message);
                        $scope.ErrorArray = [];
                    } else {
                        ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    }
                });
            }else{
                return true;
            }
        }
    };
    /* PROPERTY FEATURES End  */
});


app.controller("DevelopmentVideoController",function($scope,$http){
    /* Development Video List and Delete Development Video Start */
    $scope.DevelopmentVideoListURL = baseUrl+'/developmentvideo';
    $scope.DeleteDevelopmentVideoURL = baseUrl+'/removedevelopmentvideo';
    $scope.DevelopmentModel.NoImagePath = window.NoImagePath;
    $scope.DevelopmentVideoList = []; //Define a blank Array
    $scope.ListPager = new PagerModule("Title");

    $scope.DevelopmentInfoList = function(){ //Create a new DevelopmentListInfo function
        var pagermodel = {//Define and bind all value related to pagination,sorting and searching
            SearchParams: $scope.DevelopmentModel.DevelopmentID,
            PageSize: $scope.ListPager.pageSize,
            PageIndex: $scope.ListPager.currentPage,
            SortIndex: $scope.ListPager.sortIndex,
            SortDirection: $scope.ListPager.sortDirection
        };
        var postData = {};
        postData.Data = $scope.DevelopmentVideoList;
        var jsonData = angular.toJson({Data:pagermodel});//default data bind with pagermodel
        AngularAjaxCall($http, $scope.DevelopmentVideoListURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
            if (response.IsSuccess) {
                $scope.DevelopmentVideoList = response.Data.Items;
                if ($scope.DevelopmentVideoList.length == 0){
                    $('#nodata').show();
                }else{
                    $('#nodata').hide();
                }
                $scope.ListPager.totalRecords = response.Data.TotalItems; //bind total records into ListPager.totalRecords

            }
        });
    };
    $scope.ListPager.getDataCallback = $scope.DevelopmentInfoList; // call function DevelopmentInfoList
    $scope.ListPager.getDataCallback(); // call getDataCallback function


    $scope.DeleteDevelopmentVideo = function(data) {
        ShowConfirm("this Video?", function () {
            var postData = { Data: data.VideoID };
            AngularAjaxCall($http,$scope.DeleteDevelopmentVideoURL,angular.toJson(postData), 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    $scope.DevelopmentInfoList();
                    ShowSuccessMessage(response.Message);
                }else{
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        });
    }
    /* Development Video List and Delete Development Video End */

});




app.controller("DevelopmentListingController",function($scope,$http) {

    /* Development Listing Start */
    $scope.Data = $.parseJSON($("#DevelopmentModel").val());
    $scope.DevelopmentListModel = $scope.Data.DevDetails;

    $scope.DevelopmentPropertyListURL = baseUrl+'/getdevelopmentpropertylist'; // For URL
    $scope.DeleteDevelopmentListingURL = baseUrl+'/deletedevelopmentlisting';

    $scope.DevelopmentPropertyList = [];
    $scope.ListPagerListing = new PagerModule("");
    $scope.DevelopmentPropertyInfoList = function(){
        var pagermodel = {
            SearchParams: $scope.DevelopmentListModel.backSearchModel,
            PageSize: $scope.ListPagerListing.pageSize,
            PageIndex: $scope.ListPagerListing.currentPage,
            SortIndex: $scope.ListPagerListing.sortIndex,
            SortDirection: $scope.ListPagerListing.sortDirection
        };
        var postData = {};
        postData.Data = $scope.DevelopmentPropertyList;
        var jsonData = angular.toJson({Data:pagermodel});
        AngularAjaxCall($http, $scope.DevelopmentPropertyListURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
            if (response.IsSuccess){
                $scope.DevelopmentPropertyList = response.Data.Items;
                if ($scope.DevelopmentPropertyList.length == 0) {
                    $('#nodata1').show();
                }else{
                    $('#nodata1').hide();
                }
                $scope.ListPagerListing.totalRecords = response.Data.TotalItems;

            }
        });
    };

    //For search records
    $scope.SearchDevelopmentPropertyRecords = function () {
        CopyProperties($scope.DevelopmentListModel.frontSearchModel, $scope.DevelopmentListModel.backSearchModel);
        $scope.ListPagerListing.currentPage = 1;
        $scope.DevelopmentPropertyInfoList();
    };

    $scope.ListPagerListing.getDataCallback = $scope.DevelopmentPropertyInfoList;
    $scope.ListPagerListing.getDataCallback();

    $scope.DeleteDevelopmentListing = function(data) {
        ShowConfirm("this Listing?", function () {
            var postData = { Data: data.ListingID };
            AngularAjaxCall($http,$scope.DeleteDevelopmentListingURL,angular.toJson(postData), 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    $scope.DevelopmentPropertyInfoList();
                    ShowSuccessMessage(response.Message);
                }else{
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        });
    }

    /* Development Listing End */


});

