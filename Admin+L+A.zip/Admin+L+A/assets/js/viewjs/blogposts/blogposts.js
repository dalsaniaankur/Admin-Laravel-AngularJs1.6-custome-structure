app.controller('BlogPostController', function ($scope, $http) {
    $scope.BlogPostListURL = baseUrl + '/getblogpostlist';
    $scope.DeleteBlogPostURL = baseUrl + '/deletepost';
    $scope.ListModel = $.parseJSON($("#ListModel").val());
    $scope.BlogPostList = [];

    $scope.ListPager = new PagerModule('ModifiedDate','Desc');
    $scope.BlogPostInfoList = function (setHistoryData) {
        if (setHistoryData == undefined)
            setHistoryData = true;

        var pagermodel = {
            SearchParams: $scope.ListModel.backSearchModel,
            PageSize: $scope.ListPager.pageSize,
            PageIndex: $scope.ListPager.currentPage,
            SortIndex: $scope.ListPager.sortIndex,
            SortDirection: $scope.ListPager.sortDirection
        };
        var postData = {};
        postData.Data = $scope.BlogPostList;
        var jsonData = angular.toJson({Data: pagermodel});
        AngularAjaxCall($http, $scope.BlogPostListURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
            if (response.IsSuccess) {
                $scope.BlogPostList = response.Data.Items;
                if ($scope.BlogPostList.length == 0) {
                    $('#nodata').show();
                } else {
                    $('#nodata').hide();
                }
                $scope.ListPager.totalRecords = response.Data.TotalItems;
                if (setHistoryData)
                    SetHistoryData(window.location.href, {
                        searchModel: $scope.ListModel.backSearchModel,
                        searchedCriteria: $scope.ListModel.backSearchModel,
                        pager: {
                            currentPage: $scope.ListPager.currentPage,
                            pageSize: $scope.ListPager.pageSize,
                            sortIndex: $scope.ListPager.sortIndex,
                            sortDirection: $scope.ListPager.sortDirection,
                            reverse: $scope.ListPager.reverse
                        },
                        setCriteria: 'SetCriteria'
                    }, document.title);
            }
            else {
                ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
            }
        });
    };
    $scope.SearchBlogPostRecords = function () {
        CopyProperties($scope.ListModel.frontSearchModel, $scope.ListModel.backSearchModel);
        $scope.ListPager.currentPage = 1;
        $scope.BlogPostInfoList();
    };

    /* For Tab Wise Filter set.*/
    $scope.getList = function(data){
        $scope.ListModel.frontSearchModel.StatusID = data;
        $scope.SearchBlogPostRecords();
    }



    $scope.ListPager.getDataCallback = $scope.BlogPostInfoList;

    window.SetCriteria = function (data, pagerData) {


        $scope.ListModel.backSearchModel.DateFrom = data.DateFrom;
        $scope.ListModel.backSearchModel.DateTo = data.DateTo;
        $scope.ListModel.backSearchModel.StatusID = data.StatusID;
        $scope.ListModel.backSearchModel.Today = data.Today;
        $scope.ListModel.backSearchModel.CategoryID = data.CategoryID;

        $scope.ListModel.frontSearchModel.DateFrom = data.DateFrom;
        $scope.ListModel.frontSearchModel.DateTo = data.DateTo;
        $scope.ListModel.frontSearchModel.StatusID = data.StatusID;
        $scope.ListModel.frontSearchModel.Today = data.Today;
        $scope.ListModel.frontSearchModel.CategoryID = data.CategoryID;

        if (pagerData != undefined) {
            $scope.ListPager.currentPage = pagerData.currentPage;
            $scope.ListPager.sortDirection = pagerData.sortDirection;
            $scope.ListPager.sortIndex = pagerData.sortIndex;
            $scope.ListPager.pageSize = pagerData.pageSize;
            $scope.ListPager.reverse = pagerData.reverse;
        }

        $scope.ListPager.getDataCallback(false);
    }

    if (window.History.getState().data.param != undefined) {
        SetParamData();
    } else {
        $scope.ListPager.getDataCallback();
    }

    $scope.editBlog = baseUrl+'/editblog/';
    $scope.EditBlog = function (blog) {
        location.href = $scope.editBlog + blog.encryptedBlogPostID;
    };


    $scope.DeleteBlogPost = function (blog) {
        var postData = {};
        postData.Data={};
        postData.Data.ID = blog.BlogPostID;
        postData.Data.Slug = blog.Slug;
        var jsonData = angular.toJson(postData);
        ShowConfirm("this post ?", function () {
            AngularAjaxCall($http, $scope.DeleteBlogPostURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    ShowSuccessMessage(response.Message);
                    $scope.BlogPostInfoList();       // what if only one data in page ?
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        });
    }
});