app.controller("BlogController",function($scope,$http,$timeout){
    $scope.addBlogURL = baseUrl+'/saveblog';
    $scope.saveImageURL = baseUrl+'/saveblogpostimage';
    $scope.removeProfileImageURL = baseUrl+'/removeblogpostimage';
    $scope.blogListURL =  baseUrl+'/blogposts/';
    $scope.BlogModel = $.parseJSON($("#BlogModel").val());
    $scope.encryptedSiteID = $scope.BlogModel.encryptedSiteID;
    $scope.RedirectURL = $scope.BlogModel.RedirectURL;
    $scope.BlogModel.BlogDetails.OldAgents=$scope.BlogModel.BlogDetails.TagAgent;

    $scope.$watch('BlogModel.BlogDetails.Title',function(newVal,oldVal){
        /*Here this condition solve watch problem for edit and add mode*/
        if(newVal != oldVal) {
            $scope.BlogModel.BlogDetails.BrowserTitle = newVal;
            $scope.BlogModel.BlogDetails.FBTitle = newVal;
            $scope.BlogModel.BlogDetails.TwitterTitle = newVal;
            $scope.BlogModel.BlogDetails.Headline = newVal;
        }
    });

    /* Recommended dimensions set */
    if((Window.ImageResitrictions[$scope.BlogModel.BlogDetails.SiteID] != undefined)  && Window.ImageResitrictions[$scope.BlogModel.BlogDetails.SiteID]['BlogFeatureImages']['Height'] != undefined){
        $scope.AllowedFeatureImageFixHeight = Window.ImageResitrictions[$scope.BlogModel.BlogDetails.SiteID]['BlogFeatureImages']['Height'];
    }
    if((Window.ImageResitrictions[$scope.BlogModel.BlogDetails.SiteID] != undefined) && Window.ImageResitrictions[$scope.BlogModel.BlogDetails.SiteID]['BlogFeatureImages']['Width'] != undefined){
        $scope.AllowedFeatureImageFixWidth = Window.ImageResitrictions[$scope.BlogModel.BlogDetails.SiteID]['BlogFeatureImages']['Width'];
    }

    $scope.$watch('BlogModel.BlogDetails.Slug',function(newVal,oldVal){
        /*Here this condition solve watch problem for edit and add mode*/
        if(newVal != oldVal){
            /*Here this condition for made canonicalURL with section and without section*/
            if($scope.BlogModel.Section != '' && $scope.BlogModel.Section != null){
                $scope.BlogModel.BlogDetails.CanonicalURL = $scope.BlogModel.BaseUrl+'/'+$scope.BlogModel.Section+'/'+$scope.BlogModel.BlogDetails.Slug;
            }else{
                $scope.BlogModel.BlogDetails.CanonicalURL = $scope.BlogModel.BaseUrl+'/'+$scope.BlogModel.BlogDetails.Slug;
            }
        }
    });

    $scope.$watch('BlogModel.BlogDetails.Summary',function(newVal,oldVal){
        /*Here this condition solve watch problem for edit and add mode*/
        if(newVal != oldVal) {
            $scope.BlogModel.BlogDetails.FBDescription = newVal;
            $scope.BlogModel.BlogDetails.TwitterDescription = newVal;
            $scope.BlogModel.BlogDetails.Description = newVal;
        }
    });


    /* Tag functionality Start */
    $scope.ShowTagError = false;

    // Load Tag.
    $scope.loadTags = function($query) {
        return $scope.BlogModel.TagListArray.filter(function(Word) {
            return Word.Tag.toLowerCase().indexOf($query.toLowerCase()) != -1;
        });
    };
    // Tag Validation.
    $(".ngTagsInput").focusout(function () {
        $scope.ShowTagError = $scope.BlogForm.$submitted && $scope.BlogForm.$error.leftoverText != undefined && $scope.BlogForm.$error.leftoverText.length > 0;

    });

    $scope.checkSave = function(yourForm) {
        checkValidationFocus(yourForm);
    };

    $scope.Save = function () {
        $scope.ShowTagError = $scope.BlogForm.$error.leftoverText != undefined && $scope.BlogForm.$error.leftoverText.length > 0;
        var postData = {};
        postData.Data = $scope.BlogModel.BlogDetails;
        var jsonData = angular.toJson(postData);
        if($scope.BlogForm.$valid && $scope.FormImageBlogFeatured.$valid){
            AngularAjaxCall($http, $scope.addBlogURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess){
                    SetMessageForPageLoad(response.Message);
                    window.location.href = response.RedirectURL;
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }else{
            $timeout(function() {
                openErrorPortlets();
            });
        }
    }

    /* For Approve Start */
    $scope.approveBlogURL = baseUrl+'/approveblog';
    $scope.Approve = function () {
        var postData = {};
        postData.Data = $scope.BlogModel.BlogDetails;
        var jsonData = angular.toJson(postData);
        if($scope.BlogForm.$valid && $scope.FormImageBlogFeatured.$valid) {
            AngularAjaxCall($http, $scope.approveBlogURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    SetMessageForPageLoad(response.Message);
                    window.location.href = response.RedirectURL;
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }
    }
    /* Approve End */

    /* For Deny Start */
    $scope.denyBlogURL = baseUrl+'/denyblog';
    $scope.Deny = function () {
        if($scope.BlogModel.BlogDetails.Message == undefined || $scope.BlogModel.BlogDetails.Message ==''){
            ShowAlertMessage(window.MessageRequired, 'error', window.ConfirmDialogSomethingWrong);
            $("#deny-message").focus();
        }else{
            var postData = {};
            postData.Data = $scope.BlogModel.BlogDetails;
            var jsonData = angular.toJson(postData);
                if($scope.BlogForm.$valid && $scope.FormImageBlogFeatured.$valid) {
                AngularAjaxCall($http, $scope.denyBlogURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                    if (response.IsSuccess) {
                        SetMessageForPageLoad(response.Message);
                        window.location.href = response.RedirectURL;
                    } else {
                        ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    }
                });
            }
        }
    }


    /* Deny End */


    /* For Publish Start */
    $scope.publishBlogURL = baseUrl+'/publishblog';
    $scope.Publish = function () {
        var postData = {};
        postData.Data = $scope.BlogModel.BlogDetails;
        var jsonData = angular.toJson(postData);
        if($scope.BlogForm.$valid && $scope.FormImageBlogFeatured.$valid) {
            AngularAjaxCall($http, $scope.publishBlogURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    SetMessageForPageLoad(response.Message);
                    window.location.href = response.RedirectURL;
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }

    }
    /* Publish End */

    $scope.Cancel = function(){
        window.location.href = $scope.RedirectURL;
    }


    /* Delete Blog Post */
    $scope.DeleteBlogPostURL = baseUrl + '/deletepost';
    $scope.DeleteBlogPost = function () {
        var postData = {};
        postData.Data = {};
        postData.Data.ID = $scope.BlogModel.BlogDetails.BlogPostID;
        postData.Data.Slug = $scope.BlogModel.BlogDetails.Slug;
        var jsonData = angular.toJson(postData);
        ShowConfirm("this post ?", function () {
            AngularAjaxCall($http, $scope.DeleteBlogPostURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    window.location.href = $scope.blogListURL.concat( $scope.BlogModel.encryptedSiteID);
                    SetMessageForPageLoad(response.Message);
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        });
    }




    /*Bellow code for file upload*/
    $scope.AwsUploadBaseURL = $scope.BlogModel.BlogDetails.Fileuploadsettings.url;
    $scope.BlogModel.BlogDetails.NoImagePath = window.NoImagePath;
    $scope.BlogModel.BlogDetails.NoProfileImagePath = window.NoProfileImagePath;
    $scope.requestCounter = 0;
    $scope.responseCounter = 0;
    /*For Image upload*/
    $(document).ready(function() {
        var AwsSettingModel = $scope.BlogModel.BlogDetails.Fileuploadsettings;
        $('.direct-upload').each(function() {
            var imgType = $(this).attr('img-type');
            var form = $(this);
            var parentDiv =  $(form).parents('.fileinput');
            var uploadMaxFileSizeErrorMessage = '';
            var checkForMaxDimensionsRequired = true;
            var AllowedFixHeight = 0;
            var AllowedFixWidth = 0;
            var FixWidthMessage = "";
            var FixHeightMessage = "";
            var FixHeightWidthMessage="";
            switch(imgType) {
                case window.FBImageType:
                    uploadMaxFileSizeErrorMessage = window.FBMaxFileSizeErrorMessage;
                    var maxFileSize = window.ImageSize;
                    break;
                case window.TwitterImageType:
                    uploadMaxFileSizeErrorMessage = window.TwitterMaxFileSizeErrorMessage;
                    var maxFileSize = window.ImageSize;
                    break;
                case window.GoogleImageType:
                    uploadMaxFileSizeErrorMessage = window.GoogleMaxFileSizeErrorMessage;
                    var maxFileSize = window.ImageSize;
                    break;
                case window.BlogFeaturedImageType:
                    uploadMaxFileSizeErrorMessage = '';
                    var maxFileSize = undefined;
                    var Images = 'BlogFeatureImages';
                    if((Window.ImageResitrictions[$scope.BlogModel.BlogDetails.SiteID] != undefined)  && Window.ImageResitrictions[$scope.BlogModel.BlogDetails.SiteID][Images]['Height'] != undefined){
                        var AllowedFixHeight = Window.ImageResitrictions[$scope.BlogModel.BlogDetails.SiteID][Images]['Height'];
                        var FixWidthMessage= Window.ImageResitrictions[$scope.BlogModel.BlogDetails.SiteID][Images]['WidthMessage'];
                    }
                    if((Window.ImageResitrictions[$scope.BlogModel.BlogDetails.SiteID] != undefined) && Window.ImageResitrictions[$scope.BlogModel.BlogDetails.SiteID][Images]['Width'] != undefined){
                        var AllowedFixWidth = Window.ImageResitrictions[$scope.BlogModel.BlogDetails.SiteID][Images]['Width'];
                        var FixHeightMessage= Window.ImageResitrictions[$scope.BlogModel.BlogDetails.SiteID][Images]['HeightMessage'];
                    }
                    if((AllowedFixHeight != undefined && AllowedFixHeight != '' && AllowedFixHeight != null && AllowedFixHeight != 0) && (AllowedFixWidth != undefined && AllowedFixWidth != '' && AllowedFixWidth != null && AllowedFixWidth != 0)) {
                        var FixHeightWidthMessage = Window.ImageResitrictions[$scope.BlogModel.BlogDetails.SiteID][Images]['HeightWidthMessage'];
                    }
                    if(AllowedFixHeight != undefined || AllowedFixWidth != undefined){
                        var checkForMaxDimensionsRequired = true;
                    }else{
                        var checkForMaxDimensionsRequired = false;
                    }
                    break;
            }
            var options ={
                successCallBack: function(new_filename,tempFileName, imageWidth, imageHeight){
                    AngularAjaxCall($http, $scope.saveImageURL,angular.toJson({ Data : {ImageName: new_filename,ImageType: imgType} }) , 'POST', 'json', 'application/json').success(function (response) {
                        if(true) {
                            var realImagePath = $scope.AwsUploadBaseURL + new_filename;
                            $scope.BlogModel.BlogDetails.ImageName = new_filename;
                            switch(imgType) {
                                case window.FBImageType:
                                    $scope.BlogModel.BlogDetails.FBImage = new_filename;
                                    $scope.BlogModel.BlogDetails.FBRealImagePath = realImagePath;
                                break;
                                case window.TwitterImageType:
                                    $scope.BlogModel.BlogDetails.TwitterImage = new_filename;
                                    $scope.BlogModel.BlogDetails.TwitterRealImagePath = realImagePath;
                                break;
                                case window.GoogleImageType:
                                    $scope.BlogModel.BlogDetails.Image = new_filename;
                                    $scope.BlogModel.BlogDetails.GoogleRealImagePath = realImagePath;
                                    $scope.BlogModel.BlogDetails.ImageHeight = imageHeight;
                                    $scope.BlogModel.BlogDetails.ImageWidth = imageWidth;
                                break;
                                case window.BlogFeaturedImageType:
                                    $scope.BlogModel.BlogDetails.FeaturedImage = new_filename;
                                    $scope.BlogModel.BlogDetails.RealFeaturedImagePath = realImagePath;
                                    break;
                            }

                            $scope.responseCounter = $scope.responseCounter+1;
                            $(parentDiv).find('#file').removeAttr('disabled');
                            $(parentDiv).find('.progress').hide();
                            $(parentDiv).find('.bar').css('width', '0');
                            $(parentDiv).find('#loadingImage').css('display', 'block');
                            $(parentDiv).find('#actualImage').on('load', function () {
                                $(parentDiv).find('#loadingImage').css('display', 'none');
                            });
                            //$scope.BlogModel.BlogDetails.UploadFilesArray.push = new_filename;
                        }
                    });
                },
                AWSBaseURL: $scope.AwsUploadBaseURL,
                AWSSettingsModel:AwsSettingModel,
                form:form,
                AllwoedExts:uploadphotoexts,
                maxFileSizeLimit:maxFileSize,
                maxFileSizeErrorMessage:uploadMaxFileSizeErrorMessage,
                AlertMessage:window.ImageFileAllowedMessage,
                ResizeRequired:false,
                getDimensions: true,
                multiple:true,
                checkForMaxDimensionsRequired: checkForMaxDimensionsRequired,
                AllowedFixHeight: AllowedFixHeight,
                AllowedFixWidth: AllowedFixWidth,
                FixWidthMessage: FixWidthMessage,
                FixHeightMessage:FixHeightMessage,
                FixHeightWidthMessage: FixHeightWidthMessage,
                progressCallback : function(){

                },
                addCallback : function(){
                    $scope.requestCounter = $scope.requestCounter + 1;
                }
            };
            Awsfileupload(options);

        });
    });
    /* For Remove An Image */
    $scope.RemoveImage = function(imageType) {
        var imageName ='';
        var realImagePath = '';
        switch(imageType) {
            case window.FBImageType:
                imageName =  $scope.BlogModel.BlogDetails.FBImage;
                realImagePath =  $scope.BlogModel.BlogDetails.FBRealImagePath;
            break;
            case window.TwitterImageType:
                imageName = $scope.BlogModel.BlogDetails.TwitterImage;
                realImagePath = $scope.BlogModel.BlogDetails.TwitterRealImagePath;
            break;
            case window.GoogleImageType:
                imageName = $scope.BlogModel.BlogDetails.Image;
                realImagePath = $scope.BlogModel.BlogDetails.GoogleRealImagePath;
            break;
            case window.BlogFeaturedImageType:
                imageName = $scope.BlogModel.BlogDetails.FeaturedImage;
                realImagePath = $scope.BlogModel.BlogDetails.RealFeaturedImagePath;
            break;
        }
        ShowConfirm("this Image?", function () {
            AngularAjaxCall($http, $scope.removeProfileImageURL, angular.toJson({Data:{BlogPostID: $scope.BlogModel.BlogDetails.BlogPostID,RemoveType: imageType,ImageName: imageName}}),'POST','json','application/json').success(function(response){
                if (response.IsSuccess) {
                    $scope.BlogModel.BlogDetails.UploadFilesArray = realImagePath;
                    switch(imageType) {
                        case window.FBImageType:
                            $scope.BlogModel.BlogDetails.FBImage = '';
                            $scope.BlogModel.BlogDetails.FBRealImagePath = response.Data;
                        break;
                        case window.TwitterImageType:
                            $scope.BlogModel.BlogDetails.TwitterImage = '';
                            $scope.BlogModel.BlogDetails.TwitterRealImagePath = response.Data;
                        break;
                        case window.GoogleImageType:
                            $scope.BlogModel.BlogDetails.Image = '';
                            $scope.BlogModel.BlogDetails.GoogleRealImagePath = response.Data;
                            $scope.BlogModel.BlogDetails.ImageHeight = '';
                            $scope.BlogModel.BlogDetails.ImageWidth = '';
                        break;
                        case window.BlogFeaturedImageType:
                            $scope.BlogModel.BlogDetails.FeaturedImage = '';
                            $scope.BlogModel.BlogDetails.RealFeaturedImagePath ='';
                            break;
                    }
                    $scope.BlogModel.BlogDetails.IsImageRemoved = 1;
                    $scope.BlogModel.BlogDetails.ImageName = '';
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        });
    };

    //We need to add this to hide help text while page load
    $(".help-block").removeClass("display-none");

});