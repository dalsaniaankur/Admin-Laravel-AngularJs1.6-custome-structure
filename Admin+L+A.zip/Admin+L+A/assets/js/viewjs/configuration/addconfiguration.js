app.controller('ConfigurationController',function($scope,$http,$timeout) {
    $scope.ConfigurationModel = $.parseJSON($("#ConfigurationModel").val());
    $scope.TimeZonesArray = $scope.ConfigurationModel.TimeZonesArray;
    $scope.AddConfigurationURL = baseUrl+'/saveconfiguration';
    $scope.GetSiteImageUrl = baseUrl+'/getsiteimage';
    $scope.RemoveSiteImageURL = baseUrl+'/removesiteimage';
    $scope.RedirectURL = baseUrl + '/dashboard';

    $scope.ConfigurationModel = angular.extend($scope.ConfigurationModel.ConfigurationDetails);
    $scope.ConfigurationModel.NoImagePath = window.NoImagePath;
    $scope.AwsUploadBaseURL = $scope.ConfigurationModel.Fileuploadsettings.url;
    $scope.encryptedSiteID = $scope.ConfigurationModel.encryptedSiteID;

    $scope.DisableButtons = false;
    
    $scope.checkSave = function(yourForm) {
        checkValidationFocus(yourForm);
    };

    $scope.SaveConfiguration = function() {
        if ($scope.ConfigurationForm.$valid && $scope.ImageForm.$valid) {
            $scope.DisableButtons = true;
            var postData = {};
            postData.Data = $scope.ConfigurationModel;
            var jsonData = angular.toJson(postData);
            AngularAjaxCall($http,$scope.AddConfigurationURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    ShowSuccessMessage(response.Message);
                    $scope.DisableButtons = false;
                }else{
                    $scope.DisableButtons = false;
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }else{
            $timeout(function() {
                openErrorPortlets();
            });
        }
    }


    /* For Image Upload */
    $(document).ready(function() {
        var AwsSettingModel = $scope.ConfigurationModel.Fileuploadsettings;
        $('.direct-upload').each(function() {
            var form = $(this);
            var options ={
                successCallBack: function(new_filename, tempFileName, imageWidth, imageHeight){
                    AngularAjaxCall($http, $scope.GetSiteImageUrl,angular.toJson({ Data : {PublisherLogoPath: new_filename,SiteID: 0} }) , 'POST', 'json', 'application/json').success(function (response) {
                        if(true) {
                            var realImagePath = $scope.AwsUploadBaseURL + new_filename;
                            $scope.ConfigurationModel.PublisherLogoPath = new_filename;
                            $scope.ConfigurationModel.RealImagePath = realImagePath;

                            /* Set uploaded images height and width */
                            $scope.ConfigurationModel.PublisherLogoHeight = imageHeight;
                            $scope.ConfigurationModel.PublisherLogoWidth = imageWidth;

                            $('#file').removeAttr('disabled');
                            $("#ImageError").removeClass("ValidationError").text("");
                            $('.progress').hide();
                            $('.bar').css('width', '0');
                            $("#btn-submit").removeAttr('disabled');
                            $("#RemoveImage").show();
                            $("#cancel").removeAttr('disabled');
                            $('#loadingImage').css('display', 'block');
                            $('#actualImage').on('load', function () {
                                $('#loadingImage').css('display', 'none');
                            });
                            $scope.ConfigurationModel.UploadFilesArray=[];
                            $scope.ConfigurationModel.UploadFilesArray.push = new_filename;
                        }
                    });

                },
                AWSBaseURL: $scope.AwsUploadBaseURL,
                AWSSettingsModel:AwsSettingModel,
                form:form,
                AllwoedExts:uploadphotoexts,
                AlertMessage:window.ImageFileAllowedMessage,
                ResizeRequired:false,
                getDimensions: true,
                checkForMaxDimensionsRequired: true,
                maxAllowedHeight: 60,
                maxAllowedWidth: 599,
                maxWidthMessage: 'Publisher Logo width should be less than or equal 600px.',
                maxHeightMessage:'Publisher Logo height should be less than 60px.',
                maxHeightWidthMessage: 'Publisher Logo width should be less than or equal 600px & height should be less than 60px.',
                progressCallback : function(){
                }
            };
            Awsfileupload(options);
        });
    });

    /* For Remove An Image */
    $scope.RemoveImage = function(data) {
        ShowConfirm("this Image?", function () {
            AngularAjaxCall($http, $scope.RemoveSiteImageURL, angular.toJson({ Data : {SiteID: $scope.ConfigurationModel.SiteID,PublisherLogoPath: $scope.ConfigurationModel.PublisherLogoPath} }), 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    $scope.ConfigurationModel.UploadFilesArray = $scope.ConfigurationModel.RealImagePath;
                    $scope.ConfigurationModel.RealImagePath = response.Data;
                    $scope.ConfigurationModel.IsImageRemoved = 1;
                    $scope.ConfigurationModel.PublisherLogoPath ='';
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        });
    };

    /* On Cancel button click redirect to userList page */
    $scope.Cancel = function(){
        window.location.href = $scope.RedirectURL;
    }

});







