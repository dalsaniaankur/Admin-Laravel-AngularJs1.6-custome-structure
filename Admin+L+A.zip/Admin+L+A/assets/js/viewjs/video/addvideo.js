app.controller('VideoController',function($scope,$http,$timeout) {
    $scope.AddVideoURL = baseUrl+'/savevideo';
    $scope.deleteVideoURL = baseUrl+'/deletevideo';
    $scope.GetVideoImageUrl = baseUrl+'/getvideoimage';
    $scope.RemoveVideoImageURL = baseUrl+'/removevideoimage';
    $scope.RedirectURL = baseUrl + '/videolist/';
    $scope.DisableButtons = false;

    $scope.VideoModel = $.parseJSON($("#VideoModel").val());
    $scope.VideoModel = $scope.VideoModel.VideoDetails;
    $scope.AwsUploadBaseURL = $scope.VideoModel.Fileuploadsettings.url;
    $scope.encryptedSiteID = $scope.VideoModel.encryptedSiteID;
    $scope.VideoModel.NoImagePath = window.NoImagePath;
    $scope.ShowTagsError = false;

    /* Recommended dimensions set */
    if((Window.ImageResitrictions[$scope.VideoModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.VideoModel.SiteID]['VideoImages']['Height'] != undefined){
        $scope.AllowedFixHeight = Window.ImageResitrictions[$scope.VideoModel.SiteID]['VideoImages']['Height'];
    }
    if((Window.ImageResitrictions[$scope.VideoModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.VideoModel.SiteID]['VideoImages']['Width'] != undefined){
        $scope.AllowedFixWidth = Window.ImageResitrictions[$scope.VideoModel.SiteID]['VideoImages']['Width'];
    }


    $scope.checkSave = function(yourForm) {
        checkValidationFocus(yourForm);
    };
    $scope.AddVideo = function() {
        $scope.ShowTagsError = $scope.VideoForm.$error.leftoverText != undefined && $scope.VideoForm.$error.leftoverText.length > 0;
        var postData = {};
        postData.Data = $scope.VideoModel;
        postData.Data.SiteID = $scope.VideoModel.SiteID;
        var jsonData = angular.toJson(postData);
        if ($scope.VideoForm.$valid) {
            $scope.DisableButtons = true;
            AngularAjaxCall($http,$scope.AddVideoURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    SetMessageForPageLoad(response.Message);
                    window.location.href = response.RedirectUrl;
                }else{
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    $scope.DisableButtons = false;
                }
            });
        }else{
            $timeout(function() {
                openErrorPortlets();
            });
        }

    }
    // Tag Validation.
    $(".ngTagsInput").focusout(function () {
    $scope.ShowTagsError = $scope.VideoForm.$submitted && $scope.VideoForm.$error.leftoverText != undefined && $scope.VideoForm.$error.leftoverText.length > 0;

    });

    // Load Tags.
    $scope.loadSiteTags = function($query) {
        return $scope.VideoModel.SiteTagsArray.filter(function(SiteTags) {
            return SiteTags.Tag.toLowerCase().indexOf($query.toLowerCase()) != -1;
        });

    };

    // Delete Video
    $scope.deleteVideo = function(data) {
        ShowConfirm("this Video?", function () {
            var postData = {};
            postData.Data = {};
            postData.Data.VideoID=data.VideoID;
            postData.Data.DevelopmentID=data.DevelopmentID;
            AngularAjaxCall($http,$scope.deleteVideoURL,angular.toJson(postData), 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    SetMessageForPageLoad(response.Message);
                    window.location.href = response.RedirectUrl;
                }else{
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }, 'Yes');
    }

    /* On Cancel button click redirect to userList page */
    $scope.Cancel = function(){
        window.location.href = $scope.RedirectURL.concat($scope.encryptedSiteID);
    }

    /* For Remove An Image */
    $scope.RemoveImage = function(data) {
        ShowConfirm("this Image?", function () {
            AngularAjaxCall($http, $scope.RemoveVideoImageURL, angular.toJson({ Data : {VideoID: $scope.VideoModel.VideoID,ThumbnailImageURL: $scope.VideoModel.ThumbnailImageURL} }), 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    $scope.VideoModel.UploadFilesArray = $scope.VideoModel.RealImagePath;
                    $scope.VideoModel.RealImagePath = response.Data;
                    $scope.VideoModel.IsImageRemoved = 1;
                    $scope.VideoModel.ThumbnailImageURL ='';
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        });
    };

    /* For Image Upload */
    $(document).ready(function() {
        $scope.requestCounter = 0;
        $scope.responseCounter = 0;
        var AwsSettingModel = $scope.VideoModel.Fileuploadsettings;
        $('.direct-upload').each(function() {
            var form = $(this);
            if((Window.ImageResitrictions[$scope.VideoModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.VideoModel.SiteID]['VideoImages']['Height'] != undefined){
                var AllowedFixHeight = Window.ImageResitrictions[$scope.VideoModel.SiteID]['VideoImages']['Height'];
                var FixWidthMessage= Window.ImageResitrictions[$scope.VideoModel.SiteID]['VideoImages']['WidthMessage'];
            }
            if((Window.ImageResitrictions[$scope.VideoModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.VideoModel.SiteID]['VideoImages']['Width'] != undefined){
                var AllowedFixWidth = Window.ImageResitrictions[$scope.VideoModel.SiteID]['VideoImages']['Width'];
                var FixHeightMessage= Window.ImageResitrictions[$scope.VideoModel.SiteID]['VideoImages']['HeightMessage'];
            }
            if(AllowedFixHeight != undefined && AllowedFixWidth != undefined) {
                var FixHeightWidthMessage = Window.ImageResitrictions[$scope.VideoModel.SiteID]['VideoImages']['HeightWidthMessage'];
            }
            if(AllowedFixHeight != undefined || AllowedFixWidth != undefined){
                var checkForMaxDimensionsRequired = true;
            }else{
                var checkForMaxDimensionsRequired = false;
            }
            var options ={
                successCallBack: function(new_filename){
                    AngularAjaxCall($http, $scope.GetVideoImageUrl,angular.toJson({ Data : {ThumbnailImageURL: new_filename,VideoID: 0} }) , 'POST', 'json', 'application/json').success(function (response) {
                        if(true) {
                            var realImagePath = $scope.AwsUploadBaseURL + new_filename;
                            $scope.VideoModel.ThumbnailImageURL = new_filename;
                            $scope.VideoModel.RealImagePath = realImagePath;
                            $scope.requestCounter = $scope.requestCounter - 1;
                            $('.file').removeAttr('disabled');
                            $("#ImageError").removeClass("ValidationError").text("");
                            $('.progress').hide();
                            $('.bar').css('width', '0');
                            $("#RemoveImage").show();
                            $('.loadingImage').css('display', 'block');
                            $('#actualImage').on('load', function () {
                            $('.loadingImage').css('display', 'none');
                            });
                        }
                    });

                },
                AWSBaseURL: $scope.AwsUploadBaseURL,
                AWSSettingsModel:AwsSettingModel,
                form:form,
                AllwoedExts:uploadphotoexts,
                AlertMessage:window.ImageFileAllowedMessage,
                ResizeRequired:false,
                getDimensions: true,
                checkForMaxDimensionsRequired: checkForMaxDimensionsRequired,
                AllowedFixHeight: AllowedFixHeight,
                AllowedFixWidth: AllowedFixWidth,
                FixWidthMessage: FixWidthMessage,
                FixHeightMessage:FixHeightMessage,
                FixHeightWidthMessage: FixHeightWidthMessage,
                progressCallback : function(){

                },
                addCallback : function(){
                    $scope.requestCounter = $scope.requestCounter + 1;
                }
            };
            Awsfileupload(options);
        });
        /*Amazon Upload End*/

    });
});







