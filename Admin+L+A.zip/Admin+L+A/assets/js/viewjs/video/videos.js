app.controller("VideoListController",function($scope,$http){
    $scope.SortOrderVideoURL = baseUrl+'/updatesortordervideo';
    $scope.deleteVideoURL = baseUrl+'/deletevideo'; // For URL
    $scope.VideoList = []; //Define a blank Array
    $scope.VideoModel = $.parseJSON($("#VideoModel").val());
    $scope.SiteID = $scope.VideoModel.SiteID;
    $scope.VideoModel.NoImagePath = window.NoImagePath;

    $scope.VideoListArray = $scope.VideoModel.VideoListArray;
    if ($scope.VideoListArray.length == 0) {
        $('#nodata').show();
    }else{
        $('#nodata').hide();
    }

    // Update SortOrder
    $scope.updateSortOrder = function(sourceIndex,newIndex)
    {
        var postData = {};
        postData.Data = {};
        postData.Data.OldOrder = sourceIndex;
        postData.Data.newOrder = newIndex;
        var jsonData = angular.toJson(postData);
        if((newIndex != undefined && sourceIndex != undefined ) && (newIndex !='' && newIndex != '' ) && ( sourceIndex != newIndex ) ) {
            AngularAjaxCall($http, $scope.SortOrderVideoURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
               if(response.IsSuccess){
                    ShowSuccessMessage(response.Message);
               }
            });
        }
    }

    // Delete Video
    $scope.deleteVideo = function(data) {
        ShowConfirm("this Video?", function () {
            var postData = {};
            postData.Data = {};
            postData.Data.VideoID=data.VideoID;
            postData.Data.DevelopmentID=data.DevelopmentID;
            AngularAjaxCall($http,$scope.deleteVideoURL,angular.toJson(postData), 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    SetMessageForPageLoad(response.Message);
                    window.location.href = response.RedirectUrl;
                }else{
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }, 'Yes');
    }
});

