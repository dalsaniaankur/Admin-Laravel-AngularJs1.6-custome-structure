app.controller("FaqListController",function($scope,$http){
    $scope.SortOrderFaqURL = baseUrl+'/updatesortorderfaq';
    $scope.deleteFaqURL = baseUrl+'/deletefaq'; // For URL
    $scope.FaqList = []; //Define a blank Array
    $scope.FaqModel = $.parseJSON($("#FaqModel").val());
    $scope.SiteID = $scope.FaqModel.SiteID;

    $scope.FaqListArray = $scope.FaqModel.FaqListArray;
    if ($scope.FaqListArray.length == 0) {
        $('#nodata').show();
    }else{
        $('#nodata').hide();
    }

    // Update SortOrder
    $scope.updateSortOrder = function(sourceIndex,newIndex)
    {
        var postData = {};
        postData.Data = {};
        postData.Data.OldOrder = sourceIndex;
        postData.Data.newOrder = newIndex;
        var jsonData = angular.toJson(postData);
        if((newIndex != undefined && sourceIndex != undefined ) && (newIndex !='' && newIndex != '' ) && ( sourceIndex != newIndex ) ) {
            AngularAjaxCall($http, $scope.SortOrderFaqURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
               if(response.IsSuccess){
                    ShowSuccessMessage(response.Message);
               }
            });
        }
    }

    // Delete Faq
    $scope.deleteFaq = function(data) {
        ShowConfirm("this FAQ?", function () {
            var postData = { Data: data.FAQID };
            AngularAjaxCall($http,$scope.deleteFaqURL,angular.toJson(postData), 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    SetMessageForPageLoad(response.Message);
                    window.location.href = response.RedirectUrl;
                }else{
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }, 'Yes');
    }

});

