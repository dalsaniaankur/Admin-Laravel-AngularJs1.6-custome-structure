app.controller('FaqController',function($scope,$http,$timeout) {
    $scope.AddFaqdURL = baseUrl+'/savefaq';
    $scope.deleteFaqURL = baseUrl+'/deletefaq';
    $scope.FaqModel = $.parseJSON($("#FaqModel").val());
    $scope.SiteID= $scope.FaqModel.SiteID;
    $scope.RedirectURL = baseUrl + '/faqlist/';
    $scope.encryptedSiteID = $scope.FaqModel.encryptedSiteID;
    $scope.TypeArray = $scope.FaqModel.TypeArray;
    $scope.FaqModel =  $scope.FaqModel.FAQDetails;
    $scope.DisableButtons = false;

    $scope.checkSave = function(yourForm) {
        checkValidationFocus(yourForm);
    };
    
    $scope.AddFaq = function() {
        if ($scope.FaqForm.$valid) {
            $scope.DisableButtons = true;
            var postData = {};
            postData.Data = $scope.FaqModel;
            postData.Data.SiteID = $scope.SiteID;
            var jsonData = angular.toJson(postData);
            AngularAjaxCall($http,$scope.AddFaqdURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    SetMessageForPageLoad(response.Message);
                    window.location.href = response.RedirectUrl;
                }else{
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    $scope.DisableButtons = false;
                }
            });
        }else{
            $timeout(function() {
                openErrorPortlets();
            });
        }
    }
    // Delete Faq
    $scope.deleteFaq = function(data) {
        ShowConfirm("this FAQ?", function () {
            var postData = { Data: data.FAQID };
            AngularAjaxCall($http,$scope.deleteFaqURL,angular.toJson(postData), 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    SetMessageForPageLoad(response.Message);
                    window.location.href = response.RedirectUrl;
                }else{
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }, 'Yes');
    }

    /* On Cancel button click redirect to userList page */
    $scope.Cancel = function(){
        window.location.href = $scope.RedirectURL.concat($scope.encryptedSiteID);
    }
});







