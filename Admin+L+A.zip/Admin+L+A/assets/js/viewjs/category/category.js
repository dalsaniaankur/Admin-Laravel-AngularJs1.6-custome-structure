app.controller("CategoryListController",function($scope,$http,$timeout){
    $scope.AddCategoryURL = baseUrl+'/savecategory';
    $scope.CategoryModel = $.parseJSON($("#CategoryModel").val());
    $scope.CategoryListURL = baseUrl+'/getcategorylist'; /*  URL For Category list */
    $scope.deleteCategoryURL = baseUrl+'/deletecategory'; /*  URL For Delete category */
    $scope.CategoryList = []; /* Define a blank Array */
    $scope.DisableButtons = false;
    $scope.ListPager = new PagerModule("Category"); /* create a variable Listpager and set sortIndex Category by default into PagerModule function */
    $scope.CategoryInfoList = function(){  /* Create a new CategoryInfoList function */
        var pagermodel = $scope.ListPager;
        var jsonData = angular.toJson({Data:pagermodel}); /* default data bind with pagermodel */
        AngularAjaxCall($http, $scope.CategoryListURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
            if (response.IsSuccess) {
                $scope.CategoryList = response.Data.Items;
                if ($scope.CategoryList.length == 0) {
                    $('#nodata').show();
                }else{
                    $('#nodata').hide();
                }
                $scope.ListPager.totalRecords = response.Data.TotalItems;  /* bind total records into ListPager.totalRecords */
            }
        });
    };

    $scope.ListPager.getDataCallback = $scope.CategoryInfoList; /* call function CategoryInfoList  */
    $scope.ListPager.getDataCallback(); /* call getDataCallback function */


    /* Add Category */
    $scope.AddCategory = function() {
        if ($scope.CategoryForm.$valid) {
            $scope.DisableButtons = true;
            var postData = {};
            postData.Data = {
                CategoryModel: $scope.CategoryModel.TestDetails,
                PagerModel: $scope.ListPager
            };
            var jsonData = angular.toJson(postData);
            AngularAjaxCall($http,$scope.AddCategoryURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    $scope.CategoryList = response.Data;
                    $scope.ListPager.totalRecords = response.TotalItems;
                    $scope.CategoryForm.$submitted = false;
                    $scope.CategoryModel.TestDetails = angular.copy($scope.CategoryModel.DefaultTestDetails);
                    ShowSuccessMessage(response.Message);
                    $scope.DisableButtons = false;
                }else{
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    $scope.DisableButtons = false;
                }
            });
        }else{
            $timeout(function() {
                openErrorPortlets();
            });
        }
    }

    /* Delete Category */
    $scope.deleteCategory = function(data) {
        ShowConfirm("this Category?", function () {
            var postData = {};
            postData.Data = { CategoryID: data.CategoryID, PagerModel: $scope.ListPager };
            AngularAjaxCall($http,$scope.deleteCategoryURL,angular.toJson(postData), 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    $scope.CategoryList = response.Data;
                    $scope.ListPager.totalRecords = response.TotalItems;
                    $scope.CategoryModel.TestDetails = angular.copy($scope.CategoryModel.DefaultTestDetails);
                    $('#Category').focus();
                    ShowSuccessMessage(response.Message);
                }else{
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }, 'Yes');
    }

    /* Category cancel button  */
    $scope.CancelCategory = function(){
        $scope.CategoryModel.TestDetails = angular.copy($scope.CategoryModel.DefaultTestDetails);
        $scope.CategoryForm.$submitted = false;
        $('#Category').focus();
    }

    /* For Edit Category Link set */
    $scope.EditCategory = function(Data) {
        $scope.CategoryModel.TestDetails = angular.copy(Data);
        $('#Category').focus();
    }

});

app.controller("TagListController",function($scope,$http,$timeout){

    $scope.AddTagURL = baseUrl+'/savetag'; /* URL For save tag. */
    $scope.TagModel = $.parseJSON($("#TagModel").val());
    $scope.TagListURL = baseUrl+'/gettaglist'; /*  URL For Tag list. */
    $scope.deleteTagURL = baseUrl+'/deletetag'; /*  URL For Tag category. */
    $scope.TagList = []; /* Define a blank Array. */
    $scope.DisableButtons = false;
    $scope.TagListPager = new PagerModule("Tag"); /* create a variable TagListPager and set sortIndex Tag by default into PagerModule function */

    $scope.TagInfoList = function(){  /* Create a new TagInfoList function */
        var pagermodel = $scope.TagListPager;
        var jsonData = angular.toJson({Data:pagermodel}); /* default data bind with pagerModel */
        AngularAjaxCall($http, $scope.TagListURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
            if (response.IsSuccess) {
                $scope.TagList = response.Data.Items;
                if ($scope.TagList.length == 0) {
                    $('#TagNoData').show();
                }else{
                    $('#TagNoData').hide();
                }
                $scope.TagListPager.totalRecords = response.Data.TotalItems;  /* bind total records into ListPager.totalRecords */
            }
        });
    };

    $scope.TagListPager.getDataCallback = $scope.TagInfoList; /* call function TagInfoList  */
    $scope.TagListPager.getDataCallback();  /* call getDataCallback function */

    /* For Edit Tag Link set */
    $scope.EditTag = function(Data) {
        $scope.TagModel.TestDetails = angular.copy(Data);
        $('#Tag').focus();
    }

    /* Add Tag */
    $scope.AddTag = function() {
        if ($scope.TagForm.$valid) {
            $scope.DisableButtons = true;
            var postData = {};
            postData.Data = {
                TagModel: $scope.TagModel.TestDetails,
                PagerModel: $scope.TagListPager
            };
            var jsonData = angular.toJson(postData);
            AngularAjaxCall($http,$scope.AddTagURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    $scope.TagList = response.Data;
                    $scope.TagListPager.totalRecords = response.TotalItems;
                    $scope.TagForm.$submitted = false;
                    $scope.TagModel.TestDetails = angular.copy($scope.TagModel.DefaultTestDetails);
                    ShowSuccessMessage(response.Message);
                    $scope.DisableButtons = false;
                }else{
                    $scope.DisableButtons = false;
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }else{
            $timeout(function() {
                openErrorPortlets();
            });
        }
    }

    /* Delete Tag */
    $scope.deleteTag = function(data) {
        ShowConfirm("this Tag?", function () {
            var postData = {};
            postData.Data = { TagID: data.TagID, PagerModel: $scope.TagListPager };
            AngularAjaxCall($http,$scope.deleteTagURL,angular.toJson(postData), 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    $scope.TagList = response.Data;
                    $scope.TagListPager.totalRecords = response.TotalItems;
                    if ($scope.TagList.length == 0) {
                        $('#TagNoData').show();
                    }else{
                        $('#TagNoData').hide();
                    }
                    $scope.TagModel.TestDetails = angular.copy($scope.TagModel.DefaultTestDetails);
                    $('#Tag').focus();
                    ShowSuccessMessage(response.Message);
                }else{
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }, 'Yes');
    }

    /* Tag cancel button  */
    $scope.CancelTag = function(){
        $scope.TagModel.TestDetails = angular.copy($scope.TagModel.DefaultTestDetails);
        $scope.TagForm.$submitted = false;
        $('#Tag').focus();
    }
});
