﻿var DefaultCookieName = "DefaultMessage";
var serverError = "Oops! Something went wrong on server, suspected error would be ";
var error_message_header='Oops! Something went wrong';
var uploadphotoexts = ["jpg", "jpeg", "png", "gif", "JPG", "JPEG", "GIF", "PNG"];
var uploadvideoogexts = ["ogv"];
var uploadvideoMp4exts = ["mp4"];
var uploadvideoWebmexts = ["webm"];
var defaultMaxFileErrorMessage = "Uploaded file size exceeds the allowable limit";

/* Dev_RB Start*/
function AngularAjaxCall($angularHttpObject, url, postData, httpMethod, callDataType, contentType) {
    if (contentType == undefined)
        contentType = "application/x-www-form-urlencoded;charset=UTF-8";

    if (callDataType == undefined)
        callDataType = "json";

    return $angularHttpObject({
        method: httpMethod,
        responseType: callDataType,
        url: url,
        data: postData,
        crossDomain: true,
        headers: {'Content-Type': contentType}}).error(function(data, status) {
        if (status == 403) {
            if (data != null && data.Type == "NotAuthorized" && data.Link != undefined)
                window.location = window.baseUrl + data.Link;
            else
                window.location = window.baseUrl;
        }
        if (!userAborted(xhr)) {
                if (status == 403) {
                    if (data != null && data.Type == "NotAuthorized" && data.Link != undefined)
                        window.location = window.baseUrl + data.Link;
                    else
                        window.location = window.baseUrl;
                }
                else {
                    var alertText = "";
                    switch (status) {
                        case 404:
                            alertText = serverError + "'Method Not Found'";
                            break;

                        case 200:
                            break;

                        default :
                            alertText = serverError + "'" + data + "'";
                            break;
                    }
                    alert(alertText);
                    OnError(alertText, "", "", "");

                }
            }
        });

}

function OnError(message, file, line, error) {

    var apiUrl = baseUrl+'/javascripterror';
    if(line == undefined || line ==  ""){
        line = "";
    }
    if(file == undefined || file ==  ""){
        file = "";
    }
    if(error == undefined || error ==  ""){
        error = "";
    }
    else{
        error = error.stack;
    }
    //suppress browser error messages
    var suppressErrors = true;
    $.ajax({
        url: apiUrl,
        type: 'POST',
        data: {
            errorMsg: message,
            errorLine: line,
            queryString: file,
            url: document.location.pathname,
            referrer: document.referrer,
            stack: error,
            userAgent: navigator.userAgent
        }
    });

    return suppressErrors;
}

window.onerror = function(message, file, line,error) {
    OnError(message, file, line, error);
};



function ShowAlertMessage(message, type, header) {
    var classname;
    if (!header) {
        header = '';
    }

    switch (type) {
        case 'alert':
            classname = 'warning';
            break;
        case 'info':
            classname = 'info';
            break;
        case 'error':
            classname = 'error';
            break;
        default:
            classname = 'warning';
            type = 'alert';
            break;
    }

    BootstrapDialog.show({
        title: header,
        message: message,
        buttons: [{
            label: 'Close',
            cssClass: 'btn btn-danger',
            action: function(dialogItself){
                dialogItself.close();
            }
        }]
    });
}


function SetMessageForPageLoad(data, cookieName,days) {
    if (cookieName == undefined) {
        cookieName = DefaultCookieName;
    }
    if (days)
        $.cookie(cookieName, JSON.stringify(data), { expires: days, path: '/' });
    else
        $.cookie(cookieName, JSON.stringify(data), { path: '/' });
}

$(document).ready(function () {
    var attr = $('.page-content').attr('auto-input-focus-off');
    if(attr == undefined || attr == false)
        $('.page-content input:not([disabled]):not([type="submit"]):not([type="button"]):first').focus();
    ShowPageLoadMessage();
});

function ShowPageLoadMessage(cookieName) {
    if (cookieName == undefined) {
        cookieName = DefaultCookieName;
    }
    if ($.cookie(cookieName) != null && $.cookie(cookieName) != "null") {
        ShowSuccessMessage($.cookie(cookieName),'success','Success');
        $.cookie(cookieName, null, { path: '/' });
    }
}

function ShowSuccessMessage(message, type){
    $.msgGrowl({
        type : type ? type : "Success",
        text : message,
        position: 'top-center',
        lifetime: 5000
    });
}

function ShowConfirm(message, callback, successButtonText, cancelButtonText) {
    var success = "Yes";
    var cancel = "No";
    if (successButtonText != null)
        success = successButtonText;
    if (cancelButtonText != null)
        cancel = cancelButtonText;

    new BootstrapDialog({

        title: window.ConfirmDialogTitle,
        message: window.Confirmdialogmessage + message,
        closable: true,
        data: {
            'callback': callback
        },

        buttons: [{
            label: success,
            cssClass: 'btn btn-danger',
            action: function (dialogItself) {
                dialogItself.close();
                typeof dialogItself.getData('callback') === 'function' && dialogItself.getData('callback')(false);
            }
        },
            {
                label: cancel,
                cssClass: 'btn btn-grey',
                action: function (dialogItself) {
                    dialogItself.close();
                }
            }]

    }).open();
}

function CopyProperties(theSource,theTarget) {
    for (var propertyName in theTarget)
        //theTarget[propertyName] && (theTarget[propertyName] = theSource[propertyName]);
        theTarget[propertyName] = theSource[propertyName];
}


/* For AWS */
function generateUUID(id){
    var enc_id = id;
    $.cookie("enc_userid", enc_id);
    var d = new Date();
    var milliseconds=d.getMilliseconds();

    var userid = $.cookie('enc_userid');
    var str = milliseconds+userid;
    var hex_chr = "0123456789abcdef";
    hash='';
    for(j = 0; j < str.length; j++)
        hash += hex_chr.charAt((str >> (j * 8 + 4)) & 0x0F) +
        hex_chr.charAt((str >> (j * 8)) & 0x0F);
    var seconds=d.getSeconds();
    if (seconds < 10) { seconds = '0' + seconds; }
    var minutes=d.getMinutes();
    if (minutes < 10) { minutes = '0' + minutes; }
    var hours=d.getHours();
    if (hours < 10) { hours = '0' + hours; }
    var day=d.getDate();
    if (day < 10) { day = '0' + day; }
    var month=d.getMonth()+1;
    if (month < 10) { month = '0' + month; }
    var year=d.getFullYear();
    var uuid = ""+hash+""+"-"+""+seconds+""+minutes+""+hours+""+"-"+""+month+""+day+""+year+"";
    return uuid;
}

function generateUUID3(val){
    //enc_id = val;
    return generateUUID(val);
}

var SearchArrayByPropertyValue = function(obj, value) {

    var returnKey = -1;
    $.each(obj, function (key, info) {
        if (info.FilePath == value) {
            returnKey = key;
            return false;
        }
    });
    return returnKey;
};

var SearchArrayByPropertyValueImage = function(obj, value) {

    var returnKey = -1;
    $.each(obj, function (key, info) {
        if (info.ImagePath == value) {
            returnKey = key;
            return false;
        }
    });
    return returnKey;
};

function resize(file, max_width, max_height,  imageEncoding){
    var fileLoader = new FileReader(),
        canvas = document.createElement('canvas'),
        context = null,
        imageObj = new Image(),
        blob = null;
    canvas.id     = "hiddenCanvas";
    canvas.width  = max_width;
    canvas.height = max_height;
    canvas.style.visibility   = "hidden";
    document.body.appendChild(canvas);
    context = canvas.getContext('2d');

    if (file.type.match('image.*')) {
        fileLoader.readAsDataURL(file);
    } else {
        alert('File is not an image');
    }

    fileLoader.onload = function() {
        var data = this.result;
        imageObj.src = data;
    };

    fileLoader.onabort = function() {
        alert("The upload was aborted.");
    };

    fileLoader.onerror = function() {
        alert("An error occured while reading the file.");
    };
    imageObj.onload = function() {
        if(this.width == 0 || this.height == 0){
            alert('Image is empty');
        } else {
            context.clearRect(0,0,max_width,max_height);
            context.drawImage(imageObj, 0, 0, this.width, this.height, 0, 0, max_width, max_height);
            blob = dataURItoBlob(canvas.toDataURL(imageEncoding));
            upload(blob);
        }
    };
    imageObj.onabort = function() {
        alert("Image load was aborted.");
    };
    imageObj.onerror = function() {
        alert("An error occured while loading image.");
    };
}

function SingleImageUploadCommon(data, AWSSettingsModel, newFileObj, getDimensions, ext, parentDiv, ResizeRequired,uploadedImageWidth, uploadedImageHeight) {
    var options = {
        file: data.files[0],
        callback: function (canvasfile, width, height) {
            var name = generateUUID3(AWSSettingsModel.enc_userid);
            newFileObj.new_filename = (canvasfile.name);
            newFileObj.new_fileWidth = width;
            newFileObj.new_fileHeight = height;
            if (getDimensions && (width == undefined || height == undefined)) {
                img = new Image();
                img.onload = function () {
                    newFileObj.new_fileWidth = img.width;
                    newFileObj.new_fileHeight = img.height;
                };
                var _URL = window.URL || window.webkitURL;
                img.src = _URL.createObjectURL(canvasfile);
            }
            if (AWSSettingsModel.folder)
                newFileObj.new_filename = AWSSettingsModel.folder + "/" + name + "." + ext;
            $(parentDiv).find('.progress').show();
            $(parentDiv).find('#key').val(newFileObj.new_filename);
            data.files[0] = canvasfile;
            data.submit();
        }
    };
    if (ResizeRequired) {
        ResizeFile(options);
    } else {
        options.callback(data.files[0],uploadedImageWidth, uploadedImageHeight);
    }
}

function Awsfileupload(options){

    var form = options.form;
    var newFileObj = {};
    var tempname;
    var AWSSettingsModel = options.AWSSettingsModel;
    var AllowedExts =options.AllwoedExts;
    var AlertMessage  =options.AlertMessage;
    var ResizeRequired  =options.ResizeRequired;
    var AWSBaseURL = options.AWSBaseURL;
    var parentDiv =  $(form).parents('.fileinput');
    var maxFileSize = options.maxFileSizeLimit;
    var maxFileSizeErrorMessage = options.maxFileSizeErrorMessage;
    var getDimensions = options.getDimensions;
    var checkForMaxDimensionsRequired = options.checkForMaxDimensionsRequired;
    var maxAllowedHeight = options.maxAllowedHeight;
    var maxAllowedWidth = options.maxAllowedWidth;
    var maxWidthMessage = options.maxWidthMessage;
    var maxHeightMessage = options.maxHeightMessage;
    var maxHeightWidthMessage = options.maxHeightWidthMessage;
    var AllowedFixHeight = options.AllowedFixHeight;
    var AllowedFixWidth = options.AllowedFixWidth;
    var FixWidthMessage = options.FixWidthMessage;
    var FixHeightMessage = options.FixHeightMessage;
    var FixHeightWidthMessage = options.FixHeightWidthMessage;
    var submitButtonClassOrId = options.submitButtonClassOrId != undefined ? options.submitButtonClassOrId :  "#btn-submit,.btn-submit";

    form.fileupload({
        url: AWSBaseURL,
        maxFileSizeLimit: maxFileSize,
        type: 'POST',
        datatype: 'xml',
        add: function (event, data) {
            tempname = data.originalFiles[0].name;
            var filename = data.originalFiles[0].name.split(".");
            var ext = filename[filename.length - 1];
            var fileSize = data.originalFiles[0].size;
            if(AllowedExts.indexOf(ext) >= 0 && (maxFileSize == undefined || fileSize <= maxFileSize ))
            {
                $(submitButtonClassOrId).attr('disabled','disabled');
                $("#cancel").attr('disabled','disabled');
                $(parentDiv).find('#file').attr('disabled', 'disabled');
                $(parentDiv).find('.bar').removeClass('bg-red');
                $(parentDiv).find('.progress').removeClass('bg-red');
                $(parentDiv).find('.bar').css('width', '0%');

                if(checkForMaxDimensionsRequired == true)
                {
                    img = new Image();
                    img.onload = function () {
                        var status = 0;
                        if(maxAllowedWidth != undefined && img.width > maxAllowedWidth)
                            status = 1;
                        if(maxAllowedHeight != undefined && img.height > maxAllowedHeight)
                            status = status == 0 ? 2 : 3;
                        if(AllowedFixHeight != undefined && (img.height != AllowedFixHeight) && (AllowedFixHeight != '') && (AllowedFixHeight != 0))
                            status = 4;
                        if(AllowedFixWidth != undefined && (img.width != AllowedFixWidth) && (AllowedFixWidth != '') && (AllowedFixWidth != 0))
                            status = status == 0 ? 5 : 6;
                        if(status == 0) {
                            SingleImageUploadCommon(data, AWSSettingsModel, newFileObj, getDimensions, ext, parentDiv, ResizeRequired, img.width, img.height);
                            if(options.addCallback != undefined)
                                options.addCallback();
                        }else {
                            switch (status) {
                                case 1:
                                    ShowAlertMessage(maxWidthMessage,'error',error_message_header);
                                    break;
                                case 2:
                                    ShowAlertMessage(maxHeightMessage,'error',error_message_header);
                                    break;
                                case 3:
                                    ShowAlertMessage(maxHeightWidthMessage,'error',error_message_header);
                                    break;
                                case 4:
                                    ShowAlertMessage(FixHeightMessage,'error',error_message_header);
                                    break;
                                case 5:
                                    ShowAlertMessage(FixWidthMessage,'error',error_message_header);
                                    break;
                                case 6:
                                    ShowAlertMessage(FixHeightWidthMessage,'error',error_message_header);
                                    break;
                            }
                            $(submitButtonClassOrId).removeAttr('disabled');
                            $("#cancel").removeAttr('disabled');
                            $(parentDiv).find('#file').removeAttr('disabled');
                        }
                    };
                    var _URL = window.URL || window.webkitURL;
                    img.src = _URL.createObjectURL(data.files[0]);
                }
                else {
                    SingleImageUploadCommon(data, AWSSettingsModel, newFileObj, getDimensions, ext, parentDiv, ResizeRequired);
                    if(options.addCallback != undefined)
                        options.addCallback();
                }

            }
            else {
                if(AllowedExts.indexOf(ext) < 0){
                    ShowAlertMessage(AlertMessage,'error',error_message_header);
                }else{
                    ShowAlertMessage(maxFileSizeErrorMessage != undefined ? maxFileSizeErrorMessage : defaultMaxFileErrorMessage,'error',error_message_header);
                }
                if(options.multiple != true || options.multiple == undefined){
                    $(submitButtonClassOrId).removeAttr('disabled');
                    $("#cancel").removeAttr('disabled');
                }
                //$(submitButtonClassOrId).removeAttr('disabled');
                //$("#cancel").removeAttr('disabled');
                $(parentDiv).find('#file').removeAttr('disabled');
            }

        },
        progress: function(e, data){
            if(options.progressCallback !=undefined){
                options.progressCallback();
            }

            // model.EnableAddButton(false);
            //$scope.UserModel.EnableSubmitButton = 0;
            var percent = Math.round((data.loaded / data.total) * 100);
            $(parentDiv).find('.bar').css('width', percent + '%');
        },
        fail: function(e, data) {
            $(parentDiv).find('.bar').css('width', '100%').addClass('bg-red');
            $(parentDiv).find('.progress').addClass('bg-red');
            $(parentDiv).find('#file').removeAttr('disabled');
            if(options.multiple != true || options.multiple == undefined){
                $(submitButtonClassOrId).removeAttr('disabled');
                $("#cancel").removeAttr('disabled');
            }
            //$(submitButtonClassOrId).removeAttr('disabled');
            //$(".cancel").removeAttr('disabled');
        },
        done: function (event, data) {
            /* Change Disable to Enable buutton (Save & Cancel) */
            if(submitButtonClassOrId != undefined){ $(submitButtonClassOrId).removeAttr('disabled');}
            window.onbeforeunload = null;
            options.successCallBack(newFileObj.new_filename,tempname,newFileObj.new_fileWidth, newFileObj.new_fileHeight);
        }
    });
}


function blobToFile(theBlob, fileName,previewElement,previewTemplate) {
    theBlob.lastModifiedDate = new Date();
    theBlob.name = fileName;
    theBlob.previewElement=previewElement;
    theBlob.previewTemplate=previewTemplate;
    return theBlob;
}

function CheckSizeBeforeResizing(resizeFile, width, height, iteration, callback) {
    var maxHeight = 600;
    var maxWidth = 600;
    var maxIteration = 3;
    var proposedHeight = (height / 2);
    var proposedWidth = (width / 2);

    if(proposedHeight < parseInt(maxHeight) &&  proposedWidth >= parseInt(maxWidth))
        proposedHeight = parseInt(maxHeight);
    else if(height> maxHeight)
        proposedHeight =maxHeight;

    if(proposedWidth < parseInt(maxWidth) && proposedHeight >= parseInt(maxHeight))
        proposedWidth = parseInt(maxWidth);
    else if(width > maxHeight)
        proposedWidth =maxWidth;

    if (iteration < maxIteration && proposedHeight >= maxHeight && proposedWidth >= maxWidth) {
        canvasResize(resizeFile, {
            width: proposedWidth,
            height: proposedHeight,
            crop: false,
            quality: 100,
            rotate: 0,
            callback: function (data,previewElement,previewTemplate, width, height) {
                iteration++;
                var newfile = blobToFile(canvasResize('dataURLtoBlob', data,previewElement,previewTemplate), resizeFile.name,resizeFile.previewElement,resizeFile.previewTemplate);
                var options =
                {
                    file: newfile,
                    width: width,
                    height: height,
                    iteration: iteration,
                    callback: callback
                }
                ResizeFile(options);
            }
        });
    }
    else {
        callback(resizeFile,width,height);
    }
}

function ResizeFile(options) {
    var iteration = options.iteration == undefined ? 0 : options.iteration;
    if (options.width == undefined && options.height == undefined) {
        img = new Image();
        img.onload = function () {
            CheckSizeBeforeResizing(options.file, img.width, img.height, iteration, options.callback)
        };
        var _URL = window.URL || window.webkitURL;
        img.src = _URL.createObjectURL(options.file);
    }
    else {
        CheckSizeBeforeResizing(options.file, options.width, options.height, iteration, options.callback);
    }
}
window.ConfirmUploadMessage = "Do you want to save the uploaded files?";

/* Dev_RB End */

var PagerModule = function (sortIndex, sortDirection) {
    var $scope = this;
    $scope.getDataCallback = function () {
        alert(window.NotImplementedGetDataCallbackFunction);
    };
    $scope.currentPage = 1;
    $scope.pageSize = window.PageSize ? window.PageSize : 10;
    $scope.totalRecords = 0;
    $scope.sortIndex = sortIndex;
    $scope.sortDirection = sortDirection ? sortDirection : "ASC";
    $scope.pageChanged = function (newPage) {
        $scope.currentPage = newPage;
        $scope.getDataCallback();
    };

    $scope.TotalPages = function() {
        return parseInt($scope.totalRecords / $scope.pageSize) + 1;
    };

    //-----------------------------------------CODE FOR SORT-------------------------------------------
    //$scope.predicate = predicate; // coulumn name

    $scope.reverse = $scope.sortDirection != "ASC"; // false; // asc and desc
    $scope.sortColumn = function (newPredicate) {
        $scope.reverse = ($scope.sortIndex === newPredicate) ? !$scope.reverse : false;
        $scope.predicate = newPredicate;
        $scope.sortIndex = newPredicate != undefined ? newPredicate : sortIndex;
        $scope.sortDirection = $scope.reverse === true ? "DESC" : "ASC";
        $scope.getDataCallback();
    }


    //-----------------------------------------End CODE FOR SORT-------------------------------------------
};


/* Start Dev_DN */

var History = window.History, State;

var backButtonClicked = true;

function SetHistoryData(url, param, title) {
    backButtonClicked = false;
    var querystring = "?q=" + Math.floor((Math.random() * 10000000) + 1);
    var newURL = url + querystring;
    if (url.indexOf('?q') > -1)
        window.History.pushState({ state: newURL, param: param }, title, querystring);
    else
        window.History.replaceState({ state: newURL, param: param }, title, newURL);
}

window.userInteractionInHTMLArea = false;
window.onBrowserHistoryButtonClicked = null;

if (window.history && window.history.pushState) {
    $(window).on('statechange', function () {
        if (!window.userInteractionInHTMLArea) {
            if (backButtonClicked) {
                SetParamData();
            }
            backButtonClicked = true;
            if (window.onBrowserHistoryButtonClicked) {
                window.onBrowserHistoryButtonClicked();
            }
        }
    });
}

function SetParamData() {

    var state = window.History.getState();
    var statedata = state.data;
    var callBackButtonClick = false;
    var horseCallBackButtonClick = false;

    if (statedata != null && statedata.param != null && statedata.param.searchedCriteria != null && statedata.param.searchModel != null && statedata.param.setCriteria != null) {
        var searchModel = eval(statedata.param.searchModel);
        var setCriteria = eval(statedata.param.setCriteria);
        var setCri;
        if (setCriteria != null && searchModel != null) {
            setCri = window[statedata.param.setCriteria];
            if (setCri != undefined) {
                setCri(statedata.param.searchedCriteria, statedata.param.pager != null ? statedata.param.pager : undefined);
                callBackButtonClick = true;
            }

        }
    }
    if (statedata != null && statedata.param != null && statedata.param.pager != null) {

        callBackButtonClick = true;
        angular.extend(statedata.param.pager,{},'');
        //  ko.mapping.fromJS(statedata.param.pager, {}, model.pager);
    }

    if (statedata != null && statedata.param != null && statedata.param.horsePager != null) {

        horseCallBackButtonClick = true;
        angular.extend(statedata.param.p)
        //ko.mapping.fromJS(statedata.param.horsePager, {}, model.horsePager);
    }
    if (callBackButtonClick)
        backButtonClicked;

    if (horseCallBackButtonClick)
        horseCallBackButtonClick;

}
function openErrorPortlets()
{
    var errorPortlets = $(".has-error").parents(".portlet");
    $.each(errorPortlets, function() {
        var link = $(this).find(".tools a");
        var el = $(link).closest(".portlet").children(".portlet-body");
        if ($(link).hasClass("expand")) {
            $(link).removeClass("expand").addClass("collapse");
            el.slideDown(200);
        }
    });
}

/* End Dev_DN */

/* Start Dev_Umesh */
function checkValidationFocus(form){
    if (!form.$valid) {
        if(angular.element("[name='" + form.$name + "']").find('.ng-invalid:first')[0].tagName == "TEXTAREA")
        {
            //angular.element("[name='" + form.$name + "']").find('.ng-invalid:first').focus();

            $('html, body').animate({
                scrollTop: angular.element("[name='" + form.$name + "']").find('.ng-invalid:first').prev().offset().top-250
            },1000);
            return false;
        }
        else
        {
            /*angular.element("[name='" + form.$name + "']").find('.ng-invalid:visible:first').focus();
            return false;*/
             $('html, body').animate({
                scrollTop: angular.element("[name='" + form.$name + "']").find('.ng-invalid:first').offset().top-250
           },1000).focus();
        }
        angular.element("[name='" + form.$name + "']").find('.ng-invalid:visible:first').focus();
        return false;
    }
}
/* End Dev_Umesh */


Window.ImageResitrictions = {
    1: {
        Profile:{ Height: 1050,
            Width: 700,
            HeightMessage: "Profile images height should be 1015px.",
            WidthMessage: "Images width should be 700px.",
            HeightWidthMessage: "Images width should be 700px & height should be 1015px."},

        Smaller:{ Height: 440,
            Width: 700,
            HeightMessage: "Images height should be 440px.",
            WidthMessage: "Images width should be 700px.",
            HeightWidthMessage: "Images width should be 700px & height should be 440px."},

        DevelopmentTopImages:{
            Height: 801,
            Width: 1700,
            HeightMessage: "Images height should be 1700px.",
            WidthMessage: "Images width should be 801px.",
            HeightWidthMessage: "Images width should be 1700px & height should be 801px."},

        BlogFeatureImages:{
            Height: 570,
            Width: 1660,
            HeightMessage: "Images height should be 570px.",
            WidthMessage: "Images width should be 1660px.",
            HeightWidthMessage: "Images width should be 1660px & height should be 570px."},
        VideoImages:{
            Height: 760,
            Width: 1660,
            HeightMessage: "Images height should be 760px.",
            WidthMessage: "Images width should be 1660px.",
            HeightWidthMessage: "Images width should be 1660px & height should be 760px."},

        HomePageVideoImages:{
            Height: 679,
            Width: 1660,
            HeightMessage: "Images height should be 679px.",
            WidthMessage: "Images width should be 1660px.",
            HeightWidthMessage: "Images width should be 1660px & height should be 679px."},

        HomePageStoryImages:{
            Height: 1002,
            Width: 1700,
            HeightMessage: "Images height should be 1002px.",
            WidthMessage: "Images width should be 1700px.",
            HeightWidthMessage: "Images width should be 1700px & height should be 1002px."}
    },


    2:{
        Smaller:{ Height: 280,
            Width: 210,
            HeightMessage: "Images height should be 280px.",
            WidthMessage: "Images width should be 210px.",
            HeightWidthMessage: "Images width should be 210px & height should be 280px."},
        PagesTopImage:{
            Height: 490,
            Width: 1664,
            HeightMessage: "Images height should be 490px.",
            WidthMessage: "Images width should be 1664px.",
            HeightWidthMessage: "Images width should be 1664px & height should be 490px."},
        BlogFeatureImages:{
            Height: 450,
            Width: 1300,
            HeightMessage: "Images height should be 450px.",
            WidthMessage: "Images width should be 1300px.",
            HeightWidthMessage: "Images width should be 1300px & height should be 450px."},

        HomeTopCTAImages:{
            Height: 481,
            Width: 700,
            HeightMessage: "Images height should be 481px.",
            WidthMessage: "Images width should be 700px.",
            HeightWidthMessage: "Images width should be 700px & height should be 481px."},

        HomeBottomCTAImages:{
            Height: 405,
            Width: 457,
            HeightMessage: "Images height should be 405px.",
            WidthMessage: "Images width should be 457px.",
            HeightWidthMessage: "Images width should be 457px & height should be 405px."},

        COHomePageSliderImage:{
            Height: 750,
            Width: 1664,
            HeightMessage: "Images height should be 750px.",
            WidthMessage: "Images width should be 1664px.",
            HeightWidthMessage: "Images width should be 1664px & height should be 750px."},

        HomeVideoPoster:{
            Height: 964,
            Width: 1664,
            HeightMessage: "Images height should be 964px.",
            WidthMessage: "Images width should be 1664px.",
            HeightWidthMessage: "Images width should be 1664px & height should be 964px."}
        },
    3:{
        
        PagesTopImage:{
            Height: 490,
            Width: 1664,
            HeightMessage: "Images height should be 490px.",
            WidthMessage: "Images width should be 1664px.",
            HeightWidthMessage: "Images width should be 1664px & height should be 490px."},
        
        
        PagesBottomRightImage:{
            Height: 522,
            Width: 662,
            HeightMessage: "Images height should be 522px.",
            WidthMessage: "Images width should be 662px.",
            HeightWidthMessage: "Images width should be 662px & height should be 522px."},
        BlogFeatureImages:{
            Height: 371,
            Width: 945,
            HeightMessage: "Images height should be 371px.",
            WidthMessage: "Images width should be 945px.",
            HeightWidthMessage: "Images width should be 945px & height should be 371px."},

        HomeTopCTAImages:{
            Height: 80,
            Width: 80,
            HeightMessage: "Images height should be 80px.",
            WidthMessage: "Images width should be 80px.",
            HeightWidthMessage: "Images width should be 80px & height should be 80px."},

        HomeBottomCTAImages:{
            Height: 145,
            Width: 144,
            HeightMessage: "Images height should be 145px.",
            WidthMessage: "Images width should be 144px.",
            HeightWidthMessage: "Images width should be 144px & height should be 145px."},

        HomeSliderImages:{
            Height: 772,
            Width: 1600,
            HeightMessage: "Images height should be 772px.",
            WidthMessage: "Images width should be 1600.",
            HeightWidthMessage: "Images width should be 1600px & height should be 772px."}
        },



    4:{
        BlogFeatureImages:{
            Height: 368,
            Width: 905,
            HeightMessage: "Images height should be 368px.",
            WidthMessage: "Images width should be 905px.",
            HeightWidthMessage: "Images width should be 905px & height should be 368px."},

        HomePageBlock1Image:{
            Height: 246,
            Width: 683,
            HeightMessage: "Images height should be 246px.",
            WidthMessage: "Images width should be 683px.",
            HeightWidthMessage: "Images width should be 683px & height should be 246px."},

        HomePageBlock2Image:{
            Height: 246,
            Width: 322,
            HeightMessage: "Images height should be 246px.",
            WidthMessage: "Images width should be 322px.",
            HeightWidthMessage: "Images width should be 322px & height should be 246px."},

        HomePageBlock3Image:{
            Height: 246,
            Width: 322,
            HeightMessage: "Images height should be 246px.",
            WidthMessage: "Images width should be 322px.",
            HeightWidthMessage: "Images width should be 322px & height should be 246px."},

        HomePageSliderImage:{
            Height: 567,
            Width: 1367,
            HeightMessage: "Images height should be 567px.",
            WidthMessage: "Images width should be 1367px.",
            HeightWidthMessage: "Images width should be 1367px & height should be 567px."},

        PagesTopImage:{
            Height: 251,
            Width: 1325,
            HeightMessage: "Images height should be 251px.",
            WidthMessage: "Images width should be 1325px.",
            HeightWidthMessage: "Images width should be 1325px & height should be 251px."}
    }

}
