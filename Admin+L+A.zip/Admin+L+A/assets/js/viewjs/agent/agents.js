app.controller("AgentListController", function ($scope, $http) {
    $scope.AgentListURL = baseUrl + '/getagentlist';
    $scope.EditAgentURL = baseUrl + '/addagent/';
    $scope.DisableAgentURL = baseUrl + '/disableagent';
    $scope.EnableAgentURL = baseUrl + '/enableagent';

    $scope.AgentList = [];
    $scope.ListModel = $.parseJSON($("#ListModel").val());


    $scope.ListPager = new PagerModule('AgentName');

    $scope.AgentInfoList = function (setHistoryData) {
        if (setHistoryData == undefined)
            setHistoryData = true;

        var pagermodel = {
            SearchParams: $scope.ListModel.backSearchModel,
            PageSize: $scope.ListPager.pageSize,
            PageIndex: $scope.ListPager.currentPage,
            SortIndex: $scope.ListPager.sortIndex,
            SortDirection: $scope.ListPager.sortDirection
        };
        var postData = {};
        postData.Data = $scope.AgentList;
        var jsonData = angular.toJson({Data: pagermodel});
        AngularAjaxCall($http, $scope.AgentListURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
            if (response.IsSuccess) {
                $scope.AgentList = response.Data.Items;
                if ($scope.AgentList.length == 0) {
                    $('#nodata').show();
                } else {
                    $('#nodata').hide();
                }
                $scope.ListPager.totalRecords = response.Data.TotalItems;
                if (setHistoryData)
                    SetHistoryData(window.location.href, {
                        searchModel: $scope.ListModel.backSearchModel,
                        searchedCriteria: $scope.ListModel.backSearchModel,
                        pager: {
                            currentPage: $scope.ListPager.currentPage,
                            pageSize: $scope.ListPager.pageSize,
                            sortIndex: $scope.ListPager.sortIndex,
                            sortDirection: $scope.ListPager.sortDirection,
                            reverse: $scope.ListPager.reverse
                        },
                        setCriteria: 'SetCriteria'
                    }, document.title);
            }
        });
    };
    $scope.SearchAgentRecords = function () {
        CopyProperties($scope.ListModel.frontSearchModel, $scope.ListModel.backSearchModel);
        $scope.ListPager.currentPage = 1;
        $scope.AgentInfoList();
    };

    $scope.ListPager.getDataCallback = $scope.AgentInfoList;

    window.SetCriteria = function (data, pagerData) {
        if(data.CalBRENo==false){
            data.CalBRENo ='';
        }
        $scope.ListModel.backSearchModel.LastName = data.LastName;
        $scope.ListModel.backSearchModel.Email = data.Email;
        $scope.ListModel.backSearchModel.CalBRENo = data.CalBRENo;
        $scope.ListModel.backSearchModel.SiteID = data.SiteID;
        $scope.ListModel.backSearchModel.StatusID = data.StatusID;

        $scope.ListModel.frontSearchModel.LastName = data.LastName;
        $scope.ListModel.frontSearchModel.Email = data.Email;
        $scope.ListModel.frontSearchModel.CalBRENo = data.CalBRENo;
        $scope.ListModel.frontSearchModel.SiteID = data.SiteID;
        $scope.ListModel.frontSearchModel.StatusID = data.StatusID;

        if (pagerData != undefined) {
            $scope.ListPager.currentPage = pagerData.currentPage;
            $scope.ListPager.sortDirection = pagerData.sortDirection;
            $scope.ListPager.sortIndex = pagerData.sortIndex;
            $scope.ListPager.pageSize = pagerData.pageSize;
            $scope.ListPager.reverse = pagerData.reverse;
        }

        $scope.ListPager.getDataCallback(false);
    };

    if (window.History.getState().data.param != undefined) {
        SetParamData();
    } else {
        $scope.ListPager.getDataCallback();
    }
    /* $scope.backButtonClicked = function () {
     $scope.PagesList(false);
     };*/


    $scope.EditAgent = function (Data) {
        location.href = $scope.EditAgentURL + Data.EncryptedUserID;
    }

    $scope.DisableAgent = function (Data) {
        var postData = {};
        postData.Data = Data;
        window.Confirmdialogmessage = window.DisabledConfirmation;
        var jsonData = angular.toJson(postData);
        ShowConfirm(" '" + Data.AgentName + "' ?", function () {
            AngularAjaxCall($http, $scope.DisableAgentURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    $scope.AgentInfoList();
                    ShowSuccessMessage(response.Message);
                }
            });
        });
    };


    $scope.EnableAgent = function (Data) {
        var postData = {};
        postData.Data = Data;
        //window.Confirmdialogmessage = window.EnabledConfirmation;
        var jsonData = angular.toJson(postData);
       // ShowConfirm(" '" + Data.AgentName + "' ?", function () {
            AngularAjaxCall($http, $scope.EnableAgentURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    $scope.AgentInfoList();
                    ShowSuccessMessage(response.Message);
                }
            });
        //});
    };

});