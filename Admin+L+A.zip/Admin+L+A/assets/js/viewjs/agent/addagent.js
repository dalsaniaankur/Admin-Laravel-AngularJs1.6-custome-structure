app.controller('AgentController',function($scope,$http,$timeout) {
    $scope.AddAgentdURL = baseUrl+'/saveagent';
    $scope.RedirectURL = baseUrl + '/agents/';
    $scope.GetAgentImageUrl = baseUrl+'/getagentimage';
    $scope.RemoveAgentImageURL = baseUrl+'/removeagentimage';
    $scope.AgentModel = $.parseJSON($("#AgentModel").val());

    $scope.AgentModel =  $scope.AgentModel.AgentDetails;

    if($scope.AgentModel.UserID == 0 || $scope.AgentModel.UserID == undefined){
        $scope.AgentModel.IsAgent = parseInt(1);
    }

    $scope.AwsUploadBaseURL = $scope.AgentModel.Fileuploadsettings.url;
    $scope.encryptedSiteID = $scope.AgentModel.encryptedSiteID;
    $scope.AgentModel.NoImagePath = window.NoImagePath;
    $scope.DisableButtons = false;
    $scope.CheckUnicueLicenseURL = baseUrl+'/checkuniquelicense';
    $scope.CheckUnicueEmailURL = baseUrl+'/checkuniqueemail';
    $scope.AgentModel.OldSlug=$scope.AgentModel.Slug;
    $scope.MercerVineSiteID = window.MercerVineSiteID;
    /* Recommended dimensions set */

    if((Window.ImageResitrictions[$scope.AgentModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.AgentModel.SiteID]['Smaller']['Height'] != undefined){
        $scope.AllowedsmallerFixHeight = Window.ImageResitrictions[$scope.AgentModel.SiteID]['Smaller']['Height'];
    }
    if((Window.ImageResitrictions[$scope.AgentModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.AgentModel.SiteID]['Smaller']['Width'] != undefined){
        $scope.AllowedSmallerFixWidth = Window.ImageResitrictions[$scope.AgentModel.SiteID]['Smaller']['Width'];
    }

    $scope.AddAgent = function() {
        if ($scope.AgentForm.$valid &&( $scope.EmailError != true && $scope.CalBRENoError != true)) {


            if($scope.AgentModel.RealSmallerImagesPath ==''){
             ShowAlertMessage(window.ProfileImage, 'error', window.ConfirmDialogSomethingWrong);
            }else if(($scope.AgentModel.IsAgent =='' || $scope.AgentModel.IsAgent ==0) && ($scope.AgentModel.IsFoundingMember =='' || $scope.AgentModel.IsFoundingMember ==0) && ($scope.AgentModel.IsTeamMember =='' || $scope.AgentModel.IsTeamMember ==0) && $scope.AgentModel.SiteID == $scope.MercerVineSiteID){
                ShowAlertMessage(window.AgentType, 'error', window.ConfirmDialogSomethingWrong);
            }else{
                $scope.DisableButtons = true;
                var postData = {};
                postData.Data = $scope.AgentModel;
                var jsonData = angular.toJson(postData);
                AngularAjaxCall($http,$scope.AddAgentdURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                    if(response.IsSuccess){
                        if(response.Data==1){
                            $scope.AgentModel.Password = '';
                            $scope.AgentModel.ConfirmPassword = '';
                            ShowSuccessMessage(response.Message);$scope.DisableButtons = false;
                        }else{
                            SetMessageForPageLoad(response.Message);
                            window.location.href = response.RedirectUrl;
                        }

                    }else{
                        ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                        $scope.DisableButtons = false;
                    }
                });
            }
        }else{
            $timeout(function() {
                openErrorPortlets();
            });
        }
    }
    $scope.$watch('AgentModel.Slug',function(newVal,oldVal){
        if($scope.AgentModel.Slug != undefined){
            $scope.AgentModel.AgentURL = $scope.AgentModel.BaseURL+'/'+$scope.AgentModel.AgentSection+'/'+$scope.AgentModel.Slug;
        }else{
            $scope.AgentModel.AgentURL = $scope.AgentModel.BaseURL+'/'+$scope.AgentModel.AgentSection+'/';
        }
    });
    $scope.$watch('AgentModel.JivePhone',function(newVal,oldVal){
        if(newVal != oldVal &&  $scope.AgentModel.IsForMV)
            $scope.AgentModel.Fax = $scope.AgentForm.JivePhone.$viewValue;

    });

    $scope.checkSave = function(yourForm) {
        checkValidationFocus(yourForm);
    };
    /* On Cancel button click redirect to userList page */
    $scope.Cancel = function(){
        window.history.back();
        //  window.location.href = $scope.AgentModel.RedirectURL;
    }

    /* For Remove An Image */
    $scope.RemoveImage = function(imageType) {
        var ImageURL ='';
        var realImagePath = '';
        var GeryScaleImageURL ='';
        var realGeryScaleImagePath = '';

        switch(imageType) {
            case window.AgentSmallerImageType:
                ImageURL = $scope.AgentModel.SmallerImagesPath;
                realImagePath = $scope.AgentModel.RealSmallerImagesPath;
                GeryScaleImageURL =$scope.AgentModel.ImagePath;
                realGeryScaleImagePath = $scope.AgentModel.RealImagePath;
                break;
        }
        ShowConfirm("this Image?", function () {
            AngularAjaxCall($http, $scope.RemoveAgentImageURL, angular.toJson({ Data : {UserID: $scope.AgentModel.UserID,ImagePath: ImageURL, GeryScaleImageURL: GeryScaleImageURL} }), 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    switch(imageType) {
                        case window.AgentSmallerImageType:
                            $scope.AgentModel.SmallerImagesPath = '';
                            $scope.AgentModel.RealSmallerImagesPath ='';
                            $scope.AgentModel.ImagePath = '';
                            $scope.AgentModel.RealImagePath = ''
                            break;
                    }
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    $scope.DisableButtons = false;
                }
            });
        });
    };

    /*Bellow code for file upload*/
    $scope.requestCounter = 0;
    $scope.responseCounter = 0;
    /* For Image Upload */
    $(document).ready(function() {
        var AwsSettingModel = $scope.AgentModel.Fileuploadsettings;
        $('.direct-upload').each(function() {
            var imgType = $(this).attr('img-type');
            var form = $(this);
            var parentDiv =  $(form).parents('.fileinput');

            if(imgType != undefined && imgType == 2){
                var Images = "Smaller"
            }
            if((Window.ImageResitrictions[$scope.AgentModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.AgentModel.SiteID][Images]['Height'] != undefined){
                var AllowedFixHeight = Window.ImageResitrictions[$scope.AgentModel.SiteID][Images]['Height'];
                var FixWidthMessage= Window.ImageResitrictions[$scope.AgentModel.SiteID][Images]['WidthMessage'];
            }
            if((Window.ImageResitrictions[$scope.AgentModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.AgentModel.SiteID][Images]['Width'] != undefined){
                var AllowedFixWidth = Window.ImageResitrictions[$scope.AgentModel.SiteID][Images]['Width'];
                var FixHeightMessage= Window.ImageResitrictions[$scope.AgentModel.SiteID][Images]['HeightMessage'];
            }
            if((AllowedFixHeight != undefined && AllowedFixHeight != null && AllowedFixHeight != '' && AllowedFixHeight != 0 ) && (AllowedFixWidth != undefined && AllowedFixWidth != null && AllowedFixWidth != '' && AllowedFixWidth != 0)) {
                var FixHeightWidthMessage = Window.ImageResitrictions[$scope.AgentModel.SiteID][Images]['HeightWidthMessage'];
            }
            if(AllowedFixHeight != undefined || AllowedFixWidth != undefined){
                var checkForMaxDimensionsRequired = true;
            }else{
                var checkForMaxDimensionsRequired = false;
            }
            var options ={
                successCallBack: function(new_filename){
                    AngularAjaxCall($http, $scope.GetAgentImageUrl,angular.toJson({ Data : {ImagePath: new_filename,UserID: 0} }) , 'POST', 'json', 'application/json').success(function (response) {
                        if(true) {
                            var realImagePath = $scope.AwsUploadBaseURL + new_filename;
                            switch(imgType) {
                                case window.AgentSmallerImageType:
                                    $scope.AgentModel.SmallerImagesPath = new_filename;
                                    $scope.AgentModel.RealSmallerImagesPath = realImagePath;
                                    $scope.AgentModel.ImagePath = '';
                                    $scope.AgentModel.RealImagePath = '';
                                    break;
                            }
                            $scope.requestCounter = $scope.requestCounter - 1;
                            $(parentDiv).find('#file').removeAttr('disabled');
                            $(parentDiv).find('.progress').hide();
                            $(parentDiv).find('.bar').css('width', '0');
                            $(parentDiv).find('#loadingImage').css('display', 'block');
                            $(parentDiv).find('#actualImage').on('load', function () {
                                $(parentDiv).find('#loadingImage').css('display', 'none');
                            });
                        }
                    });
                },
                AWSBaseURL: $scope.AwsUploadBaseURL,
                AWSSettingsModel:AwsSettingModel,
                form:form,
                AllwoedExts:uploadphotoexts,
                AlertMessage:window.ImageFileAllowedMessage,
                ResizeRequired:false,
                getDimensions: true,
                checkForMaxDimensionsRequired: checkForMaxDimensionsRequired,
                AllowedFixHeight: AllowedFixHeight,
                AllowedFixWidth: AllowedFixWidth,
                FixWidthMessage: FixWidthMessage,
                FixHeightMessage:FixHeightMessage,
                FixHeightWidthMessage: FixHeightWidthMessage,
                progressCallback : function(){

                },
                addCallback : function(){
                    $scope.requestCounter = $scope.requestCounter + 1;
                }
            };

            Awsfileupload(options);
        });
        /*Amazon Upload End*/

    });

    $scope.CalBRENoError = false;
    $scope.CheckUniqueLicense = function(){

        if($scope.AgentModel.CalBRENo != undefined )  {
            var postData = {};
            postData.Data = {};
            postData.Data.CalBRENo = $scope.AgentModel.CalBRENo;
            postData.Data.UserID = $scope.AgentModel.UserID;
            var jsonData = angular.toJson(postData);
            AngularAjaxCall($http, $scope.CheckUnicueLicenseURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    $scope.CalBRENoError = true;
                }else{
                    $scope.CalBRENoError = false;
                }
            });
        }else{
            $scope.CalBRENoError = false;
        }
    }
    $scope.EmailError = false;
    $scope.CheckUniqueEmail = function(){
        if($scope.AgentModel.Email != undefined) {
            var postData = {};
            postData.Data = {};
            postData.Data.Email = $scope.AgentModel.Email;
            postData.Data.UserID = $scope.AgentModel.UserID;
            var jsonData = angular.toJson(postData);
            AngularAjaxCall($http, $scope.CheckUnicueEmailURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    $scope.EmailError = true;
                }else{
                    $scope.EmailError = false;
                }
            });
        }else{
            $scope.EmailError = false;
        }
    }
});


/*Start Dev_VA*/
/*For add,edit,delete,list and sort order Testimonials*/
app.controller("TestimonialController",function($scope,$http,$timeout){
    $scope.addTestimonial = baseUrl+'/savetestimonial';
    $scope.TestimonialModel = $.parseJSON($("#TestimonialModel").val());
    $scope.RedirectURL = $scope.TestimonialModel.encryptedSiteID;
    $scope.SortOrderTestimonialURL = baseUrl+'/updatesortordertestimonial';
    $scope.TestimonialDeleteURL = baseUrl+'/deletetestimonialsdata';
    $scope.SiteID = $scope.TestimonialModel.SiteID;
    $scope.AgentID = $scope.TestimonialModel.AgentID;
    $scope.DisableButtons = false;
    //TODO: Check we can use below variable in Sortable List Directive
    //$scope.ResetSortableRowWidth = false;

    $scope.Save = function(){
        var postData = {};
        postData.Data = $scope.TestimonialModel.TestDetails;
        var jsonData = angular.toJson(postData);
        if($scope.TestimonialForm.$valid){
            $scope.DisableButtons = true;
            AngularAjaxCall($http, $scope.addTestimonial, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess){
                    ShowSuccessMessage(response.Message);
                    $scope.TestimonialModel.TestimonialListArray = response.Data;
                    $scope.TestimonialForm.$submitted = false;
                    $scope.TestimonialModel.TestDetails = angular.copy($scope.TestimonialModel.DefaultTestDetails);
                    $scope.DisableButtons = false;
                    //TODO: Check we can use below variable in Sortable List Directive
                    //$scope.ResetSortableRowWidth = true;
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    $scope.DisableButtons = false;
                }
            });
        }else{
            $timeout(function() {
                openErrorPortlets();
            });
        }
    }
    $scope.Cancel = function(){
        window.location.href = $scope.RedirectURL;
    }
    $scope.updateSortOrder = function(sourceIndex,newIndex){
        var postData = {};
        postData.Data = {};
        postData.Data.oldOrder = sourceIndex;
        postData.Data.newOrder = newIndex;
        postData.Data.AgentID = $scope.TestimonialModel.AgentID;
        var jsonData = angular.toJson(postData);
        if((newIndex != undefined && sourceIndex != undefined ) && (newIndex !='' && newIndex != '' ) && ( sourceIndex != newIndex ) ) {
            AngularAjaxCall($http, $scope.SortOrderTestimonialURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    ShowSuccessMessage(response.Message);
                }
            });
        }
    }
    $scope.EditTestimonial = function(data){
        $scope.TestimonialModel.TestDetails = angular.copy(data);
        $('#Testimonial').focus();
    }
    $scope.DeleteTestimonial = function(data) {
        ShowConfirm("this Testimonial?", function () {
            var postData = {};
            postData.Data = {};
            postData.Data.TestimonialID = data.TestimonialID;
            postData.Data.SiteID = $scope.TestimonialModel.SiteID;
            postData.Data.AgentID = $scope.TestimonialModel.AgentID;
            var jsonData = angular.toJson(postData);
            AngularAjaxCall($http,$scope.TestimonialDeleteURL,jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    ShowSuccessMessage(response.Message);
                    $scope.TestimonialModel.TestimonialListArray = response.Data;
                    $scope.TestimonialModel.TestDetails = angular.copy($scope.TestimonialModel.DefaultTestDetails);
                }else{
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }, 'Yes');
    }
});
app.controller('PropertyListController',function($scope,$http) {
    $scope.PropertyListURL = baseUrl+'/getpropertylistagent'; // For URL
    $scope.FeaturedChangeURL = baseUrl+'/featuredchange';
    $scope.ListModel = $.parseJSON($("#ListModel").val());

    $scope.PropertyList = []; //Define a blank Array

    $scope.ListPager = new PagerModule('Price','DESC');

    $scope.PropertyInfoList = function(){ //Create a new UserListInfo function
        var pagermodel = { //Define and bind all value related to pagination,sorting and searching
            SearchParams: $scope.ListModel.backSearchModel,
            PageSize: $scope.ListPager.pageSize,
            PageIndex: $scope.ListPager.currentPage,
            SortIndex: $scope.ListPager.sortIndex,
            SortDirection: $scope.ListPager.sortDirection
        };

        var postData = {};
        postData.Data = {};
        postData.Data.pagermodel = pagermodel;
        postData.Data.AgentID = $scope.ListModel.AgentID;

        var jsonData = angular.toJson(postData);
        AngularAjaxCall($http, $scope.PropertyListURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
            if (response.IsSuccess) {
                $scope.PropertyList = response.Data.Items;
                if ($scope.PropertyList.length == 0) {
                    $('#nodata').show();
                }else{
                    $('#nodata').hide();
                    for(var i= 0; i< $scope.PropertyList.length ;i++){
                        $scope.PropertyList[i].IsFeatured=parseInt($scope.PropertyList[i].IsFeatured);
                        if($scope.PropertyList[i].CoListingID){
                            $scope.PropertyList[i].ListingID=$scope.PropertyList[i].CoListingID;
                        }
                        if($scope.PropertyList[i].FullStreetAddress){
                            $scope.PropertyList[i].Street=$scope.PropertyList[i].FullStreetAddress;
                        }
                        if($scope.PropertyList[i].TotalSqFt){
                            $scope.PropertyList[i].SquareFeet=$scope.PropertyList[i].TotalSqFt;
                        }
                    }
                }
                $scope.ListPager.totalRecords = response.Data.TotalItems; //bind total records into ListPager.totalRecords

            }
        });
    };

    //For search records
    $scope.SearchPropertyRecords = function () {
        CopyProperties($scope.ListModel.frontSearchModel, $scope.ListModel.backSearchModel);
        $scope.ListPager.currentPage = 1;
        $scope.PropertyInfoList();
    };

    $scope.ListPager.getDataCallback = $scope.PropertyInfoList; // call function UserInfoList

    $scope.ListPager.getDataCallback(); // call getDataCallback function

    /* Change FeaturedChange */
    $scope.FeaturedChange = function(data){
        var postData = {};
        postData.Data = {};
        postData.Data.IsFeatured = data.IsFeatured;
        postData.Data.ListingID = data.ListingID;
        var jsonData = angular.toJson(postData);
        AngularAjaxCall($http,$scope.FeaturedChangeURL,jsonData, 'POST', 'json', 'application/json').success(function (response) {
            if(response.IsSuccess){
                ShowSuccessMessage(response.Message);
            }else{
                ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
            }
        });
    }
});
/*
app.controller("StylisticInfluencesController",function($scope,$http,$timeout){
    $scope.SortOrderStylicInfluencesURL = baseUrl+'/updatesortorderstylisticinfluences';
    $scope.deleteStylicInfluencesURL = baseUrl+'/deletestylisticinfluences'; // For URL
    $scope.StylisticInfluencesModel = $.parseJSON($("#StylisticInfluencesModel").val());
    $scope.AddStylisticInfluencesURL = baseUrl+'/savestylisticinfluences';
    $scope.StylisticInfluencesListArray = $scope.StylisticInfluencesModel.stylisticInfluencesDetails;
    if ($scope.StylisticInfluencesListArray.length == 0) {
        $('#stylisticinfluencesnodata').show();
    }else{
        $('#stylisticinfluencesnodata').hide();
    }

    // Update SortOrder
    $scope.updateSortOrder = function(sourceIndex,newIndex)
    {
        var postData = {};
        postData.Data = {};
        postData.Data.UserID = $scope.StylisticInfluencesModel.UserID;
        postData.Data.OldOrder = sourceIndex;
        postData.Data.newOrder = newIndex;
        var jsonData = angular.toJson(postData);
        if((newIndex != undefined && sourceIndex != undefined ) && (newIndex !='' && newIndex != '' ) && ( sourceIndex != newIndex ) ) {
            AngularAjaxCall($http, $scope.SortOrderStylicInfluencesURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    ShowSuccessMessage(response.Message);
                }
            });
        }
    }
    /*

    /* Delete StylisticInfluences */
  /*  $scope.deleteStylisticInfluences = function(data) {
        ShowConfirm("this Stylistic Influence?", function () {
            var postData = {};
            postData.Data = {};
            postData.Data.StylisticInfluencesID = data.StylisticInfluencesID;
            postData.Data.UserID = $scope.StylisticInfluencesModel.UserID;
            AngularAjaxCall($http,$scope.deleteStylicInfluencesURL,angular.toJson(postData), 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    $scope.StylisticInfluencesListArray = response.Data;
                    $scope.StylisticInfluencesModel.TestDetails = {};
                    $scope.StylisticInfluencesForm.$submitted = false;
                    $('#StylisticInfluences').focus();
                    if ($scope.StylisticInfluencesListArray == null) {
                        $('#stylisticinfluencesnodata').show();
                    }else{
                        $('#stylisticinfluencesnodata').hide();
                    }
                    ShowSuccessMessage(response.Message);
                }else{
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }, 'Yes');
    }
    /* For Edit StylisticInfluences Link set */
  /*  $scope.EditStylisticInfluences = function(Data) {
        $scope.StylisticInfluencesModel.TestDetails = Data;
        $('#StylisticInfluences').focus();
    }

    /* StylisticInfluences cancel button  */
  /*  $scope.Cancel = function(){
        $scope.StylisticInfluencesModel.TestDetails = {};
        $scope.StylisticInfluencesForm.$submitted = false;
        $('#StylisticInfluences').focus();
    }

    /* Add StylisticInfluences */
  /*  $scope.Save = function() {
        if ($scope.StylisticInfluencesForm.$valid) {
            $scope.DisableButtons = true;
            var postData = {};
            postData.Data = {};
            postData.Data = {
                StylisticInfluences: $scope.StylisticInfluencesModel.TestDetails,
                UserID: $scope.StylisticInfluencesModel.UserID
            };
            var jsonData = angular.toJson(postData);
            AngularAjaxCall($http,$scope.AddStylisticInfluencesURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    $scope.StylisticInfluencesModel.TestDetails = {};
                    $scope.StylisticInfluencesListArray = response.Data;
                    if ($scope.StylisticInfluencesListArray.length == 0) {
                        $('#stylisticinfluencesnodata').show();
                    }else{
                        $('#stylisticinfluencesnodata').hide();
                    }
                    ShowSuccessMessage(response.Message);
                    $scope.DisableButtons = false;
                    $scope.StylisticInfluencesForm.$submitted = false;
                }else{
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    $scope.DisableButtons = false;
                }
            });
        }else{
            $timeout(function() {
                openErrorPortlets();
            });
        }
    }
});  */
/*End Dev_VA*/
