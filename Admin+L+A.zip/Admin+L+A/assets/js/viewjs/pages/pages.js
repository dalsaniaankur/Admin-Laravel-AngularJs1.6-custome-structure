app.controller('PageController', function ($scope, $http) {
    $scope.PagesListURL = baseUrl + '/getpageslist';
    $scope.EditPageURL = baseUrl + '/editpage/';
    $scope.DeletePageURL = baseUrl + '/deletepage';
    $scope.PagesList = [];



    $scope.SearchPagesRecords = function () {
        CopyProperties($scope.ListModel.frontSearchModel, $scope.ListModel.backSearchModel);
        $scope.ListPager.currentPage = 1;
        $scope.PagesInfoList();
    };


    /* For Tab Wise Filter set.*/
    $scope.getList = function(data){
        $scope.ListModel.frontSearchModel.StatusID = data;
        $scope.SearchPagesRecords();
    }


    $scope.ListModel = $.parseJSON($("#ListModel").val());

    $scope.ListPager = new PagerModule('ModifiedDate','Desc');
    $scope.PagesInfoList = function (setHistoryData) {

        if (setHistoryData == undefined)
            setHistoryData = true;

        var pagermodel = {
            SearchParams: $scope.ListModel.backSearchModel,
            PageSize: $scope.ListPager.pageSize,
            PageIndex: $scope.ListPager.currentPage,
            SortIndex: $scope.ListPager.sortIndex,
            SortDirection: $scope.ListPager.sortDirection
        };
        var postData = {};
        postData.Data = $scope.PagesList;
        var jsonData = angular.toJson({Data: pagermodel});
        AngularAjaxCall($http, $scope.PagesListURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
            if (response.IsSuccess) {
                $scope.PagesList = response.Data.Items;
                if ($scope.PagesList.length == 0) {
                    $('#nodata').show();
                } else {
                    $('#nodata').hide();
                }
                $scope.ListPager.totalRecords = response.Data.TotalItems;
                if (setHistoryData)
                    SetHistoryData(window.location.href, {
                        searchModel: $scope.ListModel.backSearchModel,
                        searchedCriteria: $scope.ListModel.backSearchModel,
                        pager: {
                            currentPage: $scope.ListPager.currentPage,
                            pageSize: $scope.ListPager.pageSize,
                            sortIndex: $scope.ListPager.sortIndex,
                            sortDirection: $scope.ListPager.sortDirection,
                            revers: $scope.ListPager.reverse
                        },
                        setCriteria: 'SetCriteria'
                    }, document.title);
            }
            else {
                ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
            }
        });
    };
    $scope.ListPager.getDataCallback = $scope.PagesInfoList;

    window.SetCriteria = function (data, pagerData) {

        $scope.ListModel.backSearchModel.DateFrom = data.DateFrom;
        $scope.ListModel.backSearchModel.DateTo = data.DateTo;
        $scope.ListModel.backSearchModel.StatusID = data.StatusID;
        $scope.ListModel.backSearchModel.Today = data.Today;

        $scope.ListModel.frontSearchModel.DateFrom = data.DateFrom;
        $scope.ListModel.frontSearchModel.DateTo = data.DateTo;
        $scope.ListModel.frontSearchModel.StatusID = data.StatusID;
        $scope.ListModel.frontSearchModel.Today = data.Today;

        if (pagerData != undefined) {
            $scope.ListPager.currentPage = pagerData.currentPage;
            $scope.ListPager.sortDirection = pagerData.sortDirection;
            $scope.ListPager.sortIndex = pagerData.sortIndex;
            $scope.ListPager.pageSize = pagerData.pageSize;
            $scope.ListPager.reverse = pagerData.revers;
        }
        $scope.ListPager.getDataCallback(false);

        if (data.StatusID == 0) {
            $scope.ListModel.backSearchModel.StatusID = undefined;
            $scope.ListModel.frontSearchModel.StatusID = undefined;


            $("ul.nav-tabs li").removeClass("active");
            $("ul.nav-tabs li a").attr("aria-expanded", "false");

            $("ul.nav-tabs li:first a ").tab("show");
            $("ul.nav-tabs li:first").addClass("active");

           /* debugger;
            $scope.$apply( function() {
                $("ul.nav-tabs li:first").click();
            })
*/


        } else {
            $scope.ListModel.backSearchModel.StatusID = data.StatusID;
            $scope.ListModel.frontSearchModel.StatusID = data.StatusID;

           // $("ul.nav-tabs li").removeClass("active");
           // $("ul.nav-tabs li a").attr("aria-expanded", "false");
        }

        if (data.DateFrom == null) {
            $scope.ListModel.backSearchModel.DateFrom = null;
            $scope.ListModel.frontSearchModel.DateFrom = null;
        } else {
            $scope.ListModel.backSearchModel.DateFrom = data.DateFrom;
            //$scope.ListModel.frontSearchModel.DateFrom = data.DateFrom;
        }
    };

    if (window.History.getState().data.param != undefined) {
        SetParamData();
        //$scope.ListPager.getDataCallback(false);
    }
    else {
        $scope.ListPager.getDataCallback();
    }


    $scope.DeletePage = function (page) {
        var postData = {};
        postData.Data = {};
        postData.Data.ID = page.PageID;
        postData.Data.Slug = page.Slug;
        var jsonData = angular.toJson(postData);
        ShowConfirm("this page ?", function () {
                AngularAjaxCall($http,$scope.DeletePageURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                    if (response.IsSuccess) {
                        ShowSuccessMessage(response.Message);
                        $scope.PagesInfoList();       // what if only one data in page ?
                    } else {
                        ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    }
                });
        }, 'Yes');
    };

    /*Start Dev_VA*/
    /*Below code for edit page*/
    $scope.EditPage = function (page) {
        location.href = $scope.EditPageURL + page.encryptedPageID;
    };
    /*End Dev_VA*/
});

