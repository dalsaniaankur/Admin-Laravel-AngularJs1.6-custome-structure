app.controller("PageController",function($scope,$http,$timeout){
    $scope.addPageURL = baseUrl+'/savepage';
    $scope.saveImageURL = baseUrl+'/savepageimage';
    $scope.removeProfileImageURL = baseUrl+'/removepageimage';
    $scope.DeleteSliderFileURL = baseUrl + '/deletepagesliderimage';

    $scope.PageModel = $.parseJSON($("#PageModel").val());
    $scope.encryptedSiteID = $scope.PageModel.encryptedSiteID;
    $scope.RedirectURL = $scope.PageModel.RedirectURL;
    $scope.$watch('PageModel.PageDetails.Title',function(newVal,oldVal){
        /*Here this condition solve watch problem for edit and add mode*/
        if(newVal != oldVal) {
            $scope.PageModel.PageDetails.BrowserTitle = newVal;
            $scope.PageModel.PageDetails.FBTitle = newVal;
            $scope.PageModel.PageDetails.TwitterTitle = newVal;
            $scope.PageModel.PageDetails.Headline = newVal;
        }
    });
    $scope.$watch('PageModel.PageDetails.Slug',function(newVal,oldVal){
        /*Here this condition solve watch problem for edit and add mode*/
        if(newVal != oldVal){
            /*Here this condition for made canonicalURL with section and without section*/
            if($scope.PageModel.Section != '' && $scope.PageModel.Section != null){
                $scope.PageModel.PageDetails.CanonicalURL = $scope.PageModel.BaseUrl+'/'+$scope.PageModel.Section+'/'+$scope.PageModel.PageDetails.Slug;
            }else{
                $scope.PageModel.PageDetails.CanonicalURL = $scope.PageModel.BaseUrl+'/'+$scope.PageModel.PageDetails.Slug;
            }
        }
    });

    $scope.checkSave = function(yourForm) {
        checkValidationFocus(yourForm);
    };

    /* Recommended dimensions set */
    if($scope.PageModel.PageDetails.SiteID == RiverDaleFundingSiteID || $scope.PageModel.PageDetails.SiteID == ColoradoSiteID || $scope.PageModel.PageDetails.SiteID == WoodBridgeWealthSiteID ) {
        if ((Window.ImageResitrictions[$scope.PageModel.PageDetails.SiteID] != undefined) && Window.ImageResitrictions[$scope.PageModel.PageDetails.SiteID]['PagesTopImage']['Height'] != undefined) {
            $scope.AllowedTopFixHeight = Window.ImageResitrictions[$scope.PageModel.PageDetails.SiteID]['PagesTopImage']['Height'];
        }
        if ((Window.ImageResitrictions[$scope.PageModel.PageDetails.SiteID] != undefined) && Window.ImageResitrictions[$scope.PageModel.PageDetails.SiteID]['PagesTopImage']['Width'] != undefined) {
            $scope.AllowedTopFixWidth = Window.ImageResitrictions[$scope.PageModel.PageDetails.SiteID]['PagesTopImage']['Width'];
        }
    }

   
    $scope.Save = function () {
        var postData = {};
        postData.Data = $scope.PageModel.PageDetails;
        var jsonData = angular.toJson(postData);
        if($scope.PageForm.$valid){
            AngularAjaxCall($http, $scope.addPageURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess){
                    SetMessageForPageLoad(response.Message);
                    window.location.href = response.RedirectURL;
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }else {
            $timeout(function() {
                openErrorPortlets();
            });
        }
    }
    $scope.Cancel = function(){
        window.history.back();
        /*if($scope.PageModel.PageDetails.PageID > 0)
            window.history.back();
        else
            window.location.href = $scope.RedirectURL;*/
    }

    /* For Approve Start */
    $scope.approvePageURL = baseUrl+'/approvepage';
    $scope.Approve = function () {
        var postData = {};
        postData.Data = $scope.PageModel.PageDetails;
        var jsonData = angular.toJson(postData);
        if($scope.PageForm.$valid) {
            AngularAjaxCall($http, $scope.approvePageURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    SetMessageForPageLoad(response.Message);
                    window.location.href = response.RedirectURL;
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }
    }
    /* Approve End */

    /* For Deny Start */
    $scope.denyPageURL = baseUrl+'/denypage';
    $scope.Deny = function () {
        if($scope.PageModel.PageDetails.Message == undefined || $scope.PageModel.PageDetails.Message ==''){
            ShowAlertMessage(window.MessageRequired, 'error', window.ConfirmDialogSomethingWrong);
            $("#deny-message").focus();
        }else{
            var postData = {};
            postData.Data = $scope.PageModel.PageDetails;
            var jsonData = angular.toJson(postData);
            if($scope.PageForm.$valid) {
                AngularAjaxCall($http, $scope.denyPageURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                    if (response.IsSuccess) {
                        SetMessageForPageLoad(response.Message);
                        window.location.href = response.RedirectURL;
                    } else {
                        ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    }
                });
            }
        }
    }
    /* Deny End */


    /* For Publish Start */
    $scope.publishPageURL = baseUrl+'/publishpage';
    $scope.Publish = function () {
        var postData = {};
        postData.Data = $scope.PageModel.PageDetails;
        var jsonData = angular.toJson(postData);
        if($scope.PageForm.$valid) {
            AngularAjaxCall($http, $scope.publishPageURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    SetMessageForPageLoad(response.Message);
                    window.location.href = response.RedirectURL;
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }
    }
    /* Publish End */

    /* For Delete Page */
    $scope.DeletePageURL = baseUrl + '/deletepage';
    $scope.DeletePage = function () {
        var postData = {};
        postData.Data = {};
        postData.Data.Slug = $scope.PageModel.PageDetails.Slug;
        postData.Data.ID = $scope.PageModel.PageDetails.PageID;
        var jsonData = angular.toJson(postData);
        ShowConfirm("this page ?", function () {
            if ($scope.PageModel.IsUsedInMenu > 0) {
                ShowConfirm("this page from navigation ?", function () {
                    AngularAjaxCall($http, $scope.DeletePageURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                        if (response.IsSuccess) {
                            SetMessageForPageLoad(response.Message);
                            window.location.href = $scope.RedirectURL.concat($scope.encryptedSiteID);
                        } else {
                            ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                        }
                    });
                });
            } else {
                AngularAjaxCall($http,$scope.DeletePageURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                    if (response.IsSuccess) {
                        SetMessageForPageLoad(response.Message);
                        window.location.href = $scope.RedirectURL.concat($scope.encryptedSiteID);
                    } else {
                        ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    }
                });
            }
        });
    };


    /*Bellow code for file upload*/
    $scope.AwsUploadBaseURL = $scope.PageModel.PageDetails.Fileuploadsettings.url;
    $scope.PageModel.PageDetails.NoImagePath = window.NoImagePath;
    $scope.PageModel.PageDetails.NoProfileImagePath = window.NoProfileImagePath;
    $scope.requestCounter = 0;
    $scope.responseCounter = 0;

    /*For Image upload*/
    $(document).ready(function() {
        var AwsSettingModel = $scope.PageModel.PageDetails.Fileuploadsettings;
        $('.direct-upload').each(function() {
            var imgType = $(this).attr('img-type'); 
            var form = $(this);
            var parentDiv =  $(form).parents('.fileinput');
            var uploadMaxFileSizeErrorMessage = '';
            var maxFileSize = window.ImageSize;
            switch(imgType) {
                case window.FBImageType:
                    uploadMaxFileSizeErrorMessage = window.FBMaxFileSizeErrorMessage;
                break;
                case window.TwitterImageType:
                    uploadMaxFileSizeErrorMessage = window.TwitterMaxFileSizeErrorMessage;
                break;
                case window.GoogleImageType:
                    uploadMaxFileSizeErrorMessage = window.GoogleMaxFileSizeErrorMessage;
                break;
                case window.PageTopImageType:
                    var Images = "PagesTopImage";
                    break;
                
            }
            if(Images != undefined) {
                if ((Window.ImageResitrictions[$scope.PageModel.PageDetails.SiteID] != undefined) && Window.ImageResitrictions[$scope.PageModel.PageDetails.SiteID][Images]['Height'] != undefined) {
                    var AllowedFixHeight = Window.ImageResitrictions[$scope.PageModel.PageDetails.SiteID][Images]['Height'];
                    var FixWidthMessage = Window.ImageResitrictions[$scope.PageModel.PageDetails.SiteID][Images]['WidthMessage'];
                }
                if ((Window.ImageResitrictions[$scope.PageModel.PageDetails.SiteID] != undefined) && Window.ImageResitrictions[$scope.PageModel.PageDetails.SiteID][Images]['Width'] != undefined) {
                    var AllowedFixWidth = Window.ImageResitrictions[$scope.PageModel.PageDetails.SiteID][Images]['Width'];
                    var FixHeightMessage = Window.ImageResitrictions[$scope.PageModel.PageDetails.SiteID][Images]['HeightMessage'];
                }
                if ((AllowedFixHeight != undefined && AllowedFixHeight != null && AllowedFixHeight != '' && AllowedFixHeight != 0 ) && (AllowedFixWidth != undefined && AllowedFixWidth != null && AllowedFixWidth != '' && AllowedFixWidth != 0)) {
                    var FixHeightWidthMessage = Window.ImageResitrictions[$scope.PageModel.PageDetails.SiteID][Images]['HeightWidthMessage'];
                }
                if (AllowedFixHeight != undefined || AllowedFixWidth != undefined) {
                    var checkForMaxDimensionsRequired = true;
                } else {
                    var checkForMaxDimensionsRequired = false;
                }
            }
            
            var options ={
                successCallBack: function(new_filename,tempFileName, imageWidth, imageHeight){
                    AngularAjaxCall($http, $scope.saveImageURL,angular.toJson({ Data : {ImageName: new_filename,ImageType: imgType} }) , 'POST', 'json', 'application/json').success(function (response) {
                        if(true) {
                            var realImagePath = $scope.AwsUploadBaseURL + new_filename;
                            $scope.PageModel.PageDetails.ImageName = new_filename;
                            switch(imgType) {
                                case window.FBImageType:
                                     $scope.PageModel.PageDetails.FBImage = new_filename;
                                     $scope.PageModel.PageDetails.FBRealImagePath = realImagePath;
                                break;
                                case window.TwitterImageType:
                                     $scope.PageModel.PageDetails.TwitterImage = new_filename;
                                     $scope.PageModel.PageDetails.TwitterRealImagePath = realImagePath;
                                break;
                                case window.GoogleImageType:
                                     $scope.PageModel.PageDetails.Image = new_filename;
                                     $scope.PageModel.PageDetails.GoogleRealImagePath = realImagePath;
                                     $scope.PageModel.PageDetails.ImageHeight = imageHeight;
                                     $scope.PageModel.PageDetails.ImageWidth = imageWidth;
                                break;
                                case window.PageTopImageType:
                                    $scope.PageModel.PageDetails.TopImagePath = new_filename;
                                    $scope.PageModel.PageDetails.TopImageName = tempFileName;
                                    $scope.PageModel.PageDetails.RealTopImagePath = realImagePath;
                                break;
                                case window.PageBottomRightImageType:
                                    $scope.PageModel.PageDetails.BottomRightImagePath = new_filename;
                                    $scope.PageModel.PageDetails.BottomRightImageName = tempFileName;
                                    $scope.PageModel.PageDetails.RealBottomRightImagePath = realImagePath;
                                break;
                            }
                            $scope.responseCounter = $scope.responseCounter+1;
                            $(parentDiv).find('#file').removeAttr('disabled');
                            $(parentDiv).find('.progress').hide();
                            $(parentDiv).find('.bar').css('width', '0');
                            $(parentDiv).find('#loadingImage').css('display', 'block');
                            $(parentDiv).find('#actualImage').on('load', function () {
                                $(parentDiv).find('#loadingImage').css('display', 'none');
                            });
                            //$scope.PageModel.PageDetails.UploadFilesArray.push = new_filename;

                        }
                    });
                },

                AWSBaseURL: $scope.AwsUploadBaseURL,
                AWSSettingsModel:AwsSettingModel,
                form:form,
                AllwoedExts:uploadphotoexts,
                maxFileSizeLimit:maxFileSize,
                maxFileSizeErrorMessage:uploadMaxFileSizeErrorMessage,
                AlertMessage:window.ImageFileAllowedMessage,
                ResizeRequired:false,
                getDimensions: true,
                multiple:true,
                checkForMaxDimensionsRequired: checkForMaxDimensionsRequired,
                AllowedFixHeight: AllowedFixHeight,
                AllowedFixWidth: AllowedFixWidth,
                FixWidthMessage: FixWidthMessage,
                FixHeightMessage:FixHeightMessage,
                FixHeightWidthMessage: FixHeightWidthMessage,

                progressCallback : function(){
                },

                addCallback : function(){
                    $scope.requestCounter = $scope.requestCounter+1;
                }
            };
            Awsfileupload(options);
        });
    });

    /* For Remove An Image */
    $scope.RemoveImage = function(imageType) {
        var imageName ='';
        var realImagePath = '';
        switch(imageType) {
            case window.FBImageType:
                imageName =  $scope.PageModel.PageDetails.FBImage;
                realImagePath =  $scope.PageModel.PageDetails.FBRealImagePath;
            break;
            case window.TwitterImageType:
                imageName = $scope.PageModel.PageDetails.TwitterImage;
                realImagePath = $scope.PageModel.PageDetails.TwitterRealImagePath;
            break;
            case window.GoogleImageType:
                imageName = $scope.PageModel.PageDetails.Image;
                realImagePath = $scope.PageModel.PageDetails.GoogleRealImagePath;
            break;
            case window.PageTopImageType:
                imageName = $scope.PageModel.PageDetails.TopImagePath;
                realImagePath = $scope.PageModel.PageDetails.RealTopImagePath;
                break;
            case window.PageBottomRightImageType:
                imageName = $scope.PageModel.PageDetails.BottomRightImagePath;
                realImagePath = $scope.PageModel.PageDetails.RealBottomRightImagePath;
                break;
        }
        ShowConfirm("this Image?", function () {
            AngularAjaxCall($http, $scope.removeProfileImageURL, angular.toJson({Data:{PageID: $scope.PageModel.PageDetails.PageID,RemoveType: imageType,ImageName: imageName}}),'POST','json','application/json').success(function(response){
                if (response.IsSuccess) {
                    $scope.PageModel.PageDetails.UploadFilesArray = realImagePath;
                    switch(imageType) {
                        case window.FBImageType:
                            $scope.PageModel.PageDetails.FBImage = '';
                            $scope.PageModel.PageDetails.FBRealImagePath = response.Data;
                        break;
                        case window.TwitterImageType:
                            $scope.PageModel.PageDetails.TwitterImage = '';
                            $scope.PageModel.PageDetails.TwitterRealImagePath = response.Data;
                        break;
                        case window.GoogleImageType:
                            $scope.PageModel.PageDetails.Image = '';
                            $scope.PageModel.PageDetails.GoogleRealImagePath = response.Data;
                            $scope.PageModel.PageDetails.ImageHeight = '';
                            $scope.PageModel.PageDetails.ImageWidth = '';
                        break;
                        case window.PageTopImageType:
                            $scope.PageModel.PageDetails.TopImagePath = '';
                            $scope.PageModel.PageDetails.TopImageName = '';
                            $scope.PageModel.PageDetails.RealTopImagePath = '';
                            break;
                        case window.PageBottomRightImageType:
                            $scope.PageModel.PageDetails.BottomRightImagePath = '';
                            $scope.PageModel.PageDetails.BottomRightImageName = '';
                            $scope.PageModel.PageDetails.RealBottomRightImagePath = '';
                            break;
                    }
                    $scope.PageModel.PageDetails.IsImageRemoved = 1;
                    $scope.PageModel.PageDetails.ImageName = '';
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        });
    };

    //We need to add this to hide help text while page load
    $(".help-block").removeClass("display-none");

    /* File Upload & Remove Section Start*/
    $scope.PageModel.PageDetails.ImagesModel=[];
    $scope.PageModel.PageDetails.ImagesNameModel=[];
    $scope.PageModel.PageDetails.ImageExtensionType = ["jpg", "png", "gif", "JPG", "GIF", "PNG"];  // For image tye extensions.
    $scope.PageModel.maxFiles = 6; // For set how many file allowed to maximum upload
    $scope.PageModel.requestCounter = 0;
    $scope.PageModel.responseCounter = 0;
    $scope.PageModel.IsAllowSortable = 1;

    $scope.PushFilesToUploadArray = function(filename) {  //For Push added file into array.
        $scope.PageModel.PageDetails.ImagesModel.push(filename);
    };
    $scope.UploadComplete = true;  // for enable submit button and watching on request and response counter
    $scope.$watch('PageModel.requestCounter',function(newVal) { // for enable submit button and watching on request and response counter
        $scope.UploadComplete = newVal == $scope.PageModel.responseCounter;
    });
    $scope.$watch('PageModel.responseCounter',function(newVal) { // for enable submit button and watching on request and response counter
        $scope.UploadComplete = newVal == $scope.PageModel.requestCounter;
    });

    $scope.updateSortOrderSlider = function(sourceIndex,newIndex){
        if( newIndex != sourceIndex ) {
            var target = $scope.PageModel.PageDetails.ImagesNameModel[sourceIndex];
            var increment = newIndex < sourceIndex ? -1 : 1;
            for(var k = sourceIndex; k != newIndex; k += increment){
                $scope.PageModel.PageDetails.ImagesNameModel[k] = $scope.PageModel.PageDetails.ImagesNameModel[k + increment];
            }
            $scope.PageModel.PageDetails.ImagesNameModel[newIndex] = target;
        }
        return $scope.PageModel.PageDetails.ImagesNameModel;
    };

    $scope.RemoveFile = function(file){
        var filename = file;
        if(filename){
            var fileToRemove = SearchArrayByPropertyValue($scope.PageModel.PageDetails.ImagesModel,filename); // Using given FILENAME search in array for  delete key find.
            if($scope.PageModel.PageDetails.ImagesModel[fileToRemove]){
                $scope.PageModel.PageDetails.FilePath = $scope.PageModel.PageDetails.ImagesModel[fileToRemove].FilePath;
                if($scope.PageModel.PageDetails.ImagesModel[fileToRemove].ImageID != undefined){
                    var ImageID = $scope.PageModel.PageDetails.ImagesModel[fileToRemove].ImageID;  // find the image id
                }
            }
            if(fileToRemove != -1) {
                AngularAjaxCall($http,$scope.DeleteSliderFileURL, angular.toJson({ Data : {FilePath: $scope.PageModel.PageDetails.FilePath,ImageID:ImageID} }), 'POST', 'json', 'application/json').success(function (response) {
                    if (response.IsSuccess){
                        var index = undefined;
                        var filePath = undefined;
                        angular.forEach($scope.PageModel.PageDetails.ImagesModel, function (value, key) {
                            if(value.FilePath == filename){
                                index = key;
                                filePath = $scope.PageModel.PageDetails.ImagesModel[fileToRemove].FilePath;
                            }
                        });
                        if(filePath != undefined) {
                            var fname =  filePath.split("/").pop(-1);
                            var index = $scope.PageModel.PageDetails.ImagesNameModel.indexOf(fname);
                            if (index >= 0) {
                                $scope.PageModel.PageDetails.ImagesNameModel.splice(index,1);
                            }
                        }
                        $scope.PageModel.PageDetails.ImagesModel.splice(fileToRemove, 1); // After Delete image Remove the value from array using given KEY.
                        ShowSuccessMessage(response.Message);
                    } else {
                        ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    }
                });
            }else{
                return true;
            }
        }
    };
    /* File Upload & Remove Section End*/
});