app.controller("LoanController",function($scope,$http){
    $scope.AddLoanUrl=baseUrl+'/saveloan';
    $scope.LoanModel = $.parseJSON($("#LoanModel").val());
    $scope.deleteFile = baseUrl+'/removeloanimage';
	$scope.deleteLoanURL = baseUrl+'/deleteloan'; // For URL
    $scope.editURL = baseUrl + '/addloan/';
    $scope.LoanModel.NoImagePath = window.NoImagePath;
    $scope.RedirectURL = baseUrl + '/loans';
    $scope.DisableButtons = false;
    $scope.LoanModel.NoImagePath = window.NoImagePath;
    $scope.AwsUploadBaseURL = $scope.LoanModel.FileUploadSettings.url;

    /* Related to File Upload & Remove  Start */
    $scope.LoanModel.UploadFilesArray=[];
    $scope.LoanModel.ImagesNameModel=[];
    $scope.LoanModel.IsAllowStoreOrder=1;
    $scope.LoanModel.ImageExtensionType = ["jpg", "png", "gif", "JPG", "GIF", "PNG"];  // For image tye extensions.
    $scope.LoanModel.maxFiles = 3; // For set how many file allowed to maximum upload
    $scope.LoanModel.requestCounter = 0;
    $scope.LoanModel.responseCounter = 0;

    $scope.PushFilesToUploadArray = function(filename) {  //For Push added file into array.
        $scope.LoanModel.UploadFilesArray.push(filename);
    }

    $scope.UploadComplete = true;  // for enable submit button and watching on request and response counter
    $scope.$watch('LoanModel.requestCounter',function(newVal) { // for enable submit button and watching on request and response counter
        $scope.UploadComplete = newVal == $scope.LoanModel.responseCounter;
    });

    $scope.$watch('LoanModel.responseCounter',function(newVal) { // for enable submit button and watching on request and response counter
        $scope.UploadComplete = newVal == $scope.LoanModel.requestCounter;
    });

    $scope.RemoveFile = function(file){

        var filename= file;

        if(filename){
            var fileToRemove = SearchArrayByPropertyValue($scope.LoanModel.UploadFilesArray,filename); // Using given FILENAME search in array for  delete key find.
            if($scope.LoanModel.UploadFilesArray[fileToRemove]){
                $scope.LoanModel.FilePath = $scope.LoanModel.UploadFilesArray[fileToRemove].FilePath;
                if($scope.LoanModel.UploadFilesArray[fileToRemove].ImageID != undefined){
                    var ImageID = $scope.LoanModel.UploadFilesArray[fileToRemove].ImageID;  // find the image id
                }
            }

            if(fileToRemove != -1) {
                AngularAjaxCall($http,$scope.deleteFile, angular.toJson({ Data : {filePath: $scope.LoanModel.FilePath,fileToRemoveKey: fileToRemove,ImageID:ImageID,IsDefaultImage: $scope.LoanModel.IsDefaultImage} }), 'POST', 'json', 'application/json').success(function (response) {
                    if (response.IsSuccess){
                        $scope.LoanModel.UploadFilesArray.splice(response.Data.Key,1); // After Delete image Remove the value from array using given KEY.

                        if(response.Data.IsDeleteDefaultImages != undefined && response.Data.IsDeleteDefaultImages==1){ // Set IsDefaultImage to NULL if User delete the Default selected image.
                            $scope.LoanModel.IsDefaultImage='';
                        }
                        ShowSuccessMessage(response.Message);
                    } else {
                        ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    }
                });
            }else{
                return true;
            }
        }
    }


    // Below two fun'c used for Default image selection in add and edit page.
    $scope.OnFileAdded = function(filedata){
        $(filedata.FileData.previewElement).find(".IsDefaultImage").val(filedata.new_filename);
        $(".IsDefaultImage").click(function(){
            $scope.LoanModel.IsDefaultImage = $(this).val();
        })
    }

    $scope.OnDefaultFileLoad = function(file){
        $(file.previewElement).find(".IsDefaultImage").val(file.new_filename);
        if(file.IsDefaultImage=="1") {
            $(file.previewElement).find(".IsDefaultImage").prop('checked', true);
            $scope.LoanModel.IsDefaultImage = file.new_filename;
        }
    }
    /* Related to File Upload & Remove  End */


    $scope.SaveLoan = function() {
        if ($scope.LoanForm.$valid) {
            var postData = {};
            postData.Data = $scope.LoanModel;
            var jsonData = angular.toJson(postData);

            if ($scope.LoanModel.UploadFilesArray.length == 0) { // For Required validations of image
                ShowAlertMessage(window.LoanImage, 'error', window.ConfirmDialogSomethingWrong);
            } else if ($scope.LoanModel.IsDefaultImage == undefined || $scope.LoanModel.IsDefaultImage == '') { // For default image selection validations required.
                ShowAlertMessage(window.DefaultLoanImage, 'error', window.ConfirmDialogSomethingWrong);
            } else {
                $scope.DisableButtons = false;
                AngularAjaxCall($http, $scope.AddLoanUrl, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                    if (response.IsSuccess){
                        if($scope.LoanModel.LoanID > 0){
                            SetMessageForPageLoad(response.Message);
                            window.location.href = response.RedirectUrl;
                        }else{
                            $scope.LoanModel.UploadFilesArray = [];
                            SetMessageForPageLoad(response.Message);
                            window.location.href = response.RedirectUrl;
                        }
                        $scope.DisableButtons = false;
                    } else {
                        $scope.DisableButtons = false;
                        ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    }
                });
            }
        }
    };

    $scope.Cancel = function(){
        window.history.back();
    }
	
	
	/* For Delete Page */
    
    $scope.DeleteLoan = function () {
        var postData = {};
        postData.Data = $scope.LoanModel.LoanID;
        var jsonData = angular.toJson(postData);
        ShowConfirm("this Loan ?", function () {
            
            AngularAjaxCall($http, $scope.deleteLoanURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    SetMessageForPageLoad(response.Message);
                    window.location.href = response.RedirectUrl;
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
                
        });
    };

    $scope.checkSave = function(yourForm) {
        checkValidationFocus(yourForm);
    };
});

