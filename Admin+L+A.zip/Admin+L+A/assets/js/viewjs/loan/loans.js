app.controller("LoanListController",function($scope,$http){
    $scope.SortOrderLoanURL = baseUrl+'/updatesortorderloan';
    $scope.deleteLoanURL = baseUrl+'/deleteloan'; // For URL
    $scope.LoanList = []; //Define a blank Array
    $scope.LoanModel = $.parseJSON($("#LoanModel").val());
    $scope.SiteID = $scope.LoanModel.SiteID;
    $scope.EditLoanURL = baseUrl + '/addloan/';

    $scope.LoanListArray = $scope.LoanModel.LoanListArray;
    if ($scope.LoanListArray.length == 0) {
        $('#nodata').show();
    }else{
        $('#nodata').hide();
    }

    // Update SortOrder
    $scope.updateSortOrder = function(sourceIndex,newIndex)
    {
        var postData = {};
        postData.Data = {};
        postData.Data.OldOrder = sourceIndex;
        postData.Data.newOrder = newIndex;
        var jsonData = angular.toJson(postData);
        if((newIndex != undefined && sourceIndex != undefined ) && (newIndex !='' && newIndex != '' ) && ( sourceIndex != newIndex ) ) {
            AngularAjaxCall($http, $scope.SortOrderLoanURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
               if(response.IsSuccess){
                    ShowSuccessMessage(response.Message);
               }
            });
        }
    }

    // Delete Loan
    $scope.deleteLoan = function(data) {
        ShowConfirm("this Loan?", function () {
            var postData = { Data: data.LoanID };
            AngularAjaxCall($http,$scope.deleteLoanURL,angular.toJson(postData), 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    SetMessageForPageLoad(response.Message);
                    window.location.href = response.RedirectUrl;
                }else{
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }, 'Yes');
    }

    /* For Edit Loan Link set*/
    $scope.EditLoan = function (Data) {
        location.href = $scope.EditLoanURL + Data.combineLoanSiteid;
    }

});

