app.controller('ChooseSiteController',function($scope,$http){
    $scope.ChooseSiteModel = $.parseJSON($("#ChooseSiteModel").val());
    $scope.UserSiteList = $scope.ChooseSiteModel.UserSiteList;
    $scope.SelectSiteURL = baseUrl+'/selectsite';
    $scope.RedirectURL = baseUrl+'/dashboard/';

    $scope.SelectSite = function (SiteID) {
        var postData = {};
        postData.Data = SiteID;
        var jsonData = angular.toJson(postData);
        AngularAjaxCall($http, $scope.SelectSiteURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
            if (response.IsSuccess) {
                window.location.href = $scope.RedirectURL.concat(response.Data);
            }else{
                ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
            }
        });
    }


});

