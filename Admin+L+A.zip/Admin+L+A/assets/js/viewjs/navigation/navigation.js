app.controller('HeaderNavigationController', ['$scope','$http', function ($scope,$http) {
    $scope.GetMenuDataURL = baseUrl + '/getmenudata'; // For URL
    $scope.SaveMenuDataURL = baseUrl + '/savenavigationmenu'; // For URL
    $scope.RedirectDashboardURL = baseUrl + '/dashboard';
    $scope.IsSelected = false; /* For if Selected menu then show and hide add menu button. */
    $scope.DeletedMenuItemID = "";
    $scope.RemovePage = function(modelValue,scope){
        $scope.RemovePageRecursive(modelValue);
        scope.remove();
        $scope.IsSelected = false;
    }
    $scope.IsSelect = function(){
        if($scope.HeaderNavigationModel.Pages.length > 0){
            $scope.IsSelected = true;
        }
    }
   $scope.RemovePageRecursive= function(removeNode){
        if(removeNode.nodes.length > 0){
            angular.forEach(removeNode.nodes, function(value, key) {
                $scope.RemovePageRecursive(value);
            });
        }
        if(removeNode.MenuItemID != undefined){
            if($scope.DeletedMenuItemID == ''){
                $scope.DeletedMenuItemID = angular.copy(removeNode.MenuItemID);
            }else{
                $scope.DeletedMenuItemID = $scope.DeletedMenuItemID + ',' + removeNode.MenuItemID;
            }
        }
        /* If Not custom page to push in page array */
        if(removeNode.Type != undefined && removeNode.Type != "Custom" ) {
            delete removeNode['ParentMenuItemID'];
            delete removeNode['ItemLevel'];
            delete removeNode['MenuItemID'];
            delete removeNode['MenuID'];
            delete removeNode['ItemOrder'];
            delete removeNode['SiteID'];
            delete removeNode['IsOpenNewTab'];
            removeNode.DisplayName = removeNode.Name;
            removeNode.nodes = [];
            $scope.HeaderPagesArray.push(angular.copy(removeNode));
        }
    }

    $scope.toggle = function (scope) {
        scope.toggle();
    };

    $scope.MenuArray = [{
        'MenuID': 0,
        'Name': 'Main'
    },{
        'MenuID': 1,
        'Name': 'Footer'
    }];

    $scope.AddMenu = function() {
        $scope.HeaderNavigationModel.Pages.forEach(function(object) {
            var newobject = angular.copy(object);
            newobject.nodes = [];
            newobject.IsOpenNewTab = 0;
            if($scope.IsFooterMenu == 1){
                newobject.ItemLevel = 1; // Static as it will be added at first level
                $scope.tree.push(newobject);
            }else{
                newobject.ItemLevel = 2; // Static as it will be added at second level
                var treeLength = $scope.tree.length;
                if(treeLength > 0){
                    treeLength = $scope.tree.length - 1;
                }
                $scope.tree[treeLength].nodes.push(newobject);
            }

            var index = $scope.HeaderPagesArray.indexOf(object);
            if(index>=0)
                $scope.HeaderPagesArray.splice(index, 1);

        })
        $scope.IsSelected = false;
    }

    $scope.ChangeMenu = function(){
        if($scope.HeaderNavigationModel.MenuID != null && $scope.HeaderNavigationModel.MenuID != undefined) {
            var postData = {};
            postData.Data = {};
            postData.Data.MenuID = $scope.HeaderNavigationModel.MenuID;
            var jsonData = angular.toJson(postData);
            AngularAjaxCall($http, $scope.GetMenuDataURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    $scope.HeaderPagesArray = response.Data.Pages;
                    $scope.tree = response.Data.Tree;
                    $scope.IsFooterMenu = response.Data.IsFooterMenu;
                    $scope.MenuID = response.Data.MenuID;
                    $scope.IsPageLoad = ($scope.tree.length > 0) ? false : true;
                    $scope.AjaxRunning = true;
                }
            });

        }else{
            $scope.HeaderPagesArray = [];
            $scope.tree = [];
            $scope.IsFooterMenu = '';
            $scope.MenuID = '';
            $scope.AjaxRunning = false;
        }
    }

    $scope.SaveMenu = function() {
        if ($scope.HeaderNavigationTreeForm.$valid) {
            var postData = {};
            postData.Data = {};
            postData.Data.Tree = $scope.tree;
            postData.Data.MenuID = $scope.MenuID;
            postData.Data.SelectedMenuID = $scope.HeaderNavigationModel.MenuID;
            postData.Data.DeletedMenuItemID = $scope.DeletedMenuItemID;
            var jsonData = angular.toJson(postData);
            AngularAjaxCall($http, $scope.SaveMenuDataURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    $scope.tree = response.Data.Tree;
                    $scope.IsPageLoad = ($scope.tree.length > 0) ? false : true;
                    ShowSuccessMessage(response.Message);
                } else {
                    $scope.tree = [];
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }else{
            ShowAlertMessage(InvalidNavigation, 'error', window.ConfirmDialogSomethingWrong);
        }
    }

    /* On Cancel button click redirect to Dashboard page */
    $scope.Cancel = function(){
        window.location.href = $scope.RedirectDashboardURL;
    }

    /* Custom menu start */
    $scope.AddCustomMenu = function() {
        if ($scope.CustomNavigationMenuForm.$valid) {
            var newobject = angular.copy($scope.CustomNavigationMenu);
            newobject.nodes = [];
            newobject.Type = "Custom";
            if ($scope.IsFooterMenu == 1) {
                newobject.ItemLevel = 1; // Static as it will be added at first level
                $scope.tree.push(newobject);
            } else {
                newobject.ItemLevel = 2; // Static as it will be added at second level
                var treeLength = $scope.tree.length;
                if (treeLength > 0) {
                    treeLength = $scope.tree.length - 1;
                }
                $scope.tree[treeLength].nodes.push(newobject);
            }
            /* Clear CustomNavigationMenuForm */
            $scope.ClearCustomNavigationMenuForm();
        }
    }
    $scope.ClearCustomNavigationMenuForm = function(){
        $scope.ClearCustomNavigationMenuForm.$submitted = false;
        $scope.CustomNavigationMenu.DisplayName = '';
        $scope.CustomNavigationMenu.CustomURL = '';
        $scope.CustomNavigationMenu.IsOpenNewTab = 0;
    }
    /* Custom menu end */
}]);






