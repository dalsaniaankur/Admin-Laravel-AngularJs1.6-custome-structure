app.controller("SiteTestimonialListController",function($scope,$http){
    $scope.SortOrderSiteTestimonialURL = baseUrl+'/updatesortordersitetestimonial';
    $scope.deleteSiteTestimonialURL = baseUrl+'/deletesitetestimonial'; // For URL
    $scope.SiteTestimonialList = []; //Define a blank Array
    $scope.SiteTestimonialModel = $.parseJSON($("#SiteTestimonialModel").val());
    $scope.SiteID = $scope.SiteTestimonialModel.SiteTestimonialListArray.SiteID;
    $scope.SaveSiteTestimonialURL = baseUrl + '/savesitetestimonial';
    $scope.TestimonialDeleteURL = baseUrl+'/deletesitetestimonialsdata';

    $scope.SiteTestimonialListArray = $scope.SiteTestimonialModel.SiteTestimonialListArray;





    if ($scope.SiteTestimonialListArray.length == 0) {
        $('#nodata').show();
    }else{
        $('#nodata').hide();
    }

    // Update SortOrder
    $scope.updateSortOrder = function(sourceIndex,newIndex)
    {
        var postData = {};
        postData.Data = {};
        postData.Data.OldOrder = sourceIndex;
        postData.Data.newOrder = newIndex;
        var jsonData = angular.toJson(postData);
        if((newIndex != undefined && sourceIndex != undefined ) && (newIndex !='' && newIndex != '' ) && ( sourceIndex != newIndex ) ) {
            AngularAjaxCall($http, $scope.SortOrderSiteTestimonialURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
               if(response.IsSuccess){
                    ShowSuccessMessage(response.Message);
               }
            });
        }
    }

    // Delete SiteTestimonial
    /*$scope.deleteSiteTestimonial = function(data) {
        ShowConfirm("this SiteTestimonial?", function () {
            var postData = { Data: data.SiteTestimonialID };
            AngularAjaxCall($http,$scope.deleteSiteTestimonialURL,angular.toJson(postData), 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    SetMessageForPageLoad(response.Message);
                    window.location.href = response.RedirectUrl;
                }else{
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }, 'Yes');
    }*/

    
   
    $scope.EditSiteTestimonial = function(data){
        $scope.SiteTestimonialModel.TestDetails = angular.copy(data);

        $('#Testimonial').focus();
    }
    $scope.Cancel = function(){
        window.location.href = $scope.RedirectURL;
    }

    $scope.deleteSiteTestimonial = function(data) {
        ShowConfirm("this Testimonial?", function () {
            var postData = {};
            postData.Data = {};
            postData.Data.TestimonialID = data.TestimonialID;
            postData.Data.SiteID = $scope.SiteID;
            
            var jsonData = angular.toJson(postData);
            AngularAjaxCall($http,$scope.TestimonialDeleteURL,jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    ShowSuccessMessage(response.Message);
                    $scope.SiteTestimonialListArray = response.Data;

                    if (response.Data.length == 0) {
                        $('#nodata').show();
                    }else{
                        $('#nodata').hide();
                    }


                    $scope.SiteTestimonialModel.TestDetails = angular.copy($scope.SiteTestimonialModel.DefaultTestDetails);
                }else{
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }, 'Yes');
    }

    $scope.Save = function(){
        var postData = {};
        postData.Data = $scope.SiteTestimonialModel.TestDetails;


        


        var jsonData = angular.toJson(postData);
        if($scope.SiteTestimonialListForm.$valid){
            $scope.DisableButtons = true;
            AngularAjaxCall($http, $scope.SaveSiteTestimonialURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess){




                    ShowSuccessMessage(response.Message);
                    $scope.SiteTestimonialModel.SiteTestimonialListArray = response.Data;
                    $scope.SiteTestimonialListArray = response.Data;
                    $scope.SiteTestimonialListForm.$submitted = false;
                    $scope.SiteTestimonialModel.TestDetails = angular.copy($scope.SiteTestimonialModel.DefaultTestDetails);
                    $scope.DisableButtons = false;

                    if (response.Data.length == 0) {
                        $('#nodata').show();
                    }else{
                        $('#nodata').hide();
                    }
                    
                    //TODO: Check we can use below variable in Sortable List Directive
                    //$scope.ResetSortableRowWidth = true;
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    $scope.DisableButtons = false;
                }
            });
        }
    }



});


    

/*app.controller("SiteTestimonialListControllerController",function($scope,$http,$timeout){
    $scope.addSiteTestimonialListController = baseUrl+'/saveSiteTestimonialListController';
    $scope.SiteTestimonialListControllerModel = $.parseJSON($("#SiteTestimonialListControllerModel").val());
    $scope.RedirectURL = $scope.SiteTestimonialListControllerModel.encryptedSiteID;
    $scope.SortOrderSiteTestimonialListControllerURL = baseUrl+'/updatesortorderSiteTestimonialListController';
    $scope.SiteTestimonialListControllerDeleteURL = baseUrl+'/deleteSiteTestimonialListControllersdata';
    $scope.SiteID = $scope.SiteTestimonialListControllerModel.SiteID;
    $scope.AgentID = $scope.SiteTestimonialListControllerModel.AgentID;
    $scope.DisableButtons = false;
    //TODO: Check we can use below variable in Sortable List Directive
    //$scope.ResetSortableRowWidth = false;

    $scope.Save = function(){
        var postData = {};
        postData.Data = $scope.SiteTestimonialListControllerModel.TestDetails;
        var jsonData = angular.toJson(postData);
        if($scope.SiteTestimonialListControllerForm.$valid){
            $scope.DisableButtons = true;
            AngularAjaxCall($http, $scope.addSiteTestimonialListController, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess){
                    ShowSuccessMessage(response.Message);
                    $scope.SiteTestimonialListControllerModel.SiteTestimonialListControllerListArray = response.Data;
                    $scope.SiteTestimonialListControllerForm.$submitted = false;
                    $scope.SiteTestimonialListControllerModel.TestDetails = angular.copy($scope.SiteTestimonialListControllerModel.DefaultTestDetails);
                    $scope.DisableButtons = false;
                    //TODO: Check we can use below variable in Sortable List Directive
                    //$scope.ResetSortableRowWidth = true;
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    $scope.DisableButtons = false;
                }
            });
        }else{
            $timeout(function() {
                openErrorPortlets();
            });
        }
    }
    $scope.Cancel = function(){
        window.location.href = $scope.RedirectURL;
    }
    $scope.updateSortOrder = function(sourceIndex,newIndex){
        var postData = {};
        postData.Data = {};
        postData.Data.oldOrder = sourceIndex;
        postData.Data.newOrder = newIndex;
        postData.Data.AgentID = $scope.SiteTestimonialListControllerModel.AgentID;
        var jsonData = angular.toJson(postData);
        if((newIndex != undefined && sourceIndex != undefined ) && (newIndex !='' && newIndex != '' ) && ( sourceIndex != newIndex ) ) {
            AngularAjaxCall($http, $scope.SortOrderSiteTestimonialListControllerURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    ShowSuccessMessage(response.Message);
                }
            });
        }
    }
    $scope.EditSiteTestimonialListController = function(data){
        $scope.SiteTestimonialListControllerModel.TestDetails = data;
        $('#SiteTestimonialListController').focus();
    }
    $scope.DeleteSiteTestimonialListController = function(data) {
        ShowConfirm("this SiteTestimonialListController?", function () {
            var postData = {};
            postData.Data = {};
            postData.Data.SiteTestimonialListControllerID = data.SiteTestimonialListControllerID;
            postData.Data.SiteID = $scope.SiteTestimonialListControllerModel.SiteID;
            postData.Data.AgentID = $scope.SiteTestimonialListControllerModel.AgentID;
            var jsonData = angular.toJson(postData);
            AngularAjaxCall($http,$scope.SiteTestimonialListControllerDeleteURL,jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    ShowSuccessMessage(response.Message);
                    $scope.SiteTestimonialListControllerModel.SiteTestimonialListControllerListArray = response.Data;
                    $scope.SiteTestimonialListControllerModel.TestDetails = angular.copy($scope.SiteTestimonialListControllerModel.DefaultTestDetails);
                }else{
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }, 'Delete SiteTestimonialListController');
    }
});

*/