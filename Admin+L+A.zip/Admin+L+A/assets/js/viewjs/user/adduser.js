app.controller('UserController',function($scope,$http,$timeout){
    /* Redirect or Post Call URL */
    $scope.AddEditURL = baseUrl+'/saveuser';
    $scope.RedirectURL = baseUrl + '/users/';
    $scope.GetProfileImageUrl = baseUrl+'/getprofileimage';
    $scope.RemoveProfileImageURL = baseUrl+'/removeprofileimage';

    $scope.UserModel = $.parseJSON($("#UserModel").val());

    $scope.encryptedSiteID = $scope.UserModel.encryptedSiteID;
    $scope.RoleMVCOArray = $scope.UserModel.RoleMVCOArray;
    $scope.RoleRDWWArray = $scope.UserModel.RoleRDWWArray;
    $scope.UserModel = $scope.UserModel.UserDetails;
    $scope.DisableButtons = false;

    $scope.checkSave = function(yourForm) {
        checkValidationFocus(yourForm);
    };

    $scope.Cancel = function(){
        window.history.back();
    }

    $scope.AwsUploadBaseURL = $scope.UserModel.Fileuploadsettings.url;
    $scope.UserModel.NoImagePath = window.NoImagePath;


    /* For Save Form Data */
    $scope.Save = function () {
        if($scope.AddUserForm.$valid){
            if ($scope.UserModel.MVRole==undefined && $scope.UserModel.CORole == undefined && $scope.UserModel.WWRole==undefined && $scope.UserModel.RDRole== undefined){
                ShowAlertMessage(window.selectRole, 'error', window.ConfirmDialogSomethingWrong);
                return false;
            }
            $scope.DisableButtons = true;
            var postData = {};
            postData.Data = $scope.UserModel;
            var jsonData = angular.toJson(postData);
            AngularAjaxCall($http, $scope.AddEditURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess){
                    if(response.Data==1){
                        $scope.UserModel.Password = '';
                        $scope.UserModel.ConfirmPassword = '';
                        ShowSuccessMessage(response.Message);
                    }else{
                        SetMessageForPageLoad(response.Message);
                        window.location.href = $scope.RedirectURL.concat($scope.encryptedSiteID);
                    }
                    $scope.DisableButtons = false;
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    $scope.DisableButtons = false;
                }
            });
        }else{
            $timeout(function() {
                openErrorPortlets();
            });
        }
    }

    /* For Remove An Image */
    $scope.RemoveImage = function(data) {
        ShowConfirm("this Image?", function () {
            AngularAjaxCall($http, $scope.RemoveProfileImageURL, angular.toJson({ Data : {UserID: $scope.UserModel.UserID,ImageName: $scope.UserModel.ImageName} }), 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    $scope.UserModel.UploadFilesArray = $scope.UserModel.RealImagePath;
                    $scope.UserModel.RealImagePath = response.Data;
                    $scope.UserModel.IsImageRemoved = 1;
                    $scope.UserModel.ImageName ='';
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    $scope.DisableButtons = false;
                }
            });
        });
    };


    /* For Image Upload */
    $(document).ready(function() {
        var AwsSettingModel = $scope.UserModel.Fileuploadsettings;
        $('.direct-upload').each(function() {
            var form = $(this);
            var options ={
                successCallBack: function(new_filename){

                    AngularAjaxCall($http, $scope.GetProfileImageUrl,angular.toJson({ Data : {ImageName: new_filename,UserID: 0} }) , 'POST', 'json', 'application/json').success(function (response) {
                        if(true) {
                            var realImagePath = $scope.AwsUploadBaseURL + new_filename;
                            $scope.UserModel.ImageName = new_filename;
                            $scope.UserModel.RealImagePath = realImagePath;


                            $("#ImageError").removeClass("ValidationError").text("");
                            $('.progress').hide();
                            $('.bar').css('width', '0');
                            $("#btn-submit,.btn-submit").removeAttr('disabled');
                            $("#cancel").removeAttr('disabled');
                            $('.loadingImage').css('display', 'block');
                            $('#actualImage').on('load', function () {
                                $('.loadingImage').css('display', 'none');
                            });
                            $(".file").removeAttr('disabled');

                        }
                    });

                },
                AWSBaseURL: $scope.AwsUploadBaseURL,
                AWSSettingsModel:AwsSettingModel,
                form:form,
                AllwoedExts:uploadphotoexts,
                AlertMessage:window.ImageFileAllowedMessage,
                ResizeRequired:true ,
                progressCallback : function(){

                }
            };
            Awsfileupload(options);
        });
    });


});





