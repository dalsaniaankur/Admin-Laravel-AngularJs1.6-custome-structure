app.controller("UserListController", function ($scope, $http) {

    $scope.UserListURL = baseUrl + '/getuserlist'; // For URL
    $scope.EditUserURL = baseUrl + '/adduser/';
    $scope.DisableUserURL = baseUrl + '/disableuser';
    $scope.EnableUserURL = baseUrl + '/enableuser';

    $scope.UserList = []; //Define a blank Array

    $scope.ListModel = $.parseJSON($("#ListModel").val());

    $scope.RedirectToAdd = function () {
        location.href = $scope.EditUserURL + $scope.ListModel.encryptedSiteID;
    }

    $scope.ListPager = new PagerModule("LastName");//create a variable Listpager and set sortIndex userID by default into PagerModule function
    $scope.UserInfoList = function (setHistoryData) {  //Create a new UserListInfo function
        if (setHistoryData == undefined)
            setHistoryData = true;

        var pagermodel = { //Define and bind all value related to pagination,sorting and searching
            SearchParams: $scope.ListModel.backSearchModel,
            PageSize: $scope.ListPager.pageSize,
            PageIndex: $scope.ListPager.currentPage,
            SortIndex: $scope.ListPager.sortIndex,
            SortDirection: $scope.ListPager.sortDirection
        };
        var postData = {};
        postData.Data = $scope.UserList;
        var jsonData = angular.toJson({Data: pagermodel});//default data bind with pagermodel
        AngularAjaxCall($http, $scope.UserListURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
            if (response.IsSuccess) {
                $scope.UserList = response.Data.Items;
                if ($scope.UserList.length == 0) {
                    $('#nodata').show();
                } else {
                    $('#nodata').hide();
                }
                $scope.ListPager.totalRecords = response.Data.TotalItems; //bind total records into ListPager.totalRecords
                if (setHistoryData)
                    SetHistoryData(window.location.href, {
                        searchModel: $scope.ListModel.backSearchModel,
                        searchedCriteria: $scope.ListModel.backSearchModel,
                        pager: {
                            currentPage: $scope.ListPager.currentPage,
                            pageSize: $scope.ListPager.pageSize,
                            sortIndex: $scope.ListPager.sortIndex,
                            sortDirection: $scope.ListPager.sortDirection,
                            reverse: $scope.ListPager.reverse
                        },
                        setCriteria: 'SetCriteria'
                    }, document.title);
            }
        });
    };

    //For search records
    $scope.SearchUserRecords = function () {
        CopyProperties($scope.ListModel.frontSearchModel, $scope.ListModel.backSearchModel);
        $scope.ListPager.currentPage = 1;
        $scope.UserInfoList();
    };

    $scope.ListPager.getDataCallback = $scope.UserInfoList; // call function UserInfoList

    window.SetCriteria = function (data, pagerData) {

        $scope.ListModel.backSearchModel.Email = data.Email;
        $scope.ListModel.backSearchModel.LastName = data.LastName;
        $scope.ListModel.backSearchModel.RoleID = data.RoleID;
        $scope.ListModel.backSearchModel.SiteID = data.SiteID;
        $scope.ListModel.backSearchModel.StatusID = data.StatusID;

        $scope.ListModel.frontSearchModel.Email = data.Email;
        $scope.ListModel.frontSearchModel.LastName = data.LastName;
        $scope.ListModel.frontSearchModel.RoleID = data.RoleID;
        $scope.ListModel.frontSearchModel.SiteID = data.SiteID;
        $scope.ListModel.frontSearchModel.StatusID = data.StatusID;

        if (pagerData != undefined) {
            $scope.ListPager.currentPage = pagerData.currentPage;
            $scope.ListPager.sortDirection = pagerData.sortDirection;
            $scope.ListPager.sortIndex = pagerData.sortIndex;
            $scope.ListPager.pageSize = pagerData.pageSize;
            $scope.ListPager.reverse = pagerData.reverse;
        }
        $scope.ListPager.getDataCallback(false);
    }

    if (window.History.getState().data.param != undefined) {

        SetParamData();
        //$scope.ListPager.getDataCallback(false);
    }
    else {
        $scope.ListPager.getDataCallback(); // call getDataCallback function
    }


    /* For Edit User Link set*/
    $scope.EditUser = function (Data) {
        location.href = $scope.EditUserURL + Data.EncryptedSiteUserID;
    }

    $scope.DisableUser = function (Data) {
        var postData = {};
        postData.Data = Data;
        var jsonData = angular.toJson(postData);
        window.Confirmdialogmessage = window.DisabledConfirmation;
        ShowConfirm(" " + "'" + Data.Name + "' ?", function () {
            AngularAjaxCall($http, $scope.DisableUserURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    $scope.UserInfoList();
                    ShowSuccessMessage(response.Message);
                }
            });
        });
    };

     $scope.EnableUser = function(Data){
     var postData = {};
     postData.Data = Data;
    //window.Confirmdialogmessage = window.EnabledConfirmation;
     var jsonData = angular.toJson(postData);
        // ShowConfirm(" " + "'" + Data.Name + "' ?", function () {
                AngularAjaxCall($http,$scope.EnableUserURL, jsonData, 'POST','json','application/json').success(function (response) {
                    if(response.IsSuccess){
                        $scope.UserInfoList();
                        ShowSuccessMessage(response.Message);
                     }
                });
        // });
     };


});