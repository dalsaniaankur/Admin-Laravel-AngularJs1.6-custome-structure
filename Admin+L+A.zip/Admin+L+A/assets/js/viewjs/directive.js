﻿app.directive('datepicker', function () {
    return {
        restrict: 'A',
        scope: {
            ngDateval: "=",
            ngMaxdate: "=",
            ngMindate: "="
        },
        link: function (scope, element, attrs) {

            $(element).datepicker(
                {
                    format: 'mm/dd/yyyy',

                    endDate: moment(scope.ngMaxdate, "MM/DD/YYYY").toDate(),
                    autoclose: !0

                }
            );

            if (scope.ngMindate != undefined) {
                $(element).datepicker('setStartDate', moment(scope.ngMindate, "MM/DD/YYYY").toDate());

                scope.$watch('ngMindate', function (value, oldvalue) {
                    if (value != null && new Date(value) != 'Invalid Date') {

                        $(element).datepicker('setStartDate', moment(value, "MM/DD/YYYY").toDate());
                    }
                    else {
                        $(element).datepicker('setStartDate', '');
                    }
                });
            }

            $(element).on('keypress', function (e) {
                var leng = $(this).val().length;

                var code;
                if (window.event) {
                    code = e.keyCode;
                } else {
                    code = e.which;
                }

                var allowedCharacters = [49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 47];
                var isValidInput = false;

                for (var i = allowedCharacters.length - 1; i >= 0; i--) {
                    if (allowedCharacters[i] == code) {
                        isValidInput = true;
                    }
                }


                if (isValidInput === false || /* Can only input 1,2,3,4,5,6,7,8,9 or - */
                    (code == 47 && (leng < 2 || leng > 5 || leng == 3 || leng == 4)) ||
                    ((leng == 2 || leng == 5) && code !== 47) || /* only can hit a - for 3rd pos. */
                    leng == 10) /* only want 10 characters "12-45-7890" */
                {
                    e.preventDefault();
                    return;
                }

            });

            scope.$watch('ngMaxdate', function (value, oldvalue) {
                if (value != null && new Date(value) != 'Invalid Date') {

                    $(element).datepicker('setEndDate', moment(value, "MM/DD/YYYY").toDate());
                }
                else {
                    $(element).datepicker('setEndDate', '');
                }
            });

        }
    };
});

app.directive('dropZone', function () {
    Dropzone.autoDiscover = false;
    return {
        scope: {
            ngAwsSettingsModel: "=",   // this variable used fro aws file upload setting.
            successCallback: "=",
            removeFile: "=",  // used for remove file.
            uploadFile: "=", //Used for store file after added into array.
            extType: "=",
            maxFiles: "=",
            requestCounter: "=",
            responseCounter: "=",
            uploadComplete: "=",
            uploadedFile: "=",   // get the list of uploaded file array during edit page.
            fileSizeExceeds: "@",  // for validation message of file size.
            invalidFileFormat: "@",  // for validation message of file type format.
            onFile: "=",   // for default file selection
            onFileLoad: "=",  // for default file selection.
            radioSelectValue: "=", // for select default radio
            allowSortable: "=", // for allowed file to sortable or not.
            sortableCallback: "=",
            fileName: "=",
            allowOrder: "=",  // user for save image in proper order.
            clearPreviousImages: "@" //to clear previous uploaded images, to show new one
        },
        link: function (scope, element, attrs) {
            if (scope.allowSortable == 1) {
                $(element[0]).sortable({
                    items: '.dz-preview',
                    cursor: 'move',
                    containment: '.dropzone',
                    connectWith: element[0],
                    start: function (event, body) {
                        startIndex = ($(body.item).index() - 1);
                        //console.log("start");
                    },
                    handle: '.sortable-handle',
                    stop: function (event, body) {
                        var newIndex = ($(body.item).index() - 1);
                        if (scope.sortableCallback != undefined)
                            scope.sortableCallback((startIndex), (newIndex));
                        //console.log("stop");
                    }
                });

            }

            /* For Default File Selection */
            if (scope.radioSelectValue != undefined) {
                $(element).on("click", ".IsDefaultImage", function () {
                    var fname = $(this).val();
                    scope.$apply(function () {
                        scope.radioSelectValue = fname;
                    });
                });
            }

            var previewNode = document.querySelector("#template"); // get the template of dropzone.
            previewNode.id = "";
            var previewTemplate = previewNode.parentNode.innerHTML;
            previewNode.parentNode.removeChild(previewNode);

            scope.fileCounter = 0;  // File counter variable used for validation in number of file upload
            var dropzone = element.dropzone({
                url: "jjj",
                maxFilesize: 100,
                maxFiles: scope.maxFiles,
                paramName: "uploadfile",
                maxThumbnailFilesize: 5,
                parallelUploads: 5,
                previewTemplate: previewTemplate,
                autoQueue: false, // Make sure the files aren't queued until manually added

                init: function () {

                    this.on('addedfile', function (file) {

                        // scope.$apply(function () {

                        var filename = file.name.split(".");
                        var ext = filename[filename.length - 1];
                        //var name=generateUUID(scope.ngAwsSettingsModel.enc_userid);
                        ext = ext.toLowerCase();
                        if (scope.extType.indexOf(ext) >= 0) { // For check file tye validations
                            if (scope.uploadFile.length <= scope.maxFiles && scope.fileCounter < scope.maxFiles) { // Set file max size validations.
                                scope.fileCounter++;
                                var progressbardiv = $(file.previewElement).find("#totalprogressbar .progress-bar");
                                var progressbarparentdiv = $(file.previewElement).find("#totalprogressbar");
                                var cancelButton = file.previewElement.querySelector(".cancel");

                                // To exclude Mock File
                                if (!file.IsSavedInDB == 1 || !file.IsSavedInDB == 2) {
                                            var awsSettingModel = scope.ngAwsSettingsModel;
                                            var name = generateUUID(awsSettingModel.enc_userid);
                                            var new_filename = name + "." + ext;

                                            file.new_filename_search = awsSettingModel.folder + "/" + new_filename; //For used in remove file.

                                            var DefaultRadio = file.previewElement.querySelector(".IsDefaultImage"); // Used For Disabled/Enable Default Image Selection radio Button

                                            if (scope.allowSortable == 1 || scope.allowOrder == 1) {
                                                scope.fileName.push(new_filename);
                                            }

                                            /*if(scope.allowOrder == 1){
                                             scope.fileName(new_filename);
                                             }*/

                                            if (awsSettingModel.folder) {
                                                new_filename = awsSettingModel.folder + "/" + new_filename;

                                                /**---------------Upload to amazone Start---------------**/
                                                var fd = new FormData();
                                                fd.append('key', new_filename);
                                                fd.append('acl', awsSettingModel.acl);
                                                //fd.append('Content-Type', file.type);
                                                fd.append('AWSAccessKeyId', awsSettingModel.accesskey);
                                                fd.append('policy', awsSettingModel.base64Policy);
                                                fd.append('signature', awsSettingModel.signature);
                                                fd.append('success_action_status', awsSettingModel.success_action);
                                                fd.append('Cache-Control',awsSettingModel.cacheControlTime);
                                                fd.append("file", file);


                                                var xhr = new XMLHttpRequest();
                                                xhr.upload.addEventListener("progress", function (oEvent) {
                                                    /**-------Uploading In progress-------**/
                                                    var percent = Math.round((oEvent.loaded / oEvent.total) * 100);
                                                    //progressbardiv.style.width = percent + '%';
                                                    progressbardiv.width(percent + '%');
                                                }, false);


                                                xhr.addEventListener("load", function () {
                                                    /**-------Uploading Complete-------**/
                                                    progressbardiv.remove();
                                                    //progressbarparentdiv.style.background = "#85C220";
                                                    progressbarparentdiv.addClass('prg-green');



                                                    //document.querySelector("#total-progress").style.opacity = "0";
                                                    var CancelBtn = file.previewElement.querySelector(".btn.cancel");
                                                    $(CancelBtn).removeAttr('disabled');
                                                }, false);


                                                xhr.addEventListener("loadstart", function () {
                                                    $(cancelButton).addClass("uploadInProgress");
                                                    $(".sortable-handle").addClass("pointer-disable");

                                                    if (DefaultRadio)  /// Used For Disabled Default Image Selection radio Button
                                                        DefaultRadio.disabled = true;

                                                    var phase = scope.$root.$$phase;
                                                    if (phase == '$apply' || phase == '$digest') {
                                                        scope.requestCounter = scope.requestCounter + 1;  // For disable submit button
                                                    } else {
                                                        scope.$apply(function () {
                                                            scope.requestCounter = scope.requestCounter + 1; // For disable submit button
                                                        });
                                                    }
                                                });


                                                xhr.addEventListener("loadend", function (oEvent) {
                                                    $(cancelButton).removeClass("uploadInProgress");
                                                    $(".sortable-handle").removeClass("pointer-disable");

                                                    if (DefaultRadio) /// Used For Enable Default Image Selection radio Button
                                                        DefaultRadio.disabled = false;

                                                    var phase = scope.$root.$$phase;
                                                    if (phase == '$apply' || phase == '$digest') {
                                                        scope.responseCounter = scope.responseCounter + 1;  // For disable submit button
                                                    } else {
                                                        scope.$apply(function () {
                                                            scope.responseCounter = scope.responseCounter + 1; // For disable submit button
                                                        });
                                                    }

                                                    //var New_FileName = file.new_filename.substr(file.new_filename.lastIndexOf('/') + 1);

                                                    if (awsSettingModel.success_action == oEvent.currentTarget.status) {
                                                        scope.successCallback({
                                                            FilePath: new_filename,
                                                            FileName: file.name,
                                                            FileSize: file.size,
                                                            IsSavedInDB: 0
                                                            //Search_FileName:New_FileName
                                                        });// Store file in successCallback after successfully uploaded on amazone.
                                                        if (scope.onFile != undefined) {
                                                            scope.onFile({FileData: file, new_filename: new_filename});
                                                        }

                                                    } else {
                                                        if (progressbardiv != undefined) {
                                                            progressbardiv.remove();
                                                            if (progressbarparentdiv != undefined)
                                                            //progressbarparentdiv.style.backgroundColor="#e7505a";
                                                                progressbarparentdiv.addClass('prg-red');
                                                        }
                                                    }
                                                });


                                                xhr.addEventListener("error", function () {
                                                    /**-------Uploading Fail -------**/
                                                    progressbardiv.remove();
                                                    //progressbarparentdiv.style.backgroundColor="#e7505a";
                                                    progressbarparentdiv.addClass('prg-red');
                                                }, false);

                                                xhr.addEventListener("abort", function () {
                                                    /**----------Remove Uploading file-------**/
                                                    progressbardiv.remove();
                                                    //progressbarparentdiv.style.backgroundColor="#e7505a";
                                                    progressbarparentdiv.addClass('prg-red');
                                                }, false);

                                                xhr.open('POST', awsSettingModel.url, true); //MUST BE LAST LINE BEFORE YOU SEND

                                                $(file.previewElement.querySelector(".cancel")).click(function () {
                                                    if (xhr && xhr.readyState != 4) {
                                                        xhr.abort();
                                                    }
                                                });

                                                xhr.send(fd);
                                                /**---------------AJAX CALL to save file to amazone-------*/
                                                /**---------------Upload to amazone end---------------**/
                                            }
                                } else {
                                    if (scope.onFileLoad != undefined)
                                        scope.onFileLoad(file);  // used for default file selection functinality.
                                    progressbardiv.remove();
                                    //progressbarparentdiv.style.background = "#85C220";
                                    progressbarparentdiv.addClass('prg-green');
                                    //progressbardiv.style.width = '100%';
                                    progressbardiv.width('100%');
                                }

                            } else {
                                ShowAlertMessage(scope.fileSizeExceeds, 'error', window.ConfirmDialogSomethingWrong);
                                file.removeCallbackFlag = 0;
                                this.removeFile(file);
                            }
                            //});
                        } else {
                            ShowAlertMessage(scope.invalidFileFormat, 'error', window.ConfirmDialogSomethingWrong);
                            file.removeCallbackFlag = 0;
                            this.removeFile(file);
                        }

                    });

                    this.on('removedfile', function (file) {
                        if (file.removeCallbackFlag != 0) {
                            scope.removeFile(file.new_filename_search);
                            /*  scope.$apply(function () {
                             scope.fileCounter--;
                             });*/
                            var phase = scope.$root.$$phase;
                            if (phase == '$apply' || phase == '$digest') {
                                scope.fileCounter--;
                            } else {
                                scope.$apply(function () {
                                    scope.fileCounter--;
                                });
                            }
                        }
                    });

                }

            });

            /* Used for Preview Uploaded file in to dropzone section During EDIT page */
            scope.$watch(function(){return scope.uploadedFile} , function (newValue) {

                if (scope.uploadedFile != undefined) {

                    if(scope.clearPreviousImages != undefined && scope.clearPreviousImages == 'true')
                    {
                        // To clear all files instead of removing from database
                        $.each(dropzone[0].dropzone.files, function (key, value) {
                            value.removeCallbackFlag = 0;
                        });
                        dropzone[0].dropzone.removeAllFiles(true);
                        scope.uploadFile = [];
                        scope.fileCounter = 0;
                    }

                    $.each(scope.uploadedFile, function (key, value) {
                        if (scope.allowSortable == 1) {

                            if (scope.fileName == undefined)
                                scope.fileName = [];
                            scope.fileName.push(value.FilePath.split("/").pop(-1));

                        }

                        if (scope.uploadFile == undefined)
                            scope.uploadFile = [];
                        scope.uploadFile.push(value);


                        var mockFile = { name: value.FileName, size: value.FileSize, IsSavedInDB: value.IsSavedInDB,IsDefaultImage:value.IsDefaultImage,new_filename:value.FilePath,new_filename_search:value.FilePath};
                        // Call the default addedfile event handler
                        dropzone[0].dropzone.emit("addedfile", mockFile);

                        // And optionally show the thumbnail of the file:
                        var basePath = scope.ngAwsSettingsModel.url;  //set base path of aws
                        dropzone[0].dropzone.emit("thumbnail", mockFile, basePath.concat(value.FilePath));
                        dropzone[0].dropzone.emit("complete", mockFile);
                        dropzone[0].dropzone.files.push(mockFile);

                    });
                }
            });

        }
    };
});

app.directive('dropZoneWithExtraFields', function () {
    Dropzone.autoDiscover = false;
    return {
        scope: {
            ngAwsSettingsModel: "=",   // this variable used fro aws file upload setting.
            successCallback: "=",
            removeFile: "=",  // used for remove file.
            uploadFile: "=", //Used for store file after added into array.
            extType: "=",
            maxFiles: "=",
            requestCounter: "=",
            responseCounter: "=",
            uploadComplete: "=",
            uploadedFile: "=",   // get the list of uploaded file array during edit page.
            fileSizeExceeds: "@",  // for validation message of file size.
            invalidFileFormat: "@",  // for validation message of file type format.
            //propertyFile:"=",
            errorArray: "=",
            allowOrder: "=",  // user for save image in proper order.
            fileOrderName: "=",
            allowedWidth: "@",  // for validation fix Allowed Width  of file size.
            allowedHeight: "@",  // for validation fix Allowed Height  of file size.
            checkDimensionValidation: "=",  // for validation check true or false .
            dimensionErrorMessage: "@"  // for validation error message fix Allowed Height & width .

        },
        link: function (scope, element, attrs) {
            var previewNode = document.querySelector("#template"); // get the template of dropzone.
            previewNode.id = "";
            var previewTemplate = previewNode.parentNode.innerHTML;
            previewNode.parentNode.removeChild(previewNode);

            scope.fileCounter = 0;  // File counter variable used for validation in number of file upload
            var dropzone = element.dropzone({
                url: "jjj",
                maxFilesize: 100,
                maxFiles: scope.maxFiles,
                paramName: "uploadfile",
                maxThumbnailFilesize: 5,
                parallelUploads: 5,
                previewTemplate: previewTemplate,
                autoQueue: false, // Make sure the files aren't queued until manually added
                init: function () {

                    this.on('addedfile', function (file) {
                        var filename = file.name.split(".");
                        var ext = filename[filename.length - 1];
                        ext = ext.toLowerCase();

                        if (scope.extType.indexOf(ext) >= 0) { // For check file tye validations
                            if (scope.uploadFile.length <= scope.maxFiles && scope.fileCounter < scope.maxFiles) { // Set file max size validations.
                                scope.fileCounter++;
                                var progressbardiv = $(file.previewElement).find("#totalprogressbar .progress-bar");
                                var progressbarparentdiv = $(file.previewElement).find("#totalprogressbar");

                                // To exclude Mock File
                                if (!file.IsSavedInDB == 1 || !file.IsSavedInDB == 2) {
                                    var awsSettingModel = scope.ngAwsSettingsModel;
                                    var name = generateUUID(awsSettingModel.enc_userid);
                                    var new_filename = name + "." + ext;

                                    file.new_filename_search = awsSettingModel.folder + "/" + new_filename;

                                    if (scope.allowOrder == 1) {
                                        scope.fileOrderName.push(new_filename);  // set Image in proper order same as uploaded.
                                    }

                                    if (awsSettingModel.folder) {
                                        new_filename = awsSettingModel.folder + "/" + new_filename;

                                        /**---------------Upload to amazone Start---------------**/
                                        var fd = new FormData();
                                        fd.append('key', new_filename);
                                        fd.append('acl', awsSettingModel.acl);
                                        //fd.append('Content-Type', file.type);
                                        fd.append('AWSAccessKeyId', awsSettingModel.accesskey);
                                        fd.append('policy', awsSettingModel.base64Policy);
                                        fd.append('signature', awsSettingModel.signature);
                                        fd.append('success_action_status', awsSettingModel.success_action);
                                        fd.append('Cache-Control',awsSettingModel.cacheControlTime);
                                        fd.append("file", file);


                                        var xhr = new XMLHttpRequest();
                                        xhr.upload.addEventListener("progress", function (oEvent) {
                                            /**-------Uploading In progress-------**/
                                            var percent = Math.round((oEvent.loaded / oEvent.total) * 100);
                                            //progressbardiv.style.width = percent + '%';
                                            progressbardiv.width(percent + '%');
                                        }, false);


                                        xhr.addEventListener("load", function () {
                                            /**-------Uploading Complete-------**/
                                            progressbardiv.remove();
                                            //progressbarparentdiv.style.background = "#85C220";
                                            progressbarparentdiv.addClass('prg-green');

                                            //document.querySelector("#total-progress").style.opacity = "0";
                                            var CancelBtn = file.previewElement.querySelector(".btn.cancel");
                                            $(CancelBtn).removeAttr('disabled');
                                        }, false);


                                        xhr.addEventListener("loadstart", function () {
                                            var phase = scope.$root.$$phase;
                                            if (phase == '$apply' || phase == '$digest') {
                                                scope.requestCounter = scope.requestCounter + 1;  // For disable submit button
                                            } else {
                                                scope.$apply(function () {
                                                    scope.requestCounter = scope.requestCounter + 1; // For disable submit button
                                                });
                                            }
                                        });


                                        xhr.addEventListener("loadend", function (oEvent) {
                                            scope.$apply(function () {
                                                scope.responseCounter = scope.responseCounter + 1; // For disable submit button
                                            });

                                            var section = new_filename.substr(new_filename.lastIndexOf('/') + 1)
                                            var parts = section.match(/[^\.]+/);

                                            var titleEle = file.previewElement.querySelector("#PropertyFeaturesTitle .form-control");
                                            var titleClass = "title_" + parts[0];
                                            $(titleEle).addClass(titleClass);

                                            var descriptionEle = file.previewElement.querySelector("#PropertyFeaturesDescriptions .form-control");
                                            var descriptionClass = "description_" + parts[0];
                                            $(descriptionEle).addClass(descriptionClass);

                                            // var New_FileName = file.new_filename.substr(file.new_filename.lastIndexOf('/') + 1);

                                            if (awsSettingModel.success_action == oEvent.currentTarget.status) {
                                                scope.successCallback({
                                                    FilePath: new_filename,
                                                    FileName: file.name,
                                                    FileSize: file.size,
                                                    IsSavedInDB: 0,
                                                    TitleClass: titleClass,
                                                    DescriptionClass: descriptionClass
                                                    //   New_FileName:New_FileName
                                                });// Store file in successCallback after successfully uploaded on amazone.


                                            } else {
                                                if (progressbardiv != undefined) {
                                                    progressbardiv.remove();
                                                    if (progressbarparentdiv != undefined)
                                                    //progressbarparentdiv.style.backgroundColor="#e7505a";
                                                        progressbarparentdiv.addClass('prg-red');
                                                }
                                            }
                                        });


                                        xhr.addEventListener("error", function () {
                                            /**-------Uploading Fail -------**/
                                            progressbardiv.remove();
                                            //progressbarparentdiv.style.backgroundColor="#e7505a";
                                            progressbarparentdiv.addClass('prg-red');
                                        }, false);

                                        xhr.addEventListener("abort", function () {
                                            /**----------Remove Uploading file-------**/
                                            progressbardiv.remove();
                                            //progressbarparentdiv.style.backgroundColor="#e7505a";
                                            progressbarparentdiv.addClass('prg-red');
                                        }, false);

                                        xhr.open('POST', awsSettingModel.url, true); //MUST BE LAST LINE BEFORE YOU SEND

                                        $(file.previewElement.querySelector(".cancel")).click(function () {
                                            if (xhr && xhr.readyState != 4) {
                                                xhr.abort();
                                            }
                                        });

                                        xhr.send(fd);
                                        /**---------------AJAX CALL to save file to amazone-------*/
                                        /**---------------Upload to amazone end---------------**/
                                    }
                                } else {
                                    progressbardiv.remove();
                                    //progressbarparentdiv.style.background = "#85C220";
                                    progressbarparentdiv.addClass('prg-green');
                                    progressbardiv.width('100%');
                                }

                            } else {
                                    ShowAlertMessage(scope.fileSizeExceeds, 'error', window.ConfirmDialogSomethingWrong);
                                file.removeCallbackFlag = 0;
                                this.removeFile(file);
                            }
                            //});
                        } else {
                            ShowAlertMessage(scope.invalidFileFormat, 'error', window.ConfirmDialogSomethingWrong);
                            file.removeCallbackFlag = 0;
                            this.removeFile(file);
                        }

                    });
                    /* File Width and Height validation fix size */
                    this.on("thumbnail", function (file) {
                        if (!file.IsSavedInDB == 1 || !file.IsSavedInDB == 2) {
                            if ((scope.checkDimensionValidation != undefined && scope.checkDimensionValidation == 1) && (scope.allowedWidth != file.width || scope.allowedHeight != file.height)) {
                                ShowAlertMessage(scope.dimensionErrorMessage, 'error', window.ConfirmDialogSomethingWrong);
                                file.removeCallbackFlag = 0;
                                this.removeFile(file);
                            }
                        }
                    });

                    this.on('removedfile', function (file) {
                        if (file.removeCallbackFlag != 0) {
                            scope.removeFile(file);
                            scope.$apply(function () {
                                scope.fileCounter--;
                            });
                        }
                    });

                }
            });

            /* Used for Preview Uploaded file in to dropzone section During EDIT page */
            scope.$watch(function () {
                return scope.uploadedFile
            }, function (newValue) {
                scope.errorArray = [];
                if (scope.uploadedFile != undefined) {
                    $.each(scope.uploadedFile, function (key, value) {

                        if (scope.allowOrder == 1) {
                            if (scope.fileOrderName == undefined)
                                scope.fileOrderName = [];
                            scope.fileOrderName.push(value.FilePath.split("/").pop(-1));
                        }

                        if (scope.uploadFile == undefined)
                            scope.uploadFile = [];
                        scope.uploadFile.push(value);

                        var mockFile = {
                            name: value.FileName,
                            size: value.FileSize,
                            IsSavedInDB: value.IsSavedInDB,
                            IsDefaultImage: value.IsDefaultImage,
                            new_filename: value.FilePath,
                            title: value.Title,
                            new_filename_search: value.FilePath
                        };
                        // Call the default addedfile event handler
                        dropzone[0].dropzone.emit("addedfile", mockFile);

                        // And optionally show the thumbnail of the file:
                        var basePath = scope.ngAwsSettingsModel.url;  //set base path of aws
                        dropzone[0].dropzone.emit("thumbnail", mockFile, basePath.concat(value.FilePath));
                        dropzone[0].dropzone.emit("complete", mockFile);

                        new_filename = value.FilePath;
                        var section = new_filename.substr(new_filename.lastIndexOf('/') + 1)
                        var parts = section.match(/[^\.]+/);

                        var titleEle = mockFile.previewElement.querySelector("#PFTitle");
                        var titleClass = "title_" + parts[0];
                        $(titleEle).addClass(titleClass);
                        titleEle.value = value.Title;

                        var descriptionEle = mockFile.previewElement.querySelector("#PFDescription");
                        var descriptionClass = "description_" + parts[0];
                        $(descriptionEle).addClass(descriptionClass);
                        descriptionEle.value = value.Description;

                        this.TitleClass = titleClass;
                        this.DescriptionClass = descriptionClass;

                    });
                }
            });


        }
    };
});


/* Dev_AD Region Start */


app.directive('nxEqualEx', function () {
    return {
        require: 'ngModel',
        link: function (scope, elem, attrs, model) {
            if (!attrs.nxEqualEx) {
                console.error('nxEqualEx expects a model as an argument!');
                return;
            }
            scope.$watch(attrs.nxEqualEx, function (value) {
                // Only compare values if the second ctrl has a value.
                if (model.$viewValue !== undefined && model.$viewValue !== '') {
                    model.$setValidity('nxEqualEx', value === model.$viewValue);
                }
            });
            model.$parsers.push(function (value) {
                // Mute the nxEqual error if the second ctrl is empty.
                if (value === undefined || value === '') {
                    model.$setValidity('nxEqualEx', true);
                    return value;
                }
                var isValid = value === scope.$eval(attrs.nxEqualEx);
                model.$setValidity('nxEqualEx', isValid);
                return value;
            });
        }
    };
});


/*Start Dev_VA*/
app.directive('ckEditor', function () {
    return {
        require: '?ngModel',
        link: function (scope, elm, attr, ngModel) {
            var ck = CKEDITOR.replace(elm[0]);
            if (!ngModel) return;
            ck.on('instanceReady', function () {
                ck.setData(ngModel.$viewValue);
            });
            function updateModel() {
                setTimeout(function(){
                scope.$apply(function () {
                    ngModel.$setViewValue(ck.getData());
                });},10)
            }

            ck.on('change', updateModel);
            ck.on('key', updateModel);
            ck.on('dataReady', updateModel);

            ngModel.$render = function (value) {
                ck.setData(ngModel.$viewValue);
            };
        }
    };
});
/*End Dev_VA*/

/* Dev_AD Region Start */

app.directive('sortableList', function () {
    return {
        restrict: 'A',
        scope: {
            sortableCallback: "=",
            sortableContainment: "@",
            sortableResetWidth: "@"

        },
        link: function (scope, element, attrs) {
            var sortablecontainment = ".sortable";
            if (scope.sortableContainment != undefined && scope.sortableContainment != null && scope.sortableContainment != '') {
                sortablecontainment = '.' + scope.sortableContainment;
            }
            var isPlaceholderWidthSet = false;
            var startIndex = -1;
            $(element[0]).sortable({
                items: 'tbody tr',
                connectWith: element[0],
                start: function (event, tbody) {
                    startIndex = ($(tbody.item).index() + 1);

                    if (!isPlaceholderWidthSet || scope.sortableResetWidth) {
                        $(tbody.item).addClass('exclude');
                        var totalColumnCount = $(tbody.item).children('td').length;
                        $(sortablecontainment + " tr:not(.exclude) td").each(function (index) {
                            var cell = $(this);
                            if (index < totalColumnCount)
                                $(tbody.item).children('td').eq(index).width(cell.width());
                            cell.width(cell.width());
                        });

                        $(tbody.item).removeClass('exclude');
                        $(sortablecontainment + ' > div').css('padding-bottom', $(sortablecontainment + " tr:last").height());
                        isPlaceholderWidthSet = true;

                        //TODO: Check if we can update its value from Add Agent -> Testimonials controller
                        // I tried lot, but sortableResetWidth is updating from Controller only first time.
                        /*scope.$apply(function () {
                         scope.sortableResetWidth = false;
                         });*/
                        //scope.$apply();
                    }
                },
                handle: '.sortable-handle',
                //placeholder: "tr.sortable-row",
                stop: function (event, tbody) {
                    var newIndex = ($(tbody.item).index() + 1);
                    if (scope.sortableCallback != undefined)
                        scope.sortableCallback((startIndex), (newIndex));
                },
                axis: 'y',
                //containment: ".sortable"
                containment: sortablecontainment
            });
        }
    }
});


app.directive('intype', function () {
    return {
        require: 'ngModel',
        restrict: 'A',
        scope: {
            intype: '@'
        },
        link: function (scope, element, attr, ngModelCtrl) {
            //To restrict space
            //attr.$set('ngTrim', "false");
            function from(text) {
                if (text) {

                    var regex = "";
                    switch (scope.intype) {
                        case 'digit':
                            regex = /[^0-9]/g;
                            break;
                        case 'alphaNumeric':
                            regex = /[^A-Za-z0-9]/g;
                            break;
                        case 'positiveNumeric':
                            regex = /[^0-9\.]/g;
                            break;
                        default:
                            regex = "";
                    }
                    if (regex != undefined && regex != "") {
                        var transformedInput = text.replace(regex, '');
                        if (transformedInput !== text) {
                            ngModelCtrl.$setViewValue(transformedInput);
                            ngModelCtrl.$render();
                        }
                        return transformedInput;

                    }
                    return undefined;
                }
                return "";
            }

            ngModelCtrl.$parsers.push(from);
        }
    };
});

app.directive('pwCheck', [function () {
    return {
        require: 'ngModel',
        link: function (scope, elem, attrs, ctrl) {
            var firstPassword = '#' + attrs.pwCheck;
            elem.add(firstPassword).on('keyup', function () {
                scope.$apply(function () {
                    var v = elem.val() === $(firstPassword).val();
                    ctrl.$setValidity('pwmatch', v);
                });
            });
        }
    }
}]);

app.directive('futureYearNotAllowed', [function () {
    return {
        require: 'ngModel',
        link: function (scope, elem, attrs, ctrl) {
            elem.on('keyup', function () {
                scope.$apply(function () {
                    var v = true;
                    if (elem.val() != undefined && elem.val().length == 4) {
                        var utcFullYear = new Date().getUTCFullYear();
                        v = (parseInt(elem.val()) <= parseInt(utcFullYear));
                    }
                    ctrl.$setValidity('invalidYear', v);
                });
            });
        }
    }
}]);

app.directive('remodeledYear', function () {
    return {
        require: 'ngModel',
        link: function (scope, elem, attrs, ctrl) {
            var yearBuiltElement = $('#' + attrs.remodeledYear);
            elem.add(yearBuiltElement).on('keyup', function () {
                scope.$apply(function () {
                    var v = true;
                    var yearBuiltValue = $(yearBuiltElement).val();
                    if( yearBuiltValue != undefined && yearBuiltValue.length == 4 && elem.val() != undefined && elem.val().length == 4){
                        var utcFullYear = new Date().getUTCFullYear();
                        v = ((parseInt(elem.val()) >= parseInt(yearBuiltValue)) && (parseInt(elem.val()) <= parseInt(utcFullYear)));
                    }
                    ctrl.$setValidity('invalidRemodeledYear', v);
                });
            });
        }
    }
});

app.directive('slug', function () {
    return {
        require: 'ngModel',
        restrict: 'A',
        scope: {
            slug: '=',
            ngModel: '=',
            isEdit: '=',
            allowedSlash: "="
        },

        link: function (scope, element, attr, ngModelCtrl) {

            /* Slug validation */
            function from(text) {
                if (text) {

                    //if(scope.allowedSlash ==1 && scope.allowedSlash !=undefined)
                        regex = /[^A-Za-z0-9-/][^\\ ]*/g;
                    //else
                        //regex = /[^A-Za-z0-9-]/g;

                    if (regex != undefined && regex != "") {
                        var transformedInput = text.trim().toLowerCase().replace(/\-\-+/g, "-").replace(regex, '').replace(/\/\/+/g, "/").replace(/^\//, '');
                        

                        //transformedInput = transformedInput.replace(/\/\/+/g, "/").replace(/^\//, '');
                        if (transformedInput !== text) {
                            ngModelCtrl.$setViewValue(transformedInput);
                            ngModelCtrl.$render();
                        }
                        return transformedInput;
                    }
                    return undefined;
                }
                return false;
            }

            ngModelCtrl.$parsers.push(from);

            /* Slug change value */
            scope.$watch('slug', function (newValue) {
                if (scope.isEdit == 0) {
                    if (newValue != undefined && newValue != '') {
                        //if(scope.allowedSlash ==1 && scope.allowedSlash !=undefined)
                            var newVal = newValue.toString().trim().toLowerCase().replace(/\s+/g, "-").replace(/[^\w\-\/]+/g, "").replace(/\-\-+/g, "-").replace(/^-+/, "").replace(/-+$/, "").replace(/\/\/+/g, "/").replace(/^\//, '');;
                            //newVal = newVal.replace(/^\//, '');
                        //else
                          //  var newVal = newValue.toString().trim().toLowerCase().replace(/\s+/g, "-").replace(/[^\w\-]+/g, "").replace(/\-\-+/g, "-").replace(/^-+/, "").replace(/-+$/, "");
                        scope.ngModel = newVal;
                    }
                    else
                        scope.ngModel = '';
                }
            });
        }
    };
});

app.directive('collapse', function () {
    return {
        restrict: 'A',
        scope: {
            collapse: '='
        },
        link: function (scope, element, attrs) {
            /* If check collapse or not load time. */
            if (scope.collapse != undefined && scope.collapse == true) {
                element.find(".tools a").removeClass("collapse").addClass("expand");
                element.closest(".portlet").children(".portlet-body").hide();
                ;
            }

            $(element).click(function (e) {
                e.preventDefault();
                var selfclick = $(this).find(".tools a");

                var el = $(selfclick).closest(".portlet").children(".portlet-body");
                if ($(selfclick).hasClass("collapse")) {
                    $(selfclick).removeClass("collapse").addClass("expand");
                    el.slideUp(200);
                } else {
                    $(selfclick).removeClass("expand").addClass("collapse");
                    el.slideDown(200);
                }
                e.stopPropagation();
            });
        }
    }
});

/* Dev_AS Region Start */
app.directive('tooltip', function () {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            $(element).tooltip();
        }
    }
});

/* Dev_AS Region End */

/* DEV_AYS Region Start */

app.directive('clearOther', function () {
    return {
        restrict: 'A',
        scope: {
            selectVal: '=',
            otherVal: '=',
            other: '='
        },
        link: function (scope, element, attr) {
            if(scope.otherVal != undefined && scope.selectVal!= undefined && scope.otherVal != null && scope.selectVal!= null) {
                scope.$watch('selectVal', function (newValue, oldValue) {
                    var exists = newValue.indexOf(scope.otherVal.toString());
                    if (exists == -1) {
                        scope.other = '';
                    }
                })
            }
        }
    }
});

/* DEV_AYS Region End */
app.directive('dropZone1', function () {
    Dropzone.autoDiscover = false;
    return {
        scope: {
            ngAwsSettingsModel: "=",   // this variable used fro aws file upload setting.
            successCallback: "=",
            removeFile: "=",  // used for remove file.
            uploadFile: "=", //Used for store file after added into array.
            extType: "=",
            maxFiles: "=",
            requestCounter: "=",
            responseCounter: "=",
            uploadComplete: "=",
            uploadedFile: "=",   // get the list of uploaded file array during edit page.
            fileSizeExceeds: "@",  // for validation message of file size.
            invalidFileFormat: "@",  // for validation message of file type format.
            onFile: "=",   // for default file selection
            onFileLoad: "=",  // for default file selection.
            radioSelectValue: "=", // for select default radio
            allowSortable: "=", // for allowed file to sortable or not.
            sortableCallback: "=",
            fileName: "=",
            allowOrder: "=",  // user for save image in proper order.
            clearPreviousImages: "@" //to clear previous uploaded images, to show new one
        },
        link: function (scope, element, attrs) {
            if (scope.allowSortable == 1) {
                $(element[0]).sortable({
                    items: '.dz-preview',
                    cursor: 'move',
                    containment: '.dropzone',
                    connectWith: element[0],
                    start: function (event, body) {
                        startIndex = ($(body.item).index() - 1);
                        //console.log("start");
                    },
                    handle: '.sortable-handle',
                    stop: function (event, body) {
                        var newIndex = ($(body.item).index() - 1);
                        if (scope.sortableCallback != undefined)
                            scope.sortableCallback((startIndex), (newIndex));
                        //console.log("stop");
                    }
                });

            }

            /* For Default File Selection */
            if (scope.radioSelectValue != undefined) {
                $(element).on("click", ".IsDefaultImage", function () {
                    var fname = $(this).val();
                    scope.$apply(function () {
                        scope.radioSelectValue = fname;
                    });
                });
            }

            var previewNode = document.querySelector("#template"); // get the template of dropzone.
            previewNode.id = "";
            var previewTemplate = previewNode.parentNode.innerHTML;
            previewNode.parentNode.removeChild(previewNode);

            scope.fileCounter = 0;  // File counter variable used for validation in number of file upload
            var dropzone = element.dropzone({
                url: "jjj",
                maxFilesize: 100,
                maxFiles: scope.maxFiles,
                paramName: "uploadfile",
                maxThumbnailFilesize: 5,
                parallelUploads: 5,
                previewTemplate: previewTemplate,
                autoQueue: false, // Make sure the files aren't queued until manually added

                init: function () {

                    this.on('addedfile', function (file) {
                        // scope.$apply(function () {
                        var filename = file.name.split(".");
                        var ext = filename[filename.length - 1];
                        //var name=generateUUID(scope.ngAwsSettingsModel.enc_userid);
                        ext = ext.toLowerCase();
                        if (scope.extType.indexOf(ext) >= 0) { // For check file tye validations
                            if (scope.uploadFile.length <= scope.maxFiles && scope.fileCounter < scope.maxFiles) { // Set file max size validations.
                                scope.fileCounter++;
                                var progressbardiv = $(file.previewElement).find("#totalprogressbar .progress-bar");
                                var progressbarparentdiv = $(file.previewElement).find("#totalprogressbar");
                                var cancelButton = file.previewElement.querySelector(".cancel");
                                // To exclude Mock File
                                if (!file.IsSavedInDB == 1 || !file.IsSavedInDB == 2) {
                                    var options = {
                                        file: file,
                                        callback: function (file) {
                                            var awsSettingModel = scope.ngAwsSettingsModel;
                                            var name = generateUUID(awsSettingModel.enc_userid);
                                            var new_filename = name + "." + ext;
                                            file.new_filename_search = awsSettingModel.folder + "/" + new_filename; //For used in remove file.

                                            var DefaultRadio = file.previewElement.querySelector(".IsDefaultImage"); // Used For Disabled/Enable Default Image Selection radio Button

                                            if (scope.allowSortable == 1 || scope.allowOrder == 1) {
                                                scope.fileName.push(new_filename);
                                            }

                                            /*if(scope.allowOrder == 1){
                                             scope.fileName(new_filename);
                                             }*/

                                            if (awsSettingModel.folder) {
                                                new_filename = awsSettingModel.folder + "/" + new_filename;

                                                /**---------------Upload to amazone Start---------------**/
                                                var fd = new FormData();
                                                fd.append('key', new_filename);
                                                fd.append('acl', awsSettingModel.acl);
                                                //fd.append('Content-Type', file.type);
                                                fd.append('AWSAccessKeyId', awsSettingModel.accesskey);
                                                fd.append('policy', awsSettingModel.base64Policy);
                                                fd.append('signature', awsSettingModel.signature);
                                                fd.append('success_action_status', awsSettingModel.success_action);
                                                fd.append('Cache-Control',awsSettingModel.cacheControlTime);
                                                fd.append("file", file);


                                                var xhr = new XMLHttpRequest();
                                                xhr.upload.addEventListener("progress", function (oEvent) {
                                                    /**-------Uploading In progress-------**/
                                                    var percent = Math.round((oEvent.loaded / oEvent.total) * 100);
                                                    //progressbardiv.style.width = percent + '%';
                                                    progressbardiv.width(percent + '%');
                                                }, false);


                                                xhr.addEventListener("load", function () {
                                                    /**-------Uploading Complete-------**/
                                                    progressbardiv.remove();
                                                    //progressbarparentdiv.style.background = "#85C220";
                                                    progressbarparentdiv.addClass('prg-green');


                                                    //document.querySelector("#total-progress").style.opacity = "0";
                                                    var CancelBtn = file.previewElement.querySelector(".btn.cancel");
                                                    $(CancelBtn).removeAttr('disabled');
                                                }, false);


                                                xhr.addEventListener("loadstart", function () {
                                                    $(cancelButton).addClass("uploadInProgress");
                                                    $(".sortable-handle").addClass("pointer-disable");

                                                    if (DefaultRadio)  /// Used For Disabled Default Image Selection radio Button
                                                        DefaultRadio.disabled = true;

                                                    var phase = scope.$root.$$phase;
                                                    if (phase == '$apply' || phase == '$digest') {
                                                        scope.requestCounter = scope.requestCounter + 1;  // For disable submit button
                                                    } else {
                                                        scope.$apply(function () {
                                                            scope.requestCounter = scope.requestCounter + 1; // For disable submit button
                                                        });
                                                    }
                                                });


                                                xhr.addEventListener("loadend", function (oEvent) {
                                                    $(cancelButton).removeClass("uploadInProgress");
                                                    $(".sortable-handle").removeClass("pointer-disable");

                                                    if (DefaultRadio) /// Used For Enable Default Image Selection radio Button
                                                        DefaultRadio.disabled = false;

                                                    var phase = scope.$root.$$phase;
                                                    if (phase == '$apply' || phase == '$digest') {
                                                        scope.responseCounter = scope.responseCounter + 1;  // For disable submit button
                                                    } else {
                                                        scope.$apply(function () {
                                                            scope.responseCounter = scope.responseCounter + 1; // For disable submit button
                                                        });
                                                    }

                                                    //var New_FileName = file.new_filename.substr(file.new_filename.lastIndexOf('/') + 1);

                                                    if (awsSettingModel.success_action == oEvent.currentTarget.status) {
                                                        scope.successCallback({
                                                            FilePath: new_filename,
                                                            FileName: file.name,
                                                            FileSize: file.size,
                                                            IsSavedInDB: 0
                                                            //Search_FileName:New_FileName
                                                        });// Store file in successCallback after successfully uploaded on amazone.
                                                        if (scope.onFile != undefined) {
                                                            scope.onFile({FileData: file, new_filename: new_filename});
                                                        }

                                                    } else {
                                                        if (progressbardiv != undefined) {
                                                            progressbardiv.remove();
                                                            if (progressbarparentdiv != undefined)
                                                            //progressbarparentdiv.style.backgroundColor="#e7505a";
                                                                progressbarparentdiv.addClass('prg-red');
                                                        }
                                                    }
                                                });


                                                xhr.addEventListener("error", function () {
                                                    /**-------Uploading Fail -------**/
                                                    progressbardiv.remove();
                                                    //progressbarparentdiv.style.backgroundColor="#e7505a";
                                                    progressbarparentdiv.addClass('prg-red');
                                                }, false);

                                                xhr.addEventListener("abort", function () {
                                                    /**----------Remove Uploading file-------**/
                                                    progressbardiv.remove();
                                                    //progressbarparentdiv.style.backgroundColor="#e7505a";
                                                    progressbarparentdiv.addClass('prg-red');
                                                }, false);

                                                xhr.open('POST', awsSettingModel.url, true); //MUST BE LAST LINE BEFORE YOU SEND

                                                $(file.previewElement.querySelector(".cancel")).click(function () {
                                                    if (xhr && xhr.readyState != 4) {
                                                        xhr.abort();
                                                    }
                                                });

                                                xhr.send(fd);
                                                /**---------------AJAX CALL to save file to amazone-------*/
                                                /**---------------Upload to amazone end---------------**/
                                            }
                                        }
                                    };
                                    ResizeFile(options);
                                } else {
                                    if (scope.onFileLoad != undefined)
                                        scope.onFileLoad(file);  // used for default file selection functinality.
                                    progressbardiv.remove();
                                    //progressbarparentdiv.style.background = "#85C220";
                                    progressbarparentdiv.addClass('prg-green');
                                    //progressbardiv.style.width = '100%';
                                    progressbardiv.width('100%');
                                }


                            } else {
                                ShowAlertMessage(scope.fileSizeExceeds, 'error', window.ConfirmDialogSomethingWrong);
                                file.removeCallbackFlag = 0;
                                this.removeFile(file);
                            }
                            //});
                        } else {
                            ShowAlertMessage(scope.invalidFileFormat, 'error', window.ConfirmDialogSomethingWrong);
                            file.removeCallbackFlag = 0;
                            this.removeFile(file);
                        }

                    });

                    this.on('removedfile', function (file) {
                        if (file.removeCallbackFlag != 0) {
                            scope.removeFile(file.new_filename_search);
                            /*  scope.$apply(function () {
                             scope.fileCounter--;
                             });*/
                            var phase = scope.$root.$$phase;
                            if (phase == '$apply' || phase == '$digest') {
                                scope.fileCounter--;
                            } else {
                                scope.$apply(function () {
                                    scope.fileCounter--;
                                });
                            }
                        }
                    });

                }

            });

            /* Used for Preview Uploaded file in to dropzone section During EDIT page */
            scope.$watch(function () {
                return scope.uploadedFile
            }, function (newValue) {

                if (scope.uploadedFile != undefined) {

                    if (scope.clearPreviousImages != undefined && scope.clearPreviousImages == 'true') {
                        // To clear all files instead of removing from database
                        $.each(dropzone[0].dropzone.files, function (key, value) {
                            value.removeCallbackFlag = 0;
                        });
                        dropzone[0].dropzone.removeAllFiles(true);
                        scope.uploadFile = [];
                        scope.fileCounter = 0;
                    }

                    $.each(scope.uploadedFile, function (key, value) {
                        if (scope.allowSortable == 1) {

                            if (scope.fileName == undefined)
                                scope.fileName = [];
                            scope.fileName.push(value.FilePath.split("/").pop(-1));

                        }

                        if (scope.uploadFile == undefined)
                            scope.uploadFile = [];
                        scope.uploadFile.push(value);


                        var mockFile = {
                            name: value.FileName,
                            size: value.FileSize,
                            IsSavedInDB: value.IsSavedInDB,
                            IsDefaultImage: value.IsDefaultImage,
                            new_filename: value.FilePath,
                            new_filename_search: value.FilePath
                        };
                        // Call the default addedfile event handler
                        dropzone[0].dropzone.emit("addedfile", mockFile);

                        // And optionally show the thumbnail of the file:
                        var basePath = scope.ngAwsSettingsModel.url;  //set base path of aws
                        dropzone[0].dropzone.emit("thumbnail", mockFile, basePath.concat(value.FilePath));
                        dropzone[0].dropzone.emit("complete", mockFile);
                        dropzone[0].dropzone.files.push(mockFile);

                    });
                }
            });

        }
    };
});