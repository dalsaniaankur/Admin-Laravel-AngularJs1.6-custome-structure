app.controller('LandingPageController',function($scope,$http,$timeout) {
    $scope.LandingPageModel = $.parseJSON($("#LandingPageModel").val());
    $scope.LandingPageModel.NoImagePath = window.NoImagePath;

    $scope.LandingPageImageUrl = baseUrl+'/landingpageimage';

    /* For Remove An Image */
    $scope.RemoveLandingPageImageURL = baseUrl + '/removelandingpageimage';

    $scope.RemoveImage = function(data) {
        ShowConfirm("this Image?", function () {
            var tempSearch = data.ImagePath;
            AngularAjaxCall($http, $scope.RemoveLandingPageImageURL, angular.toJson({ Data : {fileObject: data} }), 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    var fileToRemove = SearchArrayByPropertyValueImage($scope.LandingPageModel.PageData,tempSearch);
                    $scope.LandingPageModel.PageData[fileToRemove].ImagePath = null;
                    $scope.LandingPageModel.PageData[fileToRemove].RealImagePath = '';
                    ShowSuccessMessage(response.Message);
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        });
    };

    $scope.RemoveBottomImage = function(data) {
        ShowConfirm("this Image?", function () {
            var tempSearch = data.ImagePath;

            AngularAjaxCall($http, $scope.RemoveLandingPageImageURL, angular.toJson({ Data : {fileObject: data} }), 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    var fileToRemove = SearchArrayByPropertyValueImage($scope.LandingPageModel.PageRightBottomImageData,tempSearch);
                    $scope.LandingPageModel.PageRightBottomImageData[fileToRemove].ImagePath = null;
                    $scope.LandingPageModel.PageRightBottomImageData[fileToRemove].RealImagePath = '';
                    ShowSuccessMessage(response.Message);
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        });
    };

    $scope.requestCounter = 0;
    $scope.responseCounter = 0;

    /* For Image Upload */
    $(document).ready(function() {
        var AwsSettingModel = $scope.LandingPageModel.FileUploadSettings;

        $('.direct-upload').each(function() {
            var form = $(this);

            var parentDiv =  $(form).parents('.fileinput');

            if(angular.element(this).scope().data.AllowedFixHeight){
                var AllowedFixHeight = angular.element(this).scope().data.AllowedFixHeight;
                var FixHeightMessage= angular.element(this).scope().data.HeightMessage;
            }

            if(angular.element(this).scope().data.AllowedFixWidth){
                var AllowedFixWidth = angular.element(this).scope().data.AllowedFixWidth;
                var FixWidthMessage= angular.element(this).scope().data.WidthMessage;
            }

            if((AllowedFixHeight != undefined && AllowedFixHeight != null && AllowedFixHeight != '' && AllowedFixHeight != 0 ) && (AllowedFixWidth != undefined && AllowedFixWidth != null && AllowedFixWidth != '' && AllowedFixWidth != 0)) {
                var FixHeightWidthMessage = angular.element(this).scope().data.HeightWidthMessage;
            }

            if(AllowedFixHeight != undefined || AllowedFixWidth != undefined){
                var checkForMaxDimensionsRequired = true;
            }else{
                var checkForMaxDimensionsRequired = false;
            }

            var fileAngObject  = angular.element(this).scope().data;
            var pageName = angular.element(this).scope().data.PageName;
            var options ={
                successCallBack: function(new_filename){

                    AngularAjaxCall($http,$scope.LandingPageImageUrl,angular.toJson({ Data : {ImagePath: new_filename,UserID: 2} }) , 'POST', 'json', 'application/json').success(function (response) {
                        if(true) {
                            var realImagePath = $scope.LandingPageModel.FileUploadSettings.url + new_filename;
                            fileAngObject.ImagePath = new_filename;
                            fileAngObject.RealImagePath = realImagePath;


                            $scope.responseCounter = $scope.responseCounter + 1;


                            $(parentDiv).find('#file').removeAttr('disabled');
                            $(parentDiv).find('.progress').hide();
                            $(parentDiv).find('.bar').css('width', '0');
                            $(parentDiv).find('#loadingImage').css('display', 'block');
                            $(parentDiv).find('#actualImage').on('load', function () {
                                $(parentDiv).find('#loadingImage').css('display', 'none');
                            });

                        }
                    });
                },
                AWSBaseURL: $scope.LandingPageModel.FileUploadSettings.url,
                AWSSettingsModel:AwsSettingModel,
                form:form,
                AllwoedExts:uploadphotoexts,
                AlertMessage:window.ImageFileAllowedMessage,
                ResizeRequired:false ,
                checkForMaxDimensionsRequired: checkForMaxDimensionsRequired,
                AllowedFixHeight: AllowedFixHeight,
                AllowedFixWidth: AllowedFixWidth,
                FixWidthMessage: FixWidthMessage,
                FixHeightMessage:FixHeightMessage,
                FixHeightWidthMessage: FixHeightWidthMessage,
                submitButtonClassOrId: "#btn-submit,#btn-submit,#cancel",
                progressCallback : function(){

                },
                addCallback : function(){
                    $scope.requestCounter = $scope.requestCounter+1;
                }

            };
            Awsfileupload(options);
        });
    });


    /* Save Landing Page Images */
    $scope.SaveLandingPageImageURL = baseUrl+'/savelandingpageimage';
    $scope.Save = function() {
        var postData = {};
        postData.Data = $scope.LandingPageModel;
        var jsonData = angular.toJson(postData);
        AngularAjaxCall($http,$scope.SaveLandingPageImageURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
            if(response.IsSuccess){
                ShowSuccessMessage(response.Message);
            }else{
                ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
            }
        });
    }

    /* Cancel Redirect On dashboard */
    $scope.RedirectURL = baseUrl + '/dashboard';
    $scope.Cancel = function(){
        window.location.href = $scope.RedirectURL;
    }

});







