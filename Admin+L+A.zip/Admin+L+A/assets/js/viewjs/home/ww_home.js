app.controller('HomeController',function($scope,$http,$timeout) {
    $scope.HomeModel = $.parseJSON($("#HomeModel").val());
    $scope.HomeModel = $scope.HomeModel.HomeDetails;

    $scope.SaveHomePageURL = baseUrl+'/savewwhomepage';
    $scope.RemoveImageURL = baseUrl+'/wwhomeremoveimage';
    $scope.GetImageUrl = baseUrl+'/getimagewwhome';
    $scope.RedirectURL = baseUrl + '/dashboard';

    $scope.AwsUploadBaseURL = $scope.HomeModel.FileUploadSettings.url;
    $scope.HomeModel.NoImagePath = window.NoImagePath;

    $scope.DisableButtons = false;
    $scope.requestCounter = 0;
    $scope.responseCounter = 0;

    /* Recommended dimensions set */
    if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomeTopCTAImages']['Width'] != undefined){
        $scope.AllowedTopBlockImagesFixWidth = Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomeTopCTAImages']['Width'];
    }
    if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomeTopCTAImages']['Height'] != undefined){
        $scope.AllowedTopBlockImagesFixHeight = Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomeTopCTAImages']['Height'];
    }

    if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomeBottomCTAImages']['Width'] != undefined){
        $scope.AllowedBottomBlockImagesFixWidth = Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomeBottomCTAImages']['Width'];
    }
    if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomeBottomCTAImages']['Height'] != undefined){
        $scope.AllowedBottomBlockImagesFixHeight = Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomeBottomCTAImages']['Height'];
    }
    if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomeSliderImages']['Width'] != undefined){
        $scope.AllowedSliderImagesFixWidth = Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomeSliderImages']['Width'];
    }
    if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomeSliderImages']['Height'] != undefined){
        $scope.AllowedSliderImagesFixHeight = Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomeSliderImages']['Height'];
    }

    /* On Cancel button  */
    $scope.Cancel = function(){
        window.location.href = $scope.RedirectURL;
    }

    $(document).ready(function() {
        /* For image upload */
        var AwsSettingModel = $scope.HomeModel.FileUploadSettings;
        $('.direct-upload').each(function() {
            var imgType = $(this).attr('img-type');
            var form = $(this);
            var parentDiv =  $(form).parents('.fileinput');
            if(imgType != undefined && (imgType == window.WWHomeTopCTABlock1ImageType || imgType == window.WWHomeTopCTABlock1HoverImageType
                                        || imgType == window.WWHomeTopCTABlock2ImageType || imgType == window.WWHomeTopCTABlock2HoverImageType
                                        || imgType == window.WWHomeTopCTABlock3ImageType || imgType == window.WWHomeTopCTABlock3HoverImageType
                                        || imgType == window.WWHomeTopCTABlock4ImageType || imgType == window.WWHomeTopCTABlock4HoverImageType
                                        || imgType == window.WWHomeBottomCTABlock1ImageType || imgType == window.WWHomeBottomCTABlock2ImageType || imgType == window.WWHomeSliderImageType)){

                if(imgType == window.WWHomeTopCTABlock1ImageType || imgType == window.WWHomeTopCTABlock1HoverImageType
                    || imgType == window.WWHomeTopCTABlock2ImageType || imgType == window.WWHomeTopCTABlock2HoverImageType
                    || imgType == window.WWHomeTopCTABlock3ImageType || imgType == window.WWHomeTopCTABlock3HoverImageType
                    || imgType == window.WWHomeTopCTABlock4ImageType || imgType == window.WWHomeTopCTABlock4HoverImageType ){
                    var Images = "HomeTopCTAImages";
                }else if(imgType == window.WWHomeBottomCTABlock1ImageType || imgType == window.WWHomeBottomCTABlock2ImageType){
                    var Images = "HomeBottomCTAImages";
                }else if(imgType == window.WWHomeSliderImageType){
                    var Images = "HomeSliderImages";
                }

                if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['Height'] != undefined){
                    var AllowedFixHeight = Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['Height'];
                    var FixWidthMessage= Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['WidthMessage'];
                }
                if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['Width'] != undefined){
                    var AllowedFixWidth = Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['Width'];
                    var FixHeightMessage= Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['HeightMessage'];
                }
                if((AllowedFixHeight != undefined && AllowedFixHeight != null && AllowedFixHeight != '' && AllowedFixHeight != 0 ) && (AllowedFixWidth != undefined && AllowedFixWidth != null && AllowedFixWidth != '' && AllowedFixWidth != 0)) {
                    var FixHeightWidthMessage = Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['HeightWidthMessage'];
                }
                if(AllowedFixHeight != undefined || AllowedFixWidth != undefined){
                    var checkForMaxDimensionsRequired = true;
                }else{
                    var checkForMaxDimensionsRequired = false;
                }
            }
            var options ={
                successCallBack: function(new_filename, tempFileName){
                    AngularAjaxCall($http, $scope.GetImageUrl,angular.toJson({ Data : {ImageURL: new_filename,HomepageID: 0} }) , 'POST', 'json', 'application/json').success(function (response) {
                        if(true) {
                            var realImagePath = $scope.AwsUploadBaseURL + new_filename;
                            switch(imgType) {
                                case window.WWFacebookImageType:
                                    $scope.HomeModel.FacebookImagePath = new_filename;
                                    $scope.HomeModel.FacebookImageName = tempFileName;
                                    $scope.HomeModel.RealFacebookImagePath = realImagePath;
                                    break;
                                case window.WWTwitterImageType:
                                    $scope.HomeModel.TwitterImagePath = new_filename;
                                    $scope.HomeModel.TwitterImageName = tempFileName;
                                    $scope.HomeModel.RealTwitterImagePath = realImagePath;
                                    break;
                                case window.WWRichSnippetsImageType:
                                    $scope.HomeModel.RichSnippetImagePath = new_filename;
                                    $scope.HomeModel.RichSnippetImageName = tempFileName;
                                    $scope.HomeModel.RealRichSnippetImagePath = realImagePath;
                                    break;
                                case window.WWHomeTopCTABlock1ImageType:
                                    $scope.HomeModel.TopCTAImagePath1 = new_filename;
                                    $scope.HomeModel.TopCTAImageName1 = tempFileName;
                                    $scope.HomeModel.RealTopCTAImagePath1 = realImagePath;
                                    break;
                                case window.WWHomeTopCTABlock1HoverImageType:
                                    $scope.HomeModel.TopCTAHoverImagePath1 = new_filename;
                                    $scope.HomeModel.TopCTAHoverImageName1 = tempFileName;
                                    $scope.HomeModel.RealTopCTAHoverImagePath1 = realImagePath;
                                    break;
                                case window.WWHomeTopCTABlock2ImageType:
                                    $scope.HomeModel.TopCTAImagePath2 = new_filename;
                                    $scope.HomeModel.TopCTAImageName2 = tempFileName;
                                    $scope.HomeModel.RealTopCTAImagePath2 = realImagePath;
                                    break;
                                case window.WWHomeTopCTABlock2HoverImageType:
                                    $scope.HomeModel.TopCTAHoverImagePath2 = new_filename;
                                    $scope.HomeModel.TopCTAHoverImageName2 = tempFileName;
                                    $scope.HomeModel.RealTopCTAHoverImagePath2 = realImagePath;
                                    break;
                                case window.WWHomeTopCTABlock3ImageType:
                                    $scope.HomeModel.TopCTAImagePath3 = new_filename;
                                    $scope.HomeModel.TopCTAImageName3 = tempFileName;
                                    $scope.HomeModel.RealTopCTAImagePath3 = realImagePath;
                                    break;
                                case window.WWHomeTopCTABlock3HoverImageType:
                                    $scope.HomeModel.TopCTAHoverImagePath3 = new_filename;
                                    $scope.HomeModel.TopCTAHoverImageName3 = tempFileName;
                                    $scope.HomeModel.RealTopCTAHoverImagePath3 = realImagePath;
                                    break;
                                case window.WWHomeTopCTABlock4ImageType:
                                    $scope.HomeModel.TopCTAImagePath4 = new_filename;
                                    $scope.HomeModel.TopCTAImageName4 = tempFileName;
                                    $scope.HomeModel.RealTopCTAImagePath4 = realImagePath;
                                    break;
                                case window.WWHomeTopCTABlock4HoverImageType:
                                    $scope.HomeModel.TopCTAHoverImagePath4 = new_filename;
                                    $scope.HomeModel.TopCTAHoverImageName4 = tempFileName;
                                    $scope.HomeModel.RealTopCTAHoverImagePath4 = realImagePath;
                                    break;
                                case window.WWHomeBottomCTABlock1ImageType:
                                    $scope.HomeModel.BottomCTAImagePath1 = new_filename;
                                    $scope.HomeModel.BottomCTAImageName1 = tempFileName;
                                    $scope.HomeModel.RealBottomCTAImagePath1 = realImagePath;
                                    break;
                                case window.WWHomeBottomCTABlock2ImageType:
                                    $scope.HomeModel.BottomCTAImagePath2 = new_filename;
                                    $scope.HomeModel.BottomCTAImageName2 = tempFileName;
                                    $scope.HomeModel.RealBottomCTAImagePath2 = realImagePath;
                                    break;
                                case window.WWHomeSliderImageType:
                                    $scope.HomeModel.SliderImagePath = new_filename;
                                    $scope.HomeModel.SliderImageName = tempFileName;
                                    $scope.HomeModel.RealSliderImagePath = realImagePath;
                                    break;

                            }
                            $scope.responseCounter = $scope.responseCounter + 1;
                            $(parentDiv).find('#file').removeAttr('disabled');
                            $(parentDiv).find('.progress').hide();
                            $(parentDiv).find('.bar').css('width', '0');
                            $(parentDiv).find('#loadingImage').css('display', 'block');
                            $(parentDiv).find('#actualImage').on('load', function () {
                                $(parentDiv).find('#loadingImage').css('display', 'none');
                            });
                        }
                    });
                },
                AWSBaseURL: $scope.AwsUploadBaseURL,
                AWSSettingsModel:AwsSettingModel,
                form:form,
                AllwoedExts:uploadphotoexts,
                AlertMessage:window.ImageFileAllowedMessage,
                ResizeRequired:false,
                checkForMaxDimensionsRequired: checkForMaxDimensionsRequired,
                AllowedFixHeight: AllowedFixHeight,
                AllowedFixWidth: AllowedFixWidth,
                FixWidthMessage: FixWidthMessage,
                FixHeightMessage:FixHeightMessage,
                FixHeightWidthMessage: FixHeightWidthMessage,
                submitButtonClassOrId: "#submit-home,#cancel-home",
                progressCallback : function(){
                },
                addCallback : function(){
                    $scope.requestCounter = $scope.requestCounter+1;
                }
            };

            Awsfileupload(options);
        });

    });

    /* Check save error focus */
    $scope.checkSave = function(yourForm) {
        checkValidationFocus(yourForm);
    };

    $scope.RemoveImage = function(imageType) {
        var ImageURL ='';
        switch(imageType) {
            case window.WWFacebookImageType:
                ImageURL = $scope.HomeModel.FacebookImageName;
                break;
            case window.WWTwitterImageType:
                ImageURL = $scope.HomeModel.TwitterImageName;
                break;
            case window.WWRichSnippetsImageType:
                ImageURL = $scope.HomeModel.RichSnippetImageName;
                break;
            case window.WWHomeTopCTABlock1ImageType:
                ImageURL = $scope.HomeModel.TopCTAImageName1;
                break;
            case window.WWHomeTopCTABlock1HoverImageType:
                ImageURL = $scope.HomeModel.TopCTAHoverImageName1;
                break;
            case window.WWHomeTopCTABlock2ImageType:
                ImageURL = $scope.HomeModel.TopCTAImageName2;
                break;
            case window.WWHomeTopCTABlock2HoverImageType:
                ImageURL = $scope.HomeModel.TopCTAHoverImageName2;
                break;
            case window.WWHomeTopCTABlock3ImageType:
                ImageURL = $scope.HomeModel.TopCTAImageName3;
                break;
            case window.WWHomeTopCTABlock3HoverImageType:
                ImageURL = $scope.HomeModel.TopCTAHoverImageName3;
                break;
            case window.WWHomeTopCTABlock4ImageType:
                ImageURL = $scope.HomeModel.TopCTAImageName4;
                break;
            case window.WWHomeTopCTABlock4HoverImageType:
                ImageURL = $scope.HomeModel.TopCTAHoverImageName4;
                break;
            case window.WWHomeSliderImageType:
                ImageURL = $scope.HomeModel.SliderImageName;
                break;
        }
        ShowConfirm("this Image?", function () {
            AngularAjaxCall($http, $scope.RemoveImageURL, angular.toJson({ Data : {HomepageID: $scope.HomeModel.HomepageID, RemoveType: imageType, ImageURL: ImageURL} }), 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    if(response.Data == window.WWFacebookImageType) {
                        $scope.HomeModel.FacebookImagePath = '';
                        $scope.HomeModel.FacebookImageName = '';
                        $scope.HomeModel.RealFacebookImagePath = '';
                    }
                    if(response.Data == window.WWTwitterImageType) {
                        $scope.HomeModel.TwitterImagePath = '';
                        $scope.HomeModel.TwitterImageName = '';
                        $scope.HomeModel.RealTwitterImagePath = '';
                    }
                    if(response.Data == window.WWRichSnippetsImageType) {
                        $scope.HomeModel.RichSnippetImagePath = '';
                        $scope.HomeModel.RichSnippetImageName = '';
                        $scope.HomeModel.RealRichSnippetImagePath = '';
                    }

                    if(response.Data == window.WWHomeTopCTABlock1ImageType) {
                        $scope.HomeModel.TopCTAImagePath1 = '';
                        $scope.HomeModel.TopCTAImageName1 = '';
                        $scope.HomeModel.RealTopCTAImagePath1 = '';
                    }
                    if(response.Data == window.WWHomeTopCTABlock1HoverImageType) {
                        $scope.HomeModel.TopCTAHoverImagePath1 = '';
                        $scope.HomeModel.TopCTAHoverImageName1 = '';
                        $scope.HomeModel.RealTopCTAHoverImagePath1 = '';
                    }
                    if(response.Data == window.WWHomeTopCTABlock2ImageType) {
                        $scope.HomeModel.TopCTAImagePath2 = '';
                        $scope.HomeModel.TopCTAImageName2 = '';
                        $scope.HomeModel.RealTopCTAImagePath2 = '';
                    }
                    if(response.Data == window.WWHomeTopCTABlock2HoverImageType) {
                        $scope.HomeModel.TopCTAHoverImagePath2 = '';
                        $scope.HomeModel.TopCTAHoverImageName2 = '';
                        $scope.HomeModel.RealTopCTAHoverImagePath2 = '';
                    }
                    if(response.Data == window.WWHomeTopCTABlock3ImageType) {
                        $scope.HomeModel.TopCTAImagePath3 = '';
                        $scope.HomeModel.TopCTAImageName3 = '';
                        $scope.HomeModel.RealTopCTAImagePath3 = '';
                    }
                    if(response.Data == window.WWHomeTopCTABlock3HoverImageType) {
                        $scope.HomeModel.TopCTAHoverImagePath3 = '';
                        $scope.HomeModel.TopCTAHoverImageName3 = '';
                        $scope.HomeModel.RealTopCTAHoverImagePath3 = '';
                    }
                    if(response.Data == window.WWHomeTopCTABlock4ImageType) {
                        $scope.HomeModel.TopCTAImagePath4 = '';
                        $scope.HomeModel.TopCTAImageName4 = '';
                        $scope.HomeModel.RealTopCTAImagePath4 = '';
                    }
                    if(response.Data == window.WWHomeTopCTABlock4HoverImageType) {
                        $scope.HomeModel.TopCTAHoverImagePath4 = '';
                        $scope.HomeModel.TopCTAHoverImageName4 = '';
                        $scope.HomeModel.RealTopCTAHoverImagePath4 = '';
                    }

                    if(response.Data == window.WWHomeBottomCTABlock1ImageType) {
                        $scope.HomeModel.BottomCTAImagePath1 = '';
                        $scope.HomeModel.BottomCTAImageName1 = '';
                        $scope.HomeModel.RealBottomCTAImagePath1 = '';
                    }
                    if(response.Data == window.WWHomeBottomCTABlock2ImageType) {
                        $scope.HomeModel.BottomCTAImagePath2 = '';
                        $scope.HomeModel.BottomCTAImageName2 = '';
                        $scope.HomeModel.RealBottomCTAImagePath2 = '';
                    }
                    if(response.Data == window.WWHomeSliderImageType) {
                        $scope.HomeModel.SliderImagePath = '';
                        $scope.HomeModel.SliderImageName = '';
                        $scope.HomeModel.RealSliderImagePath = '';
                    }
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        });
    };
    /* Save Page */
    $scope.SaveHome = function() {
        if ($scope.HomeForm.$valid && $scope.FormImageTopBlock1.$valid && $scope.FormHoverImageTopBlock1.$valid
                                   && $scope.FormImageTopBlock2.$valid  && $scope.FormHoverImageTopBlock2.$valid
                                   && $scope.FormImageTopBlock3.$valid  && $scope.FormHoverImageTopBlock3.$valid
                                   && $scope.FormImageTopBlock4.$valid  && $scope.FormHoverImageTopBlock4.$valid
                                   && $scope.FormImageBottomBlock1.$valid  && $scope.FormImageBottomBlock2.$valid && $scope.FormImageSlider.$valid ) {
            $scope.DisableButtons = true;
            var postData = {};
            postData.Data = $scope.HomeModel;
            var jsonData = angular.toJson(postData);
            AngularAjaxCall($http,$scope.SaveHomePageURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    ShowSuccessMessage(response.Message);
                    $scope.DisableButtons = false;
                }else{
                    $scope.DisableButtons = false;
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }else{
            $timeout(function() {
                openErrorPortlets();
            });
        }
    }
});

/*app.controller('SliderController',function($scope,$http,$timeout) {
    $scope.SliderModel = $.parseJSON($("#SliderModel").val());
    $scope.SliderListArray = $scope.SliderModel.SliderListArray;
    $scope.GetImageUrl = baseUrl+'/getsliderimage';
    $scope.DeleteSliderURL = baseUrl+'/deletesliderww'; // For URL
    $scope.AddSliderURL = baseUrl + '/savesliderww';
    $scope.SortOrderSliderURL = baseUrl+'/updatesortordersliderww';
    $scope.RemoveSliderImageURL = baseUrl+'/removesliderimageww';
    $scope.AwsUploadBaseURL = $scope.SliderModel.FileUploadSettings.url;

    $scope.SliderModel.Slider = { RealBackgroundImagePath:'',IsLight: 0};
    $scope.DisableButtons = false;
    $scope.SliderModel.NoImagePath = window.NoImagePath;

    if((Window.ImageResitrictions[$scope.SliderModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.SliderModel.SiteID]['HomePageSliderImage']['Height'] != undefined){
        $scope.AllowedSliderFixHeight = Window.ImageResitrictions[$scope.SliderModel.SiteID]['HomePageSliderImage']['Height'];
    }
    if((Window.ImageResitrictions[$scope.SliderModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.SliderModel.SiteID]['HomePageSliderImage']['Width'] != undefined){
        $scope.AllowedSliderFixWidth = Window.ImageResitrictions[$scope.SliderModel.SiteID]['HomePageSliderImage']['Width'];
    }
    *//* set validation focus *//*
    $scope.checkSaveSlider = function(yourForm) {
        checkValidationFocus(yourForm);
    };

    *//* SortOrder update *//*
    $scope.updateSortOrderSlider = function(sourceIndex,newIndex){
        var postData = {};
        postData.Data = {};
        postData.Data.OldOrder = sourceIndex;
        postData.Data.newOrder = newIndex;
        var jsonData = angular.toJson(postData);
        if((newIndex != undefined && sourceIndex != undefined ) && (newIndex !='' && newIndex != '' ) && ( sourceIndex != newIndex ) ) {
            AngularAjaxCall($http, $scope.SortOrderSliderURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    ShowSuccessMessage(response.Message);
                }
            });
        }
    }

    *//* For Edit Slider  set *//*
    $scope.EditSlider = function(Data) {
        $scope.SliderModel.Slider = angular.copy(Data);
        $('#SliderTitle').focus();
    }

    *//*  Delete Slider *//*
    $scope.DeleteSlider = function(data) {
        ShowConfirm("this Slider?", function () {
            var postData = { Data: data.HomePageSliderID };
            AngularAjaxCall($http,$scope.DeleteSliderURL,angular.toJson(postData), 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    $scope.SliderListArray = response.Data.SliderListArray;
                    $scope.SliderModel.Slider = [];
                    $scope.SliderModel.Slider = { RealBackgroundImagePath:'',IsLight: 0};
                    $('#SliderTitle').focus();
                    ShowSuccessMessage(response.Message);
                }else{
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }, 'Yes');
    }

    *//* Slider cancel button *//*
    $scope.CancelSlider = function(){
        $scope.SliderForm.$submitted = false;
        $scope.SliderModel.Slider = [];
        $scope.SliderModel.Slider = { RealBackgroundImagePath:'',IsLight: 0};
        $('#SliderTitle').focus();
    }

    *//* For image upload *//*
    $(document).ready(function() {
        var AwsSettingModel = $scope.SliderModel.FileUploadSettings;
        $('.direct-upload-slider').each(function() {
            var form = $(this);
            var parentDiv =  $(form).parents('.fileinput');
            var Images = "HomePageSliderImage";

            if((Window.ImageResitrictions[$scope.SliderModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.SliderModel.SiteID][Images]['Height'] != undefined){
                var AllowedFixHeight = Window.ImageResitrictions[$scope.SliderModel.SiteID][Images]['Height'];
                var FixWidthMessage= Window.ImageResitrictions[$scope.SliderModel.SiteID][Images]['WidthMessage'];
            }
            if((Window.ImageResitrictions[$scope.SliderModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.SliderModel.SiteID][Images]['Width'] != undefined){
                var AllowedFixWidth = Window.ImageResitrictions[$scope.SliderModel.SiteID][Images]['Width'];
                var FixHeightMessage= Window.ImageResitrictions[$scope.SliderModel.SiteID][Images]['HeightMessage'];
            }
            if((AllowedFixHeight != undefined && AllowedFixHeight != null && AllowedFixHeight != '' && AllowedFixHeight != 0 ) && (AllowedFixWidth != undefined && AllowedFixWidth != null && AllowedFixWidth != '' && AllowedFixWidth != 0)) {
                var FixHeightWidthMessage = Window.ImageResitrictions[$scope.SliderModel.SiteID][Images]['HeightWidthMessage'];
            }
            if(AllowedFixHeight != undefined || AllowedFixWidth != undefined){
                var checkForMaxDimensionsRequired = true;
            }else{
                var checkForMaxDimensionsRequired = false;
            }

            var options ={
                successCallBack: function(new_filename, tempFileName){
                    AngularAjaxCall($http, $scope.GetImageUrl,angular.toJson({ Data : {ImageURL: new_filename, HomepageID: 0} }) , 'POST', 'json', 'application/json').success(function (response) {
                        if(true) {
                            var realImagePath = $scope.AwsUploadBaseURL + new_filename;
                            $scope.SliderModel.Slider.BackgroundImagePath = new_filename;
                            $scope.SliderModel.Slider.BackgroundImageName = tempFileName;
                            $scope.SliderModel.Slider.RealBackgroundImagePath = realImagePath;
                            $(parentDiv).find('#file').removeAttr('disabled');
                            $(parentDiv).find('.progress').hide();
                            $(parentDiv).find('.bar').css('width', '0');
                            $(parentDiv).find('#loadingImage').css('display', 'block');
                            $(parentDiv).find('#actualImage').on('load', function () {
                                $(parentDiv).find('#loadingImage').css('display', 'none');
                            });
                        }
                    });
                },
                AWSBaseURL: $scope.AwsUploadBaseURL,
                AWSSettingsModel:AwsSettingModel,
                form:form,
                AllwoedExts:uploadphotoexts,
                AlertMessage:window.ImageFileAllowedMessage,
                ResizeRequired:false,
                checkForMaxDimensionsRequired: checkForMaxDimensionsRequired,
                AllowedFixHeight: AllowedFixHeight,
                AllowedFixWidth: AllowedFixWidth,
                FixWidthMessage: FixWidthMessage,
                FixHeightMessage:FixHeightMessage,
                FixHeightWidthMessage: FixHeightWidthMessage,
                submitButtonClassOrId: "#submit-slider,#cancel-slider",
                progressCallback : function(){

                }
            };

            Awsfileupload(options);
        });
    });

    *//* Remove Image *//*
    $scope.RemoveImage = function() {
        var ImageURL =  $scope.SliderModel.Slider.BackgroundImagePath;
        ShowConfirm("this Image?", function () {
            AngularAjaxCall($http, $scope.RemoveSliderImageURL, angular.toJson({ Data : {HomepageID: $scope.SliderModel.Slider.HomePageSliderID ? $scope.SliderModel.Slider.HomePageSliderID : 0, RemoveType: 1, ImageURL: ImageURL} }), 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    $scope.SliderModel.Slider.BackgroundImagePath = '';
                    $scope.SliderModel.Slider.BackgroundImageName = '';
                    $scope.SliderModel.Slider.RealBackgroundImagePath = '';
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        });
    };

    *//* Add Slider *//*
    $scope.SaveSlider = function() {
        if ($scope.SliderForm.$valid && $scope.FormSliderImage.$valid) {
            $scope.DisableButtons = true;
            var postData = {};
            postData.Data = $scope.SliderModel.Slider;
            var jsonData = angular.toJson(postData);
            AngularAjaxCall($http,$scope.AddSliderURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    $scope.SliderListArray = response.Data.SliderListArray;
                    $scope.SliderForm.$submitted = false;
                    $scope.SliderModel.Slider = [];
                    $scope.SliderModel.Slider = { RealBackgroundImagePath:'',IsLight: 0};
                    $('#Header').focus();
                    ShowSuccessMessage(response.Message);
                    $scope.DisableButtons = false;
                }else{
                    $scope.DisableButtons = false;
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });

        }else{
            $timeout(function() {
                openErrorPortlets();
            });
        }
    }
});*/
