app.controller('HomeController',function($scope,$http,$timeout) {

    $scope.HomeModel = $.parseJSON($("#HomeModel").val());
    $scope.HomeModel = $scope.HomeModel.HomeDetails;

    $scope.SaveHomePageURL = baseUrl+'/savecohomepage';
    $scope.GetImageUrl = baseUrl+'/gethoverimage';
    $scope.RedirectURL = baseUrl + '/dashboard';
    $scope.RemoveHoverImageURL = baseUrl+'/removehoverimage';
    $scope.DeletevideoURL = baseUrl+'/deletehomevideo';

    $scope.requestCounter = 0;
    $scope.responseCounter = 0;
    $scope.AwsUploadBaseURL = $scope.HomeModel.FileUploadSettings.url;
    $scope.HomeModel.NoImagePath = window.NoImagePath;
    $scope.DisableButtons = false;

    /* Recommended dimensions set */
    if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomeTopCTAImages']['Height'] != undefined){
        $scope.AllowedTopBlockImagesFixHeight = Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomeTopCTAImages']['Height'];
    }
    if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomeTopCTAImages']['Width'] != undefined){
        $scope.AllowedTopBlockImagesFixWidth = Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomeTopCTAImages']['Width'];
    }

    if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomeBottomCTAImages']['Height'] != undefined){
        $scope.AllowedBottomBlockImagesFixHeight = Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomeBottomCTAImages']['Height'];
    }
    if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomeBottomCTAImages']['Width'] != undefined){
        $scope.AllowedBottomBlockImagesFixWidth = Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomeBottomCTAImages']['Width'];
    }

    if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomeVideoPoster']['Height'] != undefined){
        $scope.AllowedVideoPosterFixHeight = Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomeVideoPoster']['Height'];
    }
    if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomeVideoPoster']['Width'] != undefined){
        $scope.AllowedVideoPosterFixWidth = Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomeVideoPoster']['Width'];
    }

    /* Check save error focus */
    $scope.checkSave = function(yourForm) {
        checkValidationFocus(yourForm);
    };

    /* On Cancel button  */
     $scope.Cancel = function(){
        window.location.href = $scope.RedirectURL;
     }

    $(document).ready(function() {
        /* For image upload */
        var AwsSettingModel = $scope.HomeModel.FileUploadSettings;
        $('.direct-upload').each(function() {
            var imgType = $(this).attr('img-type');
            var form = $(this);
            var parentDiv =  $(form).parents('.fileinput');
            if(imgType != undefined && (imgType == window.COHomeTopCTABlock1ImageType || imgType == window.COHomeTopCTABlock2ImageType || imgType == window.COHomeBottomCTABlock1ImageType|| imgType == window.COHomeBottomCTABlock2ImageType || imgType == window.COHomeBottomCTABlock3ImageType  || imgType == window.COVideoPosterType)){
                if(imgType == window.COHomeTopCTABlock1ImageType || imgType == window.COHomeTopCTABlock2ImageType ){
                    var Images = "HomeTopCTAImages";
                }else if(imgType == window.COHomeBottomCTABlock1ImageType || imgType == window.COHomeBottomCTABlock2ImageType || imgType == window.COHomeBottomCTABlock3ImageType){
                    var Images = "HomeBottomCTAImages";
                }else if(imgType == window.COVideoPosterType) {
                    var Images = "HomeVideoPoster";
                }
                if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['Height'] != undefined){
                    var AllowedFixHeight = Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['Height'];
                    var FixWidthMessage= Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['WidthMessage'];
                }
                if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['Width'] != undefined){
                    var AllowedFixWidth = Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['Width'];
                    var FixHeightMessage= Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['HeightMessage'];
                }
                if((AllowedFixHeight != undefined && AllowedFixHeight != null && AllowedFixHeight != '' && AllowedFixHeight != 0 ) && (AllowedFixWidth != undefined && AllowedFixWidth != null && AllowedFixWidth != '' && AllowedFixWidth != 0)) {
                    var FixHeightWidthMessage = Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['HeightWidthMessage'];
                }
                if(AllowedFixHeight != undefined || AllowedFixWidth != undefined){
                    var checkForMaxDimensionsRequired = true;
                }else{
                    var checkForMaxDimensionsRequired = false;
                }
            }
            var options ={
                successCallBack: function(new_filename, tempFileName){
                    AngularAjaxCall($http, $scope.GetImageUrl,angular.toJson({ Data : {ImageURL: new_filename,HomepageID: 0} }) , 'POST', 'json', 'application/json').success(function (response) {
                        if(true) {
                            var realImagePath = $scope.AwsUploadBaseURL + new_filename;
                            switch(imgType) {
                                case window.COHomeFacebookImageType:
                                    $scope.HomeModel.FacebookImagePath = new_filename;
                                    $scope.HomeModel.FacebookImageName = tempFileName;
                                    $scope.HomeModel.RealFacebookImagePath = realImagePath;
                                    break;
                                case window.COHomeTwitterImageType:
                                    $scope.HomeModel.TwitterImagePath = new_filename;
                                    $scope.HomeModel.TwitterImageName = tempFileName;
                                    $scope.HomeModel.RealTwitterImagePath = realImagePath;
                                    break;
                                case window.COHomeRichSnippetsImageType:
                                    $scope.HomeModel.RichSnippetImagePath = new_filename;
                                    $scope.HomeModel.RichSnippetImageName = tempFileName;
                                    $scope.HomeModel.RealRichSnippetImagePath = realImagePath;
                                    break;
                                case window.COHomeTopCTABlock1ImageType:
                                    $scope.HomeModel.TopCTAImagePath1 = new_filename;
                                    $scope.HomeModel.TopCTAImageName1 = tempFileName;
                                    $scope.HomeModel.RealTopCTAImagePath1 = realImagePath;
                                    break;
                                case window.COHomeTopCTABlock2ImageType:
                                    $scope.HomeModel.TopCTAImagePath2 = new_filename;
                                    $scope.HomeModel.TopCTAImageName2 = tempFileName;
                                    $scope.HomeModel.RealTopCTAImagePath2 = realImagePath;
                                    break;
                                case window.COHomeBottomCTABlock1ImageType:
                                    $scope.HomeModel.BottomCTAImagePath1 = new_filename;
                                    $scope.HomeModel.BottomCTAImageName1 = tempFileName;
                                    $scope.HomeModel.RealBottomCTAImagePath1 = realImagePath;
                                    break;
                                case window.COHomeBottomCTABlock2ImageType:
                                    $scope.HomeModel.BottomCTAImagePath2 = new_filename;
                                    $scope.HomeModel.BottomCTAImageName2 = tempFileName;
                                    $scope.HomeModel.RealBottomCTAImagePath2 = realImagePath;
                                    break;
                                case window.COHomeBottomCTABlock3ImageType:
                                    $scope.HomeModel.BottomCTAImagePath3 = new_filename;
                                    $scope.HomeModel.BottomCTAImageName3 = tempFileName;
                                    $scope.HomeModel.RealBottomCTAImagePath3 = realImagePath;
                                    break;
                                case window.COVideoPosterType:
                                    $scope.HomeModel.VideoPosterPath = new_filename;
                                    $scope.HomeModel.VideoPosterName = tempFileName;
                                    $scope.HomeModel.RealVideoPosterPath = realImagePath;
                                    break;
                            }
                            $scope.responseCounter = $scope.responseCounter + 1;
                            $(parentDiv).find('#file').removeAttr('disabled');
                            $(parentDiv).find('.progress').hide();
                            $(parentDiv).find('.bar').css('width', '0');
                            $(parentDiv).find('#loadingImage').css('display', 'block');
                            $(parentDiv).find('#actualImage').on('load', function () {
                                $(parentDiv).find('#loadingImage').css('display', 'none');
                            });
                        }
                    });
                },
                AWSBaseURL: $scope.AwsUploadBaseURL,
                AWSSettingsModel:AwsSettingModel,
                form:form,
                AllwoedExts:uploadphotoexts,
                AlertMessage:window.ImageFileAllowedMessage,
                ResizeRequired:false,
                checkForMaxDimensionsRequired: checkForMaxDimensionsRequired,
                AllowedFixHeight: AllowedFixHeight,
                AllowedFixWidth: AllowedFixWidth,
                FixWidthMessage: FixWidthMessage,
                FixHeightMessage:FixHeightMessage,
                FixHeightWidthMessage: FixHeightWidthMessage,
                submitButtonClassOrId: "#submit-home,#cancel-home",
                progressCallback : function(){
                },
                addCallback : function(){
                    $scope.requestCounter = $scope.requestCounter+1;
                }
            };

            Awsfileupload(options);
        });

        /* For video upload */
        var AwsSettingModel = $scope.HomeModel.FileUploadSettings;
        $('.directuploadvideo').each(function() {
            var videoType = $(this).attr('video-type');
            var form = $(this);
            var parentDiv =  $(form).parents('.fileinput');
            switch(videoType) {
                case window.COHomeVideoMP4Type:
                    var Allwoeduploadvideoexts = uploadvideoMp4exts;
                    var VideoAlertMessage = window.VideoMP4FileAllowedMessage;
                    break;
                case window.COHomeVideoOggType:
                    var Allwoeduploadvideoexts = uploadvideoogexts;
                    var VideoAlertMessage = window.VideoOggFileAllowedMessage;
                    break;
                case window.COHomeVideoWebmType:
                    var Allwoeduploadvideoexts = uploadvideoWebmexts;
                    var VideoAlertMessage = window.VideoWebmFileAllowedMessage;
                    break;
            }
            var options ={
                successCallBack: function(new_filename, tempFileName){
                    AngularAjaxCall($http, $scope.GetImageUrl,angular.toJson({ Data : {ImageURL: new_filename,HomepageID: 0} }) , 'POST', 'json', 'application/json').success(function (response) {
                        if(true) {
                            var realImagePath = $scope.AwsUploadBaseURL + new_filename;
                            switch(videoType) {
                                case window.COHomeVideoMP4Type:
                                    $scope.HomeModel.MP4VideoURL = new_filename;
                                    $scope.HomeModel.MP4VideoName = tempFileName;
                                    $scope.HomeModel.RealMP4VideoPath = realImagePath;
                                    break;
                                case window.COHomeVideoOggType:
                                    $scope.HomeModel.OggVideoURL = new_filename;
                                    $scope.HomeModel.OggVideoName = tempFileName;
                                    $scope.HomeModel.RealOggVideoPath = realImagePath;
                                    break;
                                case window.COHomeVideoWebmType:
                                    $scope.HomeModel.WebmVideoURL = new_filename;
                                    $scope.HomeModel.WebmVideoName = tempFileName;
                                    $scope.HomeModel.RealWebmVideoPath = realImagePath;
                                    break;
                            }
                            $scope.responseCounter = $scope.responseCounter + 1;
                            $(parentDiv).find('#file').removeAttr('disabled');
                            $(parentDiv).find('.progress.video').hide();
                            $(parentDiv).find('#videobar').css('width', '0');
                            $("#btn-submit").removeAttr('disabled');
                            $("#cancel").removeAttr('disabled');
                        }
                    });
                },
                AWSBaseURL: $scope.AwsUploadBaseURL,
                AWSSettingsModel:AwsSettingModel,
                form:form,
                AllwoedExts:Allwoeduploadvideoexts,
                AlertMessage:VideoAlertMessage,
                maxFileSizeLimit:window.HomePageVideoMaxFileSize,
                maxFileSizeErrorMessage:window.HomePageVideoMaxFileSizeMessage,
                ResizeRequired:false,
                progressCallback : function(){
                },
                addCallback : function(){
                    $scope.requestCounter = $scope.requestCounter+1;
                }
            };
            Awsfileupload(options);
        });

});

    $scope.RemoveImage = function(imageType) {
        var ImageURL ='';
        switch(imageType) {
            case window.COHomeFacebookImageType:
                ImageURL = $scope.HomeModel.FacebookImageName;
                break;
            case window.COHomeTwitterImageType:
                ImageURL = $scope.HomeModel.TwitterImageName;
                break;
            case window.COHomeRichSnippetsImageType:
                ImageURL = $scope.HomeModel.RichSnippetImageName;
                break;
            case window.COHomeTopCTABlock1ImageType:
                ImageURL = $scope.HomeModel.TopCTAImageName1;
                break;
            case window.COHomeTopCTABlock2ImageType:
                ImageURL = $scope.HomeModel.TopCTAImageName2;
                break;
            case window.COHomeBottomCTABlock1ImageType:
                ImageURL = $scope.HomeModel.BottomCTAImageName1;
                break;
            case window.COHomeBottomCTABlock2ImageType:
                ImageURL = $scope.HomeModel.BottomCTAImageName2;
                break;
            case window.COHomeBottomCTABlock3ImageType:
                ImageURL = $scope.HomeModel.BottomCTAImageName3;
                break;
            case window.COVideoPosterType:
                ImageURL = $scope.HomeModel.VideoPosterName;
                break;
        }
        ShowConfirm("this Image?", function () {
            AngularAjaxCall($http, $scope.RemoveHoverImageURL, angular.toJson({ Data : {HomepageID: $scope.HomeModel.HomepageID, RemoveType: imageType, ImageURL: ImageURL} }), 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    if(response.Data == window.COHomeFacebookImageType) {
                        $scope.HomeModel.FacebookImagePath = '';
                        $scope.HomeModel.FacebookImageName = '';
                        $scope.HomeModel.RealFacebookImagePath = '';
                    }
                    if(response.Data == window.COHomeTwitterImageType) {
                        $scope.HomeModel.TwitterImagePath = '';
                        $scope.HomeModel.TwitterImageName = '';
                        $scope.HomeModel.RealTwitterImagePath = '';
                    }
                    if(response.Data == window.COHomeRichSnippetsImageType) {
                        $scope.HomeModel.RichSnippetImagePath = '';
                        $scope.HomeModel.RichSnippetImageName = '';
                        $scope.HomeModel.RealRichSnippetImagePath = '';
                    }
                    if(response.Data == window.COHomeTopCTABlock1ImageType) {
                        $scope.HomeModel.TopCTAImagePath1 = '';
                        $scope.HomeModel.TopCTAImageName1 = '';
                        $scope.HomeModel.RealTopCTAImagePath1 = '';
                    }
                    if(response.Data == window.COHomeTopCTABlock2ImageType) {
                        $scope.HomeModel.TopCTAImagePath2 = '';
                        $scope.HomeModel.TopCTAImageName2 = '';
                        $scope.HomeModel.RealTopCTAImagePath2 = '';
                    }
                    if(response.Data == window.COHomeBottomCTABlock1ImageType) {
                        $scope.HomeModel.BottomCTAImagePath1 = '';
                        $scope.HomeModel.BottomCTAImageName1 = '';
                        $scope.HomeModel.RealBottomCTAImagePath1 = '';
                    }
                    if(response.Data == window.COHomeBottomCTABlock2ImageType) {
                        $scope.HomeModel.BottomCTAImagePath2 = '';
                        $scope.HomeModel.BottomCTAImageName2 = '';
                        $scope.HomeModel.RealBottomCTAImagePath2 = '';
                    }
                    if(response.Data == window.COHomeBottomCTABlock3ImageType) {
                        $scope.HomeModel.BottomCTAImagePath3 = '';
                        $scope.HomeModel.BottomCTAImageName3 = '';
                        $scope.HomeModel.RealBottomCTAImagePath3 = '';
                    }
                    if(response.Data == window.COVideoPosterType) {
                        $scope.HomeModel.VideoPosterPath = '';
                        $scope.HomeModel.VideoPosterName = '';
                        $scope.HomeModel.RealVideoPosterPath = '';
                    }
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        });
    };

    $scope.SaveHome = function() {
        if ($scope.HomeForm.$valid && $scope.FormImageTopBlock1.$valid && $scope.FormImageTopBlock2.$valid && $scope.FormImageBottomBlock1.$valid && $scope.FormImageBottomBlock2.$valid && $scope.FormImageBottomBlock3.$valid) {
            $scope.DisableButtons = true;
            var postData = {};
            postData.Data = $scope.HomeModel;
            var jsonData = angular.toJson(postData);
            AngularAjaxCall($http,$scope.SaveHomePageURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    ShowSuccessMessage(response.Message);
                    $scope.DisableButtons = false;
                }else{
                    $scope.DisableButtons = false;
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }else{
            $timeout(function() {
                openErrorPortlets();
            });
        }
    }

    /* For Delete video */
    $scope.DeleteVideo = function(videoType) {
        var VideoURL ='';
        switch(videoType) {
            case window.COHomeVideoMP4Type:
                VideoURL =  $scope.HomeModel.MP4VideoURL;
                break;
            case window.COHomeVideoOggType:
                VideoURL =  $scope.HomeModel.OggVideoURL;
                break;
            case window.COHomeVideoWebmType:
                VideoURL =  $scope.HomeModel.WebmVideoURL;
                break;
        }
        ShowConfirm("this Video?", function () {
            AngularAjaxCall($http, $scope.DeletevideoURL, angular.toJson({ Data : {HomepageID: $scope.HomeModel.HomepageID, RemoveType: videoType, VideoURL: VideoURL} }), 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    if(response.Data == window.COHomeVideoMP4Type){
                        $scope.HomeModel.MP4VideoURL = '';
                        $scope.HomeModel.MP4VideoName = '';
                        $scope.HomeModel.RealMP4VideoPath = '';
                    }
                    if(response.Data == window.COHomeVideoOggType){
                        $scope.HomeModel.OggVideoURL = '';
                        $scope.HomeModel.OggVideoName = '';
                        $scope.HomeModel.RealOggVideoPath = '';
                    }
                    if(response.Data == window.COHomeVideoWebmType){
                        $scope.HomeModel.WebmVideoURL = '';
                        $scope.HomeModel.WebmVideoName = '';
                        $scope.HomeModel.RealWebmVideoPath = '';
                    }
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        });
    };
});

app.controller('SliderController',function($scope,$http,$timeout) {

    $scope.SliderModel = $.parseJSON($("#SliderModel").val());
    $scope.SliderListArray = $scope.SliderModel.SliderListArray;
    $scope.GetImageUrl = baseUrl+'/getsliderimage';
    $scope.DeleteSliderURL = baseUrl+'/deleteslidercolorado'; // For URL
    $scope.AddSliderURL = baseUrl + '/saveslidercolorado';
    $scope.SortOrderSliderURL = baseUrl+'/updatesortorderslidercolorado';
    $scope.RemoveSliderImageURL = baseUrl+'/removesliderimagecolorado';
    $scope.AwsUploadBaseURL = $scope.SliderModel.FileUploadSettings.url;

    $scope.SliderModel.Slider = { RealBackgroundImagePath:'',IsLight: 0};
    $scope.DisableButtons = false;
    $scope.SliderModel.NoImagePath = window.NoImagePath;

    if((Window.ImageResitrictions[$scope.SliderModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.SliderModel.SiteID]['COHomePageSliderImage']['Height'] != undefined){
        $scope.AllowedSliderFixHeight = Window.ImageResitrictions[$scope.SliderModel.SiteID]['COHomePageSliderImage']['Height'];
    }
    if((Window.ImageResitrictions[$scope.SliderModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.SliderModel.SiteID]['COHomePageSliderImage']['Width'] != undefined){
        $scope.AllowedSliderFixWidth = Window.ImageResitrictions[$scope.SliderModel.SiteID]['COHomePageSliderImage']['Width'];
    }
    /* set validation focus */
    $scope.checkSaveSlider = function(yourForm) {
        checkValidationFocus(yourForm);
    };

    /* SortOrder update */
    $scope.updateSortOrderSlider = function(sourceIndex,newIndex){
        var postData = {};
        postData.Data = {};
        postData.Data.OldOrder = sourceIndex;
        postData.Data.newOrder = newIndex;
        var jsonData = angular.toJson(postData);
        if((newIndex != undefined && sourceIndex != undefined ) && (newIndex !='' && newIndex != '' ) && ( sourceIndex != newIndex ) ) {
            AngularAjaxCall($http, $scope.SortOrderSliderURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    ShowSuccessMessage(response.Message);
                }
            });
        }
    }

    /*  Delete Slider */
    $scope.DeleteSlider = function(data) {
        ShowConfirm("this Slider?", function () {
            var postData = { Data: data.HomePageSliderID };
            AngularAjaxCall($http,$scope.DeleteSliderURL,angular.toJson(postData), 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    $scope.SliderListArray = response.Data.SliderListArray;
                    $scope.SliderModel.Slider = [];
                    $scope.SliderModel.Slider = { RealBackgroundImagePath:'',IsLight: 0};
                    $('#Header').focus();
                    ShowSuccessMessage(response.Message);
                }else{
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }, 'Yes');
    }

    /* For Edit Slider  set */
    $scope.EditSlider = function(Data) {
        $scope.SliderModel.Slider = angular.copy(Data);
        $('#Header').focus();
    }

    /* Slider cancel button */
    $scope.CancelSlider = function(){
        $scope.SliderForm.$submitted = false;
        $scope.SliderModel.Slider = [];
        $scope.SliderModel.Slider = { RealBackgroundImagePath:'',IsLight: 0};
        $('#Header').focus();
    }

    /* For image upload */
    $(document).ready(function() {
        var AwsSettingModel = $scope.SliderModel.FileUploadSettings;
        $('.direct-upload-slider').each(function() {
            var form = $(this);
            var parentDiv =  $(form).parents('.fileinput');
            var Images = "COHomePageSliderImage";

            if((Window.ImageResitrictions[$scope.SliderModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.SliderModel.SiteID][Images]['Height'] != undefined){
                var AllowedFixHeight = Window.ImageResitrictions[$scope.SliderModel.SiteID][Images]['Height'];
                var FixWidthMessage= Window.ImageResitrictions[$scope.SliderModel.SiteID][Images]['WidthMessage'];
            }
            if((Window.ImageResitrictions[$scope.SliderModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.SliderModel.SiteID][Images]['Width'] != undefined){
                var AllowedFixWidth = Window.ImageResitrictions[$scope.SliderModel.SiteID][Images]['Width'];
                var FixHeightMessage= Window.ImageResitrictions[$scope.SliderModel.SiteID][Images]['HeightMessage'];
            }
            if((AllowedFixHeight != undefined && AllowedFixHeight != null && AllowedFixHeight != '' && AllowedFixHeight != 0 ) && (AllowedFixWidth != undefined && AllowedFixWidth != null && AllowedFixWidth != '' && AllowedFixWidth != 0)) {
                var FixHeightWidthMessage = Window.ImageResitrictions[$scope.SliderModel.SiteID][Images]['HeightWidthMessage'];
            }
            if(AllowedFixHeight != undefined || AllowedFixWidth != undefined){
                var checkForMaxDimensionsRequired = true;
            }else{
                var checkForMaxDimensionsRequired = false;
            }

            var options ={
                successCallBack: function(new_filename, tempFileName){
                    AngularAjaxCall($http, $scope.GetImageUrl,angular.toJson({ Data : {ImageURL: new_filename, HomepageID: 0} }) , 'POST', 'json', 'application/json').success(function (response) {
                        if(true) {
                            var realImagePath = $scope.AwsUploadBaseURL + new_filename;
                            $scope.SliderModel.Slider.BackgroundImagePath = new_filename;
                            $scope.SliderModel.Slider.BackgroundImageName = tempFileName;
                            $scope.SliderModel.Slider.RealBackgroundImagePath = realImagePath;
                            $(parentDiv).find('#file').removeAttr('disabled');
                            $(parentDiv).find('.progress').hide();
                            $(parentDiv).find('.bar').css('width', '0');
                            $(parentDiv).find('#loadingImage').css('display', 'block');
                            $(parentDiv).find('#actualImage').on('load', function () {
                                $(parentDiv).find('#loadingImage').css('display', 'none');
                            });
                        }
                    });
                },
                AWSBaseURL: $scope.AwsUploadBaseURL,
                AWSSettingsModel:AwsSettingModel,
                form:form,
                AllwoedExts:uploadphotoexts,
                AlertMessage:window.ImageFileAllowedMessage,
                ResizeRequired:false,
                checkForMaxDimensionsRequired: checkForMaxDimensionsRequired,
                AllowedFixHeight: AllowedFixHeight,
                AllowedFixWidth: AllowedFixWidth,
                FixWidthMessage: FixWidthMessage,
                FixHeightMessage:FixHeightMessage,
                FixHeightWidthMessage: FixHeightWidthMessage,
                submitButtonClassOrId: "#submit-slider,#cancel-slider",
                progressCallback : function(){

                }
            };

            Awsfileupload(options);
        });
    });


    /* Remove Image */
    $scope.RemoveImage = function() {
        var ImageURL =  $scope.SliderModel.Slider.BackgroundImagePath;
        ShowConfirm("this Image?", function () {
            AngularAjaxCall($http, $scope.RemoveSliderImageURL, angular.toJson({ Data : {HomepageID: $scope.SliderModel.Slider.HomePageSliderID ? $scope.SliderModel.Slider.HomePageSliderID : 0, RemoveType: 1, ImageURL: ImageURL} }), 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    $scope.SliderModel.Slider.BackgroundImagePath = '';
                    $scope.SliderModel.Slider.BackgroundImageName = '';
                    $scope.SliderModel.Slider.RealBackgroundImagePath = '';
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        });
    };

    /* Add Slider */
    $scope.SaveSlider = function() {
        if ($scope.SliderForm.$valid && $scope.FormSliderImage.$valid) {
            $scope.DisableButtons = true;
            var postData = {};
            postData.Data = $scope.SliderModel.Slider;
            var jsonData = angular.toJson(postData);
            AngularAjaxCall($http,$scope.AddSliderURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    $scope.SliderListArray = response.Data.SliderListArray;
                    $scope.SliderForm.$submitted = false;
                    $scope.SliderModel.Slider = [];
                    $scope.SliderModel.Slider = { RealBackgroundImagePath:'',IsLight: 0};
                    $('#Header').focus();
                    ShowSuccessMessage(response.Message);
                    $scope.DisableButtons = false;
                }else{
                    $scope.DisableButtons = false;
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });

        }else{
            $timeout(function() {
                openErrorPortlets();
            });
        }
    }
});