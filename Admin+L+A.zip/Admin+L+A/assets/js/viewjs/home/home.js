app.controller('HomeController',function($scope,$http,$timeout) {
    $scope.HomeModel = $.parseJSON($("#HomeModel").val());
    $scope.HomeModel = $scope.HomeModel.HomeDetails;

    $scope.SaveHomePageURL = baseUrl+'/savehomepage';
    $scope.RedirectURL = baseUrl + '/dashboard';
    $scope.GetImageUrl = baseUrl+'/gethoverimage';
    $scope.RemoveHoverImageURL = baseUrl+'/removehoverimage';
    $scope.DeletevideoURL = baseUrl+'/deletehomevideo';
    $scope.GetChangeSectionURL = baseUrl+'/homechangesection';

    $scope.checkSave = function(yourForm) {
        if (!yourForm.$valid) {
            if(angular.element("[name='" + yourForm.$name + "']").find('.ng-invalid:first')[0].tagName == "TEXTAREA")
            {
                angular.element("[name='" + yourForm.$name + "']").find('.ng-invalid:first').prev().focus();
                return false;
            }
            else
            {
                angular.element("[name='" + yourForm.$name + "']").find('.ng-invalid:visible:first').focus();
                return false;
            }
            angular.element("[name='" + yourForm.$name + "']").find('.ng-invalid:visible:first').focus();
            return false;
        }
    };



    $scope.requestCounter = 0;
    $scope.responseCounter = 0;

    /* For hover images upload */
    $scope.AwsUploadBaseURL = $scope.HomeModel.FileUploadSettings.url;
    $scope.HomeModel.NoImagePath = window.NoImagePath;

    $scope.DisableButtons = false;

    /* Recommended dimensions set */
    if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomePageVideoImages']['Height'] != undefined){
        $scope.AllowedVideoImagesFixHeight = Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomePageVideoImages']['Height'];
    }
    if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomePageVideoImages']['Width'] != undefined){
        $scope.AllowedVideoImagesFixWidth = Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomePageVideoImages']['Width'];
    }

    $scope.SaveHome = function() {
        if ($scope.HomeForm.$valid && $scope.FormBackgroundImage.$valid && $scope.FormHoverImage.$valid && $scope.FormVideoMP3.$valid && $scope.FormVideoOgg.$valid && $scope.FormVideoWebm.$valid && $scope.FormImageSection1.$valid && $scope.FormImageSection2.$valid && $scope.FormImageSection3.$valid && $scope.FormYoutubeVideoImage.$valid) {
            $scope.DisableButtons = true;
            var postData = {};
            postData.Data = $scope.HomeModel;
            var jsonData = angular.toJson(postData);
            AngularAjaxCall($http,$scope.SaveHomePageURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    ShowSuccessMessage(response.Message);
                    $scope.DisableButtons = false;
                }else{
                    $scope.DisableButtons = false;
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }else{
            $timeout(function() {
                openErrorPortlets();
            });
        }
    }

    /* On Cancel button  */
    $scope.Cancel = function(){
        window.location.href = $scope.RedirectURL;
    }

    $(document).ready(function() {

        /* For image upload */
        var AwsSettingModel = $scope.HomeModel.FileUploadSettings;
        $('.direct-upload').each(function() {
            var imgType = $(this).attr('img-type');
            var form = $(this);
            var parentDiv =  $(form).parents('.fileinput');

            if(imgType != undefined && imgType == 6){
                var Images = "HomePageVideoImages";

                if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['Height'] != undefined){
                    var AllowedFixHeight = Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['Height'];
                    var FixWidthMessage= Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['WidthMessage'];
                }
                if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['Width'] != undefined){
                    var AllowedFixWidth = Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['Width'];
                    var FixHeightMessage= Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['HeightMessage'];
                }
                if((AllowedFixHeight != undefined && AllowedFixHeight != null && AllowedFixHeight != '' && AllowedFixHeight != 0 ) && (AllowedFixWidth != undefined && AllowedFixWidth != null && AllowedFixWidth != '' && AllowedFixWidth != 0)) {
                    var FixHeightWidthMessage = Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['HeightWidthMessage'];
                }
                if(AllowedFixHeight != undefined || AllowedFixWidth != undefined){
                    var checkForMaxDimensionsRequired = true;
                }else{
                    var checkForMaxDimensionsRequired = false;
                }
            }
            var options ={
                successCallBack: function(new_filename, tempFileName){
                    AngularAjaxCall($http, $scope.GetImageUrl,angular.toJson({ Data : {ImageURL: new_filename,HomepageID: 0} }) , 'POST', 'json', 'application/json').success(function (response) {
                        if(true) {
                            var realImagePath = $scope.AwsUploadBaseURL + new_filename;
                            switch(imgType) {
                                case window.HoverImagesType:
                                    $scope.HomeModel.HoverImageURL = new_filename;
                                    $scope.HomeModel.HoverImageName = tempFileName;
                                    $scope.HomeModel.RealHoverPath = realImagePath;
                                    break;
                                case window.BackgroundImagesType:
                                    $scope.HomeModel.BackgroundImageURL = new_filename;
                                    $scope.HomeModel.BackgroundImageName = tempFileName;
                                    $scope.HomeModel.RealBackgroundPath = realImagePath;
                                    break;
                                case window.MVItem1ImageType:
                                    $scope.HomeModel.MVItem1ImageURL = new_filename;
                                    $scope.HomeModel.MVItem1ImageName = tempFileName;
                                    $scope.HomeModel.RealMVItem1Path = realImagePath;
                                    break;
                                case window.MVItem2ImageType:
                                    $scope.HomeModel.MVItem2ImageURL = new_filename;
                                    $scope.HomeModel.MVItem2ImageName = tempFileName;
                                    $scope.HomeModel.RealMVItem2Path = realImagePath;
                                    break;
                                case window.MVItem3ImageType:
                                    $scope.HomeModel.MVItem3ImageURL = new_filename;
                                    $scope.HomeModel.MVItem3ImageName = tempFileName;
                                    $scope.HomeModel.RealMVItem3Path = realImagePath;
                                    break;
                                case window.YoutubeVideoImageType:
                                    $scope.HomeModel.YoutubeVideoImageURL = new_filename;
                                    $scope.HomeModel.YoutubeVideoImageName = tempFileName;
                                    $scope.HomeModel.RealYoutubeVideoImagesPath = realImagePath;
                                    break;
                                case window.HomeFacebookImageType:
                                    $scope.HomeModel.FBImage = new_filename;
                                    $scope.HomeModel.FBImageName = tempFileName;
                                    $scope.HomeModel.FBRealImagePath = realImagePath;
                                    break;
                                case window.HomeTwitterImageType:
                                    $scope.HomeModel.TwitterImage = new_filename;
                                    $scope.HomeModel.TwitterImageName = tempFileName;
                                    $scope.HomeModel.TwitterRealImagePath = realImagePath;
                                    break;
                                case window.HomeRichSnippetsImageType:
                                    $scope.HomeModel.RichSnippetsImage = new_filename;
                                    $scope.HomeModel.RichSnippetsImageName = tempFileName;
                                    $scope.HomeModel.RichSnippetsRealImagePath = realImagePath;
                                    break;
                            }
                                $scope.responseCounter = $scope.responseCounter + 1;
                                $(parentDiv).find('#file').removeAttr('disabled');
                                $(parentDiv).find('.progress').hide();
                                $(parentDiv).find('.bar').css('width', '0');
                                $(parentDiv).find('#loadingImage').css('display', 'block');
                                $(parentDiv).find('#actualImage').on('load', function () {
                                    $(parentDiv).find('#loadingImage').css('display', 'none');
                                });
                        }
                    });
                },
                AWSBaseURL: $scope.AwsUploadBaseURL,
                AWSSettingsModel:AwsSettingModel,
                form:form,
                AllwoedExts:uploadphotoexts,
                AlertMessage:window.ImageFileAllowedMessage,
                ResizeRequired:false,
                checkForMaxDimensionsRequired: checkForMaxDimensionsRequired,
                AllowedFixHeight: AllowedFixHeight,
                AllowedFixWidth: AllowedFixWidth,
                FixWidthMessage: FixWidthMessage,
                FixHeightMessage:FixHeightMessage,
                FixHeightWidthMessage: FixHeightWidthMessage,
                submitButtonClassOrId: "#submit-home,#cancel-home",
                progressCallback : function(){
                },
                addCallback : function(){
                    $scope.requestCounter = $scope.requestCounter+1;
                }
            };

            Awsfileupload(options);
        });
        /* For Remove image */


        /* For video upload */
        var AwsSettingModel = $scope.HomeModel.FileUploadSettings;
        $('.directuploadvideo').each(function() {
            var videoType = $(this).attr('video-type');
            var form = $(this);
            var parentDiv =  $(form).parents('.fileinput');
            switch(videoType) {
                case window.HomePageVideoMP3Type:
                    var Allwoeduploadvideoexts = uploadvideoMp4exts;
                    var VideoAlertMessage = window.VideoMP4FileAllowedMessage;
                    break;
                case window.HomePageVideoOggType:
                    var Allwoeduploadvideoexts = uploadvideoogexts;
                    var VideoAlertMessage = window.VideoOggFileAllowedMessage;
                    break;
                case window.HomePageVideoWebmType:
                    var Allwoeduploadvideoexts = uploadvideoWebmexts;
                    var VideoAlertMessage = window.VideoWebmFileAllowedMessage;
                    break;
            }

            var options ={
                successCallBack: function(new_filename, tempFileName){
                    AngularAjaxCall($http, $scope.GetImageUrl,angular.toJson({ Data : {ImageURL: new_filename,HomepageID: 0} }) , 'POST', 'json', 'application/json').success(function (response) {
                        if(true) {
                            var realImagePath = $scope.AwsUploadBaseURL + new_filename;
                            switch(videoType) {
                                case window.HomePageVideoMP3Type:
                                    $scope.HomeModel.MP3VideoURL = new_filename;
                                    $scope.HomeModel.MP3VideoName = tempFileName;
                                    $scope.HomeModel.RealMP3VideoPath = realImagePath;
                                    break;
                                case window.HomePageVideoOggType:
                                    $scope.HomeModel.OggVideoURL = new_filename;
                                    $scope.HomeModel.OggVideoName = tempFileName;
                                    $scope.HomeModel.RealOggVideoPath = realImagePath;
                                    break;
                                case window.HomePageVideoWebmType:
                                    $scope.HomeModel.WebmVideoURL = new_filename;
                                    $scope.HomeModel.WebmVideoName = tempFileName;
                                    $scope.HomeModel.RealWebmVideoPath = realImagePath;
                                    break;
                            }
                            $scope.responseCounter = $scope.responseCounter + 1;
                            $(parentDiv).find('#file').removeAttr('disabled');
                            /*$("#ImageError").removeClass("ValidationError").text("");*/
                            //$('.progress.video').hide();
                            $(parentDiv).find('.progress.video').hide();
                            $(parentDiv).find('#videobar').css('width', '0');
                            $("#btn-submit").removeAttr('disabled');
                            $("#cancel").removeAttr('disabled');

                        }
                    });
                },
                AWSBaseURL: $scope.AwsUploadBaseURL,
                AWSSettingsModel:AwsSettingModel,
                form:form,
                AllwoedExts:Allwoeduploadvideoexts,
                AlertMessage:VideoAlertMessage,
                maxFileSizeLimit:window.HomePageVideoMaxFileSize,
                maxFileSizeErrorMessage:window.HomePageVideoMaxFileSizeMessage,
                ResizeRequired:false,
                progressCallback : function(){
                },
                addCallback : function(){
                    $scope.requestCounter = $scope.requestCounter+1;
                }
            };
            Awsfileupload(options);
        });
    });

    $scope.RemoveImage = function(imageType) {
        var ImageURL ='';
        var realImagePath = '';
        switch(imageType) {
            case window.HoverImagesType:
                ImageURL =  $scope.HomeModel.HoverImageURL;
                realImagePath = $scope.HomeModel.RealHoverPath;
                break;
            case window.BackgroundImagesType:
                ImageURL = $scope.HomeModel.BackgroundImageURL;
                realImagePath = $scope.HomeModel.RealBackgroundPath;
                break;
            case window.MVItem1ImageType:
                ImageURL = $scope.HomeModel.MVItem1ImageURL;
                realImagePath = $scope.HomeModel.RealMVItem1Path;
                break;
            case window.MVItem2ImageType:
                ImageURL = $scope.HomeModel.MVItem2ImageURL;
                realImagePath = $scope.HomeModel.RealMVItem2Path;
                break;
            case window.MVItem3ImageType:
                ImageURL = $scope.HomeModel.MVItem3ImageURL;
                realImagePath = $scope.HomeModel.RealMVItem3Path;
                break;
            case window.YoutubeVideoImageType:
                ImageURL = $scope.HomeModel.YoutubeVideoImageURL;
               realImagePath = $scope.HomeModel.RealYoutubeVideoImagesPath;
                break;
            case window.HomeFacebookImageType:
                ImageURL = $scope.HomeModel.FBImage;
                realImagePath = $scope.HomeModel.FBRealImagePath;
                break;
            case window.HomeTwitterImageType:
                ImageURL = $scope.HomeModel.TwitterImage;
                realImagePath = $scope.HomeModel.TwitterRealImagePath;
                break;
            case window.HomeRichSnippetsImageType:
                ImageURL = $scope.HomeModel.TwitterRealImagePath;
                realImagePath = $scope.HomeModel.RichSnippetsRealImagePath;
                break;
        }
        ShowConfirm("this Image?", function () {
            AngularAjaxCall($http, $scope.RemoveHoverImageURL, angular.toJson({ Data : {HomepageID: $scope.HomeModel.HomepageID, RemoveType: imageType, ImageURL: ImageURL} }), 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    if(response.Data == window.HoverImagesType){
                        $scope.HomeModel.RealHoverPath = '';
                        $scope.HomeModel.HoverImageURL ='';
                    }
                    if(response.Data == window.BackgroundImagesType){
                        $scope.HomeModel.RealBackgroundPath = '';
                        $scope.HomeModel.BackgroundImageURL ='';
                    }
                    if(response.Data == window.MVItem1ImageType) {
                        $scope.HomeModel.MVItem1ImageURL = '';
                        $scope.HomeModel.MVItem1ImageName = '';
                        $scope.HomeModel.RealMVItem1Path = '';
                    }
                    if(response.Data == window.MVItem2ImageType) {
                        $scope.HomeModel.MVItem2ImageURL = '';
                        $scope.HomeModel.MVItem2ImageName = '';
                        $scope.HomeModel.RealMVItem2Path = '';
                    }
                    if(response.Data == window.MVItem3ImageType) {
                        $scope.HomeModel.MVItem3ImageURL = '';
                        $scope.HomeModel.MVItem3ImageName = '';
                        $scope.HomeModel.RealMVItem3Path = '';
                    }
                    if(response.Data == window.YoutubeVideoImageType) {
                        $scope.HomeModel.YoutubeVideoImageURL = '';
                        $scope.HomeModel.YoutubeVideoImageName = '';
                        $scope.HomeModel.RealYoutubeVideoImagesPath = '';
                    }
                    if(response.Data == window.HomeFacebookImageType) {
                        $scope.HomeModel.FBImage = '';
                        $scope.HomeModel.FBImageName = '';
                        $scope.HomeModel.FBRealImagePath = '';
                    }
                    if(response.Data == window.HomeTwitterImageType) {
                        $scope.HomeModel.TwitterImage = '';
                        $scope.HomeModel.TwitterImageName = '';
                        $scope.HomeModel.TwitterRealImagePath = '';
                    }
                    if(response.Data == window.HomeRichSnippetsImageType) {
                        $scope.HomeModel.RichSnippetsImage = '';
                        $scope.HomeModel.RichSnippetsImageName = '';
                        $scope.HomeModel.RichSnippetsRealImagePath = '';
                    }

                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        });
    };

    /* For Delete video */
    $scope.DeleteVideo = function(videoType) {
        var VideoURL ='';
        var realVideoPath = '';
        switch(videoType) {
            case window.HomePageVideoMP3Type:
                VideoURL =  $scope.HomeModel.MP3VideoURL;
                realVideoPath = $scope.HomeModel.RealMP3VideoPath;
                 break;
            case window.HomePageVideoOggType:
                VideoURL =  $scope.HomeModel.OggVideoURL;
                realVideoPath = $scope.HomeModel.RealOggVideoPath;
                break;
            case window.HomePageVideoWebmType:
                VideoURL =  $scope.HomeModel.WebmVideoURL;
                realVideoPath = $scope.HomeModel.RealWebmVideoPath;
                break;
        }
        ShowConfirm("this Video?", function () {
            AngularAjaxCall($http, $scope.DeletevideoURL, angular.toJson({ Data : {HomepageID: $scope.HomeModel.HomepageID, RemoveType: videoType, VideoURL: VideoURL} }), 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {

                    if(response.Data == window.HomePageVideoMP3Type){
                        $scope.HomeModel.MP3VideoURL = '';
                        $scope.HomeModel.MP3VideoName = '';
                        $scope.HomeModel.RealMP3VideoPath ='';
                    }
                    if(response.Data == window.HomePageVideoOggType){
                        $scope.HomeModel.OggVideoURL = '';
                        $scope.HomeModel.OggVideoName = '';
                        $scope.HomeModel.RealOggVideoPath ='';
                    }
                    if(response.Data == window.HomePageVideoWebmType){
                        $scope.HomeModel.WebmVideoURL = '';
                        $scope.HomeModel.WebmVideoName = '';
                        $scope.HomeModel.RealWebmVideoPath ='';
                    }
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        });
    };

    /* Change Section Type */
    $scope.ChangeSectionType = function() {
        if($scope.HomeModel.FirstSectionType != null && $scope.HomeModel.FirstSectionType != undefined )
        {
            var postData = {};
            postData.Data = {};
            postData.Data.FirstSectionType = $scope.HomeModel.FirstSectionType;
            var jsonData = angular.toJson(postData);
            AngularAjaxCall($http, $scope.GetChangeSectionURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    switch($scope.HomeModel.FirstSectionType) {
                        case "1":
                            /* Hover Images set */
                            $scope.HomeModel.HoverImageURL = response.Data.HoverImage.HoverImageURL;
                            $scope.HomeModel.HoverImageName = response.Data.HoverImage.HoverImageName;
                            $scope.HomeModel.RealHoverPath = response.Data.HoverImage.RealHoverPath;
                            $scope.HomeModel.HoverImageFileSize = response.Data.HoverImage.HoverImageFileSize;

                            /* Background Images set */
                            $scope.HomeModel.BackgroundImageURL = response.Data.BackgroundImage.BackgroundImageURL;
                            $scope.HomeModel.BackgroundImageName = response.Data.BackgroundImage.BackgroundImageName;
                            $scope.HomeModel.RealBackgroundPath = response.Data.BackgroundImage.RealBackgroundPath;
                            $scope.HomeModel.BackgroundFileSize = response.Data.BackgroundImage.BackgroundFileSize;

                            break;
                        case "2":

                            /* slider video set */
                            $scope.HomeModel.MP3VideoURL = response.Data.MP3Video.MP3VideoURL;
                            $scope.HomeModel.MP3VideoName = response.Data.MP3Video.MP3VideoName;
                            $scope.HomeModel.RealMP3VideoPath =response.Data.MP3Video.RealMP3VideoPath;
                            $scope.HomeModel.MP3VideoFileSize =response.Data.MP3Video.MP3VideoFileSize;

                            $scope.HomeModel.OggVideoURL = response.Data.OggVideo.OggVideoURL;
                            $scope.HomeModel.OggVideoName = response.Data.OggVideo.OggVideoName;
                            $scope.HomeModel.RealOggVideoPath = response.Data.OggVideo.RealOggVideoPath;
                            $scope.HomeModel.OggVideoFileSize = response.Data.OggVideo.OggVideoFileSize;

                            $scope.HomeModel.WebmVideoURL = response.Data.WebmVideo.WebmVideoURL;
                            $scope.HomeModel.WebmVideoName = response.Data.WebmVideo.WebmVideoName;
                            $scope.HomeModel.RealWebmVideoPath = response.Data.WebmVideo.RealWebmVideoPath;
                            $scope.HomeModel.WebmVideoFileSize = response.Data.WebmVideo.WebmVideoFileSize;

                            /* Background Images set */
                            $scope.HomeModel.BackgroundImageURL = response.Data.BackgroundImage.BackgroundImageURL;
                            $scope.HomeModel.BackgroundImageName = response.Data.BackgroundImage.BackgroundImageName;
                            $scope.HomeModel.RealBackgroundPath = response.Data.BackgroundImage.RealBackgroundPath;
                            $scope.HomeModel.BackgroundFileSize = response.Data.BackgroundImage.BackgroundFileSize;

                            break;
                    }
                }
            });
        }
    }

});


app.controller('StoryController',function($scope,$http,$timeout) {
    $scope.StoryModel = $.parseJSON($("#StoryModel").val());
    $scope.StoryListArray = $scope.StoryModel.StoryListArray;
    $scope.GetImageUrl = baseUrl+'/gethoverimage';
    $scope.DeleteStoryURL = baseUrl+'/deletestory'; // For URL
    $scope.RedirectURL = baseUrl + '/dashboard';
    $scope.AddStoryURL = baseUrl + '/savestory';
    $scope.SortOrderStoryURL = baseUrl+'/updatesortorderstory';
    $scope.DisableButtons = false;
    $scope.RemoveHoverImageURL = baseUrl+'/removehoverimage';
    $scope.AwsUploadBaseURL = $scope.StoryModel.FileUploadSettings.url;
    $scope.StoryModel.Story = { RealImagePath:'',IsLight: 0};
    $scope.StoryModel.NoImagePath = window.NoImagePath;

    if((Window.ImageResitrictions[$scope.StoryModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.StoryModel.SiteID]['HomePageStoryImages']['Height'] != undefined){
        $scope.AllowedStoryFixHeight = Window.ImageResitrictions[$scope.StoryModel.SiteID]['HomePageStoryImages']['Height'];
    }
    if((Window.ImageResitrictions[$scope.StoryModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.StoryModel.SiteID]['HomePageStoryImages']['Width'] != undefined){
        $scope.AllowedStoryFixWidth = Window.ImageResitrictions[$scope.StoryModel.SiteID]['HomePageStoryImages']['Width'];
    }

    $scope.checkSave = function(yourForm) {
        checkValidationFocus(yourForm);
    };
   /*  Delete Story */
    $scope.deleteStory = function(data) {
        ShowConfirm("this Story?", function () {
            var postData = { Data: data.HomePageStoryID };
            AngularAjaxCall($http,$scope.DeleteStoryURL,angular.toJson(postData), 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    $scope.StoryListArray = response.Data.StoryListArray;
                    $scope.StoryModel.Story = [];
                    $scope.StoryModel.Story = { RealImagePath:'',IsLight:0};
                    $('#StoryTitle').focus();
                    ShowSuccessMessage(response.Message);
                }else{
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }, 'Yes');
    }

     /* Update SortOrder */
    $scope.updateSortOrderStory = function(sourceIndex,newIndex){
        var postData = {};
        postData.Data = {};
        postData.Data.OldOrder = sourceIndex;
        postData.Data.newOrder = newIndex;
        var jsonData = angular.toJson(postData);
        if((newIndex != undefined && sourceIndex != undefined ) && (newIndex !='' && newIndex != '' ) && ( sourceIndex != newIndex ) ) {
            AngularAjaxCall($http, $scope.SortOrderStoryURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    ShowSuccessMessage(response.Message);
                }
            });
        }
    }

     /* For Edit Story Link set */
    $scope.EditStory = function(Data) {
        $scope.StoryModel.Story = angular.copy(Data);
        $('#StoryTitle').focus();
    }

     /* Story cancel button */
    $scope.CancelStory = function(){
        $scope.StoryForm.$submitted = false;
        $scope.StoryModel.Story = [];
        $scope.StoryModel.Story = { RealImagePath:'',IsLight: 0};
        $('#StoryTitle').focus();
    }

     /* Add Story */
    $scope.AddStory = function() {
        if ($scope.StoryForm.$valid && $scope.FormStoryImage.$valid) {
                $scope.DisableButtons = true;
                var postData = {};
                postData.Data = $scope.StoryModel.Story;
                var jsonData = angular.toJson(postData);
                AngularAjaxCall($http,$scope.AddStoryURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                    if(response.IsSuccess){
                        $scope.StoryListArray = response.Data.StoryListArray;
                        $scope.StoryForm.$submitted = false;
                        $scope.StoryModel.Story = [];
                        $scope.StoryModel.Story = { RealImagePath:'',IsLight: 0};
                        $('#StoryTitle').focus();
                        ShowSuccessMessage(response.Message);
                        $scope.DisableButtons = false;
                    }else{
                        $scope.DisableButtons = false;
                        ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                    }
                });

        }else{
            $timeout(function() {
                openErrorPortlets();
            });
        }
    }

    /* For image upload */

    $(document).ready(function() {
        $scope.requestCounter = 0;
        $scope.responseCounter = 0;
        var AwsSettingModel = $scope.StoryModel.FileUploadSettings;
        $('.direct-upload-story-image').each(function() {
            var form = $(this);
            var parentDiv =  $(form).parents('.fileinput');
                var Images = "HomePageStoryImages";

                if((Window.ImageResitrictions[$scope.StoryModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.StoryModel.SiteID][Images]['Height'] != undefined){
                    var AllowedFixHeight = Window.ImageResitrictions[$scope.StoryModel.SiteID][Images]['Height'];
                    var FixWidthMessage= Window.ImageResitrictions[$scope.StoryModel.SiteID][Images]['WidthMessage'];
                }
                if((Window.ImageResitrictions[$scope.StoryModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.StoryModel.SiteID][Images]['Width'] != undefined){
                    var AllowedFixWidth = Window.ImageResitrictions[$scope.StoryModel.SiteID][Images]['Width'];
                    var FixHeightMessage= Window.ImageResitrictions[$scope.StoryModel.SiteID][Images]['HeightMessage'];
                }
                if((AllowedFixHeight != undefined && AllowedFixHeight != null && AllowedFixHeight != '' && AllowedFixHeight != 0 ) && (AllowedFixWidth != undefined && AllowedFixWidth != null && AllowedFixWidth != '' && AllowedFixWidth != 0)) {
                    var FixHeightWidthMessage = Window.ImageResitrictions[$scope.StoryModel.SiteID][Images]['HeightWidthMessage'];
                }
                if(AllowedFixHeight != undefined || AllowedFixWidth != undefined){
                    var checkForMaxDimensionsRequired = true;
                }else{
                    var checkForMaxDimensionsRequired = false;
                }

            var options ={
                successCallBack: function(new_filename, tempFileName){
                    AngularAjaxCall($http, $scope.GetImageUrl,angular.toJson({ Data : {ImageURL: new_filename, HomepageID: 0} }) , 'POST', 'json', 'application/json').success(function (response) {
                        if(true) {
                            var realImagePath = $scope.AwsUploadBaseURL + new_filename;
                            $scope.StoryModel.Story.ImageURL = new_filename;
                            $scope.StoryModel.Story.ImageName = tempFileName;
                            $scope.StoryModel.Story.RealImagePath = realImagePath;
                            $scope.requestCounter = $scope.requestCounter - 1;
                            $(parentDiv).find('#file').removeAttr('disabled');
                            $(parentDiv).find('.progress').hide();
                            $(parentDiv).find('.bar').css('width', '0');
                            $(parentDiv).find('#loadingImage').css('display', 'block');
                            $(parentDiv).find('#actualImage').on('load', function () {
                                $(parentDiv).find('#loadingImage').css('display', 'none');
                            });
                        }
                    });
                },
                AWSBaseURL: $scope.AwsUploadBaseURL,
                AWSSettingsModel:AwsSettingModel,
                form:form,
                AllwoedExts:uploadphotoexts,
                AlertMessage:window.ImageFileAllowedMessage,
                ResizeRequired:false,
                checkForMaxDimensionsRequired: checkForMaxDimensionsRequired,
                AllowedFixHeight: AllowedFixHeight,
                AllowedFixWidth: AllowedFixWidth,
                FixWidthMessage: FixWidthMessage,
                FixHeightMessage:FixHeightMessage,
                FixHeightWidthMessage: FixHeightWidthMessage,
                submitButtonClassOrId: "#submit-story,#cancel-story",
                progressCallback : function(){
                },
                addCallback : function(){
                    $scope.requestCounter = $scope.requestCounter + 1;
                }
            };

            Awsfileupload(options);
        });
    });

    $scope.RemoveImage = function() {
            var ImageURL =  $scope.StoryModel.Story.ImageURL;
            ShowConfirm("this Image?", function () {
            AngularAjaxCall($http, $scope.RemoveHoverImageURL, angular.toJson({ Data : {HomepageID: $scope.StoryModel.Story.HomePageStoryID ? $scope.StoryModel.Story.HomePageStoryID : 0, RemoveType: 1, ImageURL: ImageURL} }), 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    $scope.StoryModel.Story.ImageURL = '';
                    $scope.StoryModel.Story.RealImagePath = '';
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        });
    };
});



