app.controller('HomeController',function($scope,$http,$timeout) {

    $scope.HomeModel = $.parseJSON($("#HomeModel").val());
    $scope.HomeModel = $scope.HomeModel;

    $scope.SaveHomePageURL = baseUrl+'/saverdhomepage';
    $scope.RemoveImageURL = baseUrl+'/rdhomeremoveimage';
    $scope.GetImageUrl = baseUrl+'/getimagerdhome';
    $scope.RedirectURL = baseUrl + '/dashboard';

    $scope.AwsUploadBaseURL = $scope.HomeModel.FileUploadSettings.url;
    $scope.HomeModel.NoImagePath = window.NoImagePath;

    $scope.DisableButtons = false;
    $scope.requestCounter = 0;
    $scope.responseCounter = 0;

    /* Recommended dimensions set */
    if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomePageBlock1Image']['Height'] != undefined){
        $scope.AllowedBlock1ImagesFixHeight = Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomePageBlock1Image']['Height'];
    }
    if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomePageBlock1Image']['Width'] != undefined){
        $scope.AllowedBlock1ImagesFixWidth = Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomePageBlock1Image']['Width'];
    }

    if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomePageBlock2Image']['Height'] != undefined){
        $scope.AllowedBlock2ImagesFixHeight = Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomePageBlock2Image']['Height'];
    }
    if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomePageBlock2Image']['Width'] != undefined){
        $scope.AllowedBlock2ImagesFixWidth = Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomePageBlock2Image']['Width'];
    }

    if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomePageBlock3Image']['Height'] != undefined){
        $scope.AllowedBlock3ImagesFixHeight = Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomePageBlock3Image']['Height'];
    }
    if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomePageBlock3Image']['Width'] != undefined){
        $scope.AllowedBlock3ImagesFixWidth = Window.ImageResitrictions[$scope.HomeModel.SiteID]['HomePageBlock3Image']['Width'];
    }

    /* On Cancel button  */
    $scope.Cancel = function(){
        window.location.href = $scope.RedirectURL;
    }
    /* set field focus */
    $scope.checkSave = function(yourForm) {
        if (!yourForm.$valid) {
            if(angular.element("[name='" + yourForm.$name + "']").find('.ng-invalid:first')[0].tagName == "TEXTAREA")
            {
                angular.element("[name='" + yourForm.$name + "']").find('.ng-invalid:first').prev().focus();
                return false;
            }
            else
            {
                angular.element("[name='" + yourForm.$name + "']").find('.ng-invalid:visible:first').focus();
                return false;
            }
            angular.element("[name='" + yourForm.$name + "']").find('.ng-invalid:visible:first').focus();
            return false;
        }
    };

    $(document).ready(function() {

        /* For image upload */
        var AwsSettingModel = $scope.HomeModel.FileUploadSettings;
        $('.direct-upload').each(function() {
            var imgType = $(this).attr('img-type');
            var form = $(this);
            var parentDiv =  $(form).parents('.fileinput');

            if(imgType != undefined && (imgType == window.RDHomeBlock1ImageType || imgType == window.RDHomeBlock2ImageType || imgType == window.RDHomeBlock3ImageType)){
                if(imgType == window.RDHomeBlock1ImageType ){
                    var Images = "HomePageBlock1Image";
                }else if(imgType == window.RDHomeBlock2ImageType ){
                    var Images = "HomePageBlock2Image";
                }else if(imgType == window.RDHomeBlock3ImageType ){
                    var Images = "HomePageBlock3Image";
                }

                if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['Height'] != undefined){
                    var AllowedFixHeight = Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['Height'];
                    var FixWidthMessage= Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['WidthMessage'];
                }
                if((Window.ImageResitrictions[$scope.HomeModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['Width'] != undefined){
                    var AllowedFixWidth = Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['Width'];
                    var FixHeightMessage= Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['HeightMessage'];
                }
                if((AllowedFixHeight != undefined && AllowedFixHeight != null && AllowedFixHeight != '' && AllowedFixHeight != 0 ) && (AllowedFixWidth != undefined && AllowedFixWidth != null && AllowedFixWidth != '' && AllowedFixWidth != 0)) {
                    var FixHeightWidthMessage = Window.ImageResitrictions[$scope.HomeModel.SiteID][Images]['HeightWidthMessage'];
                }
                if(AllowedFixHeight != undefined || AllowedFixWidth != undefined){
                    var checkForMaxDimensionsRequired = true;
                }else{
                    var checkForMaxDimensionsRequired = false;
                }
            }
            var options ={
                successCallBack: function(new_filename, tempFileName){
                    AngularAjaxCall($http, $scope.GetImageUrl,angular.toJson({ Data : {ImageURL: new_filename,HomepageID: 0} }) , 'POST', 'json', 'application/json').success(function (response) {
                        if(true) {
                            var realImagePath = $scope.AwsUploadBaseURL + new_filename;
                            switch(imgType) {
                                case window.RDHomeBlock1ImageType:
                                    $scope.HomeModel.Block1ImagePath = new_filename;
                                    $scope.HomeModel.Block1ImageName = tempFileName;
                                    $scope.HomeModel.RealBlock1ImagePath = realImagePath;
                                    break;
                                case window.RDHomeBlock2ImageType:
                                    $scope.HomeModel.Block2ImagePath = new_filename;
                                    $scope.HomeModel.Block2ImageName = tempFileName;
                                    $scope.HomeModel.RealBlock2ImagePath = realImagePath;
                                    break;
                                case window.RDHomeBlock3ImageType:
                                    $scope.HomeModel.Block3ImagePath = new_filename;
                                    $scope.HomeModel.Block3ImageName = tempFileName;
                                    $scope.HomeModel.RealBlock3ImagePath = realImagePath;
                                    break;
                                case window.RDHomeFacebookImageType:
                                    $scope.HomeModel.FacebookImagePath = new_filename;
                                    $scope.HomeModel.FacebookImageName = tempFileName;
                                    $scope.HomeModel.RealFacebookImagePath = realImagePath;
                                    break;
                                case window.RDHomeTwitterImageType:
                                    $scope.HomeModel.TwitterImagePath = new_filename;
                                    $scope.HomeModel.TwitterImageName = tempFileName;
                                    $scope.HomeModel.RealTwitterImagePath = realImagePath;
                                    break;
                                case window.RDHomeRichSnippetImageType:
                                    $scope.HomeModel.RichSnippetImagePath = new_filename;
                                    $scope.HomeModel.RichSnippetImageName = tempFileName;
                                    $scope.HomeModel.RealRichSnippetImagePath = realImagePath;
                                    break;
                            }
                            $scope.responseCounter = $scope.responseCounter + 1;
                            $(parentDiv).find('#file').removeAttr('disabled');
                            $(parentDiv).find('.progress').hide();
                            $(parentDiv).find('.bar').css('width', '0');
                            $(parentDiv).find('#loadingImage').css('display', 'block');
                            $(parentDiv).find('#actualImage').on('load', function () {
                                $(parentDiv).find('#loadingImage').css('display', 'none');
                            });
                        }
                    });
                },
                AWSBaseURL: $scope.AwsUploadBaseURL,
                AWSSettingsModel:AwsSettingModel,
                form:form,
                AllwoedExts:uploadphotoexts,
                AlertMessage:window.ImageFileAllowedMessage,
                ResizeRequired:false,
                checkForMaxDimensionsRequired: checkForMaxDimensionsRequired,
                AllowedFixHeight: AllowedFixHeight,
                AllowedFixWidth: AllowedFixWidth,
                FixWidthMessage: FixWidthMessage,
                FixHeightMessage:FixHeightMessage,
                FixHeightWidthMessage: FixHeightWidthMessage,
                submitButtonClassOrId: "#submit-home,#cancel-home",
                progressCallback : function(){
                },
                addCallback : function(){
                    $scope.requestCounter = $scope.requestCounter+1;
                }
            };

            Awsfileupload(options);
        });
        /* For Remove image */

    });

    $scope.SaveHome = function() {
        if ($scope.HomeForm.$valid && $scope.FormImageBlock1.$valid && $scope.FormImageBlock2.$valid && $scope.FormImageBlock3.$valid) {
            $scope.DisableButtons = true;
            var postData = {};
            postData.Data = $scope.HomeModel;
            var jsonData = angular.toJson(postData);
            AngularAjaxCall($http,$scope.SaveHomePageURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    ShowSuccessMessage(response.Message);
                    $scope.DisableButtons = false;
                }else{
                    $scope.DisableButtons = false;
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }else{
            $timeout(function() {
                openErrorPortlets();
            });
        }
    }

    $scope.RemoveImage = function(imageType) {
        var ImageURL ='';
        switch(imageType) {
            case window.RDHomeBlock1ImageType:
                ImageURL =  $scope.HomeModel.Block1ImageName;
                break;
            case window.RDHomeBlock2ImageType:
                ImageURL = $scope.HomeModel.Block2ImageName;
                break;
            case window.RDHomeBlock3ImageType:
                ImageURL = $scope.HomeModel.Block3ImageName;
                break;
            case window.RDHomeFacebookImageType:
                ImageURL = $scope.HomeModel.FacebookImageName;
                break;
            case window.RDHomeTwitterImageType:
                ImageURL = $scope.HomeModel.TwitterImageName;
                break;
            case window.RDHomeRichSnippetImageType:
                ImageURL = $scope.HomeModel.RichSnippetImageName;
                break;
        }
        ShowConfirm("this Image?", function () {
            AngularAjaxCall($http, $scope.RemoveImageURL, angular.toJson({ Data : {HomepageID: $scope.HomeModel.HomepageID, RemoveType: imageType, ImageURL: ImageURL} }), 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    if(imageType == window.RDHomeBlock1ImageType){
                        $scope.HomeModel.RealBlock1ImagePath = '';
                        $scope.HomeModel.Block1ImageName ='';
                        $scope.HomeModel.Block1ImagePath ='';
                    }
                    if(imageType == window.RDHomeBlock2ImageType){
                        $scope.HomeModel.RealBlock2ImagePath = '';
                        $scope.HomeModel.Block2ImageName = '';
                        $scope.HomeModel.Block2ImagePath ='';
                    }
                    if(imageType == window.RDHomeBlock3ImageType) {
                        $scope.HomeModel.RealBlock3ImagePath = '';
                        $scope.HomeModel.Block3ImageName = '';
                        $scope.HomeModel.Block3ImagePath ='';
                    }
                    if(imageType == window.RDHomeFacebookImageType) {
                        $scope.HomeModel.FacebookImagePath = '';
                        $scope.HomeModel.FacebookImageName = '';
                        $scope.HomeModel.RealFacebookImagePath = '';
                    }
                    if(imageType == window.RDHomeTwitterImageType) {
                        $scope.HomeModel.TwitterImagePath = '';
                        $scope.HomeModel.TwitterImageName = '';
                        $scope.HomeModel.RealTwitterImagePath = '';
                    }
                    if(imageType == window.RDHomeRichSnippetImageType) {
                        $scope.HomeModel.RichSnippetImagePath = '';
                        $scope.HomeModel.RichSnippetImageName = '';
                        $scope.HomeModel.RealRichSnippetImagePath = '';
                    }
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        });
    };

});


app.controller('SliderController',function($scope,$http,$timeout) {

    $scope.SliderModel = $.parseJSON($("#SliderModel").val());
    $scope.SliderListArray = $scope.SliderModel.SliderListArray;
    $scope.GetImageUrl = baseUrl+'/getsliderimage';
    $scope.DeleteSliderURL = baseUrl+'/deleteslider'; // For URL
    $scope.AddSliderURL = baseUrl + '/saveslider';
    $scope.SortOrderSliderURL = baseUrl+'/updatesortorderslider';
    $scope.RemoveSliderImageURL = baseUrl+'/removesliderimage';
    $scope.AwsUploadBaseURL = $scope.SliderModel.FileUploadSettings.url;
    $scope.SliderModel.Slider = { RealBackgroundImagePath:'',IsLight: 0};
    $scope.DisableButtons = false;
    $scope.SliderModel.NoImagePath = window.NoImagePath;

    if((Window.ImageResitrictions[$scope.SliderModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.SliderModel.SiteID]['HomePageSliderImage']['Height'] != undefined){
        $scope.AllowedSliderFixHeight = Window.ImageResitrictions[$scope.SliderModel.SiteID]['HomePageSliderImage']['Height'];
    }
    if((Window.ImageResitrictions[$scope.SliderModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.SliderModel.SiteID]['HomePageSliderImage']['Width'] != undefined){
        $scope.AllowedSliderFixWidth = Window.ImageResitrictions[$scope.SliderModel.SiteID]['HomePageSliderImage']['Width'];
    }
    /* set validation focus */
    $scope.checkSaveSlider = function(yourForm) {
        checkValidationFocus(yourForm);
    };

    /* SortOrder update */
    $scope.updateSortOrderSlider = function(sourceIndex,newIndex){
        var postData = {};
        postData.Data = {};
        postData.Data.OldOrder = sourceIndex;
        postData.Data.newOrder = newIndex;
        var jsonData = angular.toJson(postData);
        if((newIndex != undefined && sourceIndex != undefined ) && (newIndex !='' && newIndex != '' ) && ( sourceIndex != newIndex ) ) {
            AngularAjaxCall($http, $scope.SortOrderSliderURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    ShowSuccessMessage(response.Message);
                }
            });
        }
    }

    /*  Delete Slider */
    $scope.DeleteSlider = function(data) {
        ShowConfirm("this Slider?", function () {
            var postData = { Data: data.HomePageSliderID };
            AngularAjaxCall($http,$scope.DeleteSliderURL,angular.toJson(postData), 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    $scope.SliderListArray = response.Data.SliderListArray;
                    $scope.SliderModel.Slider = [];
                    $scope.SliderModel.Slider = { RealBackgroundImagePath:'',IsLight: 0};
                    $('#Header').focus();
                    ShowSuccessMessage(response.Message);
                }else{
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        }, 'Yes');
    }

    /* For Edit Slider  set */
    $scope.EditSlider = function(Data) {
        $scope.SliderModel.Slider = angular.copy(Data);
        $('#Header').focus();
    }

    /* Slider cancel button */
    $scope.CancelSlider = function(){
        $scope.SliderForm.$submitted = false;
        $scope.SliderModel.Slider = [];
        $scope.SliderModel.Slider = { RealBackgroundImagePath:'',IsLight: 0};
        $('#Header').focus();
    }

    /* For image upload */
    $(document).ready(function() {
        $scope.requestCounter = 0;
        $scope.responseCounter = 0;
        var AwsSettingModel = $scope.SliderModel.FileUploadSettings;
        $('.direct-upload-slider-image').each(function() {
            var form = $(this);
            var parentDiv =  $(form).parents('.fileinput');
            var Images = "HomePageSliderImage";

            if((Window.ImageResitrictions[$scope.SliderModel.SiteID] != undefined)  && Window.ImageResitrictions[$scope.SliderModel.SiteID][Images]['Height'] != undefined){
                var AllowedFixHeight = Window.ImageResitrictions[$scope.SliderModel.SiteID][Images]['Height'];
                var FixWidthMessage= Window.ImageResitrictions[$scope.SliderModel.SiteID][Images]['WidthMessage'];
            }
            if((Window.ImageResitrictions[$scope.SliderModel.SiteID] != undefined) && Window.ImageResitrictions[$scope.SliderModel.SiteID][Images]['Width'] != undefined){
                var AllowedFixWidth = Window.ImageResitrictions[$scope.SliderModel.SiteID][Images]['Width'];
                var FixHeightMessage= Window.ImageResitrictions[$scope.SliderModel.SiteID][Images]['HeightMessage'];
            }
            if((AllowedFixHeight != undefined && AllowedFixHeight != null && AllowedFixHeight != '' && AllowedFixHeight != 0 ) && (AllowedFixWidth != undefined && AllowedFixWidth != null && AllowedFixWidth != '' && AllowedFixWidth != 0)) {
                var FixHeightWidthMessage = Window.ImageResitrictions[$scope.SliderModel.SiteID][Images]['HeightWidthMessage'];
            }
            if(AllowedFixHeight != undefined || AllowedFixWidth != undefined){
                var checkForMaxDimensionsRequired = true;
            }else{
                var checkForMaxDimensionsRequired = false;
            }

            var options ={
                successCallBack: function(new_filename, tempFileName){
                    AngularAjaxCall($http, $scope.GetImageUrl,angular.toJson({ Data : {ImageURL: new_filename, HomepageID: 0} }) , 'POST', 'json', 'application/json').success(function (response) {
                        if(true) {
                            var realImagePath = $scope.AwsUploadBaseURL + new_filename;
                            $scope.SliderModel.Slider.BackgroundImagePath = new_filename;
                            $scope.SliderModel.Slider.BackgroundImageName = tempFileName;
                            $scope.SliderModel.Slider.RealBackgroundImagePath = realImagePath;
                            $scope.requestCounter = $scope.requestCounter - 1;
                            $(parentDiv).find('#file').removeAttr('disabled');
                            $(parentDiv).find('.progress').hide();
                            $(parentDiv).find('.bar').css('width', '0');
                            $(parentDiv).find('#loadingImage').css('display', 'block');
                            $(parentDiv).find('#actualImage').on('load', function () {
                                $(parentDiv).find('#loadingImage').css('display', 'none');
                            });
                        }
                    });
                },
                AWSBaseURL: $scope.AwsUploadBaseURL,
                AWSSettingsModel:AwsSettingModel,
                form:form,
                AllwoedExts:uploadphotoexts,
                AlertMessage:window.ImageFileAllowedMessage,
                ResizeRequired:false,
                checkForMaxDimensionsRequired: checkForMaxDimensionsRequired,
                AllowedFixHeight: AllowedFixHeight,
                AllowedFixWidth: AllowedFixWidth,
                FixWidthMessage: FixWidthMessage,
                FixHeightMessage:FixHeightMessage,
                FixHeightWidthMessage: FixHeightWidthMessage,
                submitButtonClassOrId: "#submit-slider,#cancel-slider",
                progressCallback : function(){

                },
                addCallback : function(){
                    $scope.requestCounter = $scope.requestCounter + 1;
                }
            };

            Awsfileupload(options);
        });
    });

    /* Remove Image */
    $scope.RemoveImage = function() {
        var ImageURL =  $scope.SliderModel.Slider.BackgroundImagePath;
        ShowConfirm("this Image?", function () {
            AngularAjaxCall($http, $scope.RemoveSliderImageURL, angular.toJson({ Data : {HomepageID: $scope.SliderModel.Slider.HomePageSliderID ? $scope.SliderModel.Slider.HomePageSliderID : 0, RemoveType: 1, ImageURL: ImageURL} }), 'POST', 'json', 'application/json').success(function (response) {
                if (response.IsSuccess) {
                    $scope.SliderModel.Slider.BackgroundImagePath = '';
                    $scope.SliderModel.Slider.BackgroundImageName = '';
                    $scope.SliderModel.Slider.RealBackgroundImagePath = '';
                } else {
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });
        });
    };

    /* Add Slider */
    $scope.SaveSlider = function() {
        if ($scope.SliderForm.$valid && $scope.FormSliderImage.$valid) {
            $scope.DisableButtons = true;
            var postData = {};
            postData.Data = $scope.SliderModel.Slider;
            var jsonData = angular.toJson(postData);
            AngularAjaxCall($http,$scope.AddSliderURL, jsonData, 'POST', 'json', 'application/json').success(function (response) {
                if(response.IsSuccess){
                    $scope.SliderListArray = response.Data.SliderListArray;
                    $scope.SliderForm.$submitted = false;
                    $scope.SliderModel.Slider = [];
                    $scope.SliderModel.Slider = { RealBackgroundImagePath:'',IsLight: 0};
                    $('#Header').focus();
                    ShowSuccessMessage(response.Message);
                    $scope.DisableButtons = false;
                }else{
                    $scope.DisableButtons = false;
                    ShowAlertMessage(response.Message, 'error', window.ConfirmDialogSomethingWrong);
                }
            });

        }else{
            $timeout(function() {
                openErrorPortlets();
            });
        }
    }
});

