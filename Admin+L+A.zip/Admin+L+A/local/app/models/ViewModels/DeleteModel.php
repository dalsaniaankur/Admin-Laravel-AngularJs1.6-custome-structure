<?php
namespace ViewModels;
class DeleteModel{
    public $Procedure;
    public $SuccessMessage;
    public $FailMessage;
}