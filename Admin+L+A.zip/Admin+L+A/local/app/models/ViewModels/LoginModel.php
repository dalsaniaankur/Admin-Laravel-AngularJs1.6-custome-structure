<?php
namespace ViewModels;

class LoginModel {
	public $Email;
	public $Password;
}
