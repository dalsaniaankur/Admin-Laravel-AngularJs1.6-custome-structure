<?php
namespace ViewModels;

class ServiceRequest {
	public $Token;
	public $Data;
}
