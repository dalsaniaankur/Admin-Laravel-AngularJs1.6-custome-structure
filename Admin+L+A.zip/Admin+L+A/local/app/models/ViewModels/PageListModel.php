<?php
namespace ViewModels;
use Infrastructure\Common;
use Infrastructure\Constants;
class PageListModel{
    function __construct($timezone) {
        $this->DateFrom = "";
        $this->DateTo = "";
        $this->StatusID = "";
        $date = new \DateTime("today", new \DateTimeZone($timezone));
        $this->Today = $date->format(Constants::$DateFormatServerSide);
    }
    public $DateFrom;
    public $DateTo;
    public $StatusID;
    public $CategoryID;
    public $Today;
}