<?php
namespace ViewModels;

class PageModel {

    public $CurrentPage;
    public $TotalPages;
    public $TotalItems;
    public $ItemsPerPage;
    public $Items;
}
