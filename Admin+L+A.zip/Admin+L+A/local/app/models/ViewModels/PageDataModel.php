<?php
namespace ViewModels;
class PageDataModel{
    function __construct($pageData)
    {
        $this->SearchParams=  $pageData->SearchParams;
        $this->PageSize = $pageData->PageSize;
        $this->PageIndex = $pageData->PageIndex;
        $this->SortIndex = $pageData->SortIndex;
        $this->SortDirection = $pageData->SortDirection;
    }
    public $SearchParams;
    public $PageSize;
    public $PageIndex;
    public $SortIndex;
    public $SortDirection;
}