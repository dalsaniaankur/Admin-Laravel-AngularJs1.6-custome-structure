<?php
namespace ViewModels;
class WorkFlowDetailModel{
    public $Procedure;
    public $ErrorMessage;
}