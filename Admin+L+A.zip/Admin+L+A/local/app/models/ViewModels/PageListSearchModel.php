<?php
namespace ViewModels;
class PageListSearchModel{
    function __construct($timezone)
    {
        $listModel = new PageListModel($timezone);
        $this->frontSearchModel = $listModel;
        $this->backSearchModel = $listModel;
    }
    public $StatusLookup;
    public $frontSearchModel;
    public $backSearchModel;
}