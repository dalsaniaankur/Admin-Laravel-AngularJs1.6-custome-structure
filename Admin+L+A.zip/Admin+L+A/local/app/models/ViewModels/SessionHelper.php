<?php namespace ViewModels;

use Illuminate\Auth\UserTrait;
use Illuminate\Auth\UserInterface;
use Illuminate\Auth\Reminders\RemindableTrait;
use Illuminate\Auth\Reminders\RemindableInterface;
use Illuminate\Support\Facades\Session;
use \stdClass;

class SessionHelper
{

    public static function setUserSiteList($UserSiteList){
        Session::put('UserSite',$UserSiteList);
    }
    public static function getUserSiteList(){
        return Session::get('UserSite');
    }


    public static function setSelectedRoleID($RoleID){
        Session::put('SelectedRoleID',$RoleID);
    }
    public static function getSelectedRoleID(){
        return 	Session::get('SelectedRoleID');
    }


    public static function setSelectedSiteID($SiteID){
        Session::put('SelectedSiteID',$SiteID);
        @session_start();
        $_SESSION["siteID"] = $SiteID;
    }
    public static function getSelectedSiteID(){
        return 	Session::get('SelectedSiteID');
    }

    public static function setSelectedTimeZone($TimeZone){
        Session::put('SelectedTimeZone',$TimeZone);
    }

    public static function getSelectedTimeZone(){
        return Session::get('SelectedTimeZone');
    }

    public static function RemoveSessionForgetURL(){
        return  Session::forget('RedirectURL');
    }

    public static function getRedirectURL(){
        return 	Session::get('RedirectURL');
    }
    public static function setRedirectURL($RedirectURL){
        Session::put('RedirectURL',$RedirectURL);
    }

    public static function SessionFlush(){
        Session::flush();
    }

}
?>