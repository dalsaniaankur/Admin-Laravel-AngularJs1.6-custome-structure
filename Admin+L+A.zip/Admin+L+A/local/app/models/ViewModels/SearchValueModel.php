<?php
namespace ViewModels;

class SearchValueModel {
	public $Name;
	public $Value;
	public $CheckForExactMatch;
}
