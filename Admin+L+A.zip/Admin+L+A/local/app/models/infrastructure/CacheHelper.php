<?php
namespace Infrastructure;

use dataproviders\BaseDataProvider;
use Infrastructure\Constants;
use Infrastructure\Common;
use ViewModels\ServiceResponse;
use Illuminate\Support\Facades\Config;

class CacheHelper {
    public static function CacheManage($siteID,$cacheEntityID,$cacheAction,$entityID,$slug='',$IsWbProperty=0){
        $response =new ServiceResponse();
        $baseDataProvider = new BaseDataProvider();
        $baseURL = $baseDataProvider->getWebSiteBaseURL($siteID);
        $fullURL = $baseURL.'/'.Constants::$manageCache;
        switch ($siteID) {
            case Constants::$MercerVineSiteID :
                $username = Config::get('config.BasicAuthUserNameMercerVine');
                $password = Config::get('config.BasicAuthPasswordMercerVine');
                $response->Data = [ 'CacheAction' => $cacheAction, 'CacheEntityID' => $cacheEntityID, 'EntityID' => $entityID,'CacheSlug'=>$slug,'IsWBProperty'=>$IsWbProperty];
                Common::CurlRequest($fullURL,'POST',json_encode($response),$apikey="",$username,$password);
                break;
            case Constants::$ColoradoSiteID :
                $username = Config::get('config.BasicAuthUserNameColorado');
                $password = Config::get('config.BasicAuthPasswordColorado');
                $response->Data = [ 'CacheAction' => $cacheAction, 'CacheEntityID' => $cacheEntityID, 'EntityID' => $entityID,'CacheSlug'=>$slug];
                Common::CurlRequest($fullURL,'POST',json_encode($response),$apikey="",$username,$password);
                break;
            case Constants::$WoodBridgeWealthSiteID :
                break;
            case Constants::$RiverDaleFundingSiteID :
                $username = Config::get('config.BasicAuthUserNameRiverdale');
                $password = Config::get('config.BasicAuthPasswordRiverdale');
                $response->Data = [ 'CacheAction' => $cacheAction, 'CacheEntityID' => $cacheEntityID, 'EntityID' => $entityID,'CacheSlug'=>$slug];
                Common::CurlRequest($fullURL,'POST',json_encode($response),$apikey="",$username,$password);
                break;
        }
    }

    public static function ClearCache($siteID,$baseURL) {
        $fullURL = $baseURL.'/'.Constants::$ClearCache;
        switch ($siteID) {
            case Constants::$MercerVineSiteID :
                $username = Config::get('config.BasicAuthUserNameMercerVine');
                $password = Config::get('config.BasicAuthPasswordMercerVine');

                Common::CurlRequest($fullURL,'get',$updateData = '',$apiKey='',$username,$password);
                break;
            case Constants::$ColoradoSiteID :
                $username = Config::get('config.BasicAuthUserNameColorado');
                $password = Config::get('config.BasicAuthPasswordColorado');
                Common::CurlRequest($fullURL,'get',$updateData = '',$apiKey='',$username,$password);
                break;
            case Constants::$WoodBridgeWealthSiteID :
                break;
            case Constants::$RiverDaleFundingSiteID :
                $username = Config::get('config.BasicAuthUserNameRiverdale');
                $password = Config::get('config.BasicAuthPasswordRiverdale');

                Common::CurlRequest($fullURL,'get',$updateData = '',$apiKey='',$username,$password);
                break;
        }
        return true;
    }
}