<?php
namespace Infrastructure;
use Illuminate\Mail\Mailer;

class Constants
{
    /* RB */

      /* Role */
    public static $RoleBloggerDesigner=1;
    public static $RoleMarketingDirector=2;
    public static $RoleLegal=3;
    public static $RoleITAdmin=4;
    public static $RoleSEOConsultant=5;
    public static $RoleAgent=6;
    public static $RoleProcessing=7;
    public static $RoleNoAccess=8;

    public static $RoleChooseSite=0;
      /* Role */

    public static $encrypt ='encrypt';
    public static $decrypt ='decrypt';

    public static $IsVerified_True=1;
    public static $IsVerified_False=0;


    public static $defaultTimeZone = 'America/Los_Angeles';
    public static $databaseDefaultTimeZone = 'GMT';
    public static $DefaultDateTimeFormat = 'Y-m-d H:i:s';
    public static $DateFormatServerSide = "m/d/Y";
    public static $YMDDateFormatServerSide = "Y-m-d";
    public static $QueryStringUserID ='UserID';
    public static $QueryStringSiteID = 'SiteID';
    public static $ExactMatch = 1;
    public static $passwordRegex = '/^(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{12,}/';
    public static $emailRegex = '[A-Za-z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$';

    public static $LoginNotFound = '4';
    public static $UserStatusPending = '1';
    public static $UserNotVerified = '0';
    public static $UserStatusDisable = '3';
    public static $UserHaveNoRole = '2';
    public static $LoginError ='-1';
    public static $UserStatusActive = '6';
    public static $adminCannotChangeNoAccessToAllSite ='9';
    public static $cannotChaneStatusToDisabled='10';
    public static $CannotChangeStatusPendingToActive='11';
    public static $CannotChangeStatusPendingToDisable='12';
    public static $emailAlreadyExist='13';
    public static $UserStatusActiveWithOneSiteAccess = '5';
    public static $Email_VerificationEmail = 'emails.verificationemail';
    public static $Email_ResetPasswordEmail = 'emails.Resetpasswordemail';
    public static $Email_VerificationEmailSubject = 'Verify your account';
    public static $Email_ResetPasswordEmailSubject = 'Reset your password';
    public static $Email_ResetPassword_Confirmation_EmailSubject = 'Password changed';
    public static $Email_ResetPassword_Confirmation_Email = 'emails.resetpasswordconfirmationemail';
    public static $Email_PageAssignedEmail = 'emails.pageassignedemail';
    public static $Email_PageAssignedEmailSubject = 'Page Assigned to you';
    public static $Email_BlogAssignedEmail = 'emails.blogassignedemail';
    public static $Email_BlogAssignedEmailSubject = 'Blog Assigned to you';

    public static $addUserSuccess =1;
    public static $addUserSelectRole =2;
    public static $addUserCanNotChangeStatusADtoPending=4;


    public static $siteMercerVine = 'Mercer Vine';
    public static $siteColorado = 'Colorado';
    public static $siteWoodBridgeWealth = 'Woodbridge Wealth';
    public static $siteRiverDaleFunding = 'Riverdale Funding';


    public static $Value_True = 1;
    public static $Value_False = 0;

    public static $projectNameTitle = "Admin CMS";
    public static $footerText = "© 2016 Woodbridge Group of Companies, LLC. All Rights";

    public static $AuthSeparator = "-";
    public static $Separator ='@';

    public static $filedSiteID='SiteID';

        /* AWS */
        //public static $AWSuccessAction = '201';
        //public static $AWSAcl_Private = 'private';
        //public static $AWSAcl_Public = 'public-read';
        // public static $AWSRequestType_Profile_Folder='profileimages';
    public static $AWSRequestType_Profile='profile';
    public static $AWSRequestType_Video='videos';
    public static $AWSRequestType_Configuration='configurations';
    public static $AWSRequestType_Development='developments';
    public static $AWSRequestType_Loan='loans';
    public static $AWSRequestType_Home='home';
    public static $AWSRequestType_LandingPage = 'landingpage';
    public static $AWSRequestType_Listing='listings';
    public static $AWSRequestType_Pages='pages';
    public static $AWSRequestType_Blogs='blogs';


    /*Promotion Image size*/
    public static $DefaultUploadProfileWidth = 232;
    public static $DefaultUploadProfileHeight = 232;

    public static $AllStateValue ="";
    public static $AllStateText ="-- select --";
    public static $GeoMainURL ="https://maps.googleapis.com/maps/api/geocode/json?address";

    public static $maxFailedAttempts=5;
    public static $sortIndexTitle='Title';

    public static $addSuccessStatus = 1;
    public static $uniqueStatus =2;
    public static $pageNotAllowed=3;
    public static $pageSavePermissionNotFound='404';

    public static $SaveWorkFlowActionType =1;
    public static $ApproveWorkFlowActionType =2;
    public static $DenyWorkFlowActionType =3;
    public static $PublishWorkFlowActionType =4;

    public static $WorkFlowStatus_Draft =1;
    public static $WorkFlowStatus_PendingReview =2;
    public static $WorkFlowStatus_PendingLegal =3;
    public static $WorkFlowStatus_Approve =4;
    public static $WorkFlowStatus_Published =5;
    public static $WorkFlowStatus_Denied =6;

    Public static $workFlowValue_True=1;
    Public static $workFlowValue_False=0;

    public static $multipleInterventionDimension = array(
                        array('Width'=>425, 'Height'=>267, 'InterventionType'=>'fit', 'postfix' => '-thumb' , 'For' => 'PropertyDetail'),
                        array('Width'=>820, 'Height'=>470, 'InterventionType'=>'fit', 'postfix' => '-mvprop' , 'For' => 'New Properties section'),
                        array('Width'=>700, 'Height'=>490, 'InterventionType'=>'fit', 'postfix' => '-featured' , 'For' => 'Featured Section Row 1'),
                        array('Width'=>460, 'Height'=>583, 'InterventionType'=>'fit', 'postfix' => '-featuredl' , 'For' => 'Featured Section Row 2 (Left)'),
                        array('Width'=>940, 'Height'=>583, 'InterventionType'=>'fit', 'postfix' => '-featuredr' , 'For' => 'Featured Section Row 2 (Right)')
    );

    public static $multipleInterventionFitDimension = array(
        array('Width'=>425, 'Height'=>267, 'InterventionType'=>'fit', 'postfix' => '-thumb' , 'For' => 'PropertyDetail'),
        array('Width'=>820, 'Height'=>470, 'InterventionType'=>'fit', 'postfix' => '-mvprop' , 'For' => 'New Properties section'),
        array('Width'=>700, 'Height'=>490, 'InterventionType'=>'fit', 'postfix' => '-featured' , 'For' => 'Featured Section Row 1'),
        array('Width'=>460, 'Height'=>583, 'InterventionType'=>'fit', 'postfix' => '-featuredl' , 'For' => 'Featured Section Row 2 (Left)'),
        array('Width'=>940, 'Height'=>583, 'InterventionType'=>'fit', 'postfix' => '-featuredr' , 'For' => 'Featured Section Row 2 (Right)')
    );
    public static $singleInterventionDimension = array( array('Width' =>425, 'Height' => 267, 'InterventionType' => 'fit','postfix' => '-thumb', 'For' => 'PropertyDetail'));

    public static $LoanInterventionDimension = array('Width' =>307, 'Height' => 231, 'InterventionType' => 'fit','postfix' => '', 'For' => 'Loans');
    public static $isWoodBridge = 1;
    public static $isNotWoodBridge = 0;

    public static $isPropertyImagesInterventionCronRunningField = 'IsPropertyImagesInterventionCronRunning';
    /* RB Region End*/

    /* Start Region Dev_Drashtant */

    public static $Text_Status_Disable = 'Disable';
    public static $Status_Pending = '1';
    public static $Status_Active = '2';

    public static $Status_Disable = '3';
    public static $Agent_Role_ID = '6';
    public static $Is_Enabled_For_MVCO = 'IsEnabledForMVandCO';
    public static $Is_Enabled_For_RDWW = 'IsEnabledForRDandWW';

    public static $twitterCardSummery="summary";


    /* Stop Region Dev_Drashtant */


    /*Start Dev_VishalA*/
    public static $SortIndex = 'AgentName';
    public static $SortIndexASC = 'ASC';
    public static $UserPagerSize = 10;
    public static $AllRecords = -1;
    public static $TotalItemsCountColumn = "TotalItemsCount";
    public static $QueryStatusID = "StatusID";
    public static $AllStatusText = "All";
    public static $AllStatusValue = "";
    public static $AllRolesText = "-- select --";
    public static $AllRolesValue = "";
    public static $QueryStringDevelopmentID = "DevelopmentID";
    public static $QueryType_Select = "Select";
    public static $QueryType_Delete = "Delete";
    public static $QueryType_Insert = "Insert";
    public static $QueryType_Update = "Update";
    public static $QueryStringTestimonialID = "TestimonialID";
    public static $SortTestIndex = 'Testimonial';
    public static $Visible_True = 'True';
    public static $Visible_False = 'False';
    public static $SortOrder = 'SortOrder';
    public static $QueryStringPageID = "PageID";
    public static $RoleCSVForAuthor = "2,3,4,5";
    public static $getBlogRoleCSVForAuthor = "1,2,3,4,5,6";
    public static $DefaultStatusDraft = 1;
    public static $FBImageType = 1;
    public static $TwitterImageType = 2;
    public static $GoogleImageType = 3;
    public static $BlogFeaturedImageType = 4;
    public static $PageTopImageType = 5;
    public static $PageBottomRightImageType = 6;
    public static $ImageMaxSize = 1048576;
    public static $QueryStringBlogPostID = 'BlogPostID';
    /*End Dev_VishalA*/


    /* Ayushi Region Start */
    public static $PropertyImageDeleteCronJobField = 'IsPropertyImageDeleteCronJobRunning';
    public static $DeletePropertyImagesCronJobURL = 'deletepropertyimages';
    /* Ayushi Region End */

    /* Dev_DN Region Start */

    public static $MercerVineSiteID=1;
    public static $ColoradoSiteID=2;
    public static $WoodBridgeWealthSiteID=3;
    public static $RiverDaleFundingSiteID=4;

    /* Dev_DN Region End */

    public static $DefaultErrorHeader = "Default Error";

    public static $ServerErrorHeader="Server Error";
    public static $ServerErrorMessage="<p>Sorry, it looks as though something broke in our system.<br/>If you continue to experience technical difficulties with the page you're trying to reach, please let us know!</p>";
    public static $NotFoundHeader="Page Not Found";
    public static $NotFoundCodeMsg="404 Not Found";
    public static $NotFoundErrorMessage="Sorry, the page you're looking for isn't here.";
    public static $ForbiddenHeader="Forbidden";
    public static $ForbiddenErrorMessage="<p>You do not have permission to retrieve the URL or link you requested.<br/>Please inform the administrator of how you got here, if you think this was a mistake.</p>";
    public static $ForbiddenCodeMsg="403 Access Denied";
    public static $CommonErrorCodeMsg="Something's wrong";

    /* AD Region Start */
    public static $Isused = 1;
    public static $IsNotused = 0;
    //public static $UserNotFound = 0;
    public static $UserNotFound = 404;
    public static $IsForVerification = 1;
    public static $QueryStringFAQID = 'FAQID';
    public static $DevelopmentsSortIndex = 'Name';
    public static $VideoCategoriesSortIndex = 'Category';
    public static $SiteTagsSortIndex = 'Tag';
    public static $QueryStringVideoID = 'VideoID';
    //public static $WebsiteUrlRegex = '^(http[s]?:\\/\\/(www\\.)?|ftp:\\/\\/(www\\.)?|www\\.){1}([0-9A-Za-z-\\.@:%_\+~#=]+)+((\\.[a-zA-Z]{2,3})+)(/(.)*)?(\\?(.)*)?';
    public static $WebsiteUrlRegex = '^((http[s]?:\\/\\/(www\\.)?|ftp:\\/\\/(www\\.)?|www\\.){1}([0-9A-Za-z-\\.@:%_\+~#=]+)+((\\.[a-zA-Z]{2,3})+)(/(.)*)?(\\?(.)*)?|/{1}(((/{1}\.{1})?[a-zA-Z0-9-]+/?)+(\.{1}[a-zA-Z0-9-]{2,4})?)?)';
    public static $GooglePlusUrlRegex = '^(http[s]?:\\/\\/(www\\.)?|ftp:\\/\\/(www\\.)?|www\\.){1}([0-9A-Za-z-\\.@:%_\+~#=]+)+((\\.[a-zA-Z]{2,3})+)(/(.)*)?(\\?(.)*)?';
    public static $LinkedInUrlRegex = '^(http[s]?:\\/\\/(www\\.)?|ftp:\\/\\/(www\\.)?|www\\.){1}([0-9A-Za-z-\\.@:%_\+~#=]+)+((\\.[a-zA-Z]{2,3})+)(/(.)*)?(\\?(.)*)?';
    public static $YoutubeRegex = '^(?:https?:\/\/)?(?:www\.)?(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))((\w|-){11})((?!https?)\S+)?$';
    public static $zipRegex = '/^\d{5}?$/';
    public static $FaxRegex = '^\d{10}$';
    public static $MobilePhoneRegex = '^\d{10}$';
    public static $CalBreNoRegex = '^\w{8,15}$';
    public static $OpacityRegex = '\b(0*(?:[1-9][0-9]?|100))\b';
    public static $UserActive = 2;
    public static $ShowHidden = -1;
    public static $AmazonBasePath = 'https://s3.amazonaws.com/local-cms-wb';
    public static $QueryStringListingID = 'ListingID';
    public static $Property_Status_Active = '1';
    public static $Property_Default_Status = '-1';
    public static $QueryStringCategoryID = 'CategoryID';
    public static $SortIndexCategory = 'Category';
    public static $SortIndexDESC = 'DESC';
    public static $CategoryPagerSize = 15;
    public static $CategoryCurrentPager = 1;
    public static $DefaultCategorized = 'Uncategorized';
    public static $SortIndexTag = 'Tag';
    public static $TagPagerSize = 15;
    public static $PageIndex = 'PageIndex';
    public static $IsFeatured = '-1';
    public static $PriceRegex = '^\d+(\.\d{1,2})?$';
    public static $CheckForExactMatch = 1;
    public static $PageStatusPublished = 5;
    public static $WebsiteBaseURLRegex = '^(http[s]?:\\/\\/(www\\.)?|ftp:\\/\\/(www\\.)?|www\\.){1}([0-9A-Za-z-\\.@:%_\+~#=]+)+((\\.[a-zA-Z]{2,3})+)(/(.)*)?(\\?(.)*)?';
    public static $AwsURLRegex = '^(https:\\/\\/(www\\.)?|ftp:\\/\\/(www\\.)?|www\\.){1}([0-9A-Za-z-\\.@:%_\+~#=]+)+((\\.[a-zA-Z]{2,3})+)(/(.)*)?(\\?(.)*)?\\/';
    public static $YoutubeChannelRegex = '((http|https):\/\/|)(www\.)?youtube\.com\/(channel\/|user\/)[a-zA-Z0-9-_]{1,}';
    public static $IsFAQTypeEnabled = 1;
    public static $QueryStringHomeID = 'HomeID';
    public static $HoverImageType = 1;
    public static $VideoType = 2;
    public static $InvalidNavigation = "Menu item name is required.";
    public static $BackgroundImagesType = 1;
    public static $HoverImagesType = 2;
    public static $MVItem1ImageType = 3;
    public static $MVItem2ImageType = 4;
    public static $MVItem3ImageType = 5;
    public static $YoutubeVideoImageType = 6;
    public static $HomeFacebookImageType = 7;
    public static $HomeTwitterImageType = 8;
    public static $HomeRichSnippetsImageType = 9;
    public static $HomeSectionSimpleType = 1;
    public static $HomeSectionSliderType = 2;
    public static $HomeSectionVideoType = 2;
    public static $QueryStringHomepageID = 'HomepageID';
    public static $HomePageVideoMP3Type = 1;
    public static $HomePageVideoOggType = 2;
    public static $HomePageVideoWebmType = 3;
    public static $HomePageVideoMaxFileSize = 104857600;
    public static $AgentProfileImageType = 1;
    public static $AgentSmallerImageType = 2;
    public static $DevelopmentTopImageType = 1;
    public static $DevelopmentFeatureImageType = 2;
    public static $DevelopmentFeatureImageErrorMessage = "Images width should be 1700px & height should be 801px.";
    public static $DevelopmentFeatureImageWidth = 1700;
    public static $DevelopmentFeatureImageHeight = 801;
    public static $AddGeryScale = '-geryscale';

    public static $CkEditorUploadFilePaths = array('"/upload/images/', '"/upload/files/');
    public static $RDHomeBlock1ImageType = 1;
    public static $RDHomeBlock2ImageType = 2;
    public static $RDHomeBlock3ImageType = 3;
    public static $RDHomeFacebookImageType = 4;
    public static $RDHomeTwitterImageType = 5;
    public static $RDHomeRichSnippetImageType = 6;

    public static $COHomeTopCTABlock1ImageType = 1;
    public static $COHomeTopCTABlock2ImageType = 2;
    public static $COHomeBottomCTABlock1ImageType = 3;
    public static $COHomeBottomCTABlock2ImageType = 4;
    public static $COHomeBottomCTABlock3ImageType = 5;
    public static $COHomeFacebookImageType = 6;
    public static $COHomeTwitterImageType = 7;
    public static $COHomeRichSnippetsImageType = 8;
    public static $COHomeVideoMP4Type = 9;
    public static $COHomeVideoOggType = 10;
    public static $COHomeVideoWebmType = 11;
    public static $COVideoPosterType = 11;

    public static $postfixSmallImage = '-sm';
    public static $smallImageWidth = 475;
    public static $smallImageHeight = 126;

    public static $DefaultShowBrokerPackageCTA = 0;

    public static $cacheHomeID = 1;
    public static $cachePagesID = 2;
    public static $cacheBlogID = 3;
    public static $cacheDevelopmentID = 4;
    public static $cacheVideoID = 5;
    public static $cacheAgentID = 6;
    public static $cachePropertyID = 7;
    public static $cacheNavigationID = 8;
    public static $cacheFaqID = 9;
    public static $cacheUserID = 10; /* remove */
    public static $cacheSiteConfigurationID = 11;
    public static $cacheCategoryID = 12;
    public static $cacheTagID = 13;
    public static $cacheLoansClosedID = 14;
    public static $cacheSiteTestimonialsID = 15;

    public static $cacheActionInsert = 1;
    public static $cacheActionUpdate = 2;
    public static $cacheActionDelete = 3;
    public static $cacheUpdateSortOrder = 4;

    public static $MVCachingManageURL = "http://192.168.1.161/woodbridge/trunk/mercerVine/Development/mv/managecache";
    public static $MVBaseURL = "http://mv.lithyemstaging.com";
    public static $RDBaseURL = "http://rdf.lithyemstaging.com";
    public static $manageCache = 'managecache';
    public static $ClearCache ='cacheclear';

    public static $SPNameDeletePages = "deletepages";

    public static $WWHomeTopCTABlock1ImageType = 1;
    public static $WWHomeTopCTABlock1HoverImageType = 2;
    public static $WWHomeTopCTABlock2ImageType = 3;
    public static $WWHomeTopCTABlock2HoverImageType = 4;
    public static $WWHomeTopCTABlock3ImageType = 5;
    public static $WWHomeTopCTABlock3HoverImageType = 6;
    public static $WWHomeTopCTABlock4ImageType = 7;
    public static $WWHomeTopCTABlock4HoverImageType = 8;

    public static $WWHomeBottomCTABlock1ImageType = 9;
    public static $WWHomeBottomCTABlock2ImageType = 10;

    public static $WWFacebookImageType = 11;
    public static $WWTwitterImageType = 12;
    public static $WWRichSnippetsImageType = 13;
    public static $WWSliderImageType = 14;


    /* AD Region End */

    /*DEV_AYS Region Start */

    public static $DefaultMVStateID = '6';
    public static $DefaultColoradoStateID ='5';
    public static $RETSActionLogin = 'LOGIN';
    public static $RETSActionSearch = 'SEARCH PROPERTY';
    public static $RETSActionSearchMedia = 'SEARCH MEDIA';
    public static $PropertyOtherSubTypeID = 10;
    public static $PropertyOtherSecurityTypeID = 21;
    public static $PropertyOtherPoolID = 34;
    public static $PropertyOtherSpaID = 21;
    public static $PropertyOtherViewID = 45;
    public static $PropertyOtherStyleID = 64;
    public static $PropertyOtherRoofingID = 38;
    public static $PropertyOtherSewerID = 24;
    public static $PropertyOtherEquipmentID = 39;
    public static $PropertyOtherFlooringID = 27;
    public static $PropertyOtherHeatingID = 24;
    public static $PropertyOtherAirConditioningID = 16;
    public static $PropertyOtherRoomID = 77;
    public static $PropertyOtherFireplaceID = 31;
    public static $PropertyOtherLaundryID = 14;
    public static $PropertyOtherParkingID = 70;
    public static $PropertyOtherCourtID = 15;
    public static $PropertyOtherAmenityID = 57;
    public static $PropertyPriceRegex = '/^\d+(\.\d{0,2})?$/';
    public static $lotSizeRegex = '/^\d+\.?\d*$/';
    public static $squareFeetRegex = '/^\d+\.?\d*$/';
    public static $defaultStaticValue=-1;
    public static $anotherDBConnectionName='mysql2';
    /*DEV_AYS Region End */
    public static $multipleDelimeterArray="/,? ?and | ?[\\\,;: |*&#@\/] ?/";
    public static $skipFirstImageUpload=0;

    public static $SoldStatus='Sold';
    public static $SoldStatusID=4;
    public static $CronCSVInsert='insert';
    public static $CronCSVUpdate='update';
    public static $CronCSVUpdateStatus='updateStatus';
    public static $CronCSVDelete='delete';
    public static $BackUpStatus='Backup';
    public static $PropertyManagementCronCheck = 'IsPropertyManagementCronRunning';
    public static $StaticUserID=2;
    public static $StaticNullUserID=NULL;
    public static $maxImageUploadAttempt=5;
    public static $MVSiteOfficeID='X81313';
    public static $MVStatusField='CARETSListingStatus';

    /******* caretslistingstatus numaric *******/
    public static $ActiveListingStatus=50041200437; //active
    public static $ActiveContractStatus=50041200438; // Active Under Contract
    public static $ClosedListingStatus=50041200440; // Sold / closed
    public static $PendingListingStatus=50041200444; // pending
    /******* caretslistingstatus  *******/

    public static $RemainingActiveCheckField='IsActiveRemainCronRunning';
    public static $RemainingFailedActiveCheckField='IsPropertyImageCronFailedJobRunning';
    public static $RemainingFailedInterventionActiveCheckField='IsPropertyImageInterventionCronFailedJobRunning';

    /* Footer Error Message */

    public static $ForbiddenErrorFooterMessage = "Sorry, you are not authorised to access this page";
    public static $NotFoundErrorFooterMessage = "Sorry, The page you were looking for appears to have been moved, deleted or does not exist.";
    public static $ServerErrorFooterMessage = "An error occurred and your request couldn't be completed. Please try again.";
    public static $DefaultErrorFooterMessage = "Sorry, an error occurred";

    public static $imagecronjobflagfield='IsPropertyImageCronJobRunning';
    public static $imagecronjobflagfield1='IsPropertyImageCronJobRunning1';
    public static $imagecronjobflagfield2='IsPropertyImageCronJobRunning2';
    /* Footer Error Message */
    public static $MLSClassList = array('ResidentialLease','ResidentialIncome','ResidentialLand','ResidentialProperty','ResidentialMobileHome');

    public static $caretsLand='Lots and Land';
    public static $mlsLand='Residential Land';

    public static $caretsResidential='Residential';

    public static $caretsSingleFamily='Single Family';
    public static $mlsSingleFamily='Residential Single-Family';

    public static $caretsCondominium='Condominium';
    public static $mlsCondoCoOp='Residential Condo/Co-Op';

    public static $caretsMobileHome='Mobile Home';
    public static $mlsMobileHome='Residential Manufactured/Mobile';

    /*DEV_UP Region Start */
    public static $QueryStringLoanID = 'LoanID';

    
    /*DEV_UP Region End */


    /* Colorado Constant For Landing Page Image Get Start */
    public static $landingPageRealtors = 'realtors';
    public static $landingPageClientReviews = 'clientreviews';
    public static $landingPageSiteMap = 'sitemap';
    public static $landingPageGlossaryOfTerms  = 'glossaryofterms';
    public static $landingPageBlog = 'blog ';
    /* Colorado Constant For Landing Page Image Get End */

    public static $MVSlugRegex = '(?!^/?(properties|property|developments|blog|team-page|agents|contact-us|tagsearch|categorysearch|sitemap|sitesearch|communities|films|videocategorysearch|login|logout|cacheclear|dirPagination|logviewer)(/.*)?$)(^.*$)';
    public static $COSlugRegex = '(?!^/?(blog|categorysearch|tagsearch|faq|realtors|client-reviews|sitemap|contact-us|listingalert|neighborhoods|property|cacheclear|login|logout|dirPagination|logviewer)(/.*)?$)(^.*$)';
    public static $WWSlugRegex = '(?!^/?(first-position-commercial-mortgages|commercial-bridge-loan-fund|secondary-market-annuities|blog|categorysearch|tagsearch|contact-us|login|logout|cacheclear|login|logout|dirPagination|logviewer)(/.*)?$)(^.*$)';
    public static $RDSlugRegex = '(?!^/?(ebook|faq|loans-closed|news|categorysearch|states|apply-now|tagsearch|sitemap|login|logout|contact-us|cacheclear|dirPagination|logviewer)(/.*)?$)(^.*$)';

    public static $YoutubeAnyUrlRegex = '((http|https):\/\/|)(www\.)?youtube\.com\/([a-zA-Z0-9]+).*';
    
    /* check into getFieldID function */
    public static $WaterFieldName='Water';
    public static $CarportFieldName='Carport';
    public static $AccessFieldName='Access';
    public static $AmenitiesFieldName='Amenities';
    public static $ConditionsFieldName='Conditions';
    public static $ConstructionFieldName='Construction';
    public static $DisclosureFieldName='Disclosure';
    public static $ElectricFieldName='Electric';
    public static $ExteriorFieldName='Exterior';
    public static $ExtraFieldName='Extras';
    public static $FireplaceFieldName='Fireplace';
    public static $GasFieldName='Gas';
    public static $GreenFeaturesFieldName='GreenFeatures';
    public static $HeatingFieldName='Heating';
    public static $HoaAmenitiesFieldName='HoaAmenities';
    public static $LaundryFieldName='Laundry';
    public static $MineralRightsFieldName='MineralRights';
    public static $ParkingAreaFieldName='ParkingArea';
    public static $PossessionFieldName='Possession';
    public static $RoofFieldName='Roof';
    public static $SanitationFieldName='Sanitation';
    public static $ShowingInstructionsFieldName='ShowingInstructions';
    public static $StyleFieldName='Style';
    public static $SubStructureFieldName='SubStructure';
    public static $TermsOfferedFieldName='TermsOffered';
    public static $UnitFacesFieldName='UnitFaces';
    public static $WaterRightsFieldName='WaterRights';
    public static $UnfinishedSqFt='UnfinishedSqFt';
    public static $Bedroom1RoomLevel='Bedroom1RoomLevel';
    public static $Bedroom2RoomLevel='Bedroom2RoomLevel';
    public static $Bedroom3RoomLevel='Bedroom3RoomLevel';
    public static $Bedroom4PlusRoomLevel='Bedroom4PlusRoomLevel';
    public static $Bedroom4PlusRoomRemarks='Bedroom4PlusRoomRemarks';
    public static $FamilyRoomRoomLevel='FamilyRoomRoomLevel';
    public static $FullBathRoomLevel='FullBathRoomLevel';
    public static $LaundryOrUtilityRoomRoomLevel='LaundryOrUtilityRoomRoomLevel';
    public static $LivingRoomRoomLevel='LivingRoomRoomLevel';
    public static $Bedroom1Width='Bedroom1Width';
    public static $DiningRoomLength='DiningRoomLength';
    public static $DiningRoomWidth='DiningRoomWidth';
    public static $DiningRoomNoofRooms='DiningRoomNoofRooms';
    public static $DiningRoomRoomLevel='DiningRoomRoomLevel';
    public static $KitchenLength='KitchenLength';
    public static $KitchenWidth='KitchenWidth';
    public static $KitchenNoofRooms='KitchenNoofRooms';
    public static $KitchenRoomLevel='KitchenRoomLevel';
    public static $LivingRoomNoofRooms='LivingRoomNoofRooms';
    public static $LivingRoomWidth='LivingRoomWidth';
    public static $LivingRoomLength='LivingRoomLength';
    public static $SignFieldName='Sign';
    public static $AllowableUsesFieldName='AllowableUses';
    public static $Bedroom1RoomRemarksFieldName='Bedroom1RoomRemarks';
    public static $Bedroom1NoofRoomsFieldName='Bedroom1NoofRooms';
    public static $Bedroom1LengthFieldName='Bedroom1Length';
    public static $Bedroom1AreaFieldName='Bedroom1Area';
    public static $Bedroom2WidthFieldName='Bedroom2Width';
    public static $Bedroom2RoomRemarksFieldName='Bedroom2RoomRemarks';
    public static $Bedroom2LengthFieldName='Bedroom2Length';
    public static $Bedroom2AreaFieldName='Bedroom2Area';
    public static $Bedroom3WidthFieldName='Bedroom3Width';
    public static $Bedroom3RoomRemarksFieldName='Bedroom3RoomRemarks';
    public static $Bedroom3NoofRoomsFieldName='Bedroom3NoofRooms';
    public static $Bedroom3LengthFieldName='Bedroom3Length';
    public static $Bedroom3AreaFieldName='Bedroom3Area';
    public static $DiningRoomRoomRemarksFieldName='DiningRoomRoomRemarks';
    public static $DiningRoomAreaFieldName='DiningRoomArea';
    public static $KitchenRoomRemarksFieldName='KitchenRoomRemarks';
    public static $KitchenAreaFieldName='KitchenArea';
    public static $WorkShopWidthFieldName='WorkShopWidth';
    public static $WorkShopRoomRemarksFieldName='WorkShopRoomRemarks';
    public static $WorkShopLengthFieldName='WorkShopLength';
    public static $WorkShopAreaFieldName='WorkShopArea';

    public static $HoaDuesFieldName='HoaDues';
    public static $LocationAmenityFieldName='LocationAmenity';
    public static $HeatingAndCollingName='HeatingAndColling';
    
    /* check into getFieldID function */

    public static $checkForYes='Yes';
    public static $checkForNo='No';
    public static $YesValue='1';
    public static $NoValue='2';
    public static $CoISHiddenYes='Y';
    public static $CoISHiddenNo='N';

    public static $CoQueryStringListingID = 'CoListingID';

    //Active,pending - Colorado //closed
    public static $Residential='RNKKL0G8XM0,RNKKL0G8Y02'; //RNKKL0G8XOO,
    public static $Fractional='ROJN7146Q5J,ROJN7148I5C'; //ROJN714720A,
    public static $CommercialIndustrial='RON6W2B6Y85,RON6W2B8KPJ'; //RON6W2B79TS,
    public static $CommercialLease='RON7FPP5EEX,RON7FPPB3GR'; //RON7FPP6HDE,
    public static $LandResidential='ROM4RJCMCB6,ROM4RJCNZFJ'; //ROM4RJCMNYT,
    public static $LandCommercial='ROMHZBB3JF6,ROMHZBB5AUE'; //ROMHZBB3VOT,
    public static $Rentals='ZP4HK8YWNDK,ZP4HK8YY4O3'; //ZP4HK8YXF4C,

    public static $Co_AllPropertyCronJobFlag='CoIsAllPropertyCronRunning';
    public static $Co_ImageUploadCronJob='CoIsPropertyImageUploadCronRunning';
    public static $Co_ImageInterventionCronJobFlag='CoIsPropertyImageInterventionCronRunning';

    public static $ComultipleInterventionDimension = array(
        array('Width'=>457, 'Height'=>405, 'InterventionType'=>'fit', 'postfix' => '-thumb' , 'For' => 'PropertyDetail')
    );

    public static $COPropertyManagementCronCheck = 'COIsPropertyManagementCronRunning';

    public static $COCronCSVInsert='insert';
    public static $COCronCSVUpdate='update';
    public static $COCronCSVInsertStatus='newinsert';
    public static $COCronCSVDelete='delete';
    public static $COBackUpStatus='Backup';

    public static $COResidentialClass=1;
    public static $COFractionalClass=2;
    public static $COCommercialIndustrialClass=3;
    public static $COCommercialLeaseClass=4;
    public static $COLandResidentialClass=5;
    public static $COLandCommercialClass=6;
    public static $CORentalsClass=7;


    public static $ResidentialAll='RNKKL0G8XM0,RNKKL0G8Y02,RNKKL0G8YAX,RNKKL0G8Y5P,RNKKL0G8XOO';
    public static $COSiteOfficeID='20141119212758502045000000';

    public static $CheckForLastDate='2016-10-28T18:30:00';

    public static $CoFailedImageCronJob='CoIsPropertyFailedImageCronJobRunning';
    public static $CoFailedImageInterventionCronJob='CoIsPropertyFailedImageInterventionCronJobRunning';
}


