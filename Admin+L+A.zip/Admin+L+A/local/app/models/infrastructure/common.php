<?php

namespace Infrastructure;

use \EmailEntity;
use \SettingEntity;
use \Mail;
use \stdClass;
use \URL;
use Illuminate\Support\Facades\Config;
use \ViewModels\SearchValueModel;
use \dataproviders\BaseDataProvider;
use PHPMailer;
use \ViewModels\SortModel;
use \DateTime;
use \DateTimeZone;
use \Image;
use \File;
use \Exception;

class Common
{
    public static function getAllRoleArray()
    {
        return $AllRolesArray = Constants::$RoleBloggerDesigner . Constants::$Separator . Constants::$RoleMarketingDirector . Constants::$Separator . Constants::$RoleLegal . Constants::$Separator . Constants::$RoleITAdmin . Constants::$Separator . Constants::$RoleSEOConsultant . Constants::$Separator . Constants::$RoleAgent . Constants::$Separator . Constants::$RoleProcessing;
    }

    public static function getAllSiteArray()
    {
        return $AllSiteArray = Constants::$MercerVineSiteID . Constants::$Separator . Constants::$ColoradoSiteID . Constants::$Separator . Constants::$WoodBridgeWealthSiteID . Constants::$Separator . Constants::$RiverDaleFundingSiteID;
    }

    public static function getSiteMercerVineColorado()
    {
        return $siteMercerVineColorado = Constants::$MercerVineSiteID . Constants::$Separator . Constants::$ColoradoSiteID;
    }

    public static function getRoleITAdminMD()
    {
        return $roleITAdminMD = Constants::$RoleITAdmin . Constants::$Separator . Constants::$RoleMarketingDirector;
    }

    public static function getRoleMDITAdminSEO()
    {
        return $roleMDITAdminSEO = Constants::$RoleMarketingDirector . Constants::$Separator . Constants::$RoleITAdmin . Constants::$Separator . Constants::$RoleSEOConsultant;
    }

    public static function getRoleMDITAdminAgent()
    {
        return $roleMDITAdminAgent = Constants::$RoleMarketingDirector . Constants::$Separator . Constants::$RoleITAdmin . Constants::$Separator . Constants::$RoleAgent;
    }

    public static function getRoleMDITAdminSEOLegal()
    {
        return $roleMDITAdminSEOLegal = Constants::$RoleMarketingDirector . Constants::$Separator . Constants::$RoleITAdmin . Constants::$Separator . Constants::$RoleSEOConsultant . Constants::$Separator . Constants::$RoleLegal;
    }

    public static function getRoleMDITAdminLegal()
    {
        return $roleMDITAdminLegal = Constants::$RoleITAdmin . Constants::$Separator . Constants::$RoleLegal . Constants::$Separator . Constants::$RoleMarketingDirector;
    }

    public static function getRoleITAdminLegal()
    {
        return $roleITAdminLegal = Constants::$RoleITAdmin . Constants::$Separator . Constants::$RoleLegal;
    }

    public static function getRoleITAdminAndAgent()
    {
        return $roleITAdminAndAgent = Constants::$RoleITAdmin . Constants::$Separator . Constants::$RoleAgent;
    }

    public static function getRoleBloggerMDITSEOAgent()
    {
        return $roleBloggerMDITSEOAgent = Constants::$RoleBloggerDesigner . Constants::$Separator . Constants::$RoleMarketingDirector . Constants::$Separator . Constants::$RoleITAdmin . Constants::$Separator . Constants::$RoleAgent . Constants::$Separator . Constants::$RoleSEOConsultant;
    }

    public static function getRoleBloggerMDITSEOAgentLegal()
    {
        return $roleBloggerMDITSEOAgentLegal = Constants::$RoleBloggerDesigner . Constants::$Separator . Constants::$RoleMarketingDirector . Constants::$Separator . Constants::$RoleITAdmin . Constants::$Separator . Constants::$RoleSEOConsultant . Constants::$Separator . Constants::$RoleAgent . Constants::$Separator . Constants::$RoleLegal;
    }

    /*Start Dev_VA*/
    public static function setSelectedPropertyValueToIntOfList($list, $fieldArray)
    {
        //return array_map(function($o) use ($fieldArray) {foreach($fieldArray as $property){ $o->{$property} = intval($o->{$property});}  },$list);
        foreach ($list as $item) {
            foreach ($fieldArray as $field) {
                if (isset($item->{$field}))
                    $item->{$field} = intval($item->{$field});
            }
        };
        return $list;
    }
    /*End Dev_VA*/


    /* Start Dev_AD */
    public static function getSiteMercerVineWoodbridgeColorado()
    {
        return $siteMercerVineColorado = Constants::$MercerVineSiteID . Constants::$Separator . Constants::$WoodBridgeWealthSiteID . Constants::$Separator . Constants::$ColoradoSiteID;
    }

    public static function getRoleITAdminMDAgent()
    {
        return $roleITAdminMD = Constants::$RoleITAdmin . Constants::$Separator . Constants::$RoleMarketingDirector . Constants::$Separator . Constants::$RoleAgent;
    }

    public static function getRoleITAdminMDAgentBloggerSEO()
    {
        return $roleITAdminMD = Constants::$RoleITAdmin . Constants::$Separator . Constants::$RoleMarketingDirector . Constants::$Separator . Constants::$RoleAgent . Constants::$Separator . Constants::$RoleBloggerDesigner . Constants::$Separator . Constants::$RoleSEOConsultant;
    }
    public static function GetBetween($var1 = "", $var2 = "", $pool){
        $temp1 = strpos($pool, $var1) + strlen($var1);
        $result = substr($pool, $temp1, strlen($pool));
        $dd = strpos($result, $var2);
        if ($dd == 0) {
            $dd = strlen($result);
        }
        return substr($result, 0, $dd);
    }
    public static function createSmallSizeImage($postfix,$fullImagePath,$width,$height,$userID){
        $image = Image::make($fullImagePath);
        $image->resize($width, $height);
        $ext = File::extension($fullImagePath);
        $base64 = (string)$image->encode($ext);
        $filePath = explode('/',$fullImagePath);
        $fileNm = $filePath[count($filePath) - 1];
        $name = pathinfo($fileNm, PATHINFO_FILENAME);
        $filename = $name . $postfix . '.' . $ext;

        $baseDataProvider = new BaseDataProvider();
        $baseDataProvider->FileUpload(Constants::$AWSRequestType_Pages,$userID,Constants::$RiverDaleFundingSiteID, $filename, $base64);
    }
    /* End Dev_AD */

    /* RB Region Start */
    public static function setSingleDimArrayValuesToInt($array)
    {
        return array_map(function ($o) {
            $o = intval($o);
            return $o;
        }, $array);
    }

    public static function SetIsCronJobRunning(&$maxFailedMailAttempt){
        $baseDataProvider = new BaseDataProvider();
        $data = $baseDataProvider->CallRawForSingleTable('setunsetcronjob',['',$maxFailedMailAttempt]);

        if(isset($data[0]->MaxFailedMailAttempt))
            $maxFailedMailAttempt = $data[0]->MaxFailedMailAttempt;

        return $data[0]->Status;
    }

    public static function UnsetIsCronJobRunning(){
        $baseDataProvider = new BaseDataProvider();
        $baseDataProvider->CallRawForSingleTable('setunsetcronjob',[1,'']);
    }


    public static function SetCronJobRunning($field){
        $baseDataProvider = new BaseDataProvider();
        $data=array();
        switch($field){
            case Constants::$isPropertyImagesInterventionCronRunningField :
                $data = $baseDataProvider->CallRawForSingleTable('setunsetcronjobforintervention',['']);
                break;
            case Constants::$imagecronjobflagfield :
                $data = $baseDataProvider->CallRawForSingleTable('setunsetcronjobforpropertyimage',['']);
                break;
            case Constants::$PropertyManagementCronCheck :
                $data = $baseDataProvider->CallRawForSingleTable('setunsetcronjobformanageproperty',['']);
                break;
            case Constants::$PropertyImageDeleteCronJobField :
                $data = $baseDataProvider->CallRawForSingleTable('setunsetcronjobfordeletepropimage',['']);
                break;
            case Constants::$RemainingFailedActiveCheckField :
                $data = $baseDataProvider->CallRawForSingleTable('setunsetcronjobforimagecronjobfail',['']);
                break;
            case Constants::$RemainingFailedInterventionActiveCheckField:
                $data = $baseDataProvider->CallRawForSingleTable('setunsetforinterventioncronjobfail',['']);
                break;
            case Constants::$COPropertyManagementCronCheck:
                $data = $baseDataProvider->CallRawForSingleTable('setunsetforcoispropertymanagementcron',['']);
                break;
            case Constants::$CoFailedImageCronJob :
                $data = $baseDataProvider->CallRawForSingleTable('co_setunsetcronjobforimagecronjobfail',['']);
                break;
            case Constants::$CoFailedImageInterventionCronJob:
                $data = $baseDataProvider->CallRawForSingleTable('co_setunsetforinterventioncronjobfail',['']);
                break;
        }

        return $data[0]->Status;
    }

    public static function UnsetCronJobRunning($field){
        $baseDataProvider = new BaseDataProvider();
        switch($field){
            case Constants::$isPropertyImagesInterventionCronRunningField :
                $baseDataProvider->CallRawForSingleTable('setunsetcronjobforintervention',[1]);
                break;
            case Constants::$imagecronjobflagfield :
                $baseDataProvider->CallRawForSingleTable('setunsetcronjobforpropertyimage',[1]);
                break;
            case Constants::$PropertyManagementCronCheck :
                $baseDataProvider->CallRawForSingleTable('setunsetcronjobformanageproperty',[1]);
                break;
            case Constants::$PropertyImageDeleteCronJobField :
                $baseDataProvider->CallRawForSingleTable('setunsetcronjobfordeletepropimage',[1]);
                break;
            case Constants::$RemainingFailedActiveCheckField :
                $baseDataProvider->CallRawForSingleTable('setunsetcronjobforimagecronjobfail',[1]);
                break;
            case Constants::$RemainingFailedInterventionActiveCheckField:
                $baseDataProvider->CallRawForSingleTable('setunsetforinterventioncronjobfail',[1]);
                break;
            case Constants::$CoFailedImageCronJob :
                $baseDataProvider->CallRawForSingleTable('co_setunsetcronjobforimagecronjobfail',[1]);
                break;
            case Constants::$CoFailedImageInterventionCronJob:
                $baseDataProvider->CallRawForSingleTable('co_setunsetforinterventioncronjobfail',[1]);
                break;
        }
    }

    public static function encryptor($action, $string)
    {
        $output = false;

        $encrypt_method = "AES-256-CBC";
        //pls set your unique hashing key
        $secret_key = 'test';
        $secret_iv = 'test123';

        // hash
        $key = hash('sha256', $secret_key);

        // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
        $iv = substr(hash('sha256', $secret_iv), 0, 16);

        //do the encyption given text/string/number
        if ($action == 'encrypt') {
            $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
            $output = base64_encode($output);
        } else if ($action == 'decrypt') {
            //decrypt the given text/string/number
            $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
        }

        return $output;
    }

    public static function getEncryptedValue($propertyName)
    {
        return urlencode(Common::encryptor(Constants::$encrypt, $propertyName));
    }

    public static function getDecryptedValue($propertyName)
    {
        return urldecode(Common::encryptor(Constants::$decrypt, $propertyName));
    }

    public static function getParamValue($multiQueryString, $queryStringKey)
    {
        if (str_contains($multiQueryString, '&' . $queryStringKey . '=') < 0) {
            $first = explode('=', $multiQueryString);
            return $first[1];
        }

        if (starts_with($multiQueryString, $queryStringKey . '=') == 1 || str_contains($multiQueryString, '&' . $queryStringKey . '=') > 0) {
            $MultiQueryStringArray = explode('&', $multiQueryString);
            $first = current(array_filter($MultiQueryStringArray, function ($keyValue) use ($multiQueryString, $queryStringKey) {
                return starts_with($keyValue, $queryStringKey . '=') == 1;
            }));
            if (!empty($first))
                return explode('=', $first)[1];
        }
        return '0';
    }

    public static function getEloquentModel($entity, $objectData)
    {
        $class = get_class($entity);
        $objectDataArray = array($objectData);
        $objects = $class::hydrate($objectDataArray);

        return $objects[0];
    }

    public static function MailsToSend($maxFailedMailAttempt, $ImmediateSendEmailData = null)
    {
        $searchParams = Array();
        $emailEntity = new EmailEntity();
        $baseDataProvider = new BaseDataProvider();
        $searchValueData = new SearchValueModel();
        $searchValueData->Name = "IsSent";
        $searchValueData->Value = 0;
        array_push($searchParams, $searchValueData);
        if (empty($ImmediateSendEmailData)) {
            $users = $baseDataProvider->GetEntityList($emailEntity, $searchParams);
        } else {
            $users = array();
            array_push($users, $ImmediateSendEmailData);
        }

        foreach ($users as $userObj) {
            //$SMTPData = $baseDataProvider->CallRawForSingleTable('getsmtpdetails',[$userObj['CreatedBy'],$userObj['SiteID']]);
            $SMTPData = $baseDataProvider->CallRawForSingleTable('getsmtpdetails', [$userObj->CreatedBy, $userObj->SiteID]);

            $SMPTPDetails = $SMTPData[0];

            if ($SMPTPDetails) {
                $mail = new PHPMailer();
                $mail->IsSMTP();                                     // telling the class to use SMTP
                $mail->SMTPDebug = 0;
                $mail->IsHTML(true);
                $mail->SMTPAuth = true;
                $mail->Host = $SMPTPDetails->SMTPHost;//Config::get('mail.host');
                $mail->SMTPSecure = $SMPTPDetails->IsSSL == 1 ? 'tls' : '';// Config::get('mail.encryption');
                $mail->Username = $SMPTPDetails->SMTPUserName; //Config::get('mail.username');
                $mail->Password = $SMPTPDetails->SMTPPassword; //Config::get('mail.password');
                $mail->Port = $SMPTPDetails->SMTPPort; //Config::get('mail.port');
                $mail->From = $SMPTPDetails->SMTPFromAddress; //Config::get('mail.from.address');
                $mail->FromName = $SMPTPDetails->SMTPFromName; //Config::get('mail.from.name');

                if ($userObj->IsSent == 0 && $userObj->MailAttempt != $maxFailedMailAttempt) {
                    $userObj->ToEmail = is_array($userObj->ToEmail) ? $userObj->ToEmail : explode(',', $userObj->ToEmail);

                    $mail->Subject = $userObj->Subject;
                    $mail->Body = $userObj->Body;

                    if (!empty($userObj->ToEmail)) {
                        foreach ($userObj->ToEmail as $email => $name) {
                            $mail->AddAddress($name);
                        }
                    }

                    if (!empty($userObj->ToCC)) {
                        $mail->AddCC($userObj->ToCC);
                    }
                    /* if (!empty($userObj->Attachment)) {
                         $mail->AddAttachment($userObj->Attachment, Constants::$DefaultEventCalendarFileName);
                     }*/

                    if (empty($userObj->ToCC) && empty($userObj->ToEmail[0])) {
                        $isSent = true;
                    } else {
                        if (!$mail->Send()) {
                            $isSent = false;
                            $userObj->MailAttempt = $userObj->MailAttempt++;
                        } else {
                            $isSent = true;
                        }
                    }
                    $emailEntity = $baseDataProvider->GetEntityForUpdateByPrimaryKey(new EmailEntity(), $userObj->EmailID);//EmailEntity::find($userObj->EmailID);
                    $emailEntity->IsSent = $isSent;

                    if ($isSent) {
                        $emailEntity->SentDateTime = date(Constants::$DefaultDateTimeFormat);
                        if (!empty($userObj->Attachment) && file_exists($userObj->Attachment)) {
                            $checkEmail = $userObj->ToEmail[0];
                            $customWhereAttachment = "Attachment = '$userObj->Attachment' AND EmailID != '$checkEmail' AND `IsSent` = 0";
                            $attachmentCount = $baseDataProvider->GetEntityCount($emailEntity, "", "", "", $customWhereAttachment);
                            if ($attachmentCount == 0) {
                                unlink($userObj->Attachment);
                            }
                        }
                    }
                    $emailEntity->MailAttempt = $userObj->MailAttempt;
                    $baseDataProvider->SaveEntity($emailEntity);
                }
            } else {
                Log::error('SMTP setting not found.');
            }
        }
    }

    public static function SendEmail($bodyTemplate, $bodyData, $subject, $toEmail, $toEmailName = "", $toCCEmail = "", $addAttachmentURL = "", $sendInstantEmail,$IsReadFile=1)
    {
        $baseDataProvider = new BaseDataProvider();
        $emailEntity = new EmailEntity();
        $emailEntity->Subject = $subject;
        $emailEntity->ToEmail = $toEmail;
        if (!empty($toCCEmail)) {
            $emailEntity->ToCC = $toCCEmail;
        }
        if (!empty($addAttachmentURL)) {
            $emailEntity->Attachment = $addAttachmentURL;
        }
        $emailEntity->CreatedDate = date(Constants::$DefaultDateTimeFormat);
        $emailEntity->IsSent = 0;
        $emailEntity->MailAttempt = 1;

        $bodyData['logopath'] = asset('assets/images/wb_logo.png');
        $bodyData['bgimagepath'] = asset('assets/images/bg.jpg');
        $bodyData['helpsupportlink'] = Config::get('app.helpsupportlink');
        $bodyData['websitelink'] = Config::get('app.websitelink');
        $bodyData['websitename'] = Config::get('app.websitename');
        $bodyData['emaillogolink'] = Config::get('app.emaillogolink');
        if (!empty($toEmailName)) {
            $bodyData['FirstName'] = $toEmailName;
        }

        if (isset($bodyData['SiteID'])) {
            $emailEntity->SiteID = $bodyData['SiteID'];
        }

        if (isset($bodyData['CreatedBy'])) {
            $emailEntity->CreatedBy = $bodyData['CreatedBy'];
        }
        else {
            $emailEntity->CreatedBy = Constants::$StaticUserID;
        }
        if($IsReadFile == 1) {
            $mailTemplate = self::GenerateEmailBody($bodyTemplate, $bodyData);
        }
        else
        {
            $mailTemplate = $bodyTemplate;
        }

        $emailEntity->Body = $mailTemplate;

        $emailEntity = $baseDataProvider->SaveEntity($emailEntity);

        if ($sendInstantEmail == 1)
            Common::MailsToSend(Constants::$maxFailedAttempts, $emailEntity);

        return $emailEntity;
    }

    public static function GetEnableFieldName($SiteID)
    {
        switch ($SiteID) {
            case Constants::$MercerVineSiteID :
                $FieldName = Constants::$Is_Enabled_For_MVCO;
                break;
            case Constants::$ColoradoSiteID :
                $FieldName = Constants::$Is_Enabled_For_MVCO;
                break;
            case Constants::$WoodBridgeWealthSiteID :
                $FieldName = Constants::$Is_Enabled_For_RDWW;
                break;
            case Constants::$RiverDaleFundingSiteID :
                $FieldName = Constants::$Is_Enabled_For_RDWW;
                break;
        }
        return $FieldName;
    }

    public static function GenerateEmailBody($bodyTemplate, $bodyData)
    {
        $templateName = substr($bodyTemplate, strpos($bodyTemplate, ".") + 1);
        $mailTemplate = file_get_contents(URL::to('/') . '/local/app/views/emails/' . $templateName . '.blade.php', false);
        $pattern = '/\$([a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*)/';
        preg_match_all($pattern, $mailTemplate, $matches);

        if (isset($matches[1])) {
            foreach ($matches[1] as $key => $value) {
                $mailTemplate = str_replace("$" . $value, $bodyData[$value], $mailTemplate);
            }
            return $mailTemplate;
        }
        return $mailTemplate;
    }

    public static function GetArrayFilterValues($array, $fieldName, $fieldValue)
    {
        $values = array_values(array_filter($array, function ($key) use ($fieldName, $fieldValue) {
            if (is_array($key))
                $key = (object)$key;
            return $key->$fieldName == $fieldValue;
        }));
        return $values;
    }

    public static function GetRoleIDFromSessionRoles($array, $fieldName, $fieldValue)
    {
        $values = current(Common::GetArrayFilterValues($array, $fieldName, $fieldValue));
        if ($values) {
            return $values->RoleID;
        } else {
            return Constants::$RoleNoAccess;
        }
    }

    public static function CurlRequest($url, $type, $updateData = '',$apiKey='',$username="",$password=""){
        try {

            $headers = array();
            $headers[] = "Accept: application/json";
            $headers[] = "Content-Type: application/json";
            

            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
            
            if($username != "" && $password != "")
            {
                curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
                curl_setopt($curl, CURLOPT_USERPWD, $username.":".$password );    
            }
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            if ($type == 'get')
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");
            else {
                curl_setopt($curl, CURLOPT_POST, 1);
                curl_setopt($curl, CURLOPT_POSTFIELDS, $updateData);
                if ($type == 'put')
                    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
                else
                    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
            }
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);

            $resp = curl_exec($curl);
            $res = json_decode($resp);

            //Log::info(' Cache Cross : $resp :'.date('Y-m-d H:i:s'));


            curl_close($curl);
            return $res;
        } catch (Exception $e) {
            throw new Exception("Invalid", 0, $e);
        }
        restore_error_handler();
    }

    public static function getLatLong($address, $geoAPIKey)
    {
        $response = new stdClass();
        $geoUrl = Constants::$GeoMainURL;

        $url = "$geoUrl=$address&key=$geoAPIKey";
        $data = Common::CurlRequest($url, 'get', '');

        if ($data->status == 'OK') {
            $response->Latitude = $data->results[0]->geometry->location->lat;
            $response->Longitude = $data->results[0]->geometry->location->lng;
        } else if ($data->status == 'ZERO_RESULTS') {
            $response = '';
        }
        return $response;
    }

    public static function GetCsvFromArrayProperty($array, $propertyName)
    {
        $csv = "";
        for ($i = 0; $i < count($array); $i++) {
            $csv .= str_replace('"', '""', $array[$i][$propertyName]);
            if ($i < count($array) - 1) $csv .= ",";
        }
        return $csv;
    }

    public static function GetCsvFromArray($array)
    {
        $csv = "";
        for ($i = 0; $i < count($array); $i++) {
            $csv .= str_replace('"', '""', $array[$i]);
            if ($i < count($array) - 1) $csv .= ",";
        }
        return $csv;
    }

    public static function GetFullAddressSlug($address)
    {
        $output = preg_replace('/\s+/', '-', $address); // Remove single or multiple spce to
        $slugAdd = strtolower($output); // Convert string to lowerCase
        return preg_replace('/[^A-Za-z0-9\-]/', '', $slugAdd); // Removes special chars.
    }


    /* RB Region End */


    /* VA Region Start */
    public static function getValidationMessagesFormat($validationMessage)
    {
        $validationMessagesArray = "";
        foreach ($validationMessage->toArray() as $key => $value) {
            $validationMessagesArray .= '<li>' . $value[0] . '</li>';
        }
        return $validationMessagesArray;
    }

    public static function GetDataWithTrim($string)
    {
        return trim($string);
    }

    public static function SetSearchArray($name, $value, $CheckStartWith = '')
    {
        $searchParams = array();
        $searchValueData = new SearchValueModel();
        $searchValueData->Name = $name;
        $searchValueData->Value = $value;
        $searchValueData->CheckForExactMatch = $CheckStartWith;
        return $searchValueData;
    }

    /* VA Region End */

    /* DN Region Start */
    public static function ConvertDateFormatFromMDYToYMD($Date)
    {
        if ($Date > 0) {
            $Date = date(Constants::$YMDDateFormatServerSide, strtotime($Date));
        } else {
            $Date = 0;
        }
        return $Date;
    }

    public static function getDateFromStringWithTimezone($dateString, $timezone, $format = 'm/d/Y')
    {
        return DateTime::createFromFormat($format, $dateString, new DateTimeZone($timezone));
    }

    public static function checkDateFromWithDateTo($timezone, $dateFromString, $dateToString = "")
    {
        if (!empty($dateFromString)) {
            $dateFrom = Common::getDateFromStringWithTimezone($dateFromString, $timezone);
            if (empty($dateToString))
                $dateTo = new DateTime("today", new DateTimeZone($timezone));
            else
                $dateTo = Common::getDateFromStringWithTimezone($dateToString, $timezone);

            if ($dateFrom->format(Constants::$YMDDateFormatServerSide) > $dateTo->format(Constants::$YMDDateFormatServerSide)) {
                return 1;
            } else {
                return 0;
            }
        }
        return 0;
    }

    /* DN Region End */

    public static function multiexplode($delimiters, $string)
    {
        $launch = preg_split($delimiters, $string);
        return array_values(array_filter($launch));
    }

    public static function strposnth($haystack, $needle, $nth = 1, $insenstive = 0)
    {
        //if its case insenstive, convert strings into lower case
        if ($insenstive) {
            $haystack = strtolower($haystack);
            $needle = strtolower($needle);
        }
        //count number of occurances
        $count = substr_count($haystack, $needle);

        //first check if the needle exists in the haystack, return false if it does not
        //also check if asked nth is within the count, return false if it doesnt
        if ($count < 1 || $nth > $count) return false;


        //run a loop to nth number of accurance
        //start $pos from -1, cause we are adding 1 into it while searchig
        //so the very first iteration will be 0
        for ($i = 0, $pos = 0, $len = 0; $i < $nth; $i++) {
            //get the position of needle in haystack
            //provide starting point 0 for first time ($pos=0, $len=0)
            //provide starting point as position + length of needle for next time
            $pos = strpos($haystack, $needle, $pos + $len);

            //check the length of needle to specify in strpos
            //do this only first time
            if ($i == 0) $len = strlen($needle);
        }

        //return the number
        return $pos;
    }

    public static function GetUniqueCSVFromArray($csv, $GetUniqueData)
    {
        $GetUniqueData = array_map(function ($v) {
            return $v->MLSNo;
        }, $GetUniqueData);
        $replacedata = array();
        $replacedata = array_pad($replacedata, count($GetUniqueData), '');
        $csv = str_replace($GetUniqueData, $replacedata, $csv);
        $csv = preg_replace('/,,+/', ',', $csv);
        return trim($csv,',');
    }

    public static function getImageInterventionDimensionArray($siteID, $isWoodBridge,$IsResize=0){
        $array = '';
        if($siteID == Constants::$MercerVineSiteID){
            if($isWoodBridge == Constants::$isWoodBridge) {
                if($IsResize==1)
                    $array=Constants::$multipleInterventionFitDimension;
                else
                    $array = Constants::$multipleInterventionDimension;
            }
            else
                $array = Constants::$singleInterventionDimension;
        }
        if($siteID==Constants::$ColoradoSiteID){
            $array = Constants::$ComultipleInterventionDimension;
        }
        return $array;
    }

    public static function ImageIntervention($imagePath,$dimension,$awsImageUploadFilePath,$isForImageCron=0){
        $image = Image::make($imagePath);

        //if($isForImageCron==1)
         //   $ext = File::extension($awsImageUploadFilePath);
        //else{
        $ext = File::extension($imagePath);
        //}
        switch ($dimension['InterventionType']){
            case 'crop':

                if($image->height() > Config::get('config.FileUploadFitMaxDimHeight') || $image->width() > Config::get('config.FileUploadFitMaxDimWidth')) {
                    //exit;
                    $image->fit($dimension['Width'], $dimension['Height']);
                    $base64 = (string)$image->encode($ext);

                    /*$destinationPath = public_path('public/images');
                    $filename = '/'.'fit_'.time()."-".$dimension['postfix'].'.'.$ext;
                    $image->save($destinationPath.$filename);*/

                }
                else if($image->height() < $dimension['Height'] || $image->width() < $dimension['Width']) {
                    $background = Image::canvas($dimension['Width'], $dimension['Height']);
                    $background->fill('#fff');
                    $background->insert($image,'center');
                    $background->crop($dimension['Width'], $dimension['Height']);
                    $base64 = (string)$background->encode($ext);

                    //$destinationPath = public_path('public/images');
                    //$filename = '/'.'crop-bac_'.time().'.'.$ext;
                    //$background->save($destinationPath.$filename);
                }
                else{
                    $image->crop($dimension['Width'], $dimension['Height']);
                    $base64 = (string)$image->encode($ext);

                    //$destinationPath = public_path('public/images');
                    //$filename = '/'.'crop_'.time().'.'.$ext;
                    //$image->save($destinationPath.$filename);
                }
                break;
            case 'fit':
                if($image->height() < $dimension['Height'] || $image->width() < $dimension['Width']) {
                    $background = Image::canvas($dimension['Width'], $dimension['Height']);
                    $background->fill('#fff');
                    $background->insert($image,'center');
                    $background->fit($dimension['Width'], $dimension['Height']);
                    $base64 = (string)$background->encode($ext);

                    //$destinationPath = public_path('public/images');
                    //$filename = '/'.'crop-bac_'.time().'.'.$ext;
                    //$background->save($destinationPath.$filename);
                } else {
                    $image->fit($dimension['Width'], $dimension['Height']);
                    $base64 = (string)$image->encode($ext);
                }

                //$destinationPath = public_path('public/images');
                //$filename = '/'.'fit_'.time().'.'.$ext;
                //$image->save($destinationPath.$filename);
                break;
        }


        if($isForImageCron==1)
            $filePath = explode('/',$awsImageUploadFilePath);
        else{
            $filePath = explode('/',$imagePath);
        }
        $fileNm = $filePath[count($filePath) - 1];
        $name = pathinfo($fileNm, PATHINFO_FILENAME);
        $filename = $name . $dimension['postfix'] . '.' . $ext;

        $baseDataProvider = new BaseDataProvider();
        $interventionImageUpload = $baseDataProvider->FileUpload(Constants::$AWSRequestType_Listing,2,Constants::$MercerVineSiteID, $filename, $base64);
        return $interventionImageUpload;
    }

    public static function RdImageIntervention($imagePath,$dimension){
        $image = Image::make($imagePath);

        //if($isForImageCron==1)
        //   $ext = File::extension($awsImageUploadFilePath);
        //else{
        $ext = File::extension($imagePath);
        //}
        switch ($dimension['InterventionType']){
            case 'crop':
                if($image->height() < $dimension['Height'] || $image->width() < $dimension['Width']) {
                    $background = Image::canvas($dimension['Width'], $dimension['Height']);
                    $background->fill('#fff');
                    $background->insert($image,'center');
                    $background->crop($dimension['Width'], $dimension['Height']);
                    $base64 = (string)$background->encode($ext);
                }
                else{
                    $image->crop($dimension['Width'], $dimension['Height']);
                    $base64 = (string)$image->encode($ext);
                }
                break;
            case 'fit':
                if($image->height() > $dimension['Height'] && $image->width() > $dimension['Width']) {
                    $image->fit($dimension['Width'], $dimension['Height']);
                    $base64 = (string)$image->encode($ext);
                }
                else {
                    $background = Image::canvas($dimension['Width'], $dimension['Height']);
                    $background->fill('#fff');
                    $background->insert($image,'center');
                    $background->crop($dimension['Width'], $dimension['Height']);
                    $base64 = (string)$background->encode($ext);
                }
                break;

            case 'resize':
                $image->resize($dimension['Width'], $dimension['Height']);
                $base64 = (string)$image->encode($ext);
                break;
        }



        $filePath = explode('/',$imagePath);

        $fileNm = $filePath[count($filePath) - 1];
        $name = pathinfo($fileNm, PATHINFO_FILENAME);
        $filename = $name . $dimension['postfix'] . '.' . $ext;

        $baseDataProvider = new BaseDataProvider();
        $interventionImageUpload = $baseDataProvider->FileUpload(Constants::$AWSRequestType_Loan,2,Constants::$RiverDaleFundingSiteID, $filename, $base64);
        return $interventionImageUpload;
    }


    public static function ChangeImagePath($content){
        if(isset($content) && !empty($content)) {
            foreach(Constants::$CkEditorUploadFilePaths as $filePath) {
                $content = str_replace($filePath, '"'. URL::to('/') . ltrim($filePath ,'"' ), $content);
            }
        }
        return $content;
    }

    public static function getPropertyOfficeID($OfficeID,$SiteID){
        $returns=false;
        switch($SiteID){
            case '1':
                if($OfficeID==Constants::$MVSiteOfficeID)
                    $returns= true;
                else
                    $returns= false;
            case Constants::$ColoradoSiteID:
                if($OfficeID==Constants::$COSiteOfficeID)
                    $returns= true;
                else
                    $returns= false;
        }
        return $returns;
    }

    public static function CkeditorContent($content){
        $newContent = strip_tags($content);
        $newContent =  str_replace("&nbsp;", "", $newContent);
        $newContent = trim($newContent);
        if(!empty($newContent) && $newContent != null && $newContent != ''){
            return $content;
        }else{
            return $newContent;
        }
    }
    public static function getPropertyStatusField($SiteID){
        $returns=false;
        switch($SiteID){
            case '1':
                $returns=Constants::$MVStatusField;
        }
        return $returns;
    }

    /* Start Dev_UP */
    public static function getSiteRiverdale()
    {
        return $siteRiverdale = Constants::$RiverDaleFundingSiteID ;
    }

    public static function getRoleITAdminProcesing()
    {
        return $roleITAdminProcesing =  Constants::$RoleITAdmin . Constants::$Separator . Constants::$RoleProcessing ;
    }

    public static function getAWSBucketName($siteID){
        $bucketName = '';
        switch($siteID){
            case Constants::$MercerVineSiteID:
                $bucketName = Config::get('aws.MVAWSBucketName') ;
                break;
            case Constants::$ColoradoSiteID:
                $bucketName = Config::get('aws.CRAWSBucketName') ;
                break;
            case Constants::$WoodBridgeWealthSiteID:
                $bucketName = Config::get('aws.WBWAWSBucketName') ;
                break;
            case Constants::$RiverDaleFundingSiteID:
                $bucketName = Config::get('aws.RDAWSBucketName') ;
                break;
        }
        return $bucketName;
    }

    public static function getAWSUrl($siteID){
        $awsURL = '';
        switch($siteID){
            case Constants::$MercerVineSiteID:
                $awsURL = Config::get('aws.MVAWSUrl') ;
                break;
            case Constants::$ColoradoSiteID:
                $awsURL = Config::get('aws.CRAWSUrl') ;
                break;
            case Constants::$WoodBridgeWealthSiteID:
                $awsURL = Config::get('aws.WBWAWSUrl') ;
                break;
            case Constants::$RiverDaleFundingSiteID:
                $awsURL = Config::get('aws.RDAWSUrl') ;
                break;
        }
        return $awsURL;
    }

    public static function getAPIKey($siteID){
        $apiKey = '';
        switch($siteID){
            case Constants::$MercerVineSiteID:
                $apiKey = Config::get('aws.MVAPIKey') ;
                break;
            case Constants::$ColoradoSiteID:
                $apiKey = Config::get('aws.CRAPIKey') ;
                break;
            case Constants::$WoodBridgeWealthSiteID:
                $apiKey = Config::get('aws.WBWAPIKey') ;
                break;
            case Constants::$RiverDaleFundingSiteID:
                $apiKey = Config::get('aws.RDAPIKey') ;
                break;
        }
        return $apiKey;
    }

    public static function getAWSSecretKey($siteID){
        $awsSecretKey = '';
        switch($siteID){
            case Constants::$MercerVineSiteID:
                $awsSecretKey = Config::get('aws.MVAWSSecretKey') ;
                break;
            case Constants::$ColoradoSiteID:
                $awsSecretKey = Config::get('aws.CRAWSSecretKey') ;
                break;
            case Constants::$WoodBridgeWealthSiteID:
                $awsSecretKey = Config::get('aws.WBWAWSSecretKey') ;
                break;
            case Constants::$RiverDaleFundingSiteID:
                $awsSecretKey = Config::get('aws.RDAWSSecretKey') ;
                break;
        }
        return $awsSecretKey;
    }

    public static function getSiteRiverdaleColorado()
    {
        return $siteRiverdale = Constants::$RiverDaleFundingSiteID . Constants::$Separator . Constants::$ColoradoSiteID;
    }

    public static function getSiteRiverDaleColoradoWW(){
        return $siteRDCOWW = Constants::$RiverDaleFundingSiteID . Constants::$Separator . Constants::$ColoradoSiteID . Constants::$Separator . Constants::$WoodBridgeWealthSiteID;
    }

    public static function getSiteColoradoWW(){
        return $siteCOWW = Constants::$ColoradoSiteID . Constants::$Separator . Constants::$WoodBridgeWealthSiteID;
    }

    public static function getSiteMercerVine()
    {
        return $siteercerVine = Constants::$MercerVineSiteID ;
    }
    public static function getSiteColorado()
    {
        return $siteColorado = Constants::$ColoradoSiteID ;
    }
    public static function getSiteWoodBridgeWealth()
    {
        return $siteWoodBridgeWealth = Constants::$WoodBridgeWealthSiteID ;
    }
    /* End Dev_UP */

    public static function CoImageIntervention($imagePath,$dimension,$awsImageUploadFilePath,$isForImageCron=0){
        $image = Image::make($imagePath);

        //if($isForImageCron==1)
        //   $ext = File::extension($awsImageUploadFilePath);
        //else{
        $ext = File::extension($imagePath);
        //}
        switch ($dimension['InterventionType']){
            case 'crop':

                if($image->height() > Config::get('config.FileUploadFitMaxDimHeight') || $image->width() > Config::get('config.FileUploadFitMaxDimWidth')) {
                    //exit;
                    $image->fit($dimension['Width'], $dimension['Height']);
                    $base64 = (string)$image->encode($ext);

                    /*$destinationPath = public_path('public/images');
                    $filename = '/'.'fit_'.time()."-".$dimension['postfix'].'.'.$ext;
                    $image->save($destinationPath.$filename);*/

                }
                else if($image->height() < $dimension['Height'] || $image->width() < $dimension['Width']) {
                    $background = Image::canvas($dimension['Width'], $dimension['Height']);
                    $background->fill('#fff');
                    $background->insert($image,'center');
                    $background->crop($dimension['Width'], $dimension['Height']);
                    $base64 = (string)$background->encode($ext);

                    //$destinationPath = public_path('public/images');
                    //$filename = '/'.'crop-bac_'.time().'.'.$ext;
                    //$background->save($destinationPath.$filename);
                }
                else{
                    $image->crop($dimension['Width'], $dimension['Height']);
                    $base64 = (string)$image->encode($ext);

                    //$destinationPath = public_path('public/images');
                    //$filename = '/'.'crop_'.time().'.'.$ext;
                    //$image->save($destinationPath.$filename);
                }
                break;
            case 'fit':
                if($image->height() < $dimension['Height'] || $image->width() < $dimension['Width']) {
                    $background = Image::canvas($dimension['Width'], $dimension['Height']);
                    $background->fill('#fff');
                    $background->insert($image,'center');
                    $background->fit($dimension['Width'], $dimension['Height']);
                    $base64 = (string)$background->encode($ext);

                    //$destinationPath = public_path('public/images');
                    //$filename = '/'.'crop-bac_'.time().'.'.$ext;
                    //$background->save($destinationPath.$filename);
                } else {
                    $image->fit($dimension['Width'], $dimension['Height']);
                    $base64 = (string)$image->encode($ext);
                }

                //$destinationPath = public_path('public/images');
                //$filename = '/'.'fit_'.time().'.'.$ext;
                //$image->save($destinationPath.$filename);
                break;
        }


        if($isForImageCron==1)
            $filePath = explode('/',$awsImageUploadFilePath);
        else{
            $filePath = explode('/',$imagePath);
        }
        $fileNm = $filePath[count($filePath) - 1];
        $name = pathinfo($fileNm, PATHINFO_FILENAME);
        $filename = $name . $dimension['postfix'] . '.' . $ext;

        $baseDataProvider = new BaseDataProvider();
        $interventionImageUpload = $baseDataProvider->FileUpload(Constants::$AWSRequestType_Listing,2,Constants::$ColoradoSiteID, $filename, $base64);
        return $interventionImageUpload;
    }

    public static function getAWSFullURLForProfile(){
        $awsFullURL = Config::get('aws.ProfileAWSUrl').''.Config::get('aws.ProfileAWSBucketName');
        return $awsFullURL;
    }
}