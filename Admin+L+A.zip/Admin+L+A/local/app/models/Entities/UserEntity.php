<?php
use Illuminate\Auth\UserTrait;
use Illuminate\Auth\UserInterface;
use Illuminate\Auth\Reminders\RemindableTrait;
use Illuminate\Auth\Reminders\RemindableInterface;

class UserEntity extends Eloquent implements UserInterface,   RemindableInterface {

	use UserTrait, RemindableTrait;

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	public $timestamps = false;
	public $table = 'users';
	public $primaryKey = 'UserID';
	public $incrementing = 'UserID';


    public $Model_Types = array(
        'UserID'=>'int',
        'FirstName'=>'string',
        'LastName'=>'string',
        'Email'=>'string',
        'ImagePath'=>'int',
        'StatusID'=>'int',
        'CreatedDate'=>'datetime',
        'ModifiedDate'=>'datetime',
        'CreatedByID'=>'int',
        'ModifiedByID'=>'int',
        'Bio'=>'string',
        'Address'=>'string',
        'City'=>'string',
        'StateID'=>'int',
        'Zip'=>'string',
        'CalBRENo'=>'string',
        'JivePhone'=>'string',
        'MobilePhone'=>'string',
        'Fax'=>'string',
        'FacebookName'=>'string',
        'LinkedInName'=>'string',
        'TwitterName'=>'string',
        'InstagramName'=>'string',
        'PinterestName'=>'string',
        'SnapchatName'=>'string',
        'YoutubeName'=>'string',
        'WebsiteURL'=>'string',
        'FacebookUserID'=>'string',
        'LinkedInUserID'=>'string',
        'IsVerified'=>'int',
        'Slug'=>'string',
        'AgentURL'=>'string',
        'SmallerImagesPath'=>'string',
        'Title'=>'string',
        'IsAgent'=>'int',
        'IsFoundingMember'=>'int',
        'IsTeamMember'=>'int'
        //'RoleID'=>'int',
        //'Password'=>'string'
    );

    public static $Add_rules = array(
        'FirstName'=>'required|max:50',
        'LastName'=>'required|max:50',
        'Email'=>'required|email|max:50',
        //'StatusID'=>'required'
    );
    public static $Edit_rules = array(
        'FirstName'=>'required|max:50',
        'LastName'=>'required|max:50',
        'Email'=>'required|email|max:50',
       // 'StatusID'=>'required'
    );

    public static $Add_agent_rules = array(
        'FirstName'=>'required|max:50',
        'LastName'=>'required|max:50',
        'Email'=>'required|email|max:50',
        'JivePhone'=>'required',
        'MobilePhone'=>'required',
        'Fax'=>'required',
        'Slug'=>'required',
        'AgentURL'=>'required',
        'SmallerImagesPath'=>'required',
        'Title'=>'required',

    );

    public static $niceNameArray = array(
        'FirstName'=>'First Name',
        'LastName'=>'Last Name',
        //'StatusID'=>'Status',
        'Email'=>'Email',
        'JivePhone'=>'Jive Phone',
        'MobilePhone'=>'Mobile Phone',
        'Fax'=>'Fax',
        'Slug'=>'Slug',
        'AgentURL'=>'Agent URL',
        'SmallerImagesPath'=>'Profile Images',
        'Title'=>'Title',
    );


   

}
