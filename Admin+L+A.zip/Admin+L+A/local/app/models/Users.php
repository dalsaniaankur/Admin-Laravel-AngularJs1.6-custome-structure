<?php
class Users extends Eloquent {

	public function scopesaveUser($query,$data)
	{
		return $data;	
		
	}
	
}
?>