<?php
namespace dataproviders;
use Illuminate\Support\Facades\Validator;
use \ViewModels\ServiceResponse;
use \Infrastructure\Constants;
use \Infrastructure\Common;
use \stdClass;
use Illuminate\Support\Facades\URL;
use CategoriesEntity;
use SiteTagsEntity;
use SiteTestimonialEntity;
use Infrastructure\CacheHelper;
use Illuminate\Support\Facades\DB;


class SiteDataProvider extends BaseDataProvider implements ISiteDataProvider {

    /* Dev_AD Region Start */
    public function SaveCategory($Model,$loginUserID,$siteID){

        $CategoryModel = (object)$Model->CategoryModel;
        $pagerModel = (object)$Model->PagerModel;
        $response = new ServiceResponse();
        $messages = array(
            'required' => trans('messages.PropertyRequired'),
            'min' => trans('messages.PropertyMin'),
            'max' => trans('messages.PropertyMax')
        );
        $categoriesEntity = new CategoriesEntity();
        $validator = Validator::make((array)$CategoryModel,$categoriesEntity::$Add_rules, $messages);
        $validator->setAttributeNames($categoriesEntity::$niceNameArray);
        if ($validator->fails()) {
            $response->Message = Common::getValidationMessagesFormat($validator->messages());
            return $response;
        }

        if(!isset($CategoryModel->CategoryID)){$CategoryModel->CategoryID = NULL;}
        $pageIndex = $pagerModel->currentPage;
        $pageSizeCount = $pagerModel->pageSize;
        $saveCategoryResults = $this->GetPageRecordsUsingSPWithStatus('savecategory',$pageIndex,$pageSizeCount,[$pagerModel->currentPage,
                                                                                                              $pagerModel->pageSize,
                                                                                                              $pagerModel->sortIndex,
                                                                                                              $pagerModel->sortDirection,
                                                                                                              $CategoryModel->CategoryID,
                                                                                                              $CategoryModel->Category,
                                                                                                              $CategoryModel->Slug,
                                                                                                              $loginUserID,
                                                                                                              $siteID]);

        if($saveCategoryResults->IsSuccess){
            switch($saveCategoryResults->Items[0]->ResultStatus){
                case '1':
                    $response->Message =trans('messages.CategoryAlreadyExist');
                    break;
                case '2':
                    $response->Message =trans('messages.CategorySlugAlready');
                    break;
                case '3':
                    if(isset($saveCategoryResults->Items[2][0]->EntityID) && !empty($saveCategoryResults->Items[2][0]->EntityID) && $saveCategoryResults->Items[2][0]->EntityID > 0 ){
                        CacheHelper::CacheManage($siteID,Constants::$cacheCategoryID,Constants::$cacheActionInsert,$saveCategoryResults->Items[2][0]->EntityID);
                    }
                    $response->IsSuccess = true;
                    /* This date is required in pagination funcnality. */
                    $response->Data = $saveCategoryResults->Items[1];
                    $response->CurrentPage = $saveCategoryResults->CurrentPage;
                    $response->ItemsPerPage = $saveCategoryResults->ItemsPerPage;
                    $response->TotalItems = $saveCategoryResults->TotalItems;
                    $response->Message =trans('messages.CategoryAddedSuccess');
                    break;
                case '4':
                    $blogs=DB::table('blogposts')->join('blogpostcategories','blogposts.blogpostid','=','blogpostcategories.blogpostid')->select('Slug')->where('blogpostcategories.CategoryID','=',$CategoryModel->CategoryID)->get();
                    foreach($blogs as $blog){
                        CacheHelper::CacheManage($siteID,Constants::$cacheBlogID,Constants::$cacheActionUpdate,'',$blog->Slug);
                    }
                    if(isset($CategoryModel->CategoryID) && !empty($CategoryModel->CategoryID) && $CategoryModel->CategoryID > 0 ){
                        CacheHelper::CacheManage($siteID,Constants::$cacheCategoryID,Constants::$cacheActionInsert,$CategoryModel->CategoryID);
                    }
                    $response->IsSuccess = true;
                    /* This date is required in pagination funcnality. */
                    $response->Data = $saveCategoryResults->Items[1];
                    $response->CurrentPage = $saveCategoryResults->CurrentPage;
                    $response->ItemsPerPage = $saveCategoryResults->ItemsPerPage;
                    $response->TotalItems = $saveCategoryResults->TotalItems;
                    $response->Message =trans('messages.CategoryUpdateSuccess');
                    break;
                default:
                    $response->Message = trans('messages.ErrorOccured');
                    break;
            }
        }else{ $response->Message = trans('messages.ErrorOccured'); }
        return $response;
    }
    public function getCategoryDetails(){
        $response = new ServiceResponse();
        $model = new StdClass();
        /* Category Data bind */
        $categoryModel = new StdClass();
        $categoriesEntity = new CategoriesEntity();
        $categoriesEntity->CategoryID = Constants::$Value_False;
        $categoriesEntity->Category ='';
        $categoriesEntity->Slug = '';
        $testDetails = $categoriesEntity;

        $model->CategoryModel = $categoryModel;
        $model->CategoryModel->TestDetails = $testDetails;
        $model->CategoryModel->DefaultTestDetails = $testDetails;

        $tagModel = new StdClass();

        /* Tag Data bind */
        $tagEntity = new SiteTagsEntity();
        $tagEntity->TagID = Constants::$Value_False;
        $tagEntity->Tag ='';
        $tagEntity->Slug = '';
        $tagTestDetails = $tagEntity;

        $model->TagModel = $tagModel;
        $model->TagModel->TestDetails = $tagTestDetails;
        $model->TagModel->DefaultTestDetails = $tagTestDetails;

        $response->Data = $model;
        return $response;
    }
    public function getCategoryList($categoryData,$searchSiteID){
        $response = new ServiceResponse();
        if(empty($categoryData->sortIndex)){
            $categoryData->SortIndex = Constants::$SortIndexCategory;
        }

        if(empty($categoryData->sortDirection)){
              $categoryData->SortDirection = Constants::$SortIndexASC;
        }
        $sortIndex = $categoryData->sortIndex;
        $sortDirection = $categoryData->sortDirection;
        $pageIndex = $categoryData->currentPage;
        if(!empty($categoryData->pageSize)){
            $pageSizeCount = Constants::$CategoryPagerSize;
        }
        $categoryList = $this->GetPageRecordsUsingSP('categorylist',$pageIndex,$pageSizeCount, [$pageIndex,$pageSizeCount,$sortIndex,$sortDirection,$searchSiteID]);
        if(is_null($categoryList)){
            $response->Message = trans('messages.NoCategoryRecordFound');
        }else{
            $response->IsSuccess = true;
            $response->Data = $categoryList;
        }
        return $response;
    }

    public function DeleteCategory($model,$siteID){
        $categoryID = $model->CategoryID;
        $pagerModel = (object)$model->PagerModel;
        $response = new ServiceResponse();

        $pageIndex = $pagerModel->currentPage;
        $pageSizeCount = $pagerModel->pageSize;
        $defaultCategorized = Constants::$DefaultCategorized;
        $blogs=DB::table('blogposts')->join('blogpostcategories','blogposts.blogpostid','=','blogpostcategories.blogpostid')->select('Slug')->where('blogpostcategories.CategoryID','=',$categoryID)->get();
        $deleteCategoryResults = $this->GetPageRecordsUsingSPWithStatus('deletecategory',$pageIndex,$pageSizeCount,[$pagerModel->currentPage,
                                                                                                                    $pagerModel->pageSize,
                                                                                                                    $pagerModel->sortIndex,
                                                                                                                    $pagerModel->sortDirection,
                                                                                                                    $categoryID,
                                                                                                                    $siteID,
                                                                                                                    $defaultCategorized]);
        if($deleteCategoryResults->IsSuccess){
            foreach($blogs as $blog){
                CacheHelper::CacheManage($siteID,Constants::$cacheBlogID,Constants::$cacheActionUpdate,'',$blog->Slug);
            }
            if(isset($categoryID) && !empty($categoryID) && $categoryID > 0 ){
                CacheHelper::CacheManage($siteID,Constants::$cacheCategoryID,Constants::$cacheActionDelete,$categoryID);
            }
            $response->IsSuccess=true;
            $response->Message= trans('messages.CategoryDeleted');
            /* This date is required in pagination funcnality. */
            $response->Data = $deleteCategoryResults->Items[1];
            $response->CurrentPage = $deleteCategoryResults->CurrentPage;
            $response->ItemsPerPage = $deleteCategoryResults->ItemsPerPage;
            $response->TotalItems = $deleteCategoryResults->TotalItems;
        } else {
            $response->Message= trans('messages.ErrorOccured');
        }
        return $response;
    }


    public function getTagList($tagData,$searchSiteID){

        $response = new ServiceResponse();
        if(empty($tagData->sortIndex)){
            $tagData->SortIndex = Constants::$SortIndexTag;
        }

        if(empty($tagData->sortDirection)){
            $tagData->SortDirection = Constants::$SortIndexASC;
        }
        $sortIndex = $tagData->sortIndex;
        $sortDirection = $tagData->sortDirection;
        $pageIndex = $tagData->currentPage;
        if(!empty($tagData->pageSize)){
            $pageSizeCount = Constants::$TagPagerSize;
        }
        $tagList = $this->GetPageRecordsUsingSP('taglist',$pageIndex,$pageSizeCount, [$pageIndex,$pageSizeCount,$sortIndex,$sortDirection,$searchSiteID]);
        if(is_null($tagList)){
            $response->Message = trans('messages.NoTagRecordFound');
        }else{
            $response->IsSuccess = true;
            $response->Data = $tagList;
        }
        return $response;
    }

    public function SaveTag($Model,$loginUserID,$siteID){
        $TagModel = (object)$Model->TagModel;
        $pagerModel = (object)$Model->PagerModel;
        $response = new ServiceResponse();
        $messages = array(
            'required' => trans('messages.PropertyRequired'),
            'min' => trans('messages.PropertyMin'),
            'max' => trans('messages.PropertyMax')
        );
        $siteTagEntity = new SiteTagsEntity();
        $validator = Validator::make((array)$TagModel,$siteTagEntity::$Add_rules, $messages);
        $validator->setAttributeNames($siteTagEntity::$niceNameArray);
        if ($validator->fails()) {
            $response->Message = Common::getValidationMessagesFormat($validator->messages());
            return $response;
        }

        if(!isset($TagModel->TagID)){$TagModel->TagID = NULL;}

        $pageIndex = $pagerModel->currentPage;
        $pageSizeCount = $pagerModel->pageSize;
        $saveTagResults = $this->GetPageRecordsUsingSPWithStatus('savetag',$pageIndex,$pageSizeCount,[$pagerModel->currentPage,
                                                                                                    $pagerModel->pageSize,
                                                                                                    $pagerModel->sortIndex,
                                                                                                    $pagerModel->sortDirection,
                                                                                                    $TagModel->TagID,
                                                                                                    $TagModel->Tag,
                                                                                                    $TagModel->Slug,
                                                                                                    $loginUserID,
                                                                                                    $siteID]);
        if($saveTagResults->IsSuccess){
            switch($saveTagResults->Items[0]->ResultStatus){
                case '1':
                    $response->Message =trans('messages.TagAlreadyExist');
                    break;
                case '2':
                    $response->Message =trans('messages.TagSlugAlready');
                    break;
                case '3':
                    if(isset($saveTagResults->Items[2][0]->EntityID) && !empty($saveTagResults->Items[2][0]->EntityID) && $saveTagResults->Items[2][0]->EntityID > 0 ){
                        CacheHelper::CacheManage($siteID,Constants::$cacheTagID,Constants::$cacheActionInsert,$saveTagResults->Items[2][0]->EntityID);
                    }
                    $response->IsSuccess = true;
                    /* This data is required in pagination funcnality. */
                    $response->Data = $saveTagResults->Items[1];
                    $response->CurrentPage = $saveTagResults->CurrentPage;
                    $response->ItemsPerPage = $saveTagResults->ItemsPerPage;
                    $response->TotalItems = $saveTagResults->TotalItems;
                    $response->Message =trans('messages.TagAddedSuccess');
                    break;
                case '4':
                    $blogs=DB::table('blogposts')->join('blogtags','blogposts.blogpostid','=','blogtags.blogpostid')->select('Slug')->where('blogtags.tagid','=',$TagModel->TagID)->get();
                    foreach($blogs as $blog){
                        CacheHelper::CacheManage($siteID,Constants::$cacheBlogID,Constants::$cacheActionUpdate,'',$blog->Slug);
                    }
                    if(isset($TagModel->TagID) && !empty($TagModel->TagID) && $TagModel->TagID > 0 ){
                        CacheHelper::CacheManage($siteID,Constants::$cacheTagID,Constants::$cacheActionUpdate,$TagModel->TagID);
                    }
                    $response->IsSuccess = true;
                    /* This data is required in pagination funcnality. */
                    $response->Data = $saveTagResults->Items[1];
                    $response->CurrentPage = $saveTagResults->CurrentPage;
                    $response->ItemsPerPage = $saveTagResults->ItemsPerPage;
                    $response->TotalItems = $saveTagResults->TotalItems;
                    $response->Message =trans('messages.TagUpdateSuccess');
                    break;
                default:
                    $response->Message = trans('messages.ErrorOccured');
                    break;
            }
        }else{ $response->Message = trans('messages.ErrorOccured'); }
        return $response;
    }

    public function DeleteTag($model,$siteID){
        $pagerModel = (object)$model->PagerModel;
        $response = new ServiceResponse();
        $pageIndex = $pagerModel->currentPage;
        $pageSizeCount = $pagerModel->pageSize;
        $blogs=DB::table('blogposts')->join('blogtags','blogposts.blogpostid','=','blogtags.blogpostid')->select('Slug')->where('blogtags.tagid','=',$model->TagID)->get();
        $deleteTagResults = $this->GetPageRecordsUsingSPWithStatus('deletetag',$pageIndex,$pageSizeCount,[$pagerModel->currentPage,
                                                                                                          $pagerModel->pageSize,
                                                                                                          $pagerModel->sortIndex,
                                                                                                          $pagerModel->sortDirection,
                                                                                                          $model->TagID,
                                                                                                          $siteID]);
        if($deleteTagResults->IsSuccess){
            foreach($blogs as $blog){
                CacheHelper::CacheManage($siteID,Constants::$cacheBlogID,Constants::$cacheActionUpdate,'',$blog->Slug);
            }
            if(isset($model->TagID) && !empty($model->TagID) && $model->TagID > 0 ){
                CacheHelper::CacheManage($siteID,Constants::$cacheTagID,Constants::$cacheActionDelete,$model->TagID);
            }
            $response->IsSuccess=true;
            $response->Message= trans('messages.TagDeleted');
            /* This date is required in pagination funcnality. */
            $response->Data = $deleteTagResults->Items[1];
            $response->CurrentPage = $deleteTagResults->CurrentPage;
            $response->ItemsPerPage = $deleteTagResults->ItemsPerPage;
            $response->TotalItems = $deleteTagResults->TotalItems;
        } else {
            $response->Message= trans('messages.ErrorOccured');
        }
        return $response;
    }
    /* Dev_AD Region End */

    /* Dev_UP Region Start */

    public function getSearchModelForSiteTestimonialList($siteID){
        $response = new ServiceResponse();
        $model = new StdClass();
        $SiteTestimonialModel = new StdClass();

        $SiteTestimonialDetail = $this->CallRawForMultipleTable('sitetestimoniallist',[$siteID]);


        
        foreach($SiteTestimonialDetail[0] as $values){
            if($values->IsVisible ==0){
                $values->VisibleText ='False';
            } else{
                $values->VisibleText ='True';
            }
        }
        $columnName = array("IsVisible");
        $SiteTestimonialModel->SiteTestimonialListArray = Common::setSelectedPropertyValueToIntOfList($SiteTestimonialDetail[0],$columnName);
        $SiteTestimonialModel->SiteTestimonialListArray = $SiteTestimonialDetail[0];
        


        $testimonialEntity = new SiteTestimonialEntity();
        $testimonialEntity->TestimonialID = Constants::$Value_False;
        $testimonialEntity->SiteID = $siteID;
        $testimonialEntity->IsVisible = Constants::$Value_True;

        $testDetails = $testimonialEntity;
        $SiteTestimonialModel->TestDetails = $testDetails;
        $SiteTestimonialModel->DefaultTestDetails = $testDetails;




        $model->SiteTestimonialModel = $SiteTestimonialModel;


        $response->Data = $model;
        return $response;
    }

    public function DeleteSiteTestimonialList($SiteTestimonialID,$siteID){
        $response = new ServiceResponse();


         
        $deleteSiteTestimonialResults = $this->CallRawForMultipleTable('deletesitetestimonial',[$SiteTestimonialID->TestimonialID,$siteID]);
        CacheHelper::CacheManage($siteID,Constants::$cacheSiteTestimonialsID,Constants::$cacheActionDelete,$SiteTestimonialID);
        foreach($deleteSiteTestimonialResults[1] as $values){
            if($values->IsVisible ==0){
                $values->VisibleText ='False';
            } else{
                $values->VisibleText ='True';
            }
        }
        $columnName = array("IsVisible");
        $response->Data = Common::setSelectedPropertyValueToIntOfList($deleteSiteTestimonialResults[1],$columnName);
        $response->Data = $deleteSiteTestimonialResults[1];

        $response->Data =$deleteSiteTestimonialResults[1];


        if($deleteSiteTestimonialResults[0][0]->ResultStatus) {
            $response->IsSuccess=true;
            $response->Message= trans('messages.SiteTestimonialDeleted');
            $response->RedirectUrl= URL::to('/')."/sitetestimonials/".Common::getEncryptedValue(Constants::$QueryStringSiteID.'='.$siteID);
        } else {
            $response->Message= trans('messages.ErrorOccured');
        }
        return $response;
    }

    public function UpdateSortOrderSiteTestimonialList($OldOrder,$newOrder,$siteID){
        $response = new ServiceResponse();
        $addLoanResults = $this->CallRawForMultipleTable('sortordersitetestimoniallist',[$OldOrder,$newOrder,$siteID]);
        CacheHelper::CacheManage($siteID,Constants::$cacheSiteTestimonialsID,Constants::$cacheActionUpdate,$siteID);
        $response->IsSuccess=true;
        $response->Message= trans('messages.SiteTestimonialOrder');
        return $response;
    }

    public function SaveSiteTestimonialList($testModel,$loggedInUserID,$siteID){
        $response = new ServiceResponse();
        $messages = array(
            'required' => trans('messages.PropertyRequired'),
            'min' => trans('messages.PropertyMin'),
            'max' => trans('messages.PropertyMax')
        );
        $TestimonialID = $testModel->TestimonialID;
        $isEditMode = false;
        if($TestimonialID>0){
            $isEditMode = true;
        }
        $validator = Validator::make((array) $isEditMode ? SiteTestimonialEntity::$Edit_rules : SiteTestimonialEntity::$Add_rules,$messages);
        $validator->setAttributeNames(SiteTestimonialEntity::$niceNameArray);
        if ($validator->fails()) {
            $response->Message = Common::getValidationMessagesFormat($validator->messages());
            return $response;
        }

         $testModel->Attribution=isset($testModel->Attribution) ? $testModel->Attribution : "";
         $testModel->AttributionURL=isset($testModel->AttributionURL) ? $testModel->AttributionURL : "";
         $testModel->CompanyName=isset($testModel->CompanyName) ? $testModel->CompanyName : "";
         $testModel->CompanyURL=isset($testModel->CompanyURL) ? $testModel->CompanyURL : "";
        $saveTestimonialResults= $this->CallRawForMultipleTable('savesitetestimonial', [$testModel->TestimonialID,$testModel->Testimonial, $testModel->Attribution, $testModel->IsVisible,  $testModel->SiteID, $loggedInUserID, $testModel->AttributionURL, $testModel->CompanyName, $testModel->CompanyURL]);
        if ($saveTestimonialResults[0][0]->ResultStatus) {
            if($isEditMode)
                CacheHelper::CacheManage($siteID,Constants::$cacheSiteTestimonialsID,Constants::$cacheActionUpdate,$TestimonialID);
            else
                CacheHelper::CacheManage($siteID,Constants::$cacheSiteTestimonialsID,Constants::$cacheActionInsert,'');
            $response->IsSuccess = true;
            /*Here used columnName and setSelectedPropertyValueToIntOfList() for set true and false value in integer using intVal()*/
            $columnName = array("IsVisible");
            $response->Data =  Common::setSelectedPropertyValueToIntOfList($saveTestimonialResults[1],$columnName);
            $response->Message = $isEditMode ? trans('messages.SiteTestimonialUpdate') : trans('messages.SiteTestimonialInsert');
            $response->RedirectUrl = URL::to('/')."/sitetestimonials/".Common::getEncryptedValue(Constants::$QueryStringSiteID.'='.$siteID);
        } else {
            $response->Message = trans('messages.ErrorOccurred');
        }
        return $response;
    }
    /* Dev_UP Region End */

    /* RB Start */
    public function ClearCache($siteID){
        $response = new ServiceResponse();

        $baseURL = DB::table('sites')->where('SiteID', $siteID)->pluck('WebsiteBaseURL');
        $data = CacheHelper::ClearCache($siteID,$baseURL);

        $response->IsSuccess = true;
        $response->Message = trans('messages.CacheClear');
        return $response;
    }
    /* RB End */

}