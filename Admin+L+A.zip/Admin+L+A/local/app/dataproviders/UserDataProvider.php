<?php
namespace dataproviders;
use Illuminate\Support\Facades\Validator;
use \ViewModels\ServiceResponse;
use \ViewModels\SearchValueModel;
use \Infrastructure\Constants;
use \Infrastructure\Common;
use \stdClass;
use \UserEntity;
use \RoleEntity;
use \StatusEntity;
use Illuminate\Support\Facades\URL;
use Infrastructure\CacheHelper;
class UserDataProvider extends BaseDataProvider implements IUserDataProvider {
    /* Dev_RB Region Start */
    public function getUserDetail($userID, $siteID, $roleID, $updateProfile, $userSiteList){
        $response = new ServiceResponse();

        $model = new StdClass();
        $userModel = new StdClass();

        $roleNoAccess = Constants::$RoleNoAccess;
        $result = $this->CallRawForMultipleTable('userdetails', [$userID, $roleNoAccess]);


        $roleNoAccess = Constants::$RoleNoAccess;
        $userRoleArray = array_values(array_filter($result[0], function ($project) use ($roleNoAccess) {
            return $project->RoleID != $roleNoAccess;
        }));

        /* For list of  All the Roles Of MV & CO Project */
        $isEnabledForMVCO = Constants::$Value_True;
        $roleMVCOArray = array_values(array_filter($userRoleArray, function ($project) use ($isEnabledForMVCO) {
            return $project->IsEnabledForMVandCO == $isEnabledForMVCO;
        }));
        $userModel->RoleMVCOArray = $roleMVCOArray;


        /* For list of All the Roles Of RD & WW Project */
        $IsEnabledForRDWW = Constants::$Value_True;
        $roleRDWWArray = array_values(array_filter($userRoleArray, function ($project) use ($IsEnabledForRDWW) {
            return $project->IsEnabledForRDandWW == $IsEnabledForRDWW;
        }));
        $userModel->RoleRDWWArray = $roleRDWWArray;

        /* For List of User Status */

        if ($isEditMode = $userID > 0) {
            $userModel->UserDetails = $result[2][0];
            if (!empty($userModel->UserDetails->ImagePath)) {
                $imageData = $this->Awsdownloadfile($userModel->UserDetails->ImagePath,'',true);
                $userModel->UserDetails->RealImagePath = $imageData->signedUrl;
                $userModel->UserDetails->ImageName = $userModel->UserDetails->ImagePath;
            } else {
                $userModel->UserDetails->RealImagePath = '';
            }
            $userModel->UserDetails->Password = '';
        } else {
            $userEntity = new UserEntity();
            $userModel->UserDetails = $userEntity;
            $userModel->UserDetails->UserID = Constants::$Value_False;
            $userModel->UserDetails->RealImagePath = '';
            $userModel->UserDetails->ImageName = '';
            $userModel->UserDetails->IsImageRemoved = Constants::$Value_False;
            $userModel->UserDetails->UploadFilesArray = '';
            $userModel->UserDetails->TempFilesArray = '';
        }

        if ($userSiteList) {
            $userModel->UserDetails->MVUserRole = Common::GetRoleIDFromSessionRoles($userSiteList, Constants::$filedSiteID, Constants::$MercerVineSiteID);
            $userModel->UserDetails->COUserRole = Common::GetRoleIDFromSessionRoles($userSiteList, Constants::$filedSiteID, Constants::$ColoradoSiteID);
            $userModel->UserDetails->WWUserRole = Common::GetRoleIDFromSessionRoles($userSiteList, Constants::$filedSiteID, Constants::$WoodBridgeWealthSiteID);
            $userModel->UserDetails->RDUserRole = Common::GetRoleIDFromSessionRoles($userSiteList, Constants::$filedSiteID, Constants::$RiverDaleFundingSiteID);
        }
        if ($userModel->UserDetails->MVUserRole == Constants::$RoleITAdmin && $userModel->UserDetails->COUserRole == Constants::$RoleITAdmin && $userModel->UserDetails->WWUserRole == Constants::$RoleITAdmin && $userModel->UserDetails->RDUserRole == Constants::$RoleITAdmin) {
            $userModel->UserDetails->MasterUserRole = Constants::$Value_True;
        }

        if (!empty($siteID) && !empty($roleID) && $updateProfile == 1) {
            $userModel->UserDetails->RedirectURL = URL::to('/') . "/dashboard/" . Common::getEncryptedValue(Constants::$QueryStringSiteID . '=' . $siteID);
        } elseif (!empty($siteID) && !empty($roleID) && $updateProfile == 0) {
            $userModel->UserDetails->RedirectURL = URL::to('/') . "/users/" . Common::getEncryptedValue(Constants::$QueryStringSiteID . '=' . $siteID);
        } elseif (!isset($siteID) && !isset($roleID) && $updateProfile == 1) {
            $userModel->UserDetails->RedirectURL = URL::to('/') . "/choosesite";
        }


        /* For NoAccess Functionality Manage On Page Load  Start */
        if (isset($userModel->UserDetails->MVRole) && $userModel->UserDetails->MVRole == Constants::$RoleNoAccess) {
            $userModel->UserDetails->NoAccessMV = Constants::$Value_True;
            $userModel->UserDetails->MVRole = $userModel->UserDetails->PreviousMVRoleID;
        }
        if (isset($userModel->UserDetails->CORole) && $userModel->UserDetails->CORole == Constants::$RoleNoAccess) {
            $userModel->UserDetails->NoAccessCO = Constants::$Value_True;
            $userModel->UserDetails->CORole = $userModel->UserDetails->PreviousCORoleID;
        }
        if (isset($userModel->UserDetails->WWRole) && $userModel->UserDetails->WWRole == Constants::$RoleNoAccess) {
            $userModel->UserDetails->NoAccessWW = Constants::$Value_True;
            $userModel->UserDetails->WWRole = $userModel->UserDetails->PreviousWWRoleID;
        }
        if (isset($userModel->UserDetails->RDRole) && $userModel->UserDetails->RDRole == Constants::$RoleNoAccess) {
            $userModel->UserDetails->NoAccessRD = Constants::$Value_True;
            $userModel->UserDetails->RDRole = $userModel->UserDetails->PreviousRDRoleID;
        }
        /* For NoAccess End */

        $userModel->UserDetails->Fileuploadsettings = $this->FileUploadSettingsForProfileImage(Constants::$AWSRequestType_Profile,$siteID,'');

        $userModel->UserDetails->IsUpdateProfile = $updateProfile;

        $model->UserModel = $userModel;
        $response->Data = $model;
        return $response;
    }

    public function SaveUser($userModel, $loginUserID, $siteID)
    {
        $response = new ServiceResponse();
        $messages = array(
            'required' => trans('messages.PropertyRequired'),
            'min' => trans('messages.PropertyMin'),
            'max' => trans('messages.PropertyMax')
        );
        $userEntity = new UserEntity();
        $isEditMode = $userModel->UserID > 0;

        $validator = Validator::make((array)$userModel, $isEditMode ? $userEntity::$Edit_rules : $userEntity::$Add_rules, $messages);
        $validator->setAttributeNames($userEntity::$niceNameArray);
        if ($validator->fails()) {
            $response->Message = Common::getValidationMessagesFormat($validator->messages());
            return $response;
        }

        $firstName = Common::GetDataWithTrim($userModel->FirstName);
        $lastName = Common::GetDataWithTrim($userModel->LastName);
        $email = Common::GetDataWithTrim($userModel->Email);

        $hasPassword = '';
        if (!empty($userModel->ConfirmPassword))
            $hasPassword = md5($userModel->ConfirmPassword);


        isset($userModel->MVRole) ? $userModel->MVRole : $userModel->MVRole = null;
        isset($userModel->CORole) ? $userModel->CORole : $userModel->CORole = null;
        isset($userModel->WWRole) ? $userModel->WWRole : $userModel->WWRole = null;
        isset($userModel->RDRole) ? $userModel->RDRole : $userModel->RDRole = null;

        $imageName = isset($userModel->ImageName) ? $userModel->ImageName : '';

        if (isset($userModel->IsImageRemoved)) {
            if ($isEditMode && $userModel->IsImageRemoved == 1)
                $imageName = '';
        }

        /* No Access Functionality Start */
        if (isset($userModel->NoAccessMV) && $userModel->NoAccessMV == Constants::$Value_True) {
            $previousMVRoleID = $userModel->MVRole;
            $userModel->MVRole = Constants::$RoleNoAccess;
        } else {
            $previousMVRoleID = null;
        }

        if (isset($userModel->NoAccessCO) && $userModel->NoAccessCO == Constants::$Value_True) {
            $previousCORoleID = $userModel->CORole;
            $userModel->CORole = Constants::$RoleNoAccess;
        } else {
            $previousCORoleID = null;
        }

        if (isset($userModel->NoAccessWW) && $userModel->NoAccessWW == Constants::$Value_True) {
            $previousWWRoleID = $userModel->WWRole;
            $userModel->WWRole = Constants::$RoleNoAccess;
        } else {
            $previousWWRoleID = null;
        }

        if (isset($userModel->NoAccessRD) && $userModel->NoAccessRD == Constants::$Value_True) {
            $previousRDRoleID = $userModel->RDRole;
            $userModel->RDRole = Constants::$RoleNoAccess;
        } else {
            $previousRDRoleID = null;
        }

        /* No Access Functionality End */
        if(isset($userModel->MVRole) && $userModel->MVRole == Constants::$Agent_Role_ID){
            $userModel->Agent = 1;
        }else{
            $userModel->Agent ='';
        }

        $result = $this->CallRawForSingleTable('adduser', [$firstName, $lastName, $email, $loginUserID, $userModel->MVRole,
            $userModel->CORole, $userModel->WWRole, $userModel->RDRole, $userModel->UserID, $hasPassword, $imageName, $previousMVRoleID, $previousCORoleID, $previousWWRoleID, $previousRDRoleID,$userModel->Agent]);


        switch ($result[0]->AddStatus) {
            case Constants::$emailAlreadyExist:
                $response->Message = trans('messages.EmailAlreadyExist');
                break;
            case Constants::$addUserSelectRole:
                $response->Message = trans('messages.SelectRole');
                break;

            case Constants::$adminCannotChangeNoAccessToAllSite:
                $response->Message = trans('messages.CannotChangeNoAccessToAllSite');
                break;

            case Constants::$addUserSuccess:
                if (!$isEditMode) {
                    $securityDataProvider = new SecurityDataProvider();
                    $securityDataProvider->SendVerificationEmail($result[0]->UserID, $siteID, $loginUserID);
                    if(isset($result[0]->UserID) && !empty($result[0]->UserID) && $result[0]->UserID > 0 ){
                        CacheHelper::CacheManage($siteID,Constants::$cacheUserID,Constants::$cacheActionInsert,$result[0]->UserID);
                    }
                    $response->IsSuccess = true;
                    $response->Data = $userModel->IsUpdateProfile;
                    $response->Message = trans('messages.UserCreationSuccess');
                } else if ($isEditMode && $userModel->IsUpdateProfile == 0) {
                    if(isset($userModel->UserID) && !empty($userModel->UserID) && $userModel->UserID > 0 ){
                        CacheHelper::CacheManage($siteID,Constants::$cacheUserID,Constants::$cacheActionUpdate,$userModel->UserID);
                    }
                    $response->IsSuccess = true;
                    $response->Data = $userModel->IsUpdateProfile;
                    $response->Message = trans('messages.UserUpdateSuccess');
                } else {
                    if(isset($userModel->UserID) && !empty($userModel->UserID) && $userModel->UserID > 0 ){
                        CacheHelper::CacheManage($siteID,Constants::$cacheUserID,Constants::$cacheActionUpdate,$userModel->UserID);
                    }
                    $response->IsSuccess = true;
                    $response->Data = $userModel->IsUpdateProfile;
                    $response->Message = trans('messages.ProfileUpdated');
                }
                break;
            default:
                $response->Message = trans('messages.ErrorOccured');
                break;
        }

        return $response;
    }

    public function AwsFileDownload($data)
    {
        $response = new ServiceResponse();
        $response->Data = $this->Awsdownloadfile($data->ImageName,'',true);
        $response->IsSuccess = true;
        return $response;
    }

    public function DeleteProfileImageAmazon($data,$SiteID)
    {
        $response = new ServiceResponse();
        $Model = new stdClass();
        if ($data->UserID == 0) {
            $this->Awsdeletefile($data->ImageName,'',true);
        }
        $response->Data = $Model->RealImagePath = '';
        $response->IsSuccess = true;
        return $response;
    }

    /* Dev_RB Region End */


    /*Start Region Dev_Vishal*/

    public function getSearchModelForUserList($SiteID)
    {
        $response = new ServiceResponse();
        $enabledFileName = Common::GetEnableFieldName($SiteID);
        $model = new stdClass();

        $statusData = $this->GetEntityList(new StatusEntity(), array());

        $allStatus = new StatusEntity();
        $allStatus->StatusID = Constants::$AllStatusValue;
        $allStatus->Status = Constants::$AllStatusText;
        array_unshift($statusData, $allStatus);

        $SearchValueModel = new SearchValueModel();
        $SearchParam = Array();
        $SearchValueModel->Name = $enabledFileName;
        $SearchValueModel->Value = Constants::$Value_True;
        array_push($SearchParam, $SearchValueModel);
        $userRoleArray = $this->GetEntityList(new RoleEntity(), $SearchParam);

        $roleNoAccess = Constants::$RoleNoAccess;
        $roleData = array_values(array_filter($userRoleArray, function ($project) use ($roleNoAccess) {
            return $project->RoleID != $roleNoAccess;
        }));

        $allRoles = new RoleEntity();
        $allRoles->RoleID = Constants::$AllRolesValue;
        $allRoles->Role = Constants::$AllRolesText;
        array_unshift($roleData, $allRoles);

        $searchModel = new stdClass();
        $searchModel->LastName = "";
        $searchModel->Email = "";
        $searchModel->StatusID = Constants::$Status_Active;
        $searchModel->RoleID = Constants::$AllRolesValue;
        $searchModel->SiteID = $SiteID;

        $model->StatusLookup = $statusData;
        $model->rolesLookup = $roleData;
        $model->frontSearchModel = $searchModel;
        $model->backSearchModel = $searchModel;
        $response->Data = $model;
        return $response;
    }

    public function getUserInfoList($userData, $loggedInUserID)
    {
        $response = new ServiceResponse();
        if (empty($userData->SortIndex)) {
            $userData->SortIndex = Constants::$SortIndex;
        }
        if (empty($userData->SortDirection)) {
            $userData->SortDirection = Constants::$SortIndexASC;
        }
        $sortIndex = $userData->SortIndex;
        $sortDirection = $userData->SortDirection;
        $pageIndex = $userData->PageIndex;
        $pageSizeCount = $userData->PageSize;

        $searchLastName = '';
        $searchEmail = '';
        $searchStatus = '';
        $searchRoles = '';
        $searchSiteID = '';

        if (isset($userData->SearchParams)) {

            if (isset($userData->SearchParams['LastName'])) {
                $searchLastName = $userData->SearchParams['LastName'];
            }
            if (isset($userData->SearchParams['Email'])) {
                $searchEmail = $userData->SearchParams['Email'];
            }
            if (isset($userData->SearchParams['StatusID'])) {
                $searchStatus = $userData->SearchParams['StatusID'];
            }
            if (isset($userData->SearchParams['RoleID'])) {
                $searchRoles = $userData->SearchParams['RoleID'];
            }
            if (isset($userData->SearchParams['SiteID'])) {
                $searchSiteID = $userData->SearchParams['SiteID'];
            }
        }
        $userList = $this->GetPageRecordsUsingSP('userlist', $pageIndex, $pageSizeCount, [$searchLastName, $searchEmail, $searchStatus, $searchRoles, $pageIndex, $pageSizeCount, $sortIndex, $sortDirection, $searchSiteID, $loggedInUserID]);
        if (is_null($userList)) {
            $response->Message = trans('messages.NoRecordFound');
        } else {
            $response->IsSuccess = true;
            $response->Data = $userList;
        }
        return $response;
    }

    /*Stop Region Dev_Vishal*/


    /* Dev_Drashtant Region Start */
    public function postDisableUser($userData, $loggedInUserID, $siteID)
    {
        $response = new ServiceResponse();
        $dateTime = date(Constants::$DefaultDateTimeFormat);
        $userID = $userData->UserID;
        $previousRoleID = $userData->RoleID;

        $roleNoAccess = Constants::$RoleNoAccess;
        $DisableUser = $this->CallRawForSingleTable('disableuser', [$userID, $dateTime, $loggedInUserID, $siteID, $roleNoAccess, $previousRoleID]);

        if ($DisableUser) {
            $response->IsSuccess = true;
            $response->Message = trans('messages.UserDisableSuccess');
        }
        return $response;
    }

    public function postEnableUser($userData, $loggedInUserID, $siteID)
    {
        $response = new ServiceResponse();
        $dateTime = date(Constants::$DefaultDateTimeFormat);
        $userID = $userData->UserID;

        $enableUser = $this->CallRawForSingleTable('enableuser', [$userID, $dateTime, $loggedInUserID, $siteID]);

        if ($enableUser) {
            $response->IsSuccess = true;
            $response->Message = trans('messages.UserEnableSuccess');
        }
        return $response;
    }

    /* Dev_Drashtant Region End */


}