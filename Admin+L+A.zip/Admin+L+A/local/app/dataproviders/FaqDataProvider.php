<?php
namespace dataproviders;
use Illuminate\Support\Facades\Validator;
use \ViewModels\ServiceResponse;
use \Infrastructure\Constants;
use \Infrastructure\Common;
use \stdClass;
use \Crypt;
use Illuminate\Support\Facades\URL;
use \Mail;
use \ViewModels\SearchValueModel;
use File;
use FaqEntity;
use FaqTypesEntity;
use SitesEntity;
use Infrastructure\CacheHelper;
class FaqDataProvider extends BaseDataProvider implements IFaqDataProvider {

    /* Dev_AD Region Start */
    public function AddFaqData($FaqModel,$loginUserID,$siteID){
        $response = new ServiceResponse();
        $messages = array(
            'required' => trans('messages.PropertyRequired'),
            'min' => trans('messages.PropertyMin'),
            'max' => trans('messages.PropertyMax')
        );
        $isEditMode = false;
        if(isset($FaqModel->FAQID)) {
            $isEditMode = true;
        }
        $faqEntity = new FaqEntity();
        $validator = Validator::make((array)$FaqModel,FaqEntity::$Add_Faq_rules,$messages);
        $validator->setAttributeNames(FaqEntity::$niceNameArray);
        if($validator->fails()){
            $response->Message=Common::getValidationMessagesFormat($validator->messages());
            return $response;
        }

        $searchParamsQuestion = array();
        $searchValueData=new SearchValueModel();
        $searchValueData->Name="Question";
        $searchValueData->Value=$FaqModel->Question;
        $searchValueData->CheckForExactMatch = Constants::$ExactMatch;
        array_push($searchParamsQuestion, $searchValueData);

        $searchValueData=new SearchValueModel();
        $searchValueData->Name="SiteID";
        $searchValueData->Value=$FaqModel->SiteID;
        $searchValueData->CheckForExactMatch = Constants::$ExactMatch;
        array_push($searchParamsQuestion, $searchValueData);

        if ($isEditMode) {
            $customWhere = "FAQID != $FaqModel->FAQID";
        }else{
            $customWhere="";
        }
        if($this->GetEntityCount($faqEntity, $searchParamsQuestion, "", "", $customWhere)) {
            $response->Message = "" . trans('messages.FaqAlreadyExist');
        }else {
            if ($isEditMode) {
                $faqEntity = $this->GetEntityForUpdateByPrimaryKey($faqEntity, $FaqModel->FAQID);
            } else {
                $faqEntity->CreatedByID = $loginUserID;
                $faqEntity->CreatedDate = date(Constants::$DefaultDateTimeFormat);
            }
            $faqEntity->Question = $FaqModel->Question;
            $faqEntity->Answer = $FaqModel->Answer;
            $faqEntity->ModifiedDate = date(Constants::$DefaultDateTimeFormat);
            $faqEntity->ModifiedByID = $loginUserID;
            $faqEntity->SiteID = $FaqModel->SiteID;

            if (isset($FaqModel->TypeID)) {
                $faqEntity->TypeID = $FaqModel->TypeID;
            }
            $results = $this->CallRawForMultipleTable('savefaq', [$faqEntity->Question, $faqEntity->Answer, $faqEntity->TypeID, $faqEntity->FAQID, $faqEntity->SiteID, $faqEntity->CreatedByID]);
            if ($results[0][0]->ResultStatus) {
                if ($isEditMode) {
                    CacheHelper::CacheManage($siteID,Constants::$cacheFaqID,Constants::$cacheActionUpdate,'');
                    $response->IsSuccess = true;
                    $response->Message = trans('messages.FaqUpdateSuccess');
                    $response->RedirectUrl = URL::to('/') . "/faqlist/" . Common::getEncryptedValue(Constants::$QueryStringSiteID . '=' . $siteID);
                } else {
                    CacheHelper::CacheManage($siteID,Constants::$cacheFaqID,Constants::$cacheActionInsert,'');
                    $response->IsSuccess = true;
                    $response->Message = trans('messages.FaqAddedSuccess');
                    $response->RedirectUrl = URL::to('/') . "/faqlist/" . Common::getEncryptedValue(Constants::$QueryStringSiteID . '=' . $siteID);
                }

            } else {
                $response->Message = trans('messages.ErrorOccured');
            }
        }
        return $response;
    }
    public function getFaqTypeDetails($faqID,$siteID){
        $response = new ServiceResponse();
        $model = new StdClass();
        $faqModel = new StdClass();
        $searchParams = array();
        $searchValueData = new SearchValueModel();
        $searchValueData->Name = "SiteID";
        $searchValueData->Value = $siteID;
        array_push($searchParams, $searchValueData);
        $FaqTypeArray = $this->GetEntityList(new FaqTypesEntity(),$searchParams);

        $faqModel->TypeArray = $FaqTypeArray ;
        if($faqID >0) {
            $searchValueData = new SearchValueModel();
            $searchValueData->Name = "FAQID";
            $searchValueData->Value = $faqID;
            array_push($searchParams, $searchValueData);

            $FaqDetails = $this->GetEntity(new FaqEntity(), $searchParams);
            $FaqDetails->SiteID = $siteID;
            $faqModel->FAQDetails = $FaqDetails;
        }
        $faqModel->SiteID = $siteID ;
        $faqModel->encryptedSiteID = Common::getEncryptedValue(Constants::$QueryStringSiteID.'='.$siteID);

        /* Check IsFAQTypeEnabled this site or not. */

        $sitesEntity = new SitesEntity();
        $searchParams = array();
        $searchValueData=new SearchValueModel();
        $searchValueData->Name = "SiteID";
        $searchValueData->Value = $siteID;
        $searchValueData->CheckForExactMatch = Constants::$ExactMatch;
        array_push($searchParams, $searchValueData);

        $searchValueData=new SearchValueModel();
        $searchValueData->Name = "IsFAQTypeEnabled";
        $searchValueData->Value = Constants::$IsFAQTypeEnabled;;
        $searchValueData->CheckForExactMatch = Constants::$ExactMatch;
        array_push($searchParams, $searchValueData);

        $faqModel->IsFAQTypeEnabled = $this->GetEntityCount($sitesEntity, $searchParams);
        $model->FaqModel = $faqModel;
        $response->Data = $model;

        return $response;
    }

    public function getSearchModelForFaqList($siteID){
        $response = new ServiceResponse();
        $model = new StdClass();
        $faqModel = new StdClass();
        $faqDetail = $this->CallRawForMultipleTable('faqlist',[$siteID]);
        $faqModel->FaqListArray = $faqDetail[0];
        $model->FaqModel = $faqModel;
        $response->Data = $model;
        return $response;
    }

    public function DeleteFaq($FAQID,$siteID){
        $response = new ServiceResponse();
        $deleteFaqResults = $this->CallRawForMultipleTable('deletefaq',[$FAQID,$siteID]);
        if($deleteFaqResults[0][0]->ResultStatus) {
            CacheHelper::CacheManage($siteID,Constants::$cacheFaqID,Constants::$cacheActionDelete,'');
            $response->IsSuccess=true;
            $response->Message= trans('messages.FaqDeleted');
            $response->RedirectUrl= URL::to('/')."/faqlist/".Common::getEncryptedValue(Constants::$QueryStringSiteID.'='.$siteID);
        } else {
            $response->Message= trans('messages.ErrorOccured');
        }
        return $response;
    }
    public function UpdateSortOrderFaq($OldOrder,$newOrder,$siteID){
        $response = new ServiceResponse();
        $addFaqResults = $this->CallRawForMultipleTable('sortorderfaqlist',[$OldOrder,$newOrder,$siteID]);
        CacheHelper::CacheManage($siteID,Constants::$cacheFaqID,Constants::$cacheActionUpdate,'');
        $response->IsSuccess=true;
        $response->Message= trans('messages.FaqOrder');
        return $response;
    }
    /* Dev_AD Region End */
}