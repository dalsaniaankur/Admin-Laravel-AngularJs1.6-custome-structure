<?php 
namespace dataproviders;

Interface ISiteDataProvider{

    /* Dev_AD Region Start */
    public function SaveCategory($Model,$loginUserID,$siteID);
    public function getCategoryDetails();
    public function getCategoryList($categoryData,$searchSiteID);
    public function DeleteCategory($model,$siteID);
    public function getTagList($tagData,$searchSiteID);
    public function SaveTag($Model,$loginUserID,$siteID);
    public function DeleteTag($model,$siteID);
    /* Dev_AD Region End */

}
