<?php
namespace dataproviders;

use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Validator;
use \Exception;
use \ViewModels\ServiceResponse;
use \Infrastructure\Constants;
use \Infrastructure\Common;
use \stdClass;
use \SitesEntity;
use PropertyListingsEntity;
use RetsLogsEntity;
use Illuminate\Support\Facades\URL;
use PropertyListingImagesEntity;
use Illuminate\Support\Facades\DB;
use TempRetsImagesEntity;
use PropertyFeaturesEntity;
use \SettingEntity;

use \CronJobEntity;
use \COCronJobEntity;
use \Image;
use \File;
use DeletePropertyListingImagesEntity;
use PropertyImagesInterventionEntity;
use Illuminate\Support\Facades\Log;
use ImageUploadErrorEntity;
use Infrastructure\CacheHelper;
use CoPropertyListingsEntity;
use CoPropertyListingImagesEntity;
use CoTempRetsImagesEntity;
use CoPropertyImagesInterventionEntity;
use CoImageUploadErrorEntity;

class PropertyListingDataProvider extends BaseDataProvider implements IPropertyListingDataProvider
{
    /* Start Region Dev_AD */
    public function getSearchModelForPropertyList($SiteID)
    {
        $response = new ServiceResponse();
        $model = new stdClass();
        $PropertyResults = $this->CallRawForMultipleTable('propertymodel', [$SiteID]);
        $searchModel = new stdClass();
        $searchModel->StatusID = Constants::$Property_Status_Active;
        $searchModel->SiteID = $SiteID;
        $searchModel->IsFeatured = Constants::$IsFeatured;
        $searchModel->IsHidden = Constants::$ShowHidden;
        $searchModel->MLSNo = "";
        $searchModel->Address = "";
        $searchModel->AgentID = "";
        $searchModel->City = "";
        $searchModel->ZipCode = "";
        $model->StatusLookup = $PropertyResults[0];
        $model->AgentLookup = $PropertyResults[1];
        $model->frontSearchModel = $searchModel;
        $model->backSearchModel = $searchModel;
        $response->Data = $model;
        return $response;
    }

    public function getPropertyInfoList($userData, $siteID, $loggedInUserID)
    {
        $response = new ServiceResponse();
        if (isset($userData->pagermodel)) {
            $agentID = $userData->AgentID;
            $userData = (object)$userData->pagermodel;
        }
        if (empty($userData->SortIndex)) {
            $userData->SortIndex = Constants::$SortIndex;
        }
        if (empty($userData->SortDirection)) {
            $userData->SortDirection = Constants::$SortIndexASC;
        }
        $sortIndex = $userData->SortIndex;
        $sortDirection = $userData->SortDirection;
        $pageIndex = $userData->PageIndex;
        $pageSizeCount = $userData->PageSize;
        if($siteID==Constants::$MercerVineSiteID) {
            $searchMLSNo = Constants::$defaultStaticValue;
            $searchAddress = '';
            $searchUserID = Constants::$defaultStaticValue;
            $searchStatusID = Constants::$Property_Status_Active;
            $searchIsHidden = Constants::$defaultStaticValue;
            $searchCity = "";
            $searchZipCode = "";
            $searchIsFeatured = Constants::$defaultStaticValue;
            if (isset($agentID)) {
                $searchUserID = $agentID;
            }
            if (isset($userData->SearchParams)) {

                if (!empty($userData->SearchParams['MLSNo'])) {
                    $searchMLSNo = $userData->SearchParams['MLSNo'];
                }
                if (!empty($userData->SearchParams['Address'])) {
                    $searchAddress = $userData->SearchParams['Address'];
                }
                if (!empty($userData->SearchParams['AgentID'])) {
                    $searchUserID = $userData->SearchParams['AgentID'];
                }
                if (!empty($userData->SearchParams['StatusID'])) {
                    $searchStatusID = $userData->SearchParams['StatusID'];
                }
                if (!empty($userData->SearchParams['IsHidden'])) {
                    $searchIsHidden = $userData->SearchParams['IsHidden'];
                } else {
                    if (isset($userData->SearchParams['IsHidden']))
                        $searchIsHidden = 0;
                }
                if (!empty($userData->SearchParams['City'])) {
                    $searchCity = $userData->SearchParams['City'];
                }
                if (isset($userData->SearchParams['ZipCode']) && $userData->SearchParams['ZipCode'] != '' && $userData->SearchParams['ZipCode'] != -1) {
                    $searchZipCode = $userData->SearchParams['ZipCode'];
                }
                if ((isset($userData->SearchParams['IsFeatured']) AND ($userData->SearchParams['IsFeatured'] == 0)))
                    $searchIsFeatured = 0;
                if ((isset($userData->SearchParams['IsFeatured']) AND ($userData->SearchParams['IsFeatured'] == 1)))
                    $searchIsFeatured = 1;
            }
            $propertyList = $this->GetPageRecordsUsingSP('propertylist', $pageIndex, $pageSizeCount, [$searchMLSNo, $searchUserID, $searchIsHidden, $searchStatusID, $pageIndex, $pageSizeCount, $sortIndex, $sortDirection, $siteID, $loggedInUserID, $searchIsFeatured, $searchAddress, $searchCity, $searchZipCode], ["IsFeatured"]);
        }
        if($siteID==Constants::$ColoradoSiteID) {
            $searchMLSNo = Constants::$defaultStaticValue;
            $searchStreet = '';
            $searchUserID = Constants::$defaultStaticValue;
            $searchClassID = Constants::$defaultStaticValue;
            $searchStatusID = Constants::$Property_Status_Active;
            $searchIsHidden = Constants::$defaultStaticValue;
            $searchCity = "";
            $searchZipCode = "";
            if (isset($agentID)) {
                $searchUserID = $agentID;
            }
            if (isset($userData->SearchParams)) {

                if (!empty($userData->SearchParams['MLSNo'])) {
                    $searchMLSNo = $userData->SearchParams['MLSNo'];
                }
                if (!empty($userData->SearchParams['Street'])) {
                    $searchStreet = $userData->SearchParams['Street'];
                }
                if (!empty($userData->SearchParams['AgentID'])) {
                    $searchUserID = $userData->SearchParams['AgentID'];
                }
                if (!empty($userData->SearchParams['ClassID'])) {
                    $searchClassID = $userData->SearchParams['ClassID'];
                }
                if (!empty($userData->SearchParams['StatusID'])) {
                    $searchStatusID = $userData->SearchParams['StatusID'];
                }
                if (!empty($userData->SearchParams['IsHidden'])) {
                    $searchIsHidden = $userData->SearchParams['IsHidden'];
                } else {
                    if (isset($userData->SearchParams['IsHidden']))
                        $searchIsHidden = 0;
                }
                if (!empty($userData->SearchParams['City'])) {
                    $searchCity = $userData->SearchParams['City'];
                }
                if (isset($userData->SearchParams['ZipCode']) && $userData->SearchParams['ZipCode'] != '' && $userData->SearchParams['ZipCode'] != -1) {
                    $searchZipCode = $userData->SearchParams['ZipCode'];
                }
            }
            $propertyList = $this->GetPageRecordsUsingSP('co_propertylist', $pageIndex, $pageSizeCount, [$searchMLSNo, $searchUserID, $searchClassID, $searchIsHidden, $searchStatusID, $pageIndex, $pageSizeCount, $sortIndex, $sortDirection, $siteID, $loggedInUserID, $searchStreet, $searchCity, $searchZipCode]);
        }
        if (is_null($propertyList)) {
            $response->Message = trans('messages.NoRecordFound');
        } else {
            $response->IsSuccess = true;
            $response->Data = $propertyList;
        }
        return $response;
    }
    /* End Region Dev_AD */

    /* Dev_AYS Region Start */
    // This method gets page load data with property details for edit property.
    public function GetPropertyLookUps($listingID, $siteID, $agentRoleID, $userActiveStatus, $loginUserID)
    {
        $response = new ServiceResponse();
        $Model = new stdClass();
        $PropertyModel = new stdClass();
        $LookupResult = $this->CallRawForMultipleTable('propertylookups', array($listingID, $siteID, $agentRoleID, $userActiveStatus));

        $PropertyModel->PropertyTypes = $LookupResult[0];
        $PropertyModel->PropertySubTypes = $LookupResult[1];
        $PropertyModel->PropertyStatuses = $LookupResult[2];
        $PropertyModel->Areas = $LookupResult[3];
        $PropertyModel->SecurityTypes = $LookupResult[4];
        $PropertyModel->PoolTypes = $LookupResult[5];
        $PropertyModel->SpaTypes = $LookupResult[6];
        $PropertyModel->Views = $LookupResult[7];
        $PropertyModel->Styles = $LookupResult[8];
        $PropertyModel->WaterFronts = $LookupResult[9];
        $PropertyModel->Roofings = $LookupResult[10];
        $PropertyModel->Sewers = $LookupResult[11];
        $PropertyModel->Equipments = $LookupResult[12];
        $PropertyModel->Floorings = $LookupResult[13];
        $PropertyModel->Heatings = $LookupResult[14];
        $PropertyModel->Airconditionings = $LookupResult[15];
        $PropertyModel->Rooms = $LookupResult[16];
        $PropertyModel->Fireplaces = $LookupResult[17];
        $PropertyModel->Laundries = $LookupResult[18];
        $PropertyModel->Parkings = $LookupResult[19];
        $PropertyModel->DisabilityAccesses = $LookupResult[20];
        $PropertyModel->Courts = $LookupResult[21];
        $PropertyModel->Amenities = $LookupResult[22];
        $PropertyModel->Keywords = $LookupResult[23];
        $PropertyModel->States = $LookupResult[24];
        $PropertyModel->Agents = $LookupResult[25];
        $PropertyModel->Developments = $LookupResult[26];
        $PropertyModel->ListingModel = $LookupResult[27][0];
        $PropertyModel->ListingModel->UploadedFile = $LookupResult[28];
        $PropertyModel->IsShowUploadNote = $LookupResult[29][0]->IsShowUploadNote;
        // To set default value as per site selection while add property
        if (is_null($PropertyModel->ListingModel->StateID) || $PropertyModel->ListingModel->StateID == '')
            $PropertyModel->ListingModel->StateID = (($siteID == Constants::$MercerVineSiteID ? Constants::$DefaultMVStateID : ($siteID == Constants::$ColoradoSiteID ? Constants::$DefaultColoradoStateID : '')));
        if (is_null($PropertyModel->ListingModel->IsHidden) || $PropertyModel->ListingModel->IsHidden == '')
            $PropertyModel->ListingModel->IsHidden = 0;

        $PropertyModel->ListingModel->Airconditionings = array_map(function ($v)  { return $v->AirConditioningID; },$LookupResult[31]);
        $PropertyModel->ListingModel->Amenities = array_map(function ($v)  { return $v->AmenityID; },$LookupResult[32]);
        $PropertyModel->ListingModel->Courts = array_map(function ($v)  { return $v->CourtID; },$LookupResult[33]);
        $PropertyModel->ListingModel->DisabilityAccesses = array_map(function ($v)  { return $v->DisabilityAccessID; },$LookupResult[34]);
        $PropertyModel->ListingModel->Equipments = array_map(function ($v)  { return $v->EquipmentID; },$LookupResult[35]);
        $PropertyModel->ListingModel->Fireplaces = array_map(function ($v)  { return $v->FireplaceID; },$LookupResult[36]);
        $PropertyModel->ListingModel->Floorings = array_map(function ($v)  { return $v->FlooringID; },$LookupResult[37]);
        $PropertyModel->ListingModel->Heatings = array_map(function ($v)  { return $v->HeatingID; },$LookupResult[38]);

        // If we have null data and we pass blank array in js it will bind 1 blank value in auto completer.
        if (strlen($PropertyModel->ListingModel->Keywords) > 0) {
            $PropertyModel->ListingModel->Keywords = explode(',', $PropertyModel->ListingModel->Keywords);
        }
        if (strlen($PropertyModel->ListingModel->KeywordIDs) > 0) {
            $PropertyModel->ListingModel->KeywordIDs = explode(',', $PropertyModel->ListingModel->KeywordIDs);
        }
        $Word = array();
        if (is_array($PropertyModel->ListingModel->Keywords)) {
            foreach ($PropertyModel->ListingModel->Keywords as $key => $keyWord) {
                array_push($Word, array(
                    'KeywordID' => $PropertyModel->ListingModel->KeywordIDs[$key],
                    'Keyword' => $keyWord
                ));
            }
        }
        $PropertyModel->ListingModel->Keywords = $Word;
        $PropertyModel->ListingModel->Laundries = array_map(function ($v)  { return $v->LaundryID; },$LookupResult[39]);
        $PropertyModel->ListingModel->Parkings = array_map(function ($v)  { return $v->ParkingID; },$LookupResult[40]);
        $PropertyModel->ListingModel->Pools = array_map(function ($v)  { return $v->PoolTypeID; },$LookupResult[41]);
        $PropertyModel->ListingModel->Roofings = array_map(function ($v)  { return $v->RoofingID; },$LookupResult[42]);
        $PropertyModel->ListingModel->Rooms = array_map(function ($v)  { return $v->RoomID; },$LookupResult[43]);
        $PropertyModel->ListingModel->SecurityTypes = array_map(function ($v)  { return $v->SecurityTypeID; },$LookupResult[44]);
        $PropertyModel->ListingModel->Sewers = array_map(function ($v)  { return $v->SewerID; },$LookupResult[45]);
        $PropertyModel->ListingModel->Spas = array_map(function ($v)  { return $v->SpaTypeID; },$LookupResult[46]);
        $PropertyModel->ListingModel->Styles = array_map(function ($v)  { return $v->StyleID; },$LookupResult[47]);
        $PropertyModel->ListingModel->Views = array_map(function ($v)  { return $v->ViewID; },$LookupResult[48]);
        $PropertyModel->ListingModel->WaterFronts = array_map(function ($v)  { return $v->WaterfrontID; },$LookupResult[49]);

        //we need integer value in js to bind value for the checkbox.
        $PropertyModel->ListingModel->HasGuestHouse = intval($PropertyModel->ListingModel->HasGuestHouse);
        $PropertyModel->ListingModel->HasHorseProperty = intval($PropertyModel->ListingModel->HasHorseProperty);

        $PropertyModel->ListingModel->UploadedFileOfPropertyFeatures = isset($LookupResult[30]) ? $LookupResult[30] : '';

        $PropertyModel->FileUploadSettings = $this->FileUploadSettings(Constants::$AWSRequestType_Listing, $siteID, $loginUserID);
        $Model->PropertyModel = $PropertyModel;

        $response->Data = $Model;
        return $response;
    }

    public function ProcessRETSCall($MlsNo, $UserID, $SiteID,$fetchImage,$ClassID)
    {
        $response = new ServiceResponse();
        $config = new \PHRETS\Configuration;

        //CLAW (Mercer Vine)
        if ($SiteID == Constants::$MercerVineSiteID) {
            $searchParam = array();
            $searchValues = Common::SetSearchArray('MLSNo', $MlsNo, Constants::$Value_True);
            array_push($searchParam, $searchValues);
            $searchValues = Common::SetSearchArray('SiteID', $SiteID);
            array_push($searchParam, $searchValues);
            $duplicate = $this->GetEntity(new PropertyListingsEntity(), $searchParam);

            if ($duplicate && $duplicate->IsWBProperty==0) {
                $PropertyModel = new stdClass();
                $PropertyModeldata=$this->CallRawForMultipleTable('getmlsforupdate',[$duplicate->ListingID,Constants::$MercerVineSiteID]);

                $PropertyModeldata[0][0]->UploadedFile=$PropertyModeldata[1];
                $PropertyModeldata[0][0]->IsShowUploadNote=$PropertyModeldata[2][0]->IsShowUploadNote;


                if (is_null($PropertyModeldata[0][0]->StateID) || $PropertyModeldata[0][0]->StateID == '')
                    $PropertyModeldata[0][0]->StateID = (($SiteID == Constants::$MercerVineSiteID ? Constants::$DefaultMVStateID : ($SiteID == Constants::$ColoradoSiteID ? Constants::$DefaultColoradoStateID : '')));
                if (is_null($PropertyModeldata[0][0]->IsHidden) || $PropertyModeldata[0][0]->IsHidden == '')
                    $PropertyModeldata[0][0]->ListingModel->IsHidden = 0;

                $PropertyModeldata[0][0]->Airconditionings = array_map(function ($v)  { return $v->AirConditioningID; },$PropertyModeldata[4]);
                $PropertyModeldata[0][0]->Amenities =array_map(function ($v)  { return $v->AmenityID; },$PropertyModeldata[5]);
                $PropertyModeldata[0][0]->Courts =array_map(function ($v)  { return $v->CourtID; },$PropertyModeldata[6]);
                $PropertyModeldata[0][0]->DisabilityAccesses = array_map(function ($v)  { return $v->DisabilityAccessID; },$PropertyModeldata[7]);
                $PropertyModeldata[0][0]->Equipments = array_map(function ($v)  { return $v->EquipmentID; },$PropertyModeldata[8]);
                $PropertyModeldata[0][0]->Fireplaces = array_map(function ($v)  { return $v->FireplaceID; },$PropertyModeldata[9]);
                $PropertyModeldata[0][0]->Floorings = array_map(function ($v)  { return $v->FlooringID; },$PropertyModeldata[10]);
                $PropertyModeldata[0][0]->Heatings = array_map(function ($v)  { return $v->HeatingID; },$PropertyModeldata[11]);

                // explode needed as we get csv data using group_concat.
                if (strlen($PropertyModeldata[0][0]->Keywords) > 0) {
                    $PropertyModeldata[0][0]->Keywords = explode(',', $PropertyModeldata[0][0]->Keywords);
                }
                if (strlen($PropertyModeldata[0][0]->KeywordIDs) > 0) {
                    $PropertyModeldata[0][0]->KeywordIDs = explode(',', $PropertyModeldata[0][0]->KeywordIDs);
                }
                $Word = array();
                if (is_array($PropertyModeldata[0][0]->Keywords)) {
                    foreach ($PropertyModeldata[0][0]->Keywords as $key => $keyWord) {
                        array_push($Word, array(
                            'KeywordID' => $PropertyModeldata[0][0]->KeywordIDs[$key],
                            'Keyword' => $keyWord
                        ));
                    }
                }
                $PropertyModeldata[0][0]->Keywords = $Word;

                $PropertyModeldata[0][0]->Laundries = array_map(function ($v)  { return $v->LaundryID; },$PropertyModeldata[12]);
                $PropertyModeldata[0][0]->Parkings = array_map(function ($v)  { return $v->ParkingID; },$PropertyModeldata[13]);
                $PropertyModeldata[0][0]->Pools = array_map(function ($v)  { return $v->PoolTypeID; },$PropertyModeldata[14]);
                $PropertyModeldata[0][0]->Roofings = array_map(function ($v)  { return $v->RoofingID; },$PropertyModeldata[15]);
                $PropertyModeldata[0][0]->Rooms = array_map(function ($v)  { return $v->RoomID; },$PropertyModeldata[16]);
                $PropertyModeldata[0][0]->SecurityTypes = array_map(function ($v)  { return $v->SecurityTypeID; },$PropertyModeldata[17]);
                $PropertyModeldata[0][0]->Sewers = array_map(function ($v)  { return $v->SewerID; },$PropertyModeldata[18]);
                $PropertyModeldata[0][0]->Spas = array_map(function ($v)  { return $v->SpaTypeID; },$PropertyModeldata[19]);
                $PropertyModeldata[0][0]->Styles = array_map(function ($v)  { return $v->StyleID; },$PropertyModeldata[20]);
                $PropertyModeldata[0][0]->Views = array_map(function ($v)  { return $v->ViewID; },$PropertyModeldata[21]);
                $PropertyModeldata[0][0]->WaterFronts =array_map(function ($v)  { return $v->WaterfrontID; },$PropertyModeldata[22]);

                $PropertyModeldata[0][0]->HasGuestHouse = intval($PropertyModeldata[0][0]->HasGuestHouse);
                $PropertyModeldata[0][0]->HasHorseProperty = intval($PropertyModeldata[0][0]->HasHorseProperty);

                $PropertyModeldata[0][0]->UploadedFileOfPropertyFeatures=$PropertyModeldata[3];

                $PropertyModel->ListingModel = $PropertyModeldata[0][0];
                $response->Data=$PropertyModel;
                $response->IsSuccess=true;
                return $response;
            }
            if($duplicate && $duplicate->IsWBProperty==1) {
                $response->Message = trans('messages.PropertyDuplicate');
                return $response;
            }

            /* Login */
            $config->setloginurl(Config::get('config.CLAW_Login_URL'));
            $config->setRetsVersion(Config::get('config.CLAW_RETS_Version'));
            $config->setUserAgent(Config::get('config.CLAW_UserAgent'));
            $config->setHttpAuthenticationMethod(Config::get('config.CLAW_Authentication_Method'));
            $config->setOption('use_post_method', false);
            $config->setOption('disable_follow_location', false);

            // get credentials from database settings table. We kept them in db so user can change easily if there is any change.
            $Credentials = $this->GetCLAWCredentials($SiteID);
            $config->setusername($Credentials->RETSUserName);
            $config->setpassword($Credentials->RETSPassword);
            $rets = new \PHRETS\Session($config);
            $login = $rets->Login();
            $LogArray=array();
            // Add log for login request
            $LogArray=$this->StoreRetsLog($UserID, $SiteID, Constants::$RETSActionLogin, Config::get('config.CLAW_Login_URL'), '', $login,$LogArray,false);
            if ($login) {
                // Search property with user given listingID(MLS#)
                $resource = 'Property';
                $class = 'ALL';
                $query = '(ListingID=' . $MlsNo . ')';
                $result = $rets->Search(
                    $resource,
                    $class,
                    $query,
                    [
                        'QueryType' => 'DMQL2',
                        'Count' => 1, // only records
                        'Format' => 'COMPACT-DECODED',
                        'Limit' => 10,
                        'StandardNames' => 0, // give system names
                    ]
                );
                // Add log for rets search property.
                $LogArray = $this->StoreRetsLog($UserID, $SiteID, Constants::$RETSActionSearch, $result->URL, '', serialize($result->toArray()),$LogArray,false);
                $data = json_decode($result->toJSON());

                if ($data) {
                    $data = $data[0];
                    // One to one mapping of rets data to property object.
                    $PropertyModel = new stdClass();
                    $PropertyModel->ListingModel = $this->getPropertiesFormated($data,Constants::$Value_True,$SiteID);
                    //Get Object/Image data
                    $PropertyModel->ListingModel->fetchImage=$fetchImage;
                    if($fetchImage==true) {
                        $objects = $rets->Search(
                            'Media',
                            'PROP_MEDIA',
                            '(PropObjectKey=' . $data->ListingKey . ')',
                            [
                                'QueryType' => 'DMQL2',
                                'Count' => 0,
                                'Format' => 'COMPACT-DECODED',
                                'StandardNames' => 0, // give system names
                            ]
                        );

                        // Add log for rets search property media.
                        $LogArray = $this->StoreRetsLog($UserID, $SiteID, Constants::$RETSActionSearchMedia, $objects->URL, '', serialize($result->toArray()), $LogArray, true);

                        $GetFirstImage = Common::GetArrayFilterValues($objects->toArray(), 'PropMediaType', 'Photo');
                        if (count($GetFirstImage) > 0) {
                            $PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing, $UserID, $SiteID, $GetFirstImage[0]['PropMediaURL']);
                            $PropertyModel->ListingModel->UploadedFile[0]->SortOrder = 1;
                            $PropertyModel->ListingModel->UploadedFile[0]->IsSavedInDB = 2;
                        }

                        $MediaArray = array();
                        $this->CustomDeleteEntity(new TempRetsImagesEntity(), 'PropertyListingID', $data->ListingID);
                        foreach ($GetFirstImage as $key => $object) {
                            if ($object['PropMediaType'] == 'Photo' && $object['PropMediaKey'] != $GetFirstImage[0]['PropMediaKey']) {
                                $MediaData = array();
                                $MediaData['PropertyListingID'] = $data->ListingID;
                                $MediaData['UserID'] = $UserID;
                                $MediaData['SiteID'] = $SiteID;
                                $MediaData['ListingKey'] = $data->ListingKey;
                                $MediaData['PropObjectKey'] = $object['PropObjectKey'];
                                $MediaData['PropMediaKey'] = $object['PropMediaKey'];
                                $MediaData['PropMediaURL'] = $object['PropMediaURL'];
                                array_push($MediaArray, $MediaData);
                            }
                        }
                        if (count($MediaArray) > 0) {
                            $PropertyModel->IsShowUploadNote = 1;
                        } else {
                            $PropertyModel->IsShowUploadNote = 0;
                        }
                        $this->MultipleInsert(new TempRetsImagesEntity(), $MediaArray);
                    }
                    $response->Data = $PropertyModel;
                    $response->IsSuccess = true;
                } else {
                    $response->Message = trans('messages.NoRETSPropertyFound');
                }
            } else {
                $response->Message = trans('messages.RETSCredentialsInvalid');
            }
        }
        else if($SiteID == Constants::$ColoradoSiteID) {

            $searchParam = array();
            $searchValues = Common::SetSearchArray('MLSNo', $MlsNo, Constants::$Value_True);
            array_push($searchParam, $searchValues);
            $duplicate = $this->GetEntity(new CoPropertyListingsEntity(), $searchParam);

            if ($duplicate && $duplicate->IsWBProperty==0) {
                $LookupResult = $this->CallRawForMultipleTable('co_propertylookups', array($duplicate->CoListingID,Constants::$ColoradoSiteID,Constants::$Agent_Role_ID, Constants::$UserActive));
                $PropertyModel = new stdClass();

                $PropertyModel->Areas=$LookupResult[0];
                $PropertyModel->Classes=$LookupResult[1];
                $PropertyModel->MajorAreas=$LookupResult[2];
                $PropertyModel->memberAssociations=$LookupResult[3];
                $PropertyModel->Possessions=$LookupResult[4];
                $PropertyModel->StreetSuffixes=$LookupResult[5];
                $PropertyModel->SubLocs=$LookupResult[6];
                $PropertyModel->Agents=$LookupResult[7];
                $PropertyModel->HoaAmenities=$LookupResult[8];
                $PropertyModel->Accesses=$LookupResult[9];
                $PropertyModel->Amenities=$LookupResult[10];
                $PropertyModel->ApprovalFeatures=$LookupResult[11];
                $PropertyModel->BuildingSqFt=$LookupResult[12];
                $PropertyModel->Carports=$LookupResult[13];
                $PropertyModel->Conditions=$LookupResult[14];
                $PropertyModel->ConstructExterior=$LookupResult[15];
                $PropertyModel->Construction=$LookupResult[16];
                $PropertyModel->Coolings=$LookupResult[17];
                $PropertyModel->CurrentUses=$LookupResult[18];
                $PropertyModel->Deeds=$LookupResult[19];
                $PropertyModel->Disclousures=$LookupResult[20];
                $PropertyModel->Electrics=$LookupResult[21];
                $PropertyModel->EnergyEfficiency=$LookupResult[22];
                $PropertyModel->Exclusions=$LookupResult[23];
                $PropertyModel->Exteriors=$LookupResult[24];
                $PropertyModel->Extras=$LookupResult[25];
                $PropertyModel->FirePlaces=$LookupResult[26];
                $PropertyModel->Furnishes=$LookupResult[27];
                $PropertyModel->Garages=$LookupResult[28];
                $PropertyModel->Gases=$LookupResult[29];
                $PropertyModel->GreenFeatures=$LookupResult[30];
                $PropertyModel->HeatingAndCoolings=$LookupResult[31];
                $PropertyModel->Heatings=$LookupResult[32];
                $PropertyModel->SubStructures=$LookupResult[33];
                $PropertyModel->HowSold=$LookupResult[34];
                $PropertyModel->Inclusion=$LookupResult[35];
                $PropertyModel->IndoorAirQuality=$LookupResult[36];
                $PropertyModel->Laundry=$LookupResult[37];
                $PropertyModel->LeedCertified=$LookupResult[38];
                $PropertyModel->LeedForHome=$LookupResult[39];
                $PropertyModel->LocationAmenity=$LookupResult[40];
                $PropertyModel->LotDescription=$LookupResult[41];
                $PropertyModel->LotSize=$LookupResult[42];
                $PropertyModel->LowerLevel=$LookupResult[43];
                $PropertyModel->MainLevel=$LookupResult[44];
                $PropertyModel->OtherCooling=$LookupResult[45];
                $PropertyModel->OwnershipInterest=$LookupResult[46];
                $PropertyModel->ParkingArea=$LookupResult[47];
                $PropertyModel->Parking=$LookupResult[48];
                $PropertyModel->PossibleUse=$LookupResult[49];
                $PropertyModel->PreFabricatedHome=$LookupResult[50];
                $PropertyModel->RentalTerms=$LookupResult[51];
                $PropertyModel->Roofs=$LookupResult[52];
                $PropertyModel->Sanitation=$LookupResult[53];
                $PropertyModel->SeasonalInterest=$LookupResult[54];
                $PropertyModel->State=$LookupResult[55];
                $PropertyModel->Status=$LookupResult[56];
                $PropertyModel->Style=$LookupResult[57];
                $PropertyModel->SubType=$LookupResult[58];
                $PropertyModel->SustainableMaterial=$LookupResult[59];
                $PropertyModel->TermsOffered=$LookupResult[60];
                $PropertyModel->Type=$LookupResult[61];
                $PropertyModel->UnitFace=$LookupResult[62];
                $PropertyModel->Unit=$LookupResult[63];
                $PropertyModel->UnitSqFtRange=$LookupResult[64];
                $PropertyModel->UpperLevel=$LookupResult[65];
                $PropertyModel->WaterEfficiency=$LookupResult[66];
                $PropertyModel->WaterRight=$LookupResult[67];
                $PropertyModel->Water=$LookupResult[68];
                $PropertyModel->LotImprovements=$LookupResult[69];
                $PropertyModel->MineralRights=$LookupResult[70];
                $PropertyModel->ShowingInstructions=$LookupResult[71];
                $PropertyModel->StreetDirectionPfx=$LookupResult[125];


                 $PropertyModel->ListingModel = $LookupResult[72][0];

                if (is_null($PropertyModel->ListingModel->StateID) || $PropertyModel->ListingModel->StateID == '')
                    $PropertyModel->ListingModel->StateID = (($SiteID == Constants::$MercerVineSiteID ? Constants::$DefaultMVStateID : ($SiteID == Constants::$ColoradoSiteID ? Constants::$DefaultColoradoStateID : '')));
                if (is_null($PropertyModel->ListingModel->IsHidden) || $PropertyModel->ListingModel->IsHidden == '')
                    $PropertyModel->ListingModel->IsHidden = 0;

                $PropertyModel->ListingModel->Accesses = array_map(function ($v)  { return $v->AccessID; },$LookupResult[73]);
                $PropertyModel->ListingModel->Amenities = array_map(function ($v)  { return $v->AmenityID; },$LookupResult[74]);
                $PropertyModel->ListingModel->Carports = array_map(function ($v)  { return $v->CarportID; },$LookupResult[75]);
                $PropertyModel->ListingModel->Conditions = array_map(function ($v)  { return $v->ConditionID; },$LookupResult[76]);
                $PropertyModel->ListingModel->ConstructExterior = array_map(function ($v)  { return $v->ConstructExteriorID; },$LookupResult[77]);
                $PropertyModel->ListingModel->Construction = array_map(function ($v)  { return $v->ConstructionID; },$LookupResult[78]);
                $PropertyModel->ListingModel->CurrentUses = array_map(function ($v)  { return $v->CurrentUseID; },$LookupResult[79]);
                $PropertyModel->ListingModel->Deeds = array_map(function ($v)  { return $v->DeedID; },$LookupResult[80]);
                $PropertyModel->ListingModel->Disclousures = array_map(function ($v)  { return $v->DisclosureID; },$LookupResult[81]);
                $PropertyModel->ListingModel->Electrics = array_map(function ($v)  { return $v->ElectricID; },$LookupResult[82]);
                $PropertyModel->ListingModel->EnergyEfficiency = array_map(function ($v)  { return $v->EnergyEfficiencyID; },$LookupResult[83]);
                $PropertyModel->ListingModel->Exclusions = array_map(function ($v)  { return $v->ExclusionID; },$LookupResult[84]);
                $PropertyModel->ListingModel->Exteriors = array_map(function ($v)  { return $v->ExteriorID; },$LookupResult[85]);
                $PropertyModel->ListingModel->Extras = array_map(function ($v)  { return $v->ExtraID; },$LookupResult[86]);
                $PropertyModel->ListingModel->FirePlaces = array_map(function ($v)  { return $v->FireplaceID; },$LookupResult[87]);
                $PropertyModel->ListingModel->Garages = array_map(function ($v)  { return $v->GarageID; },$LookupResult[88]);
                $PropertyModel->ListingModel->Gases = array_map(function ($v)  { return $v->GasID; },$LookupResult[89]);
                $PropertyModel->ListingModel->GreenFeatures = array_map(function ($v)  { return $v->GreenFeatureID; },$LookupResult[90]);
                $PropertyModel->ListingModel->HeatingAndCoolings = array_map(function ($v)  { return $v->HeatingAndCoolingID; },$LookupResult[91]);
                $PropertyModel->ListingModel->Heatings = array_map(function ($v)  { return $v->HeatingID; },$LookupResult[92]);
                $PropertyModel->ListingModel->HoaAmenities = array_map(function ($v)  { return $v->HOAAmenityID; },$LookupResult[93]);
                $PropertyModel->ListingModel->HowSold = array_map(function ($v)  { return $v->HowSoldID; },$LookupResult[94]);
                $PropertyModel->ListingModel->Inclusion = array_map(function ($v)  { return $v->InclusionID; },$LookupResult[95]);
                $PropertyModel->ListingModel->IndoorAirQuality = array_map(function ($v)  { return $v->IndoorAirQualityID; },$LookupResult[96]);
                $PropertyModel->ListingModel->Laundry = array_map(function ($v)  { return $v->LaundryID; },$LookupResult[97]);
                $PropertyModel->ListingModel->LeedCertified = array_map(function ($v)  { return $v->LeedCertifiedID; },$LookupResult[98]);
                $PropertyModel->ListingModel->LeedForHome = array_map(function ($v)  { return $v->LeedforHomeID; },$LookupResult[99]);
                $PropertyModel->ListingModel->LocationAmenity = array_map(function ($v)  { return $v->LocationAmenityID; },$LookupResult[100]);
                $PropertyModel->ListingModel->LotDescription = array_map(function ($v)  { return $v->LotDescriptionID; },$LookupResult[101]);
                $PropertyModel->ListingModel->LotImprovements = array_map(function ($v)  { return $v->LotImprovementID; },$LookupResult[102]);
                $PropertyModel->ListingModel->LowerLevel = array_map(function ($v)  { return $v->LowerLevelID; },$LookupResult[103]);
                $PropertyModel->ListingModel->MainLevel = array_map(function ($v)  { return $v->MainLevelID; },$LookupResult[104]);
                $PropertyModel->ListingModel->MineralRights = array_map(function ($v)  { return $v->MineralRightID; },$LookupResult[105]);
                $PropertyModel->ListingModel->OtherCooling = array_map(function ($v)  { return $v->OtherCoolingID; },$LookupResult[106]);
                $PropertyModel->ListingModel->Parking = array_map(function ($v)  { return $v->ParkingID; },$LookupResult[107]);
                $PropertyModel->ListingModel->ParkingArea = array_map(function ($v)  { return $v->ParkingAreaID; },$LookupResult[108]);
                $PropertyModel->ListingModel->Possessions = array_map(function ($v)  { return $v->PossessionID; },$LookupResult[109]);
                $PropertyModel->ListingModel->PossibleUse = array_map(function ($v)  { return $v->PossibleUseID; },$LookupResult[110]);
                $PropertyModel->ListingModel->Roofs = array_map(function ($v)  { return $v->RoofID; },$LookupResult[111]);
                $PropertyModel->ListingModel->Sanitation = array_map(function ($v)  { return $v->SanitationID; },$LookupResult[112]);
                $PropertyModel->ListingModel->ShowingInstructions = array_map(function ($v)  { return $v->ShowingInstructionID; },$LookupResult[113]);
                $PropertyModel->ListingModel->Style = array_map(function ($v)  { return $v->StyleID; },$LookupResult[114]);
                $PropertyModel->ListingModel->SubStructures = array_map(function ($v)  { return $v->SubstructureID; },$LookupResult[115]);
                $PropertyModel->ListingModel->SustainableMaterial = array_map(function ($v)  { return $v->SustainableMaterialID; },$LookupResult[116]);
                $PropertyModel->ListingModel->TermsOffered = array_map(function ($v)  { return $v->TermsOfferedID; },$LookupResult[117]);
                $PropertyModel->ListingModel->UnitFace = array_map(function ($v)  { return $v->UnitFaceID; },$LookupResult[118]);
                $PropertyModel->ListingModel->UpperLevel = array_map(function ($v)  { return $v->UpperLevelID; },$LookupResult[119]);
                $PropertyModel->ListingModel->WaterEfficiency = array_map(function ($v)  { return $v->WaterEfficiencyID; },$LookupResult[120]);
                $PropertyModel->ListingModel->Water = array_map(function ($v)  { return $v->WaterID; },$LookupResult[121]);
                $PropertyModel->ListingModel->WaterRight = array_map(function ($v)  { return $v->WaterRightID; },$LookupResult[122]);
                $PropertyModel->ListingModel->AllowableUses = array_map(function ($v)  { return $v->AllowableUsesID; },$LookupResult[126]);
                /* get data for edit property */
                /* image*/
                $PropertyModel->ListingModel->UploadedFile = isset($LookupResult[123]) ? $LookupResult[123] : '';

                $PropertyModel->FileUploadSettings = $this->FileUploadSettings(Constants::$AWSRequestType_Listing, $SiteID, $UserID);

                $PropertyModel->IsShowUploadNote = $LookupResult[124][0]->IsShowUploadNote;
                $PropertyModel->ListingModel->IsWBProperty = Constants::$Value_True;

                $response->Data=$PropertyModel;
                $response->IsSuccess=true;
                return $response;
            }
            if($duplicate && $duplicate->IsWBProperty==1) {
                $response->Message = trans('messages.PropertyDuplicate');
                return $response;
            }


            /*if($duplicate) {
                $response->Message = trans('messages.PropertyDuplicate');
                return $response;
            }*/
            /* Login */
            $config->setloginurl(Config::get('config.Aspen_Login_URL'));
            $config->setHttpAuthenticationMethod(Config::get('config.CLAW_Authentication_Method'));
            $config->setOption('use_post_method', false);
            $config->setOption('disable_follow_location', false);

            // get credentials from database settings table. We kept them in db so user can change easily if there is any change.
            $Credentials = $this->GetCLAWCredentials($SiteID);

            $config->setusername(Config::get('config.Aspen_UserName'));
            $config->setpassword(Config::get('config.Aspen_Password'));

            $rets = new \PHRETS\Session($config);
            $login = $rets->Login();

            $ClassAbbreviation=$this->RunQueryStatement("select ClassAbriviation from co_lu_classes where ClassID='".$ClassID."'",Constants::$QueryType_Select);
            if ($login) {
                // Search property with user given listingID(MLS#)
                $resource = 'Property';
                $class = $ClassAbbreviation[0]->ClassAbriviation;
                $query = '(LIST_105=' . $MlsNo . ')'; //LIST_105 = 146308 //LIST_22=1+

                $result = $rets->Search(
                    $resource,
                    $class,
                    $query,
                    [
                        'QueryType' => 'DMQL2',
                        'Count' => 1, // only records
                        'Format' => 'COMPACT-DECODED',
                        'Limit' => 10,
                        'StandardNames' => 0
                    ]
                );

                // Add log for rets search property.
                //$this->StoreRetsLog($UserID, $SiteID, Constants::$RETSActionSearch, Config::get('config.Aspen_Login_URL'), '', $result);
                $data = json_decode($result->toJSON());
                if ($data) {
                    $PropertyModel = new stdClass();
                    // map value with database
                    $PropertyModel->ListingModel=$this->getColoradoPropertyFormatted($data[0],$ClassID);
                    $PropertyModel->ListingModel->fetchImage=$fetchImage;
                    if($fetchImage==true) {
                        if ($data[0]->LIST_133 > 0) { //check for
                            $objects = $rets->GetObject(
                                'Property',
                                '640x480', //Photo,HiRes
                                $PropertyModel->ListingModel->ListingKey,
                                '*', '1'
                            );
                            $checkArrayValue = $objects->toArray();
                            if (count($checkArrayValue) > 0) {
                                $MediaArray = array();
                                $this->CustomDeleteEntity(new CoTempRetsImagesEntity(), 'PropertyListingID', $data[0]->LIST_105);
                                foreach ($objects->toArray() as $key => $object) {
                                    if ($object->getObjectId() == '1') {
                                        $PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing, $UserID, $SiteID, $object->getLocation());
                                        $PropertyModel->ListingModel->UploadedFile[0]->SortOrder = 1;
                                        $PropertyModel->ListingModel->UploadedFile[0]->IsSavedInDB = 2;
                                    }
                                    if ($object->getObjectId() != '1') {
                                        $MediaData = array();
                                        $MediaData['PropertyListingID'] = $data[0]->LIST_105;
                                        $MediaData['UserID'] = $UserID;
                                        $MediaData['SiteID'] = $SiteID;
                                        $MediaData['ListingKey'] = $PropertyModel->ListingModel->ListingKey;
                                        $MediaData['PropObjectKey'] = $object->getObjectId();
                                        $MediaData['PropMediaKey'] = $object->getContentId();
                                        $MediaData['PropMediaURL'] = $object->getLocation();
                                        array_push($MediaArray, $MediaData);
                                    }
                                }
                                if (count($MediaArray) > 0) {
                                    $PropertyModel->IsShowUploadNote = 1;
                                } else {
                                    $PropertyModel->IsShowUploadNote = 0;
                                }
                                $this->MultipleInsert(new CoTempRetsImagesEntity(), $MediaArray);
                            }
                        }
                    }
                    $response->Data = $PropertyModel;
                    $response->IsSuccess = true;
                } else {
                    $response->Message = trans('messages.NoRETSPropertyFound');
                }
            } else {
                $response->Message = trans('messages.RETSCredentialsInvalid');
            }
        }
        else {
            $response->Message = trans('messages.InvalidSite');
        }
        return $response;
    }

    // This method stores rets request logs.
    public function StoreRetsLog($UserID, $SiteID, $Action, $URL, $Request = '', $Response,$LogArray=array(),$last=true)
    {
        if(Config::get('config.Add_RETS_Log')) {
            $LogData = array();
            $LogData['UserID'] = $UserID;
            $LogData['SiteID'] = $SiteID;
            $LogData['Action'] = $Action;
            $LogData['ActionDateTime'] = date(Constants::$DefaultDateTimeFormat);
            $LogData['ActionURL'] = $URL;
            $LogData['RequestData'] = $Request;
            $LogData['ResponseData'] = $Response;
            array_push($LogArray, $LogData);
            if($last) {
                $entity = new RetsLogsEntity();
                if(count($LogArray)>0)
                    $this->MultipleInsert($entity, $LogArray);
                $LogArray=array();
                }
                        }
        return $LogArray;
                    }

    // This method gets rets crendetial details from settings table
    public function GetCLAWCredentials($SiteID)
    {
        $SearchParam = array();
        $SearchValue = Common::SetSearchArray(Constants::$QueryStringSiteID, $SiteID);
        array_push($SearchParam, $SearchValue);
        $credentials = $this->GetEntity(new SitesEntity(), $SearchParam);
        return $credentials;
    }

    //This method maps RETS data with database details to get respected ID csv details.
    public function GetPropertyFeatureDetails($agentRoleID, $Features)
    {
        array_unshift($Features, $agentRoleID);
        $FeatureData = $this->CallRawForMultipleTable('propertyfeaturedetails', array_values($Features));
        return $FeatureData;
    }

    //Delete Property image from aws and also from db in edit mode.
    public function DeletePropertyImage($fileRemoveData,$siteID){
        $response = new ServiceResponse();
        if (isset($fileRemoveData)) {
            $data = $this->Awsdeletefile($fileRemoveData->FilePath,$siteID);  // Remove Image from AWS
            if ($data && isset($fileRemoveData->ImageID) && $siteID==Constants::$MercerVineSiteID) {  // Delete images from database if ImageID found during edit page.
                $this->DeleteEntity(new PropertyListingImagesEntity(), $fileRemoveData->ImageID);
            }
            if($data && isset($fileRemoveData->ImageID) && $siteID==Constants::$ColoradoSiteID) {
                $this->DeleteEntity(new CoPropertyListingImagesEntity(), $fileRemoveData->ImageID);
            }
            $response->IsSuccess = true;
            $response->Message = trans('messages.ImageRemovedSuccess');
        } else {
            $response->Message = trans('messages.ErrorOccured');
        }
        return $response;
    }

    // Add/Update Property
    public function SaveProperty($propModel, $siteID, $loggedInUserID,$isFromCMS=0)
    {
        $dateTime = date(Constants::$DefaultDateTimeFormat);
        $response = new ServiceResponse();
        $messages = array(
            'required' => trans('messages.PropertyRequired'),
            'min' => trans('messages.PropertyMin'),
            'max' => trans('messages.PropertyMax'),
        );
        $isEditMode = false;
        if ($propModel->ListingID > 0) {
            $isEditMode = true;
        }
        $entity = new PropertyListingsEntity();

        // Server Validation
        if((property_exists($propModel,'IsWBProperty') && $propModel->IsWBProperty ==0) || (property_exists($propModel,'isCron') && $propModel->isCron==1)) {
            // to skip server side validation for cron mls property
           // unset($propModel->isCron);
        }
        else {
            $propModel->isCron = 0;
            $validator = Validator::make((array)$propModel, $isEditMode == true ? PropertyListingsEntity::$Edit_rules : PropertyListingsEntity::$Add_rules, $messages);
            $validator->setAttributeNames(PropertyListingsEntity::$niceNameArray);
            if ($validator->fails()) {
                $response->Message = Common::getValidationMessagesFormat($validator->messages());
                return $response;
            }
        }
        //Get keywordIDs from Keywords whole object array.
        $KeywordIDs = array();
        if (property_exists($propModel, 'Keywords')) {
            if (!is_null($propModel->Keywords)) {
                $KeywordIDs = array_map(function ($a) {
                    if (array_key_exists('KeywordID', $a))
                        return $a['KeywordID'];
                }, $propModel->Keywords);
            }

        }
        $propModel->Keywords = $KeywordIDs;
        // set session siteID
        $propModel->SiteID = $siteID;
        // Create whole property model with either user selected array or null value.
        $propModel = $this->SetEntityAttributes($entity, $propModel, true);

        $agent=isset($propModel['ListAgentName']) ? $propModel['ListAgentName']: '';
        $broker=isset($propModel['ListOfficeName']) ? $propModel['ListOfficeName']: '';

        unset($propModel['ListAgentName']);
        unset($propModel['ListOfficeName']);
        unset($propModel['MLSAgentName']);
        unset($propModel['MLSBrokerName']);
        unset($propModel['FeaturedDate']);
        if(array_key_exists('IsWBProperty',$propModel)){
             if($propModel['IsWBProperty']==null && $propModel['IsWBProperty']!==0) {
                $propModel['IsWBProperty'] = 1;
             }
             else if ($propModel['IsWBProperty']==1){
                 $propModel['IsWBProperty'] = 1;
             }
            else {
                $propModel['IsWBProperty'] = 0;
            }
        }
        else {
            $propModel['IsWBProperty'] = 1;
        }
        if($propModel['IsWBProperty']==1){
            $propModel['isCron'] = 0;
        }
        if(!isset($propModel['isCron'])){
            if($isEditMode){
                $propModel['IsWBProperty']=1;
            }
            if($propModel['IsWBProperty']==0)
                $propModel['isCron'] = 1;
            else
                $propModel['isCron'] = 0;
        }
        $stateName1='';
        $StateISO='';
        $SearchParam = array();
        if($propModel['StateID']!='') {
            $SearchValue = Common::SetSearchArray('StateID', $propModel['StateID']);
            array_push($SearchParam, $SearchValue);
            $stateName = $this->GetEntity(new \StateEntity(), $SearchParam);
            if(count($stateName)>0) {
                $stateName1 = $stateName->StateName;
                $StateISO = $stateName->StateISO;
            }
        }
        $propModel['FullAddress1'] = $propModel['Street'].",".$propModel['City'].','.$stateName1.",".$propModel['ZipCode'];
        $propModel['FullAddress2'] = $propModel['Street'].",".$propModel['City'].','.$stateName1;
        $slugAddress = $propModel['Street']."-".$propModel['City'].'-'.$StateISO."-".$propModel['ZipCode'];
        $propModel['FullAddressSlug'] = Common::GetFullAddressSlug($slugAddress);

        if(empty($propModel['Latitude']) && empty($propModel['Longitude'])){
            $address = str_replace(' ', '',trim($propModel['Street']));
            if(isset($stateName1)){
                $sateName = str_replace(' ','',$stateName1);
            }else{
                $sateName='';
            }
            if(!empty($propModel['City'])){
                $city = str_replace(' ','',trim($propModel['City']));
            }else{
                $city='';
            }
            if(!empty($propModel['ZipCode'])){
                $zip = str_replace(' ','',trim($propModel['ZipCode']));
            }else{
                $zip='';
            }
            $data = DB::table('sites')->where('SiteID','=',1)->select('GeoAPIKey')->get();
            $geoAPIKey = $data[0]->GeoAPIKey;
            $latLong = Common::getLatLong($address.','.$city.','.$sateName.'-'.$zip, $geoAPIKey);
            if(isset($latLong->Latitude))
                $propModel['Latitude'] = $latLong->Latitude;
            if(isset($latLong->Longitude))
                $propModel['Longitude'] = $latLong->Longitude;
        }

        unset($propModel['SoldDate']);
        // we don't need to pass this parameters in save property sp so unset them.

        if(array_key_exists('ImagesNameModel',$propModel)) {
            if (is_array($propModel['ImagesNameModel'])) {
                $keys = array_flip($propModel['ImagesNameModel']);
            } else {
                $keys = $propModel['ImagesNameModel'];
            }
        }

        if(array_key_exists('ImagesModel',$propModel) && is_array($propModel['ImagesModel'])) {
            usort($propModel['ImagesModel'], function ($a, $b) use ($keys) {
                return $keys[@array_pop(explode("/", $a['FilePath']))] - $keys[@array_pop(explode("/", $b['FilePath']))];
            });
        }

        /* For Set Proper Oder In Property Feature*/
        if(array_key_exists('PropertyImagesNameModel',$propModel)) {
            if (isset($propModel['PropertyImagesNameModel'])) {
                if (is_array($propModel['PropertyImagesNameModel'])) {
                    $key = array_flip($propModel['PropertyImagesNameModel']);
                } else {
                    $key = $propModel['PropertyImagesNameModel'];
                }
            }
        }

        if(array_key_exists('ImagesModelOfPropertyFeatures',$propModel)) {
            if (isset($propModel['ImagesModelOfPropertyFeatures'])) {
                usort($propModel['ImagesModelOfPropertyFeatures'], function ($c, $d) use ($key) {
                    return $key[@array_pop(explode("/", $c['FilePath']))] - $key[@array_pop(explode("/", $d['FilePath']))];
                });
            }
        }

        /* check ListAgentName and ListOfficeName is Exist or Not */
        $propModel['ListOfficeName']=$broker;
        $propModel['ListAgentName']=$agent;

        /* end check ListAgentName and ListOfficeName is Exist or Not */
        if($propModel['isCron']==0) {
            if ($propModel['DevelopmentID'] != '') {
                CacheHelper::CacheManage($siteID, Constants::$cacheDevelopmentID, Constants::$cacheActionUpdate, $propModel['DevelopmentID']);
            }
            if ($isEditMode) {
                if (array_key_exists('oldDevelopmentID', $propModel)) {
                    if ($propModel['oldDevelopmentID'] != $propModel['DevelopmentID'] && $propModel['oldDevelopmentID'] != '') {
                        CacheHelper::CacheManage($siteID, Constants::$cacheDevelopmentID, Constants::$cacheActionUpdate, $propModel['oldDevelopmentID']);
                    }
                }
            }
        }

        $uploadImages = $propModel['ImagesModel'];
        $uploadImagesOfPropertyFeatures = isset($propModel['ImagesModelOfPropertyFeatures']) ? $propModel['ImagesModelOfPropertyFeatures'] : '';
        if(array_key_exists('oldDevelopmentID',$propModel)) {
            unset($propModel['oldDevelopmentID']);
        }
        unset($propModel['PropertyImagesNameModel']);
        unset($propModel['RestsImageURL']);
        unset($propModel['ImagesModel']);
        unset($propModel['ImagesModelOfPropertyFeatures']);
        unset($propModel['ImagesNameModel']);
        unset($propModel['FilePath']);
        unset($propModel['UploadedFile']);
        unset($propModel['KeywordIDs']);
        unset($propModel['IsFeatured']);
        unset($propModel['ModifiedByID']);
        unset($propModel['CreatedByID']);
        unset($propModel['ModifiedDate']);
        unset($propModel['CreatedDate']);
        unset($propModel['IsDisabledUser']);
        unset($propModel['ViewedCount']);
        unset($propModel['IsShowUploadNote']);
        unset($propModel['fetchImage']);
      //  unset($propModel['isCron']);
        //Generated csv with "." seperated for multiselect values.

        $array = array_values(array_map(function ($a) {
            return implode(".", (array)$a);
        }, (array)$propModel));

        //added logged in user id for created by value.
        array_push($array, $loggedInUserID);

        //Added to track if property added/updated from CMS or not
        array_push($array, $isFromCMS);
        
        $result = $this->CallRawForSingleTable('SaveProperty', $array);
        /* Caching call  */
        if(isset($array[0]) && !empty($array[0]) && $array[0] > 0 ){
            CacheHelper::CacheManage($siteID,Constants::$cachePropertyID,Constants::$cacheActionUpdate,$array[0]);
        }else{
            if(isset($result[0]->ListingID) && !empty($result[0]->ListingID) && $result[0]->ListingID > 0 ) {
                CacheHelper::CacheManage($siteID, Constants::$cachePropertyID, Constants::$cacheActionInsert, $result[0]->ListingID);
            }
        }
        if ($result[0]->ResultStatus == 1) {
            //Duplicate
            $response->Message = trans('messages.PropertyDuplicate');
        }
        else if ($result[0]->ResultStatus == 2) {

            if (!$isEditMode) {
                $propModel['ListingID'] = $result[0]->ListingID;
            }

            //Upload images
            $data = array();
            if (is_array($uploadImages)) {
                foreach ($uploadImages as $key => $imageData) {

                    if (!is_null($imageData['FileName'])) {
                        $processData = array(
                            'ListingID' => $propModel['ListingID'],
                            'SiteID' => $siteID,
                            'FileName' => $imageData['FileName'],
                            'FilePath' => $imageData['FilePath'],
                            'FileSize' => $imageData['FileSize'],
                            'SortOrder' => $key + 1,
                            'CreatedDate' => $dateTime,
                            'ModifiedDate' => $dateTime,
                            'CreatedByID' => $loggedInUserID,
                            'ModifiedByID' => $loggedInUserID,
                            'IsResize'=>(($imageData['IsSavedInDB']!=1 && $propModel['isCron']!=1)?Constants::$Value_True:Constants::$Value_False),
                        );
                        if ($imageData['IsSavedInDB'] != 1)
                            array_push($data, $processData);
                        else
                            $this->CustomUpdateEntity(new PropertyListingImagesEntity(), 'ImageID', $imageData['ImageID'], $processData);
                    }
                }
                if (count($data))
                    $this->MultipleInsert(new PropertyListingImagesEntity(), $data);
            }

            /* For Property Intervention Start*/
                $interventionData = array();
            // if ($propModel['IsWBProperty'] == 1 && is_array($uploadImages) && $siteID==Constants::$MercerVineSiteID) { changed as cron job images first image was not being uploading
            if($propModel['IsWBProperty']==1) {
                $imagePriority = Constants::$Value_True;
                if($isEditMode)
                    $action = Constants::$cacheActionUpdate;
                else
                    $action=Constants::$cacheActionInsert;
                CacheHelper::CacheManage($siteID,Constants::$cachePropertyID,$action,$array[0],'',$propModel['IsWBProperty']);
            }
            else
                $imagePriority=2;

                if (is_array($uploadImages) && $siteID==Constants::$MercerVineSiteID) {
                    //if ($propModel['IsWBProperty'] == 1) { commented for image upload upload thumb at the same time
                        foreach ($uploadImages as $key => $imageData) {
                            if ($key + 1 <= 5 && (!isset($imageData['isIntervention']) or $imageData['isIntervention'] == 0)) {
                                if (!is_null($imageData['FileName'])) {
                                    $processData = array(
                                        'ListingID' => $propModel['ListingID'],
                                        'ImageURL' => $imageData['FilePath'],
                                        'SiteID' => Constants::$MercerVineSiteID,
                                        'IsWBProperty' => $propModel['IsWBProperty'],//Constants::$isWoodBridge
                                        'ImagePriority' => $imagePriority,
                                        'IsResize'=>(($imageData['IsSavedInDB']!=1 && $propModel['isCron']!=1)?Constants::$Value_True:Constants::$Value_False)
                                    );
                                    array_push($interventionData, $processData);
                                }
                            }
                        }
                        if (count($interventionData))
                            $this->MultipleInsert(new PropertyImagesInterventionEntity(), $interventionData);
                    /*} else {
                        $imageDimensionArray = Common::getImageInterventionDimensionArray(Constants::$MercerVineSiteID, $propModel['IsWBProperty']);
                        if ($imageDimensionArray) {
                            $count=0;
                            $dimensionCount=0;
                            foreach ($imageDimensionArray as $dimension) {
                                $count++;
                                $dimensionCount=$dimensionCount+1;
                                $fullImagePath = Config::get('aws.AWSUrl') . Config::get('aws.AWSBucketName') . '/' .$imageData['FilePath'];
                                try {
                                    Common::ImageIntervention($fullImagePath, $dimension, '', 0);
                                } catch(Exception $e){
                                    if($dimensionCount==count($imageDimensionArray)) {
                                        $addToIntervention = new PropertyImagesInterventionEntity();
                                        $addToIntervention->ListingID = $result[0]->ListingID;
                                        $addToIntervention->ImageURL = $imageData['FilePath'];
                                        $addToIntervention->SiteID = Constants::$MercerVineSiteID;
                                        $addToIntervention->IsWBProperty = $propModel['IsWBProperty'];
                                        $this->SaveEntity($addToIntervention);
                                    }
                                }
                            }
                        }
                    }*/
                }
            /* For Property  Intervention End */


            /* For Property Features */
            $data1 = array();
            if (is_array($uploadImagesOfPropertyFeatures)) {
                foreach ($uploadImagesOfPropertyFeatures as $key => $imageData) {
                    if (!is_null($imageData['FileName'])) {
                        $processData1 = array(
                            'ListingID' => $propModel['ListingID'],
                            'SiteID' => $siteID,
                            'FileName' => $imageData['FileName'],
                            'FilePath' => $imageData['FilePath'],
                            'FileSize' => $imageData['FileSize'],
                            'Title' => $imageData['Title'],
                            'Description' => $imageData['Description'],
                            'CreatedDate' => $dateTime,
                            'ModifiedDate' => $dateTime,
                            'CreatedByID' => $loggedInUserID,
                            'ModifiedByID' => $loggedInUserID,
                        );
                        if ($imageData['IsSavedInDB'] != 1)
                            array_push($data1, $processData1);
                        else
                            $this->CustomUpdateEntity(new PropertyFeaturesEntity(), 'ID', $imageData['ID'], $processData1);
                    }
                }
                if (count($data1))
                    $this->MultipleInsert(new PropertyFeaturesEntity(), $data1);
            }

            $response->RedirectUrl = URL::to('/') . "/listing/" . Common::getEncryptedValue(Constants::$QueryStringSiteID . '=' . $siteID);
            if ($isEditMode) {
                $response->IsSuccess = true;
                $response->Message = trans('messages.PropertyUpdateSuccess');
            } else {
                $response->IsSuccess = true;
                $response->Message = trans('messages.PropertyAddedSuccess');
            }
        } else {
            $response->Message = trans('messages.ErrorOccured');
        }
        return $response;
    }

    public function DeleteProperty($ListingID, $siteID)
    {
        $response = new ServiceResponse();
        $rResponse='';
        if($siteID==Constants::$MercerVineSiteID) {
            $rResponse = $this->CallRawForMultipleTable('deleteproperty', array($ListingID, $siteID)); }
        if($siteID==Constants::$ColoradoSiteID) {
            $rResponse = $this->CallRawForMultipleTable('co_deleteproperty', array($ListingID, $siteID)); }
        if ($rResponse) {
            if($rResponse[0][0]->result == 1) {
                if(isset($ListingID) && !empty($ListingID) && $ListingID > 0 && $siteID==Constants::$MercerVineSiteID){
                    CacheHelper::CacheManage($siteID,Constants::$cachePropertyID,Constants::$cacheActionDelete,$ListingID,'',$rResponse[0][0]->IsWBProperty);
                    CacheHelper::CacheManage($siteID,Constants::$cacheDevelopmentID,Constants::$cacheActionUpdate,$rResponse[0][0]->DevelopmentID);
                }
                if($siteID==Constants::$ColoradoSiteID){
                    CacheHelper::CacheManage($siteID,Constants::$cachePropertyID,Constants::$cacheActionDelete,$ListingID);
                }
            $response->IsSuccess = true;
            $response->RedirectUrl = URL::to('/') . "/listing/" . Common::getEncryptedValue(Constants::$QueryStringSiteID . '=' . $siteID);
            $response->Message = trans('messages.PropertyDeleted');
            }
            else{
                $response->Message = trans('messages.PropertyWithMlsNo');
            }
        } else {
            $response->Message = trans('messages.ErrorOccurred');
        }
        return $response;
    }

    public function DeletePropertyImages(){
        $response = new ServiceResponse();
        try {
            if (Common::SetCronJobRunning(Constants::$PropertyImageDeleteCronJobField)) {
                try {
                    $imageCount = Config::get('config.ImageDeleteBulkCount');
                    $images = $this->GetEntityWithPaging(new DeletePropertyListingImagesEntity(),array(),Constants::$Value_True,$imageCount);
                    foreach($images->Items as $image)
                    {
                        $data = $this->Awsdeletefile($image->FilePath,$image->SiteID);  // Remove Image from AWS
                        if ($data && isset($image->ImageID)) {  // Delete images from database if ImageID found during edit page.
                            $this->DeleteEntity(new DeletePropertyListingImagesEntity(), $image->ImageID);
                        } else {
                            Log::info(' could not connect to AWS :' . date('Y-m-d H:i:s'));
                        }
                    }
                }catch (Exception $e) {
                    Log::info(' Property image delete cron :' . date('Y-m-d H:i:s'));
                    Log::error($e);
                    Common::UnsetCronJobRunning(Constants::$PropertyImageDeleteCronJobField);
                }
                $response->IsSuccess = true;
                Common::UnsetCronJobRunning(Constants::$PropertyImageDeleteCronJobField);
            }
        } catch (Exception $e) {
            Log::info(' Property image delete cron :' . date('Y-m-d H:i:s'));
            Log::error($e);
            Common::UnsetCronJobRunning(Constants::$PropertyImageDeleteCronJobField);
        }
        return $response;
    }
    /* Dev_AYS Region End */

    /* Dev_RB Region Start */
    public function getImageCron($offset, $field)
    {
        $response = new ServiceResponse();
        try { //'IsPropertyImageCronJobRunning'
            if (Common::SetCronJobRunning($field)) {
                try {
                    $dateTime = date(Constants::$DefaultDateTimeFormat);
                    /* get temporary image from temporary table*/
                    $imageCount = Config::get('config.NumberOfPropertyImage');
                    $getImagesForUpload = $this->CallRawForSingleTable('propertyimagecron', [$offset,$imageCount]);
                    foreach ($getImagesForUpload as $imageInfo) {
                        /* AWS upload */
                           try {
                               $awsImageUpload = $this->FileUpload(Constants::$AWSRequestType_Listing, $imageInfo->UserID, $imageInfo->SiteID, $imageInfo->PropMediaURL);
                               if (($imageInfo->SortOrder <= $imageInfo->noOfListing)) {
                                   $addToIntervention = new PropertyImagesInterventionEntity();
                                   $addToIntervention->ListingID = $imageInfo->ListingID;
                                   $addToIntervention->ImageURL = $awsImageUpload->FilePath;
                                   $addToIntervention->SiteID = $imageInfo->SiteID;
                                   $addToIntervention->IsWBProperty = $imageInfo->IsWBProperty;
                                   $addToIntervention->IsResize=$imageInfo->IsResize;
                                   $this->SaveEntity($addToIntervention);
                               }
                           }
                           catch(Exception $e){
                               $updateUploadAttempt=$this->GetEntityForUpdateByPrimaryKey(new TempRetsImagesEntity(),$imageInfo->TempID);
                               if($updateUploadAttempt->ImageUploadAttempt<Constants::$maxImageUploadAttempt) {
                                   $updateUploadAttempt->ImageUploadAttempt = $updateUploadAttempt->ImageUploadAttempt + 1;
                                   $this->SaveEntity($updateUploadAttempt);
                               }
                           }
                        if(isset($awsImageUpload)) {
                            /* save data to property image */
                            $singlePropertyImage = new PropertyListingImagesEntity();
                            $singlePropertyImage->ListingID = $imageInfo->ListingID;
                            $singlePropertyImage->SiteID = $imageInfo->SiteID;
                            $singlePropertyImage->FileName = $awsImageUpload->FileName;
                            $singlePropertyImage->FilePath = $awsImageUpload->FilePath;
                            $singlePropertyImage->CreatedDate = $dateTime;
                            $singlePropertyImage->ModifiedDate = $dateTime;
                            $singlePropertyImage->CreatedByID = $imageInfo->UserID != 0 ? $imageInfo->UserID : NULL;
                            $singlePropertyImage->ModifiedByID = $imageInfo->UserID != 0 ? $imageInfo->UserID : NULL;
                            $singlePropertyImage->SortOrder = $imageInfo->SortOrder;
                            $singlePropertyImage->Filesize = $awsImageUpload->FileSize;
                            $storePropertyImage = $this->SaveEntity($singlePropertyImage);
                            if ($storePropertyImage) {
                                /* on success delete from temporary table */
                                $this->CustomDeleteEntity(new TempRetsImagesEntity(), 'TempID', $imageInfo->TempID);
                                $response->IsSuccess = true;
                            } else {
                                $response->IsSuccess = false;
                                Log::info(' could not connect to AWS :' . date('Y-m-d H:i:s'));
                            }
                        }
                    }
                } catch (Exception $e) {
                    Log::info(' Property image cron :' . date('Y-m-d H:i:s'));
                    Log::error($e);
                }
                Common::UnsetCronJobRunning($field);
            }
        } catch (Exception $e) {
            Log::info(' Property image cron :' . date('Y-m-d H:i:s'));
            Log::error($e);
            Common::UnsetCronJobRunning($field);
        }
        return $response;
    }

    public function RemovePropertyFeaturesFiles($fileRemoveData,$siteID)
    {
        $response = new ServiceResponse();
        $deleteModel = new StdClass();
        if (isset($fileRemoveData)) {
            $data = $this->Awsdeletefile($fileRemoveData->filePath,$siteID);  // Remove Image from AWS
            if ($data && isset($fileRemoveData->ImageID)) {  // Delete images from database if ImageID found during edit page.
                $query = "delete from propertyfeatures where ID = $fileRemoveData->ImageID";
                $this->RunQueryStatement($query, Constants::$QueryType_Delete);
            }
            $response->IsSuccess = true;
            $deleteModel->Key = $fileRemoveData->fileToRemoveKey;  //send the removed array KEY.
            $response->Data = $deleteModel;
            $response->Message = trans('messages.ImageRemovedSuccess');
        } else {
            $response->Message = trans('messages.ErrorOccured');
        }
        return $response;
    }

    public function getPropertyImagesInterventionCron(){
        $response = new ServiceResponse();
        try {
            if (Common::SetCronJobRunning(Constants::$isPropertyImagesInterventionCronRunningField)) {
                try {
                    $imageCount = Config::get('config.NumberOfPropertyImagesIntervention');
                    $imagesInterventionData = $this->CallRawForSingleTable('propertyimagesinterventioncron', [$imageCount]);

                    if(!empty($imagesInterventionData)){
                        $counter=0;
                        foreach ($imagesInterventionData as $imageInfo) {
                            $imageDimensionArray = Common::getImageInterventionDimensionArray(Constants::$MercerVineSiteID, $imageInfo->IsWBProperty,$imageInfo->IsResize);
                            if($counter+count($imageDimensionArray) > $imageCount) {
                                Common::UnsetCronJobRunning(Constants::$isPropertyImagesInterventionCronRunningField);
                                break;
                            }else {
                                if ($imageDimensionArray) {
                                    $count = 0;
                                    foreach ($imageDimensionArray as $dimension) {
                                        $count++;
                                        $counter++;
                                        $fullImagePath = Common::getAWSUrl(Constants::$MercerVineSiteID) . Common::getAWSBucketName(Constants::$MercerVineSiteID) . '/' . $imageInfo->ImageURL;
                                        try {
                                            Common::ImageIntervention($fullImagePath, $dimension, '', 0);

                                        } catch (Exception $e) {
                                            $updateCropAttempt = $this->GetEntityForUpdateByPrimaryKey(new PropertyImagesInterventionEntity(), $imageInfo->ID);
                                            if ($updateCropAttempt->CropAttempt < Constants::$maxImageUploadAttempt && $count == count($imageDimensionArray)) {
                                                $updateCropAttempt->CropAttempt = $updateCropAttempt->CropAttempt + 1;
                                                $this->SaveEntity($updateCropAttempt);
                                                if ($updateCropAttempt->CropAttempt == Constants::$maxImageUploadAttempt) {
                                                    $addToUploadImage = new ImageUploadErrorEntity();
                                                    $addToUploadImage->ListingID = $imageInfo->ListingID;
                                                    $addToUploadImage->ImagePath = Common::getAWSUrl(Constants::$MercerVineSiteID) . Common::getAWSBucketName(Constants::$MercerVineSiteID) . '/' . $imageInfo->ImageURL;
                                                    $addToUploadImage->Errortype = 2;
                                                    $addToUploadImage->AddedDateTime = date(Constants::$DefaultDateTimeFormat);
                                                    $this->SaveEntity($addToUploadImage);
                                                }
                                            }
                                        }
                                    }
                                    $this->CallRawForSingleTable('deletepropertyimagesintervention', [$imageInfo->ID]);
                                }
                            }
                        }
                    $response->IsSuccess=true;
                    }
                } catch (Exception $e) {
                    Log::info(' Property Images Intervention cron :' . date('Y-m-d H:i:s'));
                    Log::error($e);
                }
                Common::UnsetCronJobRunning(Constants::$isPropertyImagesInterventionCronRunningField);
            }
        } catch (Exception $e) {
            Log::info(' Property Images Intervention cron :' . date('Y-m-d H:i:s'));
            Log::error($e);
            Common::UnsetCronJobRunning(Constants::$isPropertyImagesInterventionCronRunningField);
        }
        return $response;
    }
    /*Dev_RB Region End */

    public function addPropertiesFromMLSDb()
    {
        $response = new ServiceResponse();
        $config = new \PHRETS\Configuration;

        //CLAW (Mercer Vine)
            $settingEntity = $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(), '1');
            $isCronJobRunning = $settingEntity->IsMLSPropertyCronRunning;
            if (!$isCronJobRunning) {
                try {
                    $settingEntity->IsMLSPropertyCronRunning = true;
                    $nextPage = $settingEntity->MLSPropertyCounter;
                    $this->SaveEntity($settingEntity);
                    /* Login */
                    $config->setloginurl(Config::get('config.CLAW_Login_URL'));
                    $config->setRetsVersion(Config::get('config.CLAW_RETS_Version'));
                    $config->setUserAgent(Config::get('config.CLAW_UserAgent'));
                    $config->setHttpAuthenticationMethod(Config::get('config.CLAW_Authentication_Method'));
                    $config->setOption('use_post_method', false);
                    $config->setOption('disable_follow_location', false);

                    // get credentials from database settings table. We kept them in db so user can change easily if there is any change.
                    $Credentials = $this->GetCLAWCredentials(Constants::$MercerVineSiteID);
                    $config->setusername($Credentials->RETSUserName);
                    $config->setpassword($Credentials->RETSPassword);
                    $rets = new \PHRETS\Session($config);
                    $login = $rets->Login();
                    $LogArray = array();
                    $LogArray = $this->StoreRetsLog(Constants::$Value_False, Constants::$MercerVineSiteID, Constants::$RETSActionLogin, Config::get('config.CLAW_Login_URL'), '', $login, $LogArray, false);
                    $resource = 'Property';
                    $class = 'ALL';
                    $statusField = Common::getPropertyStatusField(Constants::$MercerVineSiteID);
                    $query = '(ListPrice=10000000000000-),(' . $statusField . '=|' . Constants::$ActiveListingStatus . ',' . Constants::$PendingListingStatus . ',' . Constants::$ClosedListingStatus . ',' . Constants::$ActiveContractStatus . ')'; // ,~(City=.EMPTY.)';
                    $result = $rets->Search(
                        $resource,
                        $class,
                        $query,
                        [
                            'QueryType' => 'DMQL2',
                            'Count' => 1, // only records
                            'Format' => 'COMPACT-DECODED',
                            'Limit' => Config::get('config.NumberOfPropertiesToGet'),// Constants::$NumberOfPropertiesToGet,
                            'Offset' => $nextPage,
                            'StandardNames' => 0, // give system names
                        ]
                    );
                    $LogArray = $this->StoreRetsLog(Constants::$Value_False, Constants::$MercerVineSiteID, Constants::$RETSActionSearch, $result->URL, '', serialize($result->toArray()), $LogArray, false);
                    $Alldata = json_decode($result->toJSON());
                    $responseArray = [];
                    foreach ($Alldata as $propertySingle) {
                        $searchParam = array();
                        $searchValues = Common::SetSearchArray('MLSNo', $propertySingle->ListingID, Constants::$Value_True);
                        array_push($searchParam, $searchValues);

                        $duplicate = $this->GetEntity(new PropertyListingsEntity(), $searchParam);

                        if ($duplicate) {
                            $responseArray[] = trans('messages.PropertyDuplicate');
                            continue;
                        }

                        $PropertyModel = new stdClass();
                        $IsWBProperty = Constants::$Value_False;
                        $statusField = Common::getPropertyStatusField(Constants::$MercerVineSiteID);
                        $CheckForIsWB = Common::getPropertyOfficeID($propertySingle->ListOfficeId, Constants::$MercerVineSiteID);
                        if ($CheckForIsWB) {
                            $IsWBProperty = Constants::$Value_True;
                        }
                        else {
                            if ($propertySingle->{$statusField} == 'Closed') {
                                continue;
                            }
                        }
                        $PropertyModel->ListingModel = $this->getPropertiesFormated($propertySingle, $IsWBProperty, Constants::$MercerVineSiteID);
                        $PropertyModel->ListingModel->isCron = Constants::$Value_True;
                        if ($login) {
                            //Get Object/Image data
                            $objects = $rets->Search(
                                'Media',
                                'PROP_MEDIA',
                                '(PropObjectKey=' . $propertySingle->ListingKey . ')',
                                [
                                    'QueryType' => 'DMQL2',
                                    'Count' => 0,
                                    'Format' => 'COMPACT-DECODED',
                                    'StandardNames' => 0, // give system names
                                ]
                            );
                            $LogArray = $this->StoreRetsLog(Constants::$StaticUserID, Constants::$MercerVineSiteID, Constants::$RETSActionSearchMedia, $objects->URL, '', serialize($objects->toArray()), $LogArray, true);
                            // Add log for rets search property media.
                            $GetFirstImage = Common::GetArrayFilterValues($objects->toArray(), 'PropMediaType', 'Photo');
                            if (Constants::$skipFirstImageUpload == 0) {
                                if (count($GetFirstImage) > 0) {
                                    $ignoreImg = 0;
                                    //$PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing, Constants::$StaticUserID, Constants::$MercerVineSiteID, $GetFirstImage[0]['PropMediaURL']);
                                    try {
                                        $PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing,Constants::$Value_False, Constants::$MercerVineSiteID, $GetFirstImage[0]['PropMediaURL']);
                                    } catch (Exception $e) {
                                        Log::info('In first catch block of first image for Listing ID: ' . $propertySingle->ListingID);
                                        $addToUploadImage = new ImageUploadErrorEntity();
                                        $addToUploadImage->MLSNo = $propertySingle->ListingID;
                                        $addToUploadImage->ImagePath = $GetFirstImage[0]['PropMediaURL'];
                                        $addToUploadImage->Errortype = Constants::$Value_True;
                                        $addToUploadImage->AddedDateTime = date(Constants::$DefaultDateTimeFormat);
                                        $this->SaveEntity($addToUploadImage);
                                        $ignoreImg = 1;
                                        try {
                                            if (count($GetFirstImage) > 1)
                                                $PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing, Constants::$Value_False, Constants::$MercerVineSiteID, $GetFirstImage[1]['PropMediaURL']);
                                        } catch (Exception $e) {
                                            Log::info('In second catch block of first image for Listing ID: ' . $propertySingle->ListingID);
                                            $addToUploadImage = new ImageUploadErrorEntity();
                                            $addToUploadImage->MLSNo = $propertySingle->ListingID;
                                            $addToUploadImage->ImagePath = $GetFirstImage[1]['PropMediaURL'];
                                            $addToUploadImage->Errortype = Constants::$Value_True;
                                            $addToUploadImage->AddedDateTime = date(Constants::$DefaultDateTimeFormat);
                                            $this->SaveEntity($addToUploadImage);
                                            $ignoreImg = 2;
                                        }
                                    }
                                    if ($ignoreImg != 2) {
                                        $PropertyModel->ListingModel->UploadedFile[0]->SortOrder = 1;
                                        $PropertyModel->ListingModel->UploadedFile[0]->IsSavedInDB = 2;
                                        foreach ($PropertyModel->ListingModel->UploadedFile[0] as $key => $value) {
                                            $PropertyModel->ListingModel->ImagesModel[0][$key] = $value;
                                            if ($key == 'FilePath') {
                                                $getnameArray = explode('/', $value);
                                                $PropertyModel->ListingModel->ImagesNameModel[0] = $getnameArray[count($getnameArray) - 1];
                                            }
                                        }
                                    }
                                }
                            }
                            $MediaArray = array();

                            $this->CustomDeleteEntity(new TempRetsImagesEntity(), 'PropertyListingID', $propertySingle->ListingID);

                            foreach ($GetFirstImage as $key => $object) {
                                if ($object['PropMediaType'] == 'Photo' && ($key > $ignoreImg || Constants::$skipFirstImageUpload == 1)) {
                                    $MediaData = array();
                                    $MediaData['PropertyListingID'] = $propertySingle->ListingID;
                                    $MediaData['UserID'] = 0;
                                    $MediaData['SiteID'] = Constants::$MercerVineSiteID;
                                    $MediaData['ListingKey'] = $propertySingle->ListingKey;
                                    $MediaData['PropObjectKey'] = $object['PropObjectKey'];
                                    $MediaData['PropMediaKey'] = $object['PropMediaKey'];
                                    $MediaData['PropMediaURL'] = $object['PropMediaURL'];

                                    array_push($MediaArray, $MediaData);
                                }
                            }

                            if (count($MediaArray) > 0) {
                                $PropertyModel->IsShowUploadNote = 1;
                                $response->Message = trans('messages.NoRETSPropertyFound');
                            } else {
                                $PropertyModel->IsShowUploadNote = 0;
                            }
                            $this->MultipleInsert(new TempRetsImagesEntity(), $MediaArray);
                        }
                        $propertyAdded = $this->SaveProperty($PropertyModel->ListingModel, Constants::$MercerVineSiteID, Constants::$StaticUserID);
                        $responseArray[] = $propertyAdded->Message;
                    }
                    $updateCounter = Config::get('config.NumberOfPropertiesToGet') + $nextPage;
                    $response->Data = $responseArray;
                    $settingEntity->IsMLSPropertyCronRunning = false;
                    $settingEntity->MLSPropertyCounter = $updateCounter;
                    $this->SaveEntity($settingEntity);
                } catch (Exception $e) {
                    Log::info(' Adding property from MLS DB :' . date('Y-m-d H:i:s'));
                    Log::error($e);
                }
        }else
        {
                return $settingEntity->IsMLSPropertyCronRunning;
            }
        return $response;
    }

    // cron job for non MV Properties Management
    public function PropertyManagement(){
        $response=new ServiceResponse();
        if(Common::SetCronJobRunning(Constants::$PropertyManagementCronCheck)) {
            $datetime = DB::select("SELECT DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%d') as todayDate");
            $searchParam = array();
            $searchValues = Common::SetSearchArray('cronDate', $datetime[0]->todayDate);
            array_push($searchParam, $searchValues);
            $getLastData = $this->GetEntityList(new CronJobEntity(), $searchParam);
            if(count($getLastData)==0){
                //then we will add csv property
                Log::info('Added insertCSV From MLS: ' . date('Y-m-d H:i:s'));
                $response=$this->addCSVtoDb();
                Common::UnsetCronJobRunning(Constants::$PropertyManagementCronCheck);
            }
            else {
                foreach($getLastData as $functionFor) {
                    if($functionFor->cronFor==Constants::$CronCSVInsert && $functionFor->cronCSVStatus<=1) {
                        switch ($functionFor->cronCSVStatus) {
                            case "0":
                                $response=$this->addCSVProperties();
                                break;
                            case "1":
                                Log::info('Insert CSV processing Ended: ' . date('Y-m-d H:i:s'));
                                Log::info('Added updateCSV from MLS: ' . date('Y-m-d H:i:s'));
                                $response=$this->addUpdateCSVtoDb();
                                break;
                        }
                    }
                    if($functionFor->cronFor==Constants::$CronCSVUpdate && $functionFor->cronCSVStatus<=3) {
                        switch ($functionFor->cronCSVStatus) {
                            case "2":
                                $response=$this->UpdateCSVProperties();
                                break;
                            case "3":
                                Log::info('Update CSV Processing Ended: ' . date('Y-m-d H:i:s'));
                                Log::info('Added updateStatusCSV from MLS: ' . date('Y-m-d H:i:s'));
                                $response=$this->addCSVPropertyStatus();
                                break;
                        }
                    }
                    if($functionFor->cronFor==Constants::$CronCSVUpdateStatus && $functionFor->cronCSVStatus<=5){
                        switch ($functionFor->cronCSVStatus) {
                            case "4":
                                $response = $this->UpdateCSVStatusProperties();
                                break;
                            case "5":
                                Log::info('Update Status CSV Processing ended: ' . date('Y-m-d H:i:s'));
                                Log::info('Added DeleteCSV from MLS: ' . date('Y-m-d H:i:s'));
                                $response = $this->addDeleteCSVtoDB();
                                break;
                        }
                    }
                    if($functionFor->cronFor==Constants::$CronCSVDelete){
                        switch ($functionFor->cronCSVStatus) {
                            case "6":
                                $response = $this->DeleteCSVProperties();
                                break;
                            case "7":
                                $response->IsSuccess=true;
                                $response->Message="Cron job Completed For Today.";
                        }
                    }
                }
            }
            Common::UnsetCronJobRunning(Constants::$PropertyManagementCronCheck);
        }
        return $response;
    }

    // { csv for add
    public function addCSVtoDb(){
        $response = new ServiceResponse();
        try {
                 
            $datetimePrev =  DB::select("SELECT DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%d') as todayDate");
           
            $searchParam = array();
            $searchValues = Common::SetSearchArray('cronDate', $datetimePrev[0]->todayDate);
            array_push($searchParam, $searchValues);
            $searchValues = Common::SetSearchArray('cronFor', Constants::$CronCSVUpdate);
            array_push($searchParam, $searchValues);
            

            $getPrevData = $this->CallRawForSingleTable('getPrevCronData', array(Constants::$CronCSVInsert, $datetimePrev[0]->todayDate));            
            $prevCSV = "";

            $prevCSVCount = 0;
            if(isset($getPrevData[0]) && $getPrevData[0]->cronLastIndex < $getPrevData[0]->cronPropertyCount){
                $lastCronData = $getPrevData[0]->cronCSV;

                $prevCSV = substr($lastCronData, Common::strposnth($lastCronData, ',', $getPrevData[0]->cronLastIndex) + 1);
                $prevCSVArray = explode(",", $prevCSV);
                $prevCSVCount = count($prevCSVArray);

                $savePrevData = $this->CallRawForSingleTable('savePrevCronData', array($getPrevData[0]->cronId));

            }

            $datetime = DB::select("SELECT DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%d') as todayDate");

            $searchParam = array();
            $searchValues = Common::SetSearchArray('cronDate', $datetime[0]->todayDate);
            array_push($searchParam, $searchValues);
            $getLastData = $this->GetEntityList(new CronJobEntity(), $searchParam);

            
            $config = new \PHRETS\Configuration;
            $config->setloginurl(Config::get('config.CLAW_Login_URL'));
            $config->setRetsVersion(Config::get('config.CLAW_RETS_Version'));
            $config->setUserAgent(Config::get('config.CLAW_UserAgent'));
            $config->setHttpAuthenticationMethod(Config::get('config.CLAW_Authentication_Method'));
            $config->setOption('use_post_method', false);
            $config->setOption('disable_follow_location', false);
            // get credentials from database settings table. We kept them in db so user can change easily if there is any change.
            $Credentials = $this->GetCLAWCredentials(Constants::$MercerVineSiteID);
            $config->setusername($Credentials->RETSUserName);
            $config->setpassword($Credentials->RETSPassword);
            $rets = new \PHRETS\Session($config);
            $login = $rets->Login();
            $LogArray=array();
            $LogArray=$this->StoreRetsLog(Constants::$Value_False, Constants::$MercerVineSiteID, Constants::$RETSActionLogin, Config::get('config.CLAW_Login_URL'), '', $login,$LogArray,false);
            //$getDataBaseValue = DB::select("SELECT DATE_FORMAT(DATE_SUB(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), INTERVAL 24 HOUR), '%Y-%m-%dT%H:%i:%s') AS modifiedDate,DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%dT%H:%i:%s') AS todayDate");
            $getDataBaseValue = DB::select("SELECT DATE_FORMAT(CONVERT_TZ(MAX(crondate), @@session.time_zone, 'UTC' ), '%Y-%m-%dT%H:%i:%s') AS modifiedDate, DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%dT%H:%i:%s') AS todayDate FROM `cronjobhistory` where cronFor='insert'");
            $resource = 'Property';
            $class = 'ALL';
            //get records for last 24 hrs
            $statusField=Common::getPropertyStatusField(Constants::$MercerVineSiteID);
            $query = '(ModificationTimestamp=' . $getDataBaseValue[0]->modifiedDate . '-' . $getDataBaseValue[0]->todayDate . '),('.$statusField.'=|'.Constants::$ActiveListingStatus.','.Constants::$ClosedListingStatus.','.Constants::$ActiveContractStatus.','.Constants::$PendingListingStatus.')';
            $result = $rets->Search(
                $resource,
                $class,
                $query,
                [
                    'QueryType' => 'DMQL2',
                    'Count' => 1, // only records
                    'Format' => 'COMPACT-DECODED',
                    'Limit' => 'NONE',
                    /*'Offset' => $nextPage,*/
                    'StandardNames' => 0, // give system names
                    'Select' => 'ListingID'//,ModificationTimestamp'
                ]
            );
            $LogArray = $this->StoreRetsLog(Constants::$Value_False, Constants::$MercerVineSiteID, Constants::$RETSActionSearch, $result->URL, '', serialize($result->toArray()),$LogArray,false);
            $Alldata = json_decode($result->toJSON());
            $totalCount = count($Alldata);
            $csv = implode(',', array_map(function ($n) {
                return $n->ListingID;
            }, $Alldata));


            if($prevCSVCount > 0){
                $csv = $csv.",".$prevCSV;
            }

            $GetUniqueData = $this->CallRawForSingleTable('ProcessCSVForCron', [$csv]);
            //process csv to get none existing data from database
            $csv = Common::GetUniqueCSVFromArray($csv, $GetUniqueData);
            $csvCount = explode(",", $csv);

            $insertCSV = new CronJobEntity();
            $insertCSV->cronDate = $getDataBaseValue[0]->todayDate;
            $insertCSV->cronCSV = $csv;
            $insertCSV->CronPropertyCount = count($csvCount);
            //$insertCSV->CronPropertyCount = $totalCount + $prevCSVCount -count($GetUniqueData);
            //$insertCSV->CronPropertyCount = $totalCount - count($GetUniqueData);
            $insertCSV->cronFor=Constants::$CronCSVInsert;
            $saveCSV = $this->SaveEntity($insertCSV);
            if ($saveCSV) {
                $response->IsSuccess = true;
                $response->Message = "CVS added for :" . $getDataBaseValue[0]->todayDate;
            } else {
                $response->IsSuccess = false;
                $response->Message = "CVS failed for :" . $getDataBaseValue[0]->todayDate;
            }
        }
        catch (Exception $e) {
            Log::info('Adding CSV Issue :' . date('Y-m-d H:i:s'));
            Log::error($e);
        }
        return $response;
    }
    // adding property from CSV }
    public function addCSVProperties(){
        $response = new ServiceResponse();
        try {
            
            $datetime = DB::select("SELECT DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%d') as todayDate");
            $searchParam = array();
            $searchValues = Common::SetSearchArray('cronDate', $datetime[0]->todayDate);
            array_push($searchParam, $searchValues);
            $searchValues = Common::SetSearchArray('cronFor', Constants::$CronCSVInsert);
            array_push($searchParam, $searchValues);
            $getLastData = $this->GetEntityForUpdateByFilter(new CronJobEntity(), $searchParam);
            if (count($getLastData) > 0) {
                $csv = $getLastData->cronCSV;
                $lastIndex = $getLastData->cronLastIndex;
                $MaxIndex = $getLastData->cronPropertyCount;

                //$matches = preg_split('/((?:[^,]*,){15})/', $csv, -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);
                if ($lastIndex != 0 && $lastIndex <= $MaxIndex) {
                    if($MaxIndex-$lastIndex <= Config::get('config.AddPropertiesFromCSV')){
                        $finalCSV = substr($csv, Common::strposnth($csv, ',', $lastIndex) + 1);
                    }
                    else {
                        $ReducedCSV = substr($csv, Common::strposnth($csv, ',', $lastIndex) + 1);
                        $finalCSV = substr($ReducedCSV, 0, Common::strposnth($ReducedCSV, ',', Config::get('config.AddPropertiesFromCSV')));
                    }
                } else {
                    Log::info('Insert CSV processing started: ' . date('Y-m-d H:i:s'));
                    if(Config::get('config.AddPropertiesFromCSV')> $MaxIndex){
                        $finalCSV = $csv;
                    }else {
                        $finalCSV = substr($csv, 0, Common::strposnth($csv, ',', Config::get('config.AddPropertiesFromCSV')));
                    }
                }
                $GetUniqueData = $this->CallRawForSingleTable('processcsvforcron', [$finalCSV]);
                //process csv to get none existing data from database
                $finalCSV = Common::GetUniqueCSVFromArray($finalCSV, $GetUniqueData);

                Log::info('Insert Final CSV: ' . $finalCSV);
                if ($finalCSV) {
                    $response = new ServiceResponse();
                    $config = new \PHRETS\Configuration;
                    $config->setloginurl(Config::get('config.CLAW_Login_URL'));
                    $config->setRetsVersion(Config::get('config.CLAW_RETS_Version'));
                    $config->setUserAgent(Config::get('config.CLAW_UserAgent'));
                    $config->setHttpAuthenticationMethod(Config::get('config.CLAW_Authentication_Method'));
                    $config->setOption('use_post_method', false);
                    $config->setOption('disable_follow_location', false);

                    // get credentials from database settings table. We kept them in db so user can change easily if there is any change.
                    $Credentials = $this->GetCLAWCredentials(Constants::$MercerVineSiteID);
                    $config->setusername($Credentials->RETSUserName);
                    $config->setpassword($Credentials->RETSPassword);
                    $rets = new \PHRETS\Session($config);
                    $login = $rets->Login();
                    $LogArray=array();
                    $LogArray=$this->StoreRetsLog(Constants::$Value_False, Constants::$MercerVineSiteID, Constants::$RETSActionLogin, Config::get('config.CLAW_Login_URL'), '', $login,$LogArray,false);
                    $resource = 'Property';
                    $class = 'ALL';
                    $query = '(ListingID=' . $finalCSV . ')';
                    $result = $rets->Search(
                        $resource,
                        $class,
                        $query,
                        [
                            'QueryType' => 'DMQL2',
                            'Count' => 1, // only records
                            'Format' => 'COMPACT-DECODED',
                            'Limit' => 'NONE',
                            'StandardNames' => 0, // give system names
                        ]
                    );
                    $LogArray = $this->StoreRetsLog(Constants::$Value_False, Constants::$MercerVineSiteID, Constants::$RETSActionSearch, $result->URL, '', serialize($result->toArray()),$LogArray,false);
                    $Alldata = json_decode($result->toJSON());
                    $responseArray = [];

                    foreach ($Alldata as $propertySingle) {
                        $IsWBProperty=Constants::$Value_False;
                        $statusField=Common::getPropertyStatusField(Constants::$MercerVineSiteID);
                        $CheckForIsWB=Common::getPropertyOfficeID($propertySingle->ListOfficeId,Constants::$MercerVineSiteID);

                        if($CheckForIsWB){
                            $IsWBProperty=Constants::$Value_True;
                        }
                        else {
                            if($propertySingle->{$statusField}=='Closed') {
                                continue;
                            }
                        }
                        $PropertyModel = new stdClass();
                        $PropertyModel->ListingModel = $this->getPropertiesFormated($propertySingle,$IsWBProperty,Constants::$MercerVineSiteID);
                        $PropertyModel->ListingModel->isCron=Constants::$Value_True;
                        if ($login) {
                            //Get Object/Image data
                            $objects = $rets->Search(
                                'Media',
                                'PROP_MEDIA',
                                '(PropObjectKey=' . $propertySingle->ListingKey . ')',
                                [
                                    'QueryType' => 'DMQL2',
                                    'Count' => 0,
                                    'Format' => 'COMPACT-DECODED',
                                    'StandardNames' => 0, // give system names
                                ]
                            );
                            $LogArray = $this->StoreRetsLog(Constants::$Value_False, Constants::$MercerVineSiteID, Constants::$RETSActionSearchMedia, $objects->URL, '', serialize($objects->toArray()), $LogArray, true);
                            // Add log for rets search property media.
                            $GetFirstImage = Common::GetArrayFilterValues($objects->toArray(), 'PropMediaType', 'Photo');
                            if (count($GetFirstImage) > 0) {
                                $ignoreImg=0;
                                //$PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing, Constants::$StaticUserID, Constants::$MercerVineSiteID, $GetFirstImage[0]['PropMediaURL']);
                                try {
                                    $PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing,Constants::$Value_False, Constants::$MercerVineSiteID, $GetFirstImage[0]['PropMediaURL']);
                                }
                                catch(Exception $e)
                                {
                                    Log::info('In first catch block of first image for Listing ID: ' . $propertySingle->ListingID);
                                    $addToUploadImage=new ImageUploadErrorEntity();
                                    $addToUploadImage->MLSNo=$propertySingle->ListingID;
                                    $addToUploadImage->ImagePath=$GetFirstImage[0]['PropMediaURL'];
                                    $addToUploadImage->Errortype=Constants::$Value_True;
                                    $addToUploadImage->AddedDateTime=date(Constants::$DefaultDateTimeFormat);
                                    $this->SaveEntity($addToUploadImage);
                                    $ignoreImg = 1;
                                    try {
                                        if (count($GetFirstImage) > 1)
                                            $PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing, Constants::$Value_False, Constants::$MercerVineSiteID, $GetFirstImage[1]['PropMediaURL']);
                                    }
                                    catch(Exception $e)
                                    {
                                        Log::info('In second catch block of first image for Listing ID: ' . $propertySingle->ListingID);
                                        $addToUploadImage=new ImageUploadErrorEntity();
                                        $addToUploadImage->MLSNo=$propertySingle->ListingID;
                                        $addToUploadImage->ImagePath=$GetFirstImage[1]['PropMediaURL'];
                                        $addToUploadImage->Errortype=Constants::$Value_True;
                                        $addToUploadImage->AddedDateTime=date(Constants::$DefaultDateTimeFormat);
                                        $this->SaveEntity($addToUploadImage);
                                        $ignoreImg = 2;
                                    }
                                }
                                if($ignoreImg!=2) {
                                    $PropertyModel->ListingModel->UploadedFile[0]->SortOrder = 1;
                                    $PropertyModel->ListingModel->UploadedFile[0]->IsSavedInDB = 2;
                                    foreach ($PropertyModel->ListingModel->UploadedFile[0] as $key => $value) {
                                        $PropertyModel->ListingModel->ImagesModel[0][$key] = $value;
                                        if ($key == 'FilePath') {
                                            $getnameArray = explode('/', $value);
                                            $PropertyModel->ListingModel->ImagesNameModel[0] = $getnameArray[count($getnameArray) - 1];
                                        }
                                    }
                                }
                            }
                            $MediaArray = array();

                            $this->CustomDeleteEntity(new TempRetsImagesEntity(), 'PropertyListingID', $propertySingle->ListingID);

                            foreach ($GetFirstImage as $key => $object) {
                                if ($object['PropMediaType'] == 'Photo' && $key > $ignoreImg) {
                                    $MediaData = array();
                                    $MediaData['PropertyListingID'] = $propertySingle->ListingID;
                                    $MediaData['UserID'] = 0;
                                    $MediaData['SiteID'] = Constants::$MercerVineSiteID;
                                    $MediaData['ListingKey'] = $propertySingle->ListingKey;
                                    $MediaData['PropObjectKey'] = $object['PropObjectKey'];
                                    $MediaData['PropMediaKey'] = $object['PropMediaKey'];
                                    $MediaData['PropMediaURL'] = $object['PropMediaURL'];

                                    array_push($MediaArray, $MediaData);
                                }
                            }
                            if (count($MediaArray) > 0) {
                                $PropertyModel->IsShowUploadNote = 1;
                            } else {
                                $PropertyModel->IsShowUploadNote = 0;
                            }

                            $this->MultipleInsert(new TempRetsImagesEntity(), $MediaArray);
                        }
                        $propertyAdded = $this->SaveProperty($PropertyModel->ListingModel, Constants::$MercerVineSiteID, Constants::$StaticUserID);
                        $responseArray[] = $propertySingle->ListingID . ": " . $propertyAdded->Message;
                    }
                    $getLastData->cronLastIndex = $lastIndex + Config::get('config.AddPropertiesFromCSV');
                    if($lastIndex + Config::get('config.AddPropertiesFromCSV') >= $MaxIndex){
                        // changed to 1 for finished
                        $getLastData->cronCSVStatus=1;
                    }
                    $this->SaveEntity($getLastData);
                }
                else{
                    $getLastData->cronLastIndex = $lastIndex + Config::get('config.AddPropertiesFromCSV');
                    if($lastIndex + Config::get('config.AddPropertiesFromCSV') >= $MaxIndex){
                        $getLastData->cronCSVStatus=1;
                    }
                    $this->SaveEntity($getLastData);    
                }
                
                $response->IsSuccess = true;

            } else {
                $response->IsSuccess = false;
                $response->Message="CSV not added or all properties added successfully.";
            }
        }
        catch(Exception $e) {
            Log::info('Adding CSV Property Issue :' . date('Y-m-d H:i:s'));
            Log::error($e);
        }
        return $response;
    }

    // common method to format property data fetched from caret
    public function getPropertiesFormated($propertySingle,$IsWBProperty,$SiteID=null){
        $property = new stdClass();
        // One to one mapping of rets data to property object.
        $property->ListingID = '';
        $property->IsWBProperty = $IsWBProperty;
        $property->MLSNo = $propertySingle->ListingID;  //Listing ID //LIST_105
        $property->Price = $propertySingle->ListPrice; //Asking Price //LIST_22

        if ($propertySingle->LotSizeAcres != "") {
            $property->LotSize = $propertySingle->LotSizeAcres; //Lot Size //LIST_57
        } else {
            if ($propertySingle->LotSizeSQFT != "")
                $property->LotSize = round(($propertySingle->LotSizeSQFT / 43560), 2); //LIST_122
        }

        $property->SquareFeet = $propertySingle->BuildingSize; //Total SqFt //LIST_48
        $property->NoOfBeds = $propertySingle->BedroomsTotal ; //Bedrooms //LIST_66
        $property->NoOfFullBaths = $propertySingle->BathFull; //Baths - Full //LIST_68
        $property->NoOfHalfBaths = $propertySingle->BathHalf; //Baths - Half //LIST_69
        if (property_exists($propertySingle, 'DwellingStories'))
            $property->NoOfStories = $propertySingle->DwellingStories; //LIST_64
//        $property->BuiltYear = $propertySingle->YearBuilt; //Year Built  //LIST_53
        $property->Description = $propertySingle->PublicRemarks; //Public Remarks //LIST_78
            $property->Street = $propertySingle->FullStreetAddress; //Street # + StreetDirPrefix + Street Name + StreetAdditionalInfo + Street Suffix //LIST_31 + LIST_33 + LIST_34 + LIST_35 + LIST_37
        $property->City = $propertySingle->CityName; //City/Town //LIST_39
        $property->ZipCode = $propertySingle->ZipCode;// . $propertySingle->ZipCodePlus4; //Postal Code //LIST_43
        $property->County = $propertySingle->County; //County //LIST_41
        $property->ElementarySchool = $propertySingle->ElementarySchool;
        $property->JuniorHighSchool = $propertySingle->JuniorMiddleSchool;
        $property->SeniorHighSchool = $propertySingle->HighSchool;
        /* ListAgentFirstName , ListAgentLastName for MLSAgentName and ListOfficeName for MLSBrokerName */

        $property->LotSizeSource = $propertySingle->LotSizeSource;
        $property->SquareFootageSource = $propertySingle->SquareFootageSource;
        $property->ListingKey = $propertySingle->ListingDate;
        $property->OffMarketDate = $propertySingle->OffMarketDate;
        $property->DOM = $propertySingle->DOM; //LIST_137
        $property->ListAgentName = $propertySingle->ListAgentFirstName . ' ' . $propertySingle->ListAgentLastName; // LIST_5 - Agetnt ID
        $property->ListOfficeName = $propertySingle->ListOfficeName; //LIST_106 - OfficeID
        $property->Latitude = $propertySingle->Latitude; //Geo Lat - LIST_46
        $property->Longitude = $propertySingle->Longitude; //Geo Lon - LIST_47
        $property->ListingKeyOnly = $propertySingle->ListingKey;
        $property->MLSLicenseNumber = $propertySingle->ListAgentLicenseNumber;
        $property->AltLicenseNumber = $propertySingle->AltAgentLicenseNumber;
        $property->AltAgentName = $propertySingle->AltAgentFirstName." ".$propertySingle->AltAgentLastName;
        /* End ListAgentFirstName , ListAgentLastName for MLSAgentName and ListOfficeName for MLSBrokerName */

        if ($propertySingle->OtherStructures == 'GuestHouse')
            $property->HasGuestHouse = 1;
        if ($propertySingle->LotDescription == 'Horse Property')
            $property->HasHorseProperty = 1;
        $property->IsHidden = ''; //Display on Public Websites - Aspen //LIST_104

        // Mapping of rets data to property object after getting respective db ID details.
        $Features = array();
        $Features['Agent'] = $propertySingle->ListAgentLicenseNumber; //with no //Agent ID - may be

        switch($propertySingle->PropertyType){
            case Constants::$caretsLand:
                $Features['PropertyType']=Constants::$mlsLand;
                break;
            case Constants::$caretsResidential:
                if($propertySingle->PropertySubType == Constants::$caretsCondominium)
                    $Features['PropertyType']=Constants::$mlsCondoCoOp;
                else
                    $Features['PropertyType']=Constants::$mlsSingleFamily;
                break;
            case Constants::$caretsMobileHome:
                $Features['PropertyType']=Constants::$mlsMobileHome;
                break;
            default:
                $Features['PropertyType']=$propertySingle->PropertyType; //LIST_8
                break;
        }

        //$Features['PropertyType'] = $propertySingle->PropertyType; //string //Property Type
        $Features['PropertySubType'] = $propertySingle->PropertySubType; //string //Sub-Type //Type //LIST_112
        $statusField=Common::getPropertyStatusField($SiteID);
        if($propertySingle->{$statusField}=='Closed'){
            $Features['Status'] = Constants::$SoldStatus;
        }else {
            $Features['Status'] = $propertySingle->{$statusField}; //string //Status //LIST_15
        }
        $Features['Area'] = $propertySingle->Area; //Area //LIST_88
        $Features['State'] = $propertySingle->State; //State/Province //LIST_40
        $Features['Securities'] = '"' . $propertySingle->SecuritySafety . '"';
        $Features['Pools'] = '"' . $propertySingle->PoolDescriptions . '"';
        $Features['Spas'] = '"' . $propertySingle->SpaDescriptions . '"'; // in extras
        $Features['Views'] = '"' . $propertySingle->View . '"'; // in Location Amenities
        $Features['Styles'] = '"' . $propertySingle->BuildingStructureStyle . '"'; //(Substructure,Exterior,Construction,style)GF20081219153706564858000000,GF20081113193814521314000000,GF20081219172532247053000000,GF20081113193745023142000000
        $Features['WaterFronts'] = '"' . $propertySingle->Water . '"'; //Water - may be //GF20081113193939865339000000
        $Features['Roofings'] = '"' . $propertySingle->Roofing . '"'; //Roof //GF20081113193838229693000000
        $Features['Sewers'] = '"' . $propertySingle->Sewer . '"'; //Sanitation - may be //GF20081113194011590415000000
        $Features['Equipments'] = '"' . $propertySingle->Appliances . '"'; //CookingAppliances - MV  // Inclusions - Aspen //GF20081113195001529466000000
        $Features['Floorings'] = '"' . $propertySingle->FloorMaterial . '"';
        $Features['Heatings'] = '"' . $propertySingle->HeatingType . '"'; //Heating //GF20081113193905566715000000
        $Features['AirConditionings'] = '"' . $propertySingle->CoolingType . '"'; //Cooling //GF20081113193951743297000000
        $Features['Rooms'] = '"' . $propertySingle->Rooms . '"';
        $Features['FirePlaces'] = '"' . $propertySingle->FireplaceRooms . '"'; //FireplaceFeatures - MV //Fireplaces-Aspen //GF20081113194107612667000000
        $Features['Laundries'] = '"' . $propertySingle->LaundryLocations . '"'; //Laundry Facility //GFLU20110517210055312869000000
        $Features['Parkings'] = '"' . $propertySingle->ParkingType . '"'; //ParkingFeatures - MV //Garage, Parking Area- Aspen //LIST_73,GF20081113194130890449000000
        $Features['DisabilityAccesses'] = '"' . $propertySingle->DisabilityAccess . '"';
        $Features['Courts'] = '"' . $propertySingle->PlayingCourts . '"';
        $Features['Amenities'] = '"' . $propertySingle->AssociationAmenities . '"'; //KitchenFeatures,HighMidRiseAmenities - MV
        //Extras,HOA Amenities - Aspen //GFLU20081113194200562715000000, GF20081113194809194714000000
        $FeatureData = $this->GetPropertyFeatureDetails(Constants::$Agent_Role_ID, $Features);

        $property->AgentID = (property_exists($FeatureData[0][0],'Agent'))?$FeatureData[0][0]->Agent:'';
        $property->SiteID = Constants::$MercerVineSiteID;
        $property->TypeID = $FeatureData[1][0]->Type ;
        if (property_exists($FeatureData[2][0], 'SubType'))
            $property->SubTypeID = $FeatureData[2][0]->SubType;
        $property->StatusID = $FeatureData[3][0]->Status ;
        $property->AreaID = $FeatureData[4][0]->Area;
        $property->StateID = $FeatureData[5][0]->State;
        // explode needed as we get csv data using group_concat.
        $property->SecurityTypes = explode(',', $FeatureData[6][0]->SecurityTypes);
        $property->Pools = explode(',', $FeatureData[7][0]->Pools);
        $property->Spas = explode(',', $FeatureData[8][0]->Spas);
        $property->Views = explode(',', $FeatureData[9][0]->Views);
        $property->Styles = explode(',', $FeatureData[10][0]->Styles);
        $property->WaterFronts = explode(',', $FeatureData[11][0]->Waterfronts);
        $property->Roofings = explode(',', $FeatureData[12][0]->Roofings);
        $property->Sewers = explode(',', $FeatureData[13][0]->Sewers);
        $property->Equipments = explode(',', $FeatureData[14][0]->Equipments);
        $property->Floorings = explode(',', $FeatureData[15][0]->Floorings);
        $property->Heatings = explode(',', $FeatureData[16][0]->Heatings);
        $property->Airconditionings = explode(',', $FeatureData[17][0]->AirConditionings);
        $property->Rooms = explode(',', $FeatureData[18][0]->Rooms);
        $property->Fireplaces = explode(',', $FeatureData[19][0]->FirePlaces);
        $property->Laundries = explode(',', $FeatureData[20][0]->Laundries);
        $property->Parkings = explode(',', $FeatureData[21][0]->Parkings);
        $property->DisabilityAccesses = explode(',', $FeatureData[22][0]->DisabilityAccesses);
        $property->Courts = explode(',', $FeatureData[23][0]->Courts);
        $property->Amenities = explode(',', $FeatureData[24][0]->Amenities);

        return $property;
    }

    // { csv for update
    public function addUpdateCSVtoDb() {
        $response = new ServiceResponse();
        
         
        try {
            
            $datetimePrev =  DB::select("SELECT DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%d') as todayDate");
           
            $searchParam = array();
            $searchValues = Common::SetSearchArray('cronDate', $datetimePrev[0]->todayDate);
            array_push($searchParam, $searchValues);
            $searchValues = Common::SetSearchArray('cronFor', Constants::$CronCSVUpdate);
            array_push($searchParam, $searchValues);
            

            $getPrevData = $this->CallRawForSingleTable('getPrevCronData', array(Constants::$CronCSVUpdate, $datetimePrev[0]->todayDate));            
            $prevCSV = "";

            $prevCSVCount = 0;
            if(isset($getPrevData[0]) && $getPrevData[0]->cronLastIndex < $getPrevData[0]->cronPropertyCount){
                $lastCronData = $getPrevData[0]->cronCSV;

                $prevCSV = substr($lastCronData, Common::strposnth($lastCronData, ',', $getPrevData[0]->cronLastIndex) + 1);
                $prevCSVArray = explode(",", $prevCSV);
                $prevCSVCount = count($prevCSVArray);

                $savePrevData = $this->CallRawForSingleTable('savePrevCronData', array($getPrevData[0]->cronId));

            }


            $config = new \PHRETS\Configuration;
            $config->setloginurl(Config::get('config.CLAW_Login_URL'));
            $config->setRetsVersion(Config::get('config.CLAW_RETS_Version'));
            $config->setUserAgent(Config::get('config.CLAW_UserAgent'));
            $config->setHttpAuthenticationMethod(Config::get('config.CLAW_Authentication_Method'));
            $config->setOption('use_post_method', false);
            $config->setOption('disable_follow_location', false);

            // get credentials from database settings table. We kept them in db so user can change easily if there is any change.
            $Credentials = $this->GetCLAWCredentials(Constants::$MercerVineSiteID);
            $config->setusername($Credentials->RETSUserName);
            $config->setpassword($Credentials->RETSPassword);
            $rets = new \PHRETS\Session($config);
            $login = $rets->Login();
            $LogArray=array();
            $LogArray=$this->StoreRetsLog(Constants::$Value_False, Constants::$MercerVineSiteID, Constants::$RETSActionLogin, Config::get('config.CLAW_Login_URL'), '', $login,$LogArray,false);
            //$getDataBaseValue = DB::select("SELECT DATE_FORMAT(DATE_SUB(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), INTERVAL 24 HOUR), '%Y-%m-%dT%H:%i:%s') AS modifiedDate,DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%dT%H:%i:%s') AS todayDate, DATE_FORMAT(DATE_SUB(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), INTERVAL 48 HOUR), '%Y-%m-%d') as listDate");
            $getDataBaseValue=DB::select("SELECT DATE_FORMAT(CONVERT_TZ( MAX(crondate), @@session.time_zone, 'UTC' ), '%Y-%m-%dT%H:%i:%s') AS modifiedDate, DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%dT%H:%i:%s') AS todayDate, DATE_FORMAT(CONVERT_TZ( MAX(crondate), @@session.time_zone, 'UTC' ), '%Y-%m-%d') AS listDate FROM `cronjobhistory` WHERE cronFor='update'");
            $resource = 'Property';
            $class = 'ALL';
            //get records for last 24 hrs
            $statusField=Common::getPropertyStatusField(Constants::$MercerVineSiteID);
            $query = '(ModificationTimestamp=' . $getDataBaseValue[0]->modifiedDate . '-' . $getDataBaseValue[0]->todayDate . '),('.$statusField.'=|'.Constants::$ActiveListingStatus.','.Constants::$PendingListingStatus.','.Constants::$ActiveContractStatus.','.Constants::$ClosedListingStatus.'),(ListingDate=' . $getDataBaseValue[0]->listDate . '-)';
            $result = $rets->Search(
                $resource,
                $class,
                $query,
                [
                    'QueryType' => 'DMQL2',
                    'Count' => 1, // only records
                    'Format' => 'COMPACT-DECODED',
                    'Limit' => 'NONE',
                    'StandardNames' => 0, // give system names
                    'Select' => 'ListingID'//,ModificationTimestamp'
                ]
            );
            $LogArray = $this->StoreRetsLog(Constants::$Value_False, Constants::$MercerVineSiteID, Constants::$RETSActionSearch, $result->URL, '', serialize($result->toArray()),$LogArray,false);
            $Alldata = json_decode($result->toJSON());
            $totalCount=count($Alldata);
            $csv = implode(',', array_map(function ($n) {
                return $n->ListingID;
            }, $Alldata));

            if($prevCSVCount > 0){
                $csv = $csv.",".$prevCSV;
            }


            $insertCSV = new CronJobEntity();
            $insertCSV->cronDate = $getDataBaseValue[0]->todayDate;
            $insertCSV->cronCSV = $csv;
            $insertCSV->CronPropertyCount = $totalCount + $prevCSVCount;
            $insertCSV->cronFor=Constants::$CronCSVUpdate;
            $insertCSV->cronCSVStatus=2;
            $saveCSV = $this->SaveEntity($insertCSV);
            if ($saveCSV) {
                $searchParam = array();
                $searchValues = Common::SetSearchArray('cronDate', date(Constants::$YMDDateFormatServerSide,strtotime($getDataBaseValue[0]->todayDate)));
                array_push($searchParam, $searchValues);
                $searchValues = Common::SetSearchArray('cronFor',Constants::$CronCSVInsert );
                array_push($searchParam, $searchValues);
                $getLastData = $this->GetEntityForUpdateByFilter(new CronJobEntity(), $searchParam);
                $getLastData->cronCSVStatus=2;
                $this->SaveEntity($getLastData);
                $response->IsSuccess = true;
                $response->Message = "CVS added for Update :" . $getDataBaseValue[0]->todayDate;
            } else {
                $response->IsSuccess = false;
                $response->Message = "CVS failed for Update:" . $getDataBaseValue[0]->todayDate;
            }
        } catch(Exception $e){
            Log::info('Adding Update CSV Issue :' . date('Y-m-d H:i:s'));
            Log::error($e);
        }
        return $response;
    }
    // update property from update CSV }
    public function UpdateCSVProperties(){
        $response = new ServiceResponse();
        $datetime = DB::select("SELECT DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%d') as todayDate");
        $searchParam = array();
        $searchValues = Common::SetSearchArray('cronDate', $datetime[0]->todayDate);
        array_push($searchParam, $searchValues);
        $searchValues = Common::SetSearchArray('cronFor', Constants::$CronCSVUpdate);
        array_push($searchParam, $searchValues);
        $getLastData = $this->GetEntityForUpdateByFilter(new CronJobEntity(), $searchParam);
        if (count($getLastData) > 0) {
            $csv = $getLastData->cronCSV;
            $lastIndex = $getLastData->cronLastIndex;
            $MaxIndex = $getLastData->cronPropertyCount;
            //$matches = preg_split('/((?:[^,]*,){15})/', $csv, -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);
            if ($lastIndex != 0 && $lastIndex <= $MaxIndex) {
                if($MaxIndex-$lastIndex <= Config::get('config.UpdatePropertiesFromCSV')){
                    $finalCSV = substr($csv, Common::strposnth($csv, ',', $lastIndex) + 1);
                }
                else {
                    $ReducedCSV = substr($csv, Common::strposnth($csv, ',', $lastIndex) + 1);
                    $finalCSV = substr($ReducedCSV, 0, Common::strposnth($ReducedCSV, ',', Config::get('config.UpdatePropertiesFromCSV')));
                }
            } else {
                Log::info('Update CSV Processing Started: ' . date('Y-m-d H:i:s'));
                if(Config::get('config.UpdatePropertiesFromCSV') > $MaxIndex){
                    $finalCSV = $csv;
                }else {
                    $finalCSV = substr($csv, 0, Common::strposnth($csv, ',', Config::get('config.UpdatePropertiesFromCSV')));
                }
            }
            Log::info('Update Final CSV: ' . $finalCSV);
            if ($finalCSV) {
                
                $config = new \PHRETS\Configuration;
                $config->setloginurl(Config::get('config.CLAW_Login_URL'));
                $config->setRetsVersion(Config::get('config.CLAW_RETS_Version'));
                $config->setUserAgent(Config::get('config.CLAW_UserAgent'));
                $config->setHttpAuthenticationMethod(Config::get('config.CLAW_Authentication_Method'));
                $config->setOption('use_post_method', false);
                $config->setOption('disable_follow_location', false);

                // get credentials from database settings table. We kept them in db so user can change easily if there is any change.
                $Credentials = $this->GetCLAWCredentials(Constants::$MercerVineSiteID);
                $config->setusername($Credentials->RETSUserName);
                $config->setpassword($Credentials->RETSPassword);
                $rets = new \PHRETS\Session($config);
                $login = $rets->Login();
                $LogArray=array();
                $LogArray=$this->StoreRetsLog(Constants::$Value_False, Constants::$MercerVineSiteID, Constants::$RETSActionLogin, Config::get('config.CLAW_Login_URL'), '', $login,$LogArray,false);
                $resource = 'Property';
                $class = 'ALL';
                $query = '(ListingID=' . $finalCSV . ')';
                $result = $rets->Search(
                    $resource,
                    $class,
                    $query,
                    [
                        'QueryType' => 'DMQL2',
                        'Count' => 1, // only records
                        'Format' => 'COMPACT-DECODED',
                        'Limit' => 'NONE',
                        'StandardNames' => 0, // give system names
                    ]
                );
                $LogArray = $this->StoreRetsLog(Constants::$Value_False, Constants::$MercerVineSiteID, Constants::$RETSActionSearch, $result->URL, '', serialize($result->toArray()),$LogArray,false);
                $Alldata = json_decode($result->toJSON());
                $responseArray = [];
                foreach ($Alldata as $propertySingle) {
                    $searchParam = array();
                    $searchValues = Common::SetSearchArray('MLSNo', $propertySingle->ListingID,Constants::$Value_True);
                    array_push($searchParam, $searchValues);
                    $getExistingProperty=$this->GetEntity(new PropertyListingsEntity(),$searchParam);
                    $PropertyModel = new stdClass();
                    $IsWBProperty=Constants::$Value_False;
                    $statusField=Common::getPropertyStatusField(Constants::$MercerVineSiteID);
                    $CheckForIsWB=Common::getPropertyOfficeID($propertySingle->ListOfficeId,Constants::$MercerVineSiteID);
                    if($CheckForIsWB){
                        $IsWBProperty=Constants::$Value_True;
                    }
                    else {
                        if($propertySingle->{$statusField}=='Closed') {
                            continue;
                        }
                    }
                    $PropertyModel->ListingModel = $this->getPropertiesFormated($propertySingle,$IsWBProperty,Constants::$MercerVineSiteID);
                    $PropertyModel->ListingModel->isCron=Constants::$Value_True;

                    
                    if(count($getExistingProperty) > 0) {
                        if ($getExistingProperty->ListingID) {
                            $PropertyModel->ListingModel->ListingID = $getExistingProperty->ListingID;
                        }
                    }
                    if(count($getExistingProperty) == 0) {
                        Log::info('Update Insert Property: ' . $propertySingle->ListingID);
                        if ($login) {
                            //Get Object/Image data
                            $objects = $rets->Search(
                                'Media',
                                'PROP_MEDIA',
                                '(PropObjectKey=' . $propertySingle->ListingKey . ')',
                                [
                                    'QueryType' => 'DMQL2',
                                    'Count' => 0,
                                    'Format' => 'COMPACT-DECODED',
                                    'StandardNames' => 0, // give system names
                                ]
                            );
                            $LogArray = $this->StoreRetsLog(Constants::$Value_False, Constants::$MercerVineSiteID, Constants::$RETSActionSearchMedia, $objects->URL, '', serialize($objects->toArray()), $LogArray, true);
                            // Add log for rets search property media.
                            $GetFirstImage = Common::GetArrayFilterValues($objects->toArray(), 'PropMediaType', 'Photo');

                            if (count($GetFirstImage) > 0) {
                                //$PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing, Constants::$StaticUserID, Constants::$MercerVineSiteID, $GetFirstImage[0]['PropMediaURL']);
                                $ignoreImg=0;
                                try {
                                    $PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing, Constants::$Value_False, Constants::$MercerVineSiteID, $GetFirstImage[0]['PropMediaURL']);
                                }
                                catch(Exception $e)
                                {
                                    Log::info('In first catch block of first image for Listing ID: ' . $propertySingle->ListingID);
                                    $addToUploadImage=new ImageUploadErrorEntity();
                                    $addToUploadImage->MLSNo=$propertySingle->ListingID;
                                    $addToUploadImage->ImagePath=$GetFirstImage[0]['PropMediaURL'];
                                    $addToUploadImage->Errortype=Constants::$Value_True;
                                    $addToUploadImage->AddedDateTime=date(Constants::$DefaultDateTimeFormat);
                                    $this->SaveEntity($addToUploadImage);
                                    $ignoreImg = 1;
                                    try {
                                        if (count($GetFirstImage) > 1)
                                            $PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing, Constants::$Value_False, Constants::$MercerVineSiteID, $GetFirstImage[1]['PropMediaURL']);
                                    }
                                    catch(Exception $e)
                                    {
                                        Log::info('In second catch block of first image for Listing ID: ' . $propertySingle->ListingID);
                                        $addToUploadImage=new ImageUploadErrorEntity();
                                        $addToUploadImage->MLSNo=$propertySingle->ListingID;
                                        $addToUploadImage->ImagePath=$GetFirstImage[1]['PropMediaURL'];
                                        $addToUploadImage->Errortype=Constants::$Value_True;
                                        $addToUploadImage->AddedDateTime=date(Constants::$DefaultDateTimeFormat);
                                        $this->SaveEntity($addToUploadImage);
                                        $ignoreImg = 2;
                                    }
                                }
                                if($ignoreImg!=2) {
                                    $PropertyModel->ListingModel->UploadedFile[0]->SortOrder = 1;
                                    $PropertyModel->ListingModel->UploadedFile[0]->IsSavedInDB = 2;
                                    foreach ($PropertyModel->ListingModel->UploadedFile[0] as $key => $value) {
                                        $PropertyModel->ListingModel->ImagesModel[0][$key] = $value;
                                        if ($key == 'FilePath') {
                                            $getnameArray = explode('/', $value);
                                            $PropertyModel->ListingModel->ImagesNameModel[0] = $getnameArray[count($getnameArray) - 1];
                                        }
                                    }
                                }
                            }
                            $MediaArray = array();

                            $this->CustomDeleteEntity(new TempRetsImagesEntity(), 'PropertyListingID', $propertySingle->ListingID);

                            foreach ($GetFirstImage as $key => $object) {
                                if ($object['PropMediaType'] == 'Photo' && $key > $ignoreImg) {
                                    $MediaData = array();
                                    $MediaData['PropertyListingID'] = $propertySingle->ListingID;
                                    $MediaData['UserID'] = 0;
                                    $MediaData['SiteID'] = Constants::$MercerVineSiteID;
                                    $MediaData['ListingKey'] = $propertySingle->ListingKey;
                                    $MediaData['PropObjectKey'] = $object['PropObjectKey'];
                                    $MediaData['PropMediaKey'] = $object['PropMediaKey'];
                                    $MediaData['PropMediaURL'] = $object['PropMediaURL'];

                                    array_push($MediaArray, $MediaData);
                                }
                            }

                            if (count($MediaArray) > 0) {
                                $PropertyModel->IsShowUploadNote = 1;
                                $response->Message = trans('messages.NoRETSPropertyFound');
                            } else {
                                $PropertyModel->IsShowUploadNote = 0;
                            }

                            $this->MultipleInsert(new TempRetsImagesEntity(), $MediaArray);
                        }
                    }
                    $propertyAdded = $this->SaveProperty($PropertyModel->ListingModel, Constants::$MercerVineSiteID, Constants::$StaticUserID);
                    $responseArray[] = $propertySingle->ListingID . ": " . $propertyAdded->Message;

                }
                $getLastData->cronLastIndex = $lastIndex + Config::get('config.UpdatePropertiesFromCSV');
                if($lastIndex + Config::get('config.UpdatePropertiesFromCSV') >= $MaxIndex){
                    // changed to 3 for finished
                    $getLastData->cronCSVStatus=3;
                }
                $this->SaveEntity($getLastData);
            }
            else{
                $getLastData->cronLastIndex = $lastIndex + Config::get('config.UpdatePropertiesFromCSV');
                if($lastIndex + Config::get('config.UpdatePropertiesFromCSV') >= $MaxIndex){
                    // changed to 3 for finished
                    $getLastData->cronCSVStatus=3;
                }
                $this->SaveEntity($getLastData);
            }
            $response->IsSuccess = true;
            $response->Message=$responseArray;
        }
        return $response;
    }

    // { CSV for Update property status
    public function addCSVPropertyStatus(){
        $response=new ServiceResponse();

        $datetimePrev =  DB::select("SELECT DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%d') as todayDate");
           
        $searchParam = array();
        $searchValues = Common::SetSearchArray('cronDate', $datetimePrev[0]->todayDate);
        array_push($searchParam, $searchValues);
        $searchValues = Common::SetSearchArray('cronFor', Constants::$CronCSVUpdate);
        array_push($searchParam, $searchValues);
        

        $getPrevData = $this->CallRawForSingleTable('getPrevCronData', array(Constants::$CronCSVUpdateStatus, $datetimePrev[0]->todayDate));            
        $prevCSV = "";

        $prevCSVCount = 0;
        if(isset($getPrevData[0]) && $getPrevData[0]->cronLastIndex < $getPrevData[0]->cronPropertyCount){
            $lastCronData = $getPrevData[0]->cronCSV;

            $prevCSV = substr($lastCronData, Common::strposnth($lastCronData, ',', $getPrevData[0]->cronLastIndex) + 1);
            $prevCSVArray = explode(",", $prevCSV);
            $prevCSVCount = count($prevCSVArray);

            $savePrevData = $this->CallRawForSingleTable('savePrevCronData', array($getPrevData[0]->cronId));

        }


        $config = new \PHRETS\Configuration;
        $config->setloginurl(Config::get('config.CLAW_Login_URL'));
        $config->setRetsVersion(Config::get('config.CLAW_RETS_Version'));
        $config->setUserAgent(Config::get('config.CLAW_UserAgent'));
        $config->setHttpAuthenticationMethod(Config::get('config.CLAW_Authentication_Method'));
        $config->setOption('use_post_method', false);
        $config->setOption('disable_follow_location', false);

        // get credentials from database settings table. We kept them in db so user can change easily if there is any change.
        $Credentials = $this->GetCLAWCredentials(Constants::$MercerVineSiteID);
        $config->setusername($Credentials->RETSUserName);
        $config->setpassword($Credentials->RETSPassword);
        $rets = new \PHRETS\Session($config);
        $login = $rets->Login();
        $LogArray=array();
        $LogArray=$this->StoreRetsLog(Constants::$Value_False, Constants::$MercerVineSiteID, Constants::$RETSActionLogin, Config::get('config.CLAW_Login_URL'), '', $login,$LogArray,false);
        //$getDataBaseValue = DB::select("SELECT DATE_FORMAT(DATE_SUB(CONVERT_TZ(CURDATE(), @@session.time_zone, 'UTC' ), INTERVAL 24 HOUR), '%Y-%m-%dT%H:%i:%s') AS modifiedDate,DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%dT%H:%i:%s') AS todayDate");
        $getDataBaseValue=DB::select("SELECT DATE_FORMAT(CONVERT_TZ(MAX(crondate), @@session.time_zone, 'UTC' ), '%Y-%m-%dT%H:%i:%s') AS modifiedDate,DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%dT%H:%i:%s') AS todayDate FROM `cronjobhistory` WHERE cronFor='updateStatus'");
        $resource = 'History';
        $class = 'PROP_HIST';
        //get records for last 24 hrs
        $query = '(PropHistChangeTimestamp=' . $getDataBaseValue[0]->modifiedDate . '-' . $getDataBaseValue[0]->todayDate . ')';
        $result = $rets->Search(
            $resource,
            $class,
            $query,
            [
                'QueryType' => 'DMQL2',
                'Count' => 1, // only records
                'Format' => 'COMPACT-DECODED',
                'Limit' => 'NONE',
                'StandardNames' => 0, // give system names
                'Select' => 'ListingID'//,ModificationTimestamp'
            ]
        );
        $LogArray = $this->StoreRetsLog(Constants::$Value_False, Constants::$MercerVineSiteID, Constants::$RETSActionSearch, $result->URL, '', serialize($result->toArray()),$LogArray,false);
        $Alldata = json_decode($result->toJSON());
        $totalCount=count($Alldata);
        $csv = implode(',', array_map(function ($n) {
            return $n->ListingID;
        }, $Alldata));

        if($prevCSVCount > 0){
            $csv = $csv.",".$prevCSV;
        }


        $insertCSV = new CronJobEntity();
        $insertCSV->cronDate = $getDataBaseValue[0]->todayDate;
        $insertCSV->cronCSV = $csv;
        $insertCSV->CronPropertyCount = $totalCount + $prevCSVCount;
        $insertCSV->cronFor=Constants::$CronCSVUpdateStatus;
        $insertCSV->cronCSVStatus=4;
        $saveCSV = $this->SaveEntity($insertCSV);
        if ($saveCSV) {
            $searchParam = array();
            $searchValues = Common::SetSearchArray('cronDate', date(Constants::$YMDDateFormatServerSide,strtotime($getDataBaseValue[0]->todayDate)));
            array_push($searchParam, $searchValues);
            $searchValues = Common::SetSearchArray('cronFor',Constants::$CronCSVUpdate );
            array_push($searchParam, $searchValues);
            $getLastData = $this->GetEntityForUpdateByFilter(new CronJobEntity(), $searchParam);
            $getLastData->cronCSVStatus=4;
            $this->SaveEntity($getLastData);
            $response->IsSuccess = true;
            $response->Message = "CVS added for status Update :" . $getDataBaseValue[0]->todayDate;
        } else {
            $response->IsSuccess = false;
            $response->Message = "CVS failed for status Update:" . $getDataBaseValue[0]->todayDate;
        }
        return $response;
    }
    // Update property from status update }
    public function UpdateCSVStatusProperties() {
        $response = new ServiceResponse();
        $datetime = DB::select("SELECT DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%d') as todayDate");
        $searchParam = array();
        $searchValues = Common::SetSearchArray('cronDate', $datetime[0]->todayDate);
        array_push($searchParam, $searchValues);
        $searchValues = Common::SetSearchArray('cronFor', Constants::$CronCSVUpdateStatus);
        array_push($searchParam, $searchValues);
        $getLastData = $this->GetEntityForUpdateByFilter(new CronJobEntity(), $searchParam);
        if (count($getLastData) > 0) {
            $csv = $getLastData->cronCSV;
            $lastIndex = $getLastData->cronLastIndex;
            $MaxIndex = $getLastData->cronPropertyCount;
            //$matches = preg_split('/((?:[^,]*,){15})/', $csv, -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);
            if ($lastIndex != 0 && $lastIndex <= $MaxIndex) {
                if($MaxIndex-$lastIndex <= Config::get('config.UpdatePropertiesStatusFromCSV')){
                    $finalCSV = substr($csv, Common::strposnth($csv, ',', $lastIndex) + 1);
                }
                else {
                    $ReducedCSV = substr($csv, Common::strposnth($csv, ',', $lastIndex) + 1);
                    $finalCSV = substr($ReducedCSV, 0, Common::strposnth($ReducedCSV, ',', Config::get('config.UpdatePropertiesStatusFromCSV')));
                }
            } else {
                Log::info('Update Status CSV Processing started: ' . date('Y-m-d H:i:s'));
                if(Config::get('config.UpdatePropertiesStatusFromCSV') > $MaxIndex){
                    $finalCSV = $csv;
                }else {
                    $finalCSV = substr($csv, 0, Common::strposnth($csv, ',', Config::get('config.UpdatePropertiesStatusFromCSV')));
                }
            }

            if ($finalCSV) {
                $config = new \PHRETS\Configuration;
                $config->setloginurl(Config::get('config.CLAW_Login_URL'));
                $config->setRetsVersion(Config::get('config.CLAW_RETS_Version'));
                $config->setUserAgent(Config::get('config.CLAW_UserAgent'));
                $config->setHttpAuthenticationMethod(Config::get('config.CLAW_Authentication_Method'));
                $config->setOption('use_post_method', false);
                $config->setOption('disable_follow_location', false);

                // get credentials from database settings table. We kept them in db so user can change easily if there is any change.
                $Credentials = $this->GetCLAWCredentials(Constants::$MercerVineSiteID);
                $config->setusername($Credentials->RETSUserName);
                $config->setpassword($Credentials->RETSPassword);
                $rets = new \PHRETS\Session($config);
                $login = $rets->Login();
                $LogArray=array();
                $LogArray=$this->StoreRetsLog(Constants::$Value_False, Constants::$MercerVineSiteID, Constants::$RETSActionLogin, Config::get('config.CLAW_Login_URL'), '', $login,$LogArray,false);
                $getDataBaseValue = DB::select("SELECT DATE_FORMAT(DATE_SUB(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), INTERVAL 24 HOUR), '%Y-%m-%dT%H:%i:%s') AS modifiedDate,DATE_FORMAT(CONVERT_TZ(CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%dT%H:%i:%s') AS todayDate");
                $resource = 'History';
                $class = 'PROP_HIST';
                //get records for last 24 hrs
                $query = '(PropHistChangeTimestamp=' . $getDataBaseValue[0]->modifiedDate . '-' . $getDataBaseValue[0]->todayDate . '),(ListingID='.$finalCSV.')';
                $result = $rets->Search(
                    $resource,
                    $class,
                    $query,
                    [
                        'QueryType' => 'DMQL2',
                        'Count' => 1, // only records
                        'Format' => 'COMPACT-DECODED',
                        'Limit' => 'NONE',
                        'StandardNames' => 0, // give system names
                        'Select' => 'ListingID,PropHistNewPickListValue,PropHistChangeTimestamp,BasicLocaleListingStatus'//,ModificationTimestamp'
                    ]
                );
                $LogArray = $this->StoreRetsLog(Constants::$Value_False, Constants::$MercerVineSiteID, Constants::$RETSActionSearch, $result->URL, '', serialize($result->toArray()),$LogArray,false);
                $Alldata = json_decode($result->toJSON());


               
                foreach($Alldata as $updateStatus){
                   
                    $LocalListingStatus = $updateStatus->BasicLocaleListingStatus;
                    if($LocalListingStatus == '' || $LocalListingStatus == NULL){
                        $newStatusArray=explode('-',$updateStatus->PropHistNewPickListValue);
                        $newStatus=ucfirst(strtolower($newStatusArray[0]));
                        if($newStatus=='Closed'){
                            $newStatus=Constants::$SoldStatus;
                            $updatedStatus = $this->CallRawForSingleTable('updatesoldpropertystatus', array($updateStatus->ListingID, $newStatus,$updateStatus->PropHistChangeTimestamp));
                        }
                        else {
                            if ($newStatus == 'Back up offer') {
                                $newStatus = Constants::$BackUpStatus;
                            }
                            $updatedStatus = $this->CallRawForSingleTable('updatepropertystatus', array($updateStatus->ListingID, $newStatus));
                        } 
                    }
                    else{
                        $newStatus = ucfirst(strtolower($LocalListingStatus));
                        if($newStatus=='Closed'){
                            $newStatus=Constants::$SoldStatus;
                        }
                        else if ($newStatus == 'Back up offer') {
                            $newStatus = Constants::$BackUpStatus;
                        }

                        $updatedStatus = $this->CallRawForSingleTable('updatepropertystatus', array($updateStatus->ListingID, $newStatus));
                    }
                        
                }
                $getLastData->cronLastIndex = $lastIndex + Config::get('config.UpdatePropertiesStatusFromCSV');
                if($lastIndex + Config::get('config.UpdatePropertiesStatusFromCSV') >= $MaxIndex){
                    $getLastData->cronCSVStatus=5;
                }
                $this->SaveEntity($getLastData);
                $response->IsSuccess=true;
            }
            else{
                $getLastData->cronLastIndex = $lastIndex + Config::get('config.UpdatePropertiesStatusFromCSV');
                if($lastIndex + Config::get('config.UpdatePropertiesStatusFromCSV') >= $MaxIndex){
                    $getLastData->cronCSVStatus=5;
                }
                $this->SaveEntity($getLastData);
                $response->IsSuccess=true;
            }
        }
        else {
            $response->IsSuccess=false;
        }
        return $response;
    }

    // { csv for delete
    public function addDeleteCSVtoDB() {
        $response=new ServiceResponse();

        $datetimePrev =  DB::select("SELECT DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%d') as todayDate");
           
        $searchParam = array();
        $searchValues = Common::SetSearchArray('cronDate', $datetimePrev[0]->todayDate);
        array_push($searchParam, $searchValues);
        $searchValues = Common::SetSearchArray('cronFor', Constants::$CronCSVUpdate);
        array_push($searchParam, $searchValues);
        

        $getPrevData = $this->CallRawForSingleTable('getPrevCronData', array(Constants::$CronCSVDelete, $datetimePrev[0]->todayDate));            
        $prevCSV = "";

        $prevCSVCount = 0;
        if(isset($getPrevData[0]) && $getPrevData[0]->cronLastIndex < $getPrevData[0]->cronPropertyCount){
            $lastCronData = $getPrevData[0]->cronCSV;

            $prevCSV = substr($lastCronData, Common::strposnth($lastCronData, ',', $getPrevData[0]->cronLastIndex) + 1);
            $prevCSVArray = explode(",", $prevCSV);
            $prevCSVCount = count($prevCSVArray);

            $savePrevData = $this->CallRawForSingleTable('savePrevCronData', array($getPrevData[0]->cronId));

        }



        $config = new \PHRETS\Configuration;
        $config->setloginurl(Config::get('config.CLAW_Login_URL'));
        $config->setRetsVersion(Config::get('config.CLAW_RETS_Version'));
        $config->setUserAgent(Config::get('config.CLAW_UserAgent'));
        $config->setHttpAuthenticationMethod(Config::get('config.CLAW_Authentication_Method'));
        $config->setOption('use_post_method', false);
        $config->setOption('disable_follow_location', false);

        // get credentials from database settings table. We kept them in db so user can change easily if there is any change.
        $Credentials = $this->GetCLAWCredentials(Constants::$MercerVineSiteID);
        $config->setusername($Credentials->RETSUserName);
        $config->setpassword($Credentials->RETSPassword);
        $rets = new \PHRETS\Session($config);
        $login = $rets->Login();
        $LogArray=array();
        $LogArray=$this->StoreRetsLog(Constants::$Value_False, Constants::$MercerVineSiteID, Constants::$RETSActionLogin, Config::get('config.CLAW_Login_URL'), '', $login,$LogArray,false);
        $getDataBaseValue = DB::select("SELECT DATE_FORMAT(CONVERT_TZ( MAX(crondate), @@session.time_zone, 'UTC' ), '%Y-%m-%dT%H:%i:%s') AS modifiedDate,DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%dT%H:%i:%s') AS todayDate FROM `cronjobhistory` WHERE cronFor='delete'");
        $resource = 'Deletions';
        $class = 'DELETIONS';
        //get records for last 24 hrs
        $query = '(SchemaShortName=LIS),(TableName=LISTINGS),(DeletionTimestamp=' . $getDataBaseValue[0]->modifiedDate . '-' . $getDataBaseValue[0]->todayDate . ')';
        $result = $rets->Search(
            $resource,
            $class,
            $query,
            [
                'QueryType' => 'DMQL2',
                'Count' => 1, // only records
                'Format' => 'COMPACT-DECODED',
                'Limit' => 'NONE',
                'StandardNames' => 0, // give system names
                'Select' => 'UniversalKey'//,ModificationTimestamp'
            ]
        );
        $LogArray = $this->StoreRetsLog(Constants::$Value_False, Constants::$MercerVineSiteID, Constants::$RETSActionSearch, $result->URL, '', serialize($result->toArray()),$LogArray,false);
        $Alldata = json_decode($result->toJSON());
        $totalCount=count($Alldata);
        $csv = implode(',', array_map(function ($n) {
            return $n->UniversalKey;
        }, $Alldata));

         if($prevCSVCount > 0){
            $csv = $csv.",".$prevCSV;
        }

        $insertCSV = new CronJobEntity();
        $insertCSV->cronDate = $getDataBaseValue[0]->todayDate;
        $insertCSV->cronCSV = $csv;
        $insertCSV->CronPropertyCount = $totalCount + $prevCSVCount;
        $insertCSV->cronFor=Constants::$CronCSVDelete;
        if($totalCount==0) {
            $insertCSV->cronCSVStatus = 7;
            Log::info('Delete CSV Processing Ended: ' . date('Y-m-d H:i:s'));
        }
        else {
            $insertCSV->cronCSVStatus = 6;
        }
        $saveCSV = $this->SaveEntity($insertCSV);
        if ($saveCSV) {
            $searchParam = array();
            $searchValues = Common::SetSearchArray('cronDate', date(Constants::$YMDDateFormatServerSide,strtotime($getDataBaseValue[0]->todayDate)));
            array_push($searchParam, $searchValues);
            $searchValues = Common::SetSearchArray('cronFor',Constants::$CronCSVUpdateStatus );
            array_push($searchParam, $searchValues);
            $getLastData = $this->GetEntityForUpdateByFilter(new CronJobEntity(), $searchParam);
            $getLastData->cronCSVStatus=6;
            $this->SaveEntity($getLastData);
            $response->IsSuccess = true;
            $response->Message = "CVS added for Delete :" . $getDataBaseValue[0]->todayDate;
        } else {
            $response->IsSuccess = false;
            $response->Message = "CVS failed for Delete:" . $getDataBaseValue[0]->todayDate;
        }
        return $response;
    }
    // delete properties from CSV }
    public function DeleteCSVProperties(){
        $response = new ServiceResponse();
        $datetime = DB::select("SELECT DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%d') as todayDate");
        $searchParam = array();
        $searchValues = Common::SetSearchArray('cronDate', $datetime[0]->todayDate);
        array_push($searchParam, $searchValues);
        $searchValues = Common::SetSearchArray('cronFor', Constants::$CronCSVDelete);
        array_push($searchParam, $searchValues);
        $getLastData = $this->GetEntityForUpdateByFilter(new CronJobEntity(), $searchParam);
        if (count($getLastData) > 0) {
            $csv = $getLastData->cronCSV;
            $lastIndex = $getLastData->cronLastIndex;
            $MaxIndex = $getLastData->cronPropertyCount;

            //$matches = preg_split('/((?:[^,]*,){15})/', $csv, -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);
            if ($lastIndex != 0 && $lastIndex <= $MaxIndex) {
                if($MaxIndex-$lastIndex <= Config::get('config.DeletePropertiesFromCSV')){
                    $finalCSV = substr($csv, Common::strposnth($csv, ',', $lastIndex) + 1);
                }
                else {
                    $ReducedCSV = substr($csv, Common::strposnth($csv, ',', $lastIndex) + 1);
                    $finalCSV = substr($ReducedCSV, 0, Common::strposnth($ReducedCSV, ',', Config::get('config.DeletePropertiesFromCSV')));
                }
            } else {
                Log::info('Delete CSV Processing Started: ' . date('Y-m-d H:i:s'));
                if(Config::get('config.DeletePropertiesFromCSV') > $MaxIndex){
                    $finalCSV = $csv;
                }else {
                    $finalCSV = substr($csv, 0, Common::strposnth($csv, ',', Config::get('config.DeletePropertiesFromCSV')));
                }
            }

            if($finalCSV){
                $deletedList=explode(',',$finalCSV);
                foreach($deletedList as $deleteProperty){
                    $ListingID=$this->CallRawForSingleTable('getlistingfromkey',[$deleteProperty]);
                    if(count($ListingID)>0) {
                        $this->CallRawForSingleTable('deleteproperty', [$ListingID[0]->ListingID, $ListingID[0]->SiteID]);
                    }
                }
                $getLastData->cronLastIndex = $lastIndex + Config::get('config.DeletePropertiesFromCSV');
                if($lastIndex + Config::get('config.DeletePropertiesFromCSV') >= $MaxIndex){
                    $getLastData->cronCSVStatus=7;
                }
                Log::info('Delete CSV Processing Ended: ' . date('Y-m-d H:i:s'));
                $this->SaveEntity($getLastData);
                $response->IsSuccess=true;
                $response->Message="Properties Deleted Successfully.";
            }
            else {
                $searchParam = array();
                $searchValues = Common::SetSearchArray('cronDate', $datetime[0]->todayDate);
                array_push($searchParam, $searchValues);
                $searchValues = Common::SetSearchArray('cronFor',Constants::$CronCSVDelete );
                array_push($searchParam, $searchValues);
                $getLastData = $this->GetEntityForUpdateByFilter(new CronJobEntity(), $searchParam);
                $getLastData->cronCSVStatus=7;
                Log::info('Delete CSV Processing Ended: ' . date('Y-m-d H:i:s'));
                $this->SaveEntity($getLastData);
                $response->IsSuccess=true;
            }
        }
        return $response;
    }

    // get active properties
    public function addActivePropertiesFromMLSDb()
    {
        $response = new ServiceResponse();
        $config = new \PHRETS\Configuration;

        //CLAW (Mercer Vine)
        $settingEntity= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
        $isCronJobRunning = $settingEntity->IsMLSPropertyCronRunning;
        if(!$isCronJobRunning) {
            try {
                $settingEntity->IsMLSPropertyCronRunning = true;
                $nextPage = $settingEntity->MLSPropertyActiveCounter;
                $this->SaveEntity($settingEntity);
                /* Login */
                $config->setloginurl(Config::get('config.CLAW_Login_URL'));
                $config->setRetsVersion(Config::get('config.CLAW_RETS_Version'));
                $config->setUserAgent(Config::get('config.CLAW_UserAgent'));
                $config->setHttpAuthenticationMethod(Config::get('config.CLAW_Authentication_Method'));
                $config->setOption('use_post_method', false);
                $config->setOption('disable_follow_location', false);

                // get credentials from database settings table. We kept them in db so user can change easily if there is any change.
                $Credentials = $this->GetCLAWCredentials(Constants::$MercerVineSiteID);
                $config->setusername($Credentials->RETSUserName);
                $config->setpassword($Credentials->RETSPassword);
                $rets = new \PHRETS\Session($config);
                $login = $rets->Login();
                $LogArray=array();
                $LogArray=$this->StoreRetsLog(Constants::$Value_False, Constants::$MercerVineSiteID, Constants::$RETSActionLogin, Config::get('config.CLAW_Login_URL'), '', $login,$LogArray,false);
                $resource = 'Property';
                $class = 'ALL';
                $statusField=Common::getPropertyStatusField(Constants::$MercerVineSiteID);
                $query = '(ListPrice=10000000000000-),('.$statusField.'=|'.Constants::$ActiveListingStatus.','.Constants::$ActiveContractStatus.')'; // ,~(City=.EMPTY.)';
                $result = $rets->Search(
                    $resource,
                    $class,
                    $query,
                    [
                        'QueryType' => 'DMQL2',
                        'Count' => 1, // only records
                        'Format' => 'COMPACT-DECODED',
                        'Limit' => Config::get('config.NumberOfPropertiesToGet'),// Constants::$NumberOfPropertiesToGet,
                        'Offset' => $nextPage,
                        'StandardNames' => 0, // give system names
                    ]
                );
                $LogArray = $this->StoreRetsLog(Constants::$Value_False, Constants::$MercerVineSiteID, Constants::$RETSActionSearch, $result->URL, '', serialize($result->toArray()),$LogArray,false);
                $Alldata = json_decode($result->toJSON());

                $responseArray = [];
                foreach ($Alldata as $propertySingle) {
                    $searchParam = array();
                    $searchValues = Common::SetSearchArray('MLSNo', $propertySingle->ListingID,Constants::$Value_True);
                    array_push($searchParam, $searchValues);

                    $duplicate = $this->GetEntity(new PropertyListingsEntity(), $searchParam);

                    if ($duplicate) {
                        $responseArray[] = trans('messages.PropertyDuplicate');
                        continue;
                    }

                    $PropertyModel = new stdClass();
                    $IsWBProperty=Constants::$Value_False;
                    $statusField=Common::getPropertyStatusField(Constants::$MercerVineSiteID);
                    $CheckForIsWB=Common::getPropertyOfficeID($propertySingle->ListOfficeId,Constants::$MercerVineSiteID);
                    if($CheckForIsWB){
                        $IsWBProperty=Constants::$Value_True;
                    }
                    else {
                        if($propertySingle->{$statusField}=='Closed') {
                            continue;
                        }
                    }
                    $PropertyModel->ListingModel = $this->getPropertiesFormated($propertySingle,$IsWBProperty,Constants::$MercerVineSiteID);
                    $PropertyModel->ListingModel->isCron=Constants::$Value_True;
                    if ($login) {
                        //Get Object/Image data
                        $objects = $rets->Search(
                            'Media',
                            'PROP_MEDIA',
                            '(PropObjectKey=' . $propertySingle->ListingKey . ')',
                            [
                                'QueryType' => 'DMQL2',
                                'Count' => 0,
                                'Format' => 'COMPACT-DECODED',
                                'StandardNames' => 0, // give system names
                            ]
                        );
                        $LogArray = $this->StoreRetsLog(Constants::$Value_False, Constants::$MercerVineSiteID, Constants::$RETSActionSearchMedia, $objects->URL, '', serialize($objects->toArray()), $LogArray, true);
                        // Add log for rets search property media.
                        $GetFirstImage = Common::GetArrayFilterValues($objects->toArray(), 'PropMediaType', 'Photo');
                        if(Constants::$skipFirstImageUpload==0) {
                            if (count($GetFirstImage) > 0) {
                                $ignoreImg=0;
                                try {
                                    $PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing, Constants::$Value_False, Constants::$MercerVineSiteID, $GetFirstImage[0]['PropMediaURL']);
                                }
                                catch(Exception $e)
                                {
                                    Log::info('In first catch block of first image for Listing ID: ' . $propertySingle->ListingID);
                                    $addToUploadImage=new ImageUploadErrorEntity();
                                    $addToUploadImage->MLSNo=$propertySingle->ListingID;
                                    $addToUploadImage->ImagePath=$GetFirstImage[0]['PropMediaURL'];
                                    $addToUploadImage->Errortype=Constants::$Value_True;
                                    $addToUploadImage->AddedDateTime=date(Constants::$DefaultDateTimeFormat);
                                    $this->SaveEntity($addToUploadImage);
                                    $ignoreImg = 1;
                                    try {
                                        if (count($GetFirstImage) > 1)
                                            $PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing, Constants::$Value_False, Constants::$MercerVineSiteID, $GetFirstImage[1]['PropMediaURL']);
                                    }
                                    catch(Exception $e)
                                    {
                                        Log::info('In second catch block of first image for Listing ID: ' . $propertySingle->ListingID);
                                        $addToUploadImage=new ImageUploadErrorEntity();
                                        $addToUploadImage->MLSNo=$propertySingle->ListingID;
                                        $addToUploadImage->ImagePath=$GetFirstImage[1]['PropMediaURL'];
                                        $addToUploadImage->Errortype=Constants::$Value_True;
                                        $addToUploadImage->AddedDateTime=date(Constants::$DefaultDateTimeFormat);
                                        $this->SaveEntity($addToUploadImage);
                                        $ignoreImg = 2;
                                    }
                                }
                                if($ignoreImg!=2) {
                                    $PropertyModel->ListingModel->UploadedFile[0]->SortOrder = 1;
                                    $PropertyModel->ListingModel->UploadedFile[0]->IsSavedInDB = 2;
                                    foreach ($PropertyModel->ListingModel->UploadedFile[0] as $key => $value) {
                                        $PropertyModel->ListingModel->ImagesModel[0][$key] = $value;
                                        if ($key == 'FilePath') {
                                            $getnameArray = explode('/', $value);
                                            $PropertyModel->ListingModel->ImagesNameModel[0] = $getnameArray[count($getnameArray) - 1];
                                        }
                                    }
                                }
                            }
                        }
                        $MediaArray = array();

                        $this->CustomDeleteEntity(new TempRetsImagesEntity(), 'PropertyListingID', $propertySingle->ListingID);

                        foreach ($GetFirstImage as $key => $object) {
                            if ($object['PropMediaType'] == 'Photo' && ($key > $ignoreImg || Constants::$skipFirstImageUpload==1)) {
                                $MediaData = array();
                                $MediaData['PropertyListingID'] = $propertySingle->ListingID;
                                $MediaData['UserID'] = 0;
                                $MediaData['SiteID'] = Constants::$MercerVineSiteID;
                                $MediaData['ListingKey'] = $propertySingle->ListingKey;
                                $MediaData['PropObjectKey'] = $object['PropObjectKey'];
                                $MediaData['PropMediaKey'] = $object['PropMediaKey'];
                                $MediaData['PropMediaURL'] = $object['PropMediaURL'];

                                array_push($MediaArray, $MediaData);
                            }
                        }

                        if (count($MediaArray) > 0) {
                            $PropertyModel->IsShowUploadNote = 1;
                            $response->Message = trans('messages.NoRETSPropertyFound');
                        } else {
                            $PropertyModel->IsShowUploadNote = 0;
                        }
                        $this->MultipleInsert(new TempRetsImagesEntity(), $MediaArray);
                    }
                    $propertyAdded = $this->SaveProperty($PropertyModel->ListingModel, Constants::$MercerVineSiteID, Constants::$StaticUserID);
                    $responseArray[] = $propertyAdded->Message;
                }
                $updateCounter=Config::get('config.NumberOfPropertiesToGet')+$nextPage;
                $response->Data = $responseArray;
                $settingEntity->IsMLSPropertyCronRunning = false;
                $settingEntity->MLSPropertyActiveCounter=$updateCounter;
                $this->SaveEntity($settingEntity);
            } catch(Exception $e){
                Log::info(' Adding property from MLS DB :' . date('Y-m-d H:i:s'));
                Log::error($e);
            }
        }else
        {
            return $settingEntity->IsMLSPropertyCronRunning;
        }
        return $response;
    }

    // get active and active under contract property from db
    public function addRemainingActiveProperty() {
        $response=new ServiceResponse();
        $config = new \PHRETS\Configuration;
        try{
        //CLAW (Mercer Vine)
        $settingEntity= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
        $isCronJobRunning = $settingEntity->{Constants::$RemainingActiveCheckField};
        if(!$isCronJobRunning) {
            $settingEntity->{Constants::$RemainingActiveCheckField} = true;
            $nextPage = $settingEntity->ActiveRemainingCount;
            $this->SaveEntity($settingEntity);

            $MLSNoArray=$this->CallRawForSingleTable('getremainingactive',[Config::get('config.NumberOfPropertiesToGet'),$nextPage]);
            $csv = implode(',', array_map(function ($n) {
                return $n->ListingID;
            }, $MLSNoArray));
            if($csv) {
                $config->setloginurl(Config::get('config.CLAW_Login_URL'));
                $config->setRetsVersion(Config::get('config.CLAW_RETS_Version'));
                $config->setUserAgent(Config::get('config.CLAW_UserAgent'));
                $config->setHttpAuthenticationMethod(Config::get('config.CLAW_Authentication_Method'));
                $config->setOption('use_post_method', false);
                $config->setOption('disable_follow_location', false);

                // get credentials from database settings table. We kept them in db so user can change easily if there is any change.
                $Credentials = $this->GetCLAWCredentials(Constants::$MercerVineSiteID);
                $config->setusername($Credentials->RETSUserName);
                $config->setpassword($Credentials->RETSPassword);
                $rets = new \PHRETS\Session($config);
                $login = $rets->Login();

                $LogArray = array();
                $LogArray = $this->StoreRetsLog(Constants::$Value_False, Constants::$MercerVineSiteID, Constants::$RETSActionLogin, Config::get('config.CLAW_Login_URL'), '', $login, $LogArray, false);
                $resource = 'Property';
                $class = 'ALL';
                $query = '(ListPrice=10000000000000-),(ListingID=' . $csv . ')';
                $result = $rets->Search(
                    $resource,
                    $class,
                    $query,
                    [
                        'QueryType' => 'DMQL2',
                        'Count' => 1, // only records
                        'Format' => 'COMPACT-DECODED',
                        'Limit' => 'NONE',
                        'StandardNames' => 0 // give system names
                    ]
                );
                $LogArray = $this->StoreRetsLog(Constants::$Value_False, Constants::$MercerVineSiteID, Constants::$RETSActionSearch, $result->URL, '', serialize($result->toArray()), $LogArray, false);
                $Alldata = json_decode($result->toJSON());
                $responseArray = [];
                foreach ($Alldata as $propertySingle) {
                    $IsWBProperty = Constants::$Value_False;
                    $statusField = Common::getPropertyStatusField(Constants::$MercerVineSiteID);
                    $CheckForIsWB = Common::getPropertyOfficeID($propertySingle->ListOfficeId, Constants::$MercerVineSiteID);
                    if ($CheckForIsWB) {
                        $IsWBProperty = Constants::$Value_True;
                    } else {
                        if ($propertySingle->{$statusField} == 'Closed') {
                            continue;
                        }
                    }

                    $PropertyModel = new stdClass();
                    $PropertyModel->ListingModel = $this->getPropertiesFormated($propertySingle, $IsWBProperty, Constants::$MercerVineSiteID);
                    $PropertyModel->ListingModel->isCron = Constants::$Value_True;
                    if ($login) {
                        //Get Object/Image data
                        $objects = $rets->Search(
                            'Media',
                            'PROP_MEDIA',
                            '(PropObjectKey=' . $propertySingle->ListingKey . ')',
                            [
                                'QueryType' => 'DMQL2',
                                'Count' => 0,
                                'Format' => 'COMPACT-DECODED',
                                'StandardNames' => 0, // give system names
                            ]
                        );
                        $LogArray = $this->StoreRetsLog(Constants::$Value_False, Constants::$MercerVineSiteID, Constants::$RETSActionSearchMedia, $objects->URL, '', serialize($objects->toArray()), $LogArray, true);
                        // Add log for rets search property media.
                        $GetFirstImage = Common::GetArrayFilterValues($objects->toArray(), 'PropMediaType', 'Photo');
                        if (Constants::$skipFirstImageUpload == 0) {
                            if (count($GetFirstImage) > 0) {
                                $ignoreImg = 0;
                                try {
                                    $PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing, Constants::$Value_False, Constants::$MercerVineSiteID, $GetFirstImage[0]['PropMediaURL']);
                                } catch (Exception $e) {
                                    Log::info('In first catch block of first image for Listing ID: ' . $propertySingle->ListingID);
                                    $addToUploadImage=new ImageUploadErrorEntity();
                                    $addToUploadImage->MLSNo=$propertySingle->ListingID;
                                    $addToUploadImage->ImagePath=$GetFirstImage[0]['PropMediaURL'];
                                    $addToUploadImage->Errortype=Constants::$Value_True;
                                    $addToUploadImage->AddedDateTime=date(Constants::$DefaultDateTimeFormat);
                                    $this->SaveEntity($addToUploadImage);
                                    $ignoreImg = 1;
                                    try {
                                        if (count($GetFirstImage) > 1)
                                            $PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing, Constants::$Value_False, Constants::$MercerVineSiteID, $GetFirstImage[1]['PropMediaURL']);
                                    } catch (Exception $e) {
                                        Log::info('In second catch block of first image for Listing ID: ' . $propertySingle->ListingID);
                                        $addToUploadImage=new ImageUploadErrorEntity();
                                        $addToUploadImage->MLSNo=$propertySingle->ListingID;
                                        $addToUploadImage->ImagePath=$GetFirstImage[1]['PropMediaURL'];
                                        $addToUploadImage->Errortype=Constants::$Value_True;
                                        $addToUploadImage->AddedDateTime=date(Constants::$DefaultDateTimeFormat);
                                        $this->SaveEntity($addToUploadImage);
                                        $ignoreImg = 2;
                                    }
                                }
                                if ($ignoreImg != 2) {
                                    $PropertyModel->ListingModel->UploadedFile[0]->SortOrder = 1;
                                    $PropertyModel->ListingModel->UploadedFile[0]->IsSavedInDB = 2;
                                    foreach ($PropertyModel->ListingModel->UploadedFile[0] as $key => $value) {
                                        $PropertyModel->ListingModel->ImagesModel[0][$key] = $value;
                                        if ($key == 'FilePath') {
                                            $getnameArray = explode('/', $value);
                                            $PropertyModel->ListingModel->ImagesNameModel[0] = $getnameArray[count($getnameArray) - 1];
                                        }
                                    }
                                }
                            }
                        }
                        $MediaArray = array();

                        $this->CustomDeleteEntity(new TempRetsImagesEntity(), 'PropertyListingID', $propertySingle->ListingID);

                        foreach ($GetFirstImage as $key => $object) {
                            if ($object['PropMediaType'] == 'Photo' && ($key > $ignoreImg || Constants::$skipFirstImageUpload == 1)) {
                                $MediaData = array();
                                $MediaData['PropertyListingID'] = $propertySingle->ListingID;
                                $MediaData['UserID'] = 0;
                                $MediaData['SiteID'] = Constants::$MercerVineSiteID;
                                $MediaData['ListingKey'] = $propertySingle->ListingKey;
                                $MediaData['PropObjectKey'] = $object['PropObjectKey'];
                                $MediaData['PropMediaKey'] = $object['PropMediaKey'];
                                $MediaData['PropMediaURL'] = $object['PropMediaURL'];

                                array_push($MediaArray, $MediaData);
                            }
                        }

                        if (count($MediaArray) > 0) {
                            $PropertyModel->IsShowUploadNote = 1;
                            $response->Message = trans('messages.NoRETSPropertyFound');
                        } else {
                            $PropertyModel->IsShowUploadNote = 0;
                        }
                        $this->MultipleInsert(new TempRetsImagesEntity(), $MediaArray);
                    }
                    $propertyAdded = $this->SaveProperty($PropertyModel->ListingModel, Constants::$MercerVineSiteID, Constants::$StaticUserID);
                    $responseArray[] = $propertyAdded->Message;
                }
                $updateCounter = Config::get('config.NumberOfPropertiesToGet') + $nextPage;
                $response->Data = $responseArray;
                $settingEntity->{Constants::$RemainingActiveCheckField} = false;
                $settingEntity->ActiveRemainingCount = $updateCounter;
                $this->SaveEntity($settingEntity);
            }
            else {
                $response->Message = 'No more csv';
            }
            }
        } catch (Exception $e) {
            Log::info(' Adding property from MLS DB :' . date('Y-m-d H:i:s'));
            Log::error($e);
        }
        return $response;
    }


    /* Dev_UP Region Start */
    public function getFailedImageCron()
    {
        $response=new ServiceResponse();
        $dateTime = date(Constants::$DefaultDateTimeFormat);
        
        /*$config = new \PHRETS\Configuration;*/
        try{
               if (Common::SetCronJobRunning(Constants::$RemainingFailedActiveCheckField)) {
                   try {
                       $settingEntity = $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(), '1');
                       $nextPage = $settingEntity->ActiveRemainingCount;

                       $MLSNoArray = $this->CallRawForSingleTable('getremainingfailedimaged', [Config::get('config.NumberOfPropertiesToGet'), $nextPage]);
                            /*$csv = implode(',', array_map(function ($n) {
                                return $n->ListingID;
                            }, $MLSNoArray));
                            */
                       $data = array();
                       $responseArray = [];
                       foreach ($MLSNoArray AS $keymls => $valmls) {

                           $ImageUploadErrorEntityEntity = $this->GetEntityForUpdateByPrimaryKey(new ImageUploadErrorEntity(), $valmls->ImageUploadErrorID);
                           if ($valmls->IsProcessed == '') {
                               $checkAlredyExistSingleImage = $this->CallRawForSingleTable('checkalreadyexistanyimage', [$valmls->ListingID, 1]);
                                if($checkAlredyExistSingleImage[0]->totalImage == 0)
                                {
                                   try {
                                       $ImageUploadErrorEntityEntity->isProcessed = 1;
                                       $this->SaveEntity($ImageUploadErrorEntityEntity);

                                       $PropertyModel = $this->FileUpload(Constants::$AWSRequestType_Listing, Constants::$Value_False, Constants::$MercerVineSiteID, $valmls->ImagePath);

                                       if (count($PropertyModel)) {

                                           $getMaxImageSortorder = $this->CallRawForSingleTable('getmaxsortorder', [$valmls->ListingID, 1]);

                                           //Upload images
                                           if (!is_null($PropertyModel->FileName)) {
                                               $processData = array(
                                                   'ListingID' => $valmls->ListingID,
                                                   'SiteID' => Constants::$MercerVineSiteID,
                                                   'FileName' => $PropertyModel->FileName,//$imageData['FileName'],
                                                   'FilePath' => $PropertyModel->FilePath,//$imageData['FilePath'],
                                                   'FileSize' => $PropertyModel->FileSize,//$imageData['FileSize'],
                                                   'SortOrder' => $getMaxImageSortorder[0]->SortOrder + 1,
                                                   'CreatedDate' => $dateTime,
                                                   'ModifiedDate' => $dateTime,
                                                   'CreatedByID' => NULL,
                                                   'ModifiedByID' => NULL
                                               );

                                               array_push($data, $processData);
                                               $ImageUploadErrorEntityEntity->IsSuccess = 1;
                                               //$ImageUploadErrorEntityEntity -> isProcessed = NULL;
                                               $this->SaveEntity($ImageUploadErrorEntityEntity);

                                           }
                                       }

                            } 
                            catch (Exception $e) {
                               /*$ImageUploadErrorEntityEntity -> isProcessed = NULL;
                               $this->SaveEntity($ImageUploadErrorEntityEntity);*/

                                   Log::info(' Adding failed images :' . date('Y-m-d H:i:s'));
                                   Log::error($e);
                                   }

                               }
                           }
                       }

                       if (count($data)) {
                           $propertyImageAdded = $this->MultipleInsert(new PropertyListingImagesEntity(), $data);
                    
                    //$responseArray[] = $propertyImageAdded;

                           $response->Data = $responseArray;
                           $response->Message = count($data) . ' image uploaded';
                           $response->IsSuccess = true;
                       }
                   }catch (Exception $e){
                       Log::info(' Adding failed images :' . date('Y-m-d H:i:s'));
                       Log::error($e);
                   }
                   Common::UnsetCronJobRunning(Constants::$RemainingFailedActiveCheckField);

               }
        }
        catch (Exception $e) {
            Log::info(' Adding failed images :' . date('Y-m-d H:i:s'));
            Log::error($e);
            Common::UnsetCronJobRunning(Constants::$RemainingFailedActiveCheckField);
        }
        return $response;      
    }

    public function getFailedPropertyImagesInterventionCron(){
        $response=new ServiceResponse();

        /*$dateTime = date(Constants::$DefaultDateTimeFormat);
        $config = new \PHRETS\Configuration;*/
        try {

            if(Common::SetCronJobRunning(Constants::$RemainingFailedInterventionActiveCheckField)) {
                try{
                        $settingEntity = $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
                        $nextPage = $settingEntity->ActiveRemainingCount;

                        $imageCount = Config::get('config.NumberOfPropertyImagesIntervention');
                        $imagesInterventionData = $this->CallRawForSingleTable('propertyfailedimagesinterventioncron', [$imageCount]);

                        if (!empty($imagesInterventionData)) {
                            foreach ($imagesInterventionData as $imageInfo) {

                                $imageDimensionArray = Common::getImageInterventionDimensionArray(Constants::$MercerVineSiteID, $imageInfo->IsWBProperty);

                                if ($imageDimensionArray) {
                                    $count = 0;
                                    foreach ($imageDimensionArray as $dimension) {

                                        $fullImagePath = $imageInfo->ImagePath;//Config::get('aws.AWSUrl') . Config::get('aws.AWSBucketName') . '/' .$imageInfo->ImageURL;
                                        try {

                                            $updateCropAttempt = $this->GetEntityForUpdateByPrimaryKey(new ImageUploadErrorEntity(), $imageInfo->ImageUploadErrorID);
                                            $updateCropAttempt->isProcessed = 1;
                                            $this->SaveEntity($updateCropAttempt);

                                            Common::ImageIntervention($fullImagePath, $dimension, '', 0);
                                            $count++;

                                        } catch (Exception $e) {
                                            $updateCropAttempt = $this->GetEntityForUpdateByPrimaryKey(new ImageUploadErrorEntity(), $imageInfo->ImageUploadErrorID);
                                            if ($updateCropAttempt->CropAttempt < Constants::$maxImageUploadAttempt && $count == count($imageDimensionArray)) {
                                                $updateCropAttempt->CropAttempt = $updateCropAttempt->CropAttempt + 1;
                                                $this->SaveEntity($updateCropAttempt);
                                                /*if($updateCropAttempt->CropAttempt == Constants::$maxImageUploadAttempt){
                                                    $addToUploadImage = new ImageUploadErrorEntity();
                                                    $addToUploadImage->ListingID = $imageInfo->ListingID;
                                                    $addToUploadImage->ImagePath = Config::get('aws.AWSUrl') . Config::get('aws.AWSBucketName') . '/' .$imageInfo->ImageURL;
                                                    $addToUploadImage->Errortype = 2;
                                                    $addToUploadImage->AddedDateTime = date(Constants::$DefaultDateTimeFormat);
                                                    $this->SaveEntity($addToUploadImage);
                                                }*/

                                            }
                                        }
                                    }
                                    if ($count == 5) {
                                        $updateCropAttempt = $this->GetEntityForUpdateByPrimaryKey(new ImageUploadErrorEntity(), $imageInfo->ImageUploadErrorID);
                                        $updateCropAttempt->IsSuccess = 1;
                                        $this->SaveEntity($updateCropAttempt);
                                    }

                                    //$this->CallRawForSingleTable('deletepropertyimagesintervention', [$imageInfo->ID]);
                                }
                            }
                            $response->IsSuccess = true;
                        }
                }
                catch (Exception $e) {
                    Log::info(' Adding failed images :' . date('Y-m-d H:i:s'));
                    Log::error($e);
                }
                Common::UnsetCronJobRunning(Constants::$RemainingFailedInterventionActiveCheckField);

            } 

            }
        catch (Exception $e) {
                Log::info(' Adding failed images :' . date('Y-m-d H:i:s'));
                Log::error($e);
            Common::UnsetCronJobRunning(Constants::$RemainingFailedInterventionActiveCheckField);
        }
        return $response;
    }
    /* Dev_UP Region End */

    /************* Colorado Property Start **************/

    /* Dev_KT Region start */
    public function COGetPropertyLookUps($ListingID,$SiteID,$AgentRoleID,$userActiveStatus,$loginUserID){
        $response = new ServiceResponse();
        $Model = new stdClass();
        $PropertyModel = new stdClass();
        $LookupResult = $this->CallRawForMultipleTable('co_propertylookups', array($ListingID, $SiteID, $AgentRoleID, $userActiveStatus));

        /* get lookup values*/
        $PropertyModel->Areas=$LookupResult[0];
        $PropertyModel->Classes=$LookupResult[1];
        $PropertyModel->MajorAreas=$LookupResult[2];
        $PropertyModel->memberAssociations=$LookupResult[3];
        $PropertyModel->Possessions=$LookupResult[4];
        $PropertyModel->StreetSuffixes=$LookupResult[5];
        $PropertyModel->SubLocs=$LookupResult[6];
        $PropertyModel->Agents=$LookupResult[7];
        $PropertyModel->HoaAmenities=$LookupResult[8];
        $PropertyModel->Accesses=$LookupResult[9];
        $PropertyModel->Amenities=$LookupResult[10];
        $PropertyModel->ApprovalFeatures=$LookupResult[11];
        $PropertyModel->BuildingSqFt=$LookupResult[12];
        $PropertyModel->Carports=$LookupResult[13];
        $PropertyModel->Conditions=$LookupResult[14];
        $PropertyModel->ConstructExterior=$LookupResult[15];
        $PropertyModel->Construction=$LookupResult[16];
        $PropertyModel->Coolings=$LookupResult[17];
        $PropertyModel->CurrentUses=$LookupResult[18];
        $PropertyModel->Deeds=$LookupResult[19];
        $PropertyModel->Disclousures=$LookupResult[20];
        $PropertyModel->Electrics=$LookupResult[21];
        $PropertyModel->EnergyEfficiency=$LookupResult[22];
        $PropertyModel->Exclusions=$LookupResult[23];
        $PropertyModel->Exteriors=$LookupResult[24];
        $PropertyModel->Extras=$LookupResult[25];
        $PropertyModel->FirePlaces=$LookupResult[26];
        $PropertyModel->Furnishes=$LookupResult[27];
        $PropertyModel->Garages=$LookupResult[28];
        $PropertyModel->Gases=$LookupResult[29];
        $PropertyModel->GreenFeatures=$LookupResult[30];
        $PropertyModel->HeatingAndCoolings=$LookupResult[31];
        $PropertyModel->Heatings=$LookupResult[32];
        $PropertyModel->SubStructures=$LookupResult[33];
        $PropertyModel->HowSold=$LookupResult[34];
        $PropertyModel->Inclusion=$LookupResult[35];
        $PropertyModel->IndoorAirQuality=$LookupResult[36];
        $PropertyModel->Laundry=$LookupResult[37];
        $PropertyModel->LeedCertified=$LookupResult[38];
        $PropertyModel->LeedForHome=$LookupResult[39];
        $PropertyModel->LocationAmenity=$LookupResult[40];
        $PropertyModel->LotDescription=$LookupResult[41];
        $PropertyModel->LotSize=$LookupResult[42];
        $PropertyModel->LowerLevel=$LookupResult[43];
        $PropertyModel->MainLevel=$LookupResult[44];
        $PropertyModel->OtherCooling=$LookupResult[45];
        $PropertyModel->OwnershipInterest=$LookupResult[46];
        $PropertyModel->ParkingArea=$LookupResult[47];
        $PropertyModel->Parking=$LookupResult[48];
        $PropertyModel->PossibleUse=$LookupResult[49];
        $PropertyModel->PreFabricatedHome=$LookupResult[50];
        $PropertyModel->RentalTerms=$LookupResult[51];
        $PropertyModel->Roofs=$LookupResult[52];
        $PropertyModel->Sanitation=$LookupResult[53];
        $PropertyModel->SeasonalInterest=$LookupResult[54];
        $PropertyModel->State=$LookupResult[55];
        $PropertyModel->Status=$LookupResult[56];
        $PropertyModel->Style=$LookupResult[57];
        $PropertyModel->SubType=$LookupResult[58];
        $PropertyModel->SustainableMaterial=$LookupResult[59];
        $PropertyModel->TermsOffered=$LookupResult[60];
        $PropertyModel->Type=$LookupResult[61];
        $PropertyModel->UnitFace=$LookupResult[62];
        $PropertyModel->Unit=$LookupResult[63];
        $PropertyModel->UnitSqFtRange=$LookupResult[64];
        $PropertyModel->UpperLevel=$LookupResult[65];
        $PropertyModel->WaterEfficiency=$LookupResult[66];
        $PropertyModel->WaterRight=$LookupResult[67];
        $PropertyModel->Water=$LookupResult[68];
        $PropertyModel->LotImprovements=$LookupResult[69];
        $PropertyModel->MineralRights=$LookupResult[70];
        $PropertyModel->ShowingInstructions=$LookupResult[71];
        $PropertyModel->StreetDirectionPfx=$LookupResult[125];
        /* get lookup values*/

        /* get Property detail */
        $PropertyModel->ListingModel = $LookupResult[72][0];

        if (is_null($PropertyModel->ListingModel->StateID) || $PropertyModel->ListingModel->StateID == '')
            $PropertyModel->ListingModel->StateID = (($SiteID == Constants::$MercerVineSiteID ? Constants::$DefaultMVStateID : ($SiteID == Constants::$ColoradoSiteID ? Constants::$DefaultColoradoStateID : '')));
        if (is_null($PropertyModel->ListingModel->IsHidden) || $PropertyModel->ListingModel->IsHidden == '')
            $PropertyModel->ListingModel->IsHidden = 0;
        /* get Property detail */

        /* get data for edit property */
        $PropertyModel->ListingModel->Accesses = array_map(function ($v)  { return $v->AccessID; },$LookupResult[73]);
        $PropertyModel->ListingModel->Amenities = array_map(function ($v)  { return $v->AmenityID; },$LookupResult[74]);
        $PropertyModel->ListingModel->Carports = array_map(function ($v)  { return $v->CarportID; },$LookupResult[75]);
        $PropertyModel->ListingModel->Conditions = array_map(function ($v)  { return $v->ConditionID; },$LookupResult[76]);
        $PropertyModel->ListingModel->ConstructExterior = array_map(function ($v)  { return $v->ConstructExteriorID; },$LookupResult[77]);
        $PropertyModel->ListingModel->Construction = array_map(function ($v)  { return $v->ConstructionID; },$LookupResult[78]);
        $PropertyModel->ListingModel->CurrentUses = array_map(function ($v)  { return $v->CurrentUseID; },$LookupResult[79]);
        $PropertyModel->ListingModel->Deeds = array_map(function ($v)  { return $v->DeedID; },$LookupResult[80]);
        $PropertyModel->ListingModel->Disclousures = array_map(function ($v)  { return $v->DisclosureID; },$LookupResult[81]);
        $PropertyModel->ListingModel->Electrics = array_map(function ($v)  { return $v->ElectricID; },$LookupResult[82]);
        $PropertyModel->ListingModel->EnergyEfficiency = array_map(function ($v)  { return $v->EnergyEfficiencyID; },$LookupResult[83]);
        $PropertyModel->ListingModel->Exclusions = array_map(function ($v)  { return $v->ExclusionID; },$LookupResult[84]);
        $PropertyModel->ListingModel->Exteriors = array_map(function ($v)  { return $v->ExteriorID; },$LookupResult[85]);
        $PropertyModel->ListingModel->Extras = array_map(function ($v)  { return $v->ExtraID; },$LookupResult[86]);
        $PropertyModel->ListingModel->FirePlaces = array_map(function ($v)  { return $v->FireplaceID; },$LookupResult[87]);
        $PropertyModel->ListingModel->Garages = array_map(function ($v)  { return $v->GarageID; },$LookupResult[88]);
        $PropertyModel->ListingModel->Gases = array_map(function ($v)  { return $v->GasID; },$LookupResult[89]);
        $PropertyModel->ListingModel->GreenFeatures = array_map(function ($v)  { return $v->GreenFeatureID; },$LookupResult[90]);
        $PropertyModel->ListingModel->HeatingAndCoolings = array_map(function ($v)  { return $v->HeatingAndCoolingID; },$LookupResult[91]);
        $PropertyModel->ListingModel->Heatings = array_map(function ($v)  { return $v->HeatingID; },$LookupResult[92]);
        $PropertyModel->ListingModel->HoaAmenities = array_map(function ($v)  { return $v->HOAAmenityID; },$LookupResult[93]);
        $PropertyModel->ListingModel->HowSold = array_map(function ($v)  { return $v->HowSoldID; },$LookupResult[94]);
        $PropertyModel->ListingModel->Inclusion = array_map(function ($v)  { return $v->InclusionID; },$LookupResult[95]);
        $PropertyModel->ListingModel->IndoorAirQuality = array_map(function ($v)  { return $v->IndoorAirQualityID; },$LookupResult[96]);
        $PropertyModel->ListingModel->Laundry = array_map(function ($v)  { return $v->LaundryID; },$LookupResult[97]);
        $PropertyModel->ListingModel->LeedCertified = array_map(function ($v)  { return $v->LeedCertifiedID; },$LookupResult[98]);
        $PropertyModel->ListingModel->LeedForHome = array_map(function ($v)  { return $v->LeedforHomeID; },$LookupResult[99]);
        $PropertyModel->ListingModel->LocationAmenity = array_map(function ($v)  { return $v->LocationAmenityID; },$LookupResult[100]);
        $PropertyModel->ListingModel->LotDescription = array_map(function ($v)  { return $v->LotDescriptionID; },$LookupResult[101]);
        $PropertyModel->ListingModel->LotImprovements = array_map(function ($v)  { return $v->LotImprovementID; },$LookupResult[102]);
        $PropertyModel->ListingModel->LowerLevel = array_map(function ($v)  { return $v->LowerLevelID; },$LookupResult[103]);
        $PropertyModel->ListingModel->MainLevel = array_map(function ($v)  { return $v->MainLevelID; },$LookupResult[104]);
        $PropertyModel->ListingModel->MineralRights = array_map(function ($v)  { return $v->MineralRightID; },$LookupResult[105]);
        $PropertyModel->ListingModel->OtherCooling = array_map(function ($v)  { return $v->OtherCoolingID; },$LookupResult[106]);
        $PropertyModel->ListingModel->Parking = array_map(function ($v)  { return $v->ParkingID; },$LookupResult[107]);
        $PropertyModel->ListingModel->ParkingArea = array_map(function ($v)  { return $v->ParkingAreaID; },$LookupResult[108]);
        $PropertyModel->ListingModel->Possessions = array_map(function ($v)  { return $v->PossessionID; },$LookupResult[109]);
        $PropertyModel->ListingModel->PossibleUse = array_map(function ($v)  { return $v->PossibleUseID; },$LookupResult[110]);
        $PropertyModel->ListingModel->Roofs = array_map(function ($v)  { return $v->RoofID; },$LookupResult[111]);
        $PropertyModel->ListingModel->Sanitation = array_map(function ($v)  { return $v->SanitationID; },$LookupResult[112]);
        $PropertyModel->ListingModel->ShowingInstructions = array_map(function ($v)  { return $v->ShowingInstructionID; },$LookupResult[113]);
        $PropertyModel->ListingModel->Style = array_map(function ($v)  { return $v->StyleID; },$LookupResult[114]);
        $PropertyModel->ListingModel->SubStructures = array_map(function ($v)  { return $v->SubstructureID; },$LookupResult[115]);
        $PropertyModel->ListingModel->SustainableMaterial = array_map(function ($v)  { return $v->SustainableMaterialID; },$LookupResult[116]);
        $PropertyModel->ListingModel->TermsOffered = array_map(function ($v)  { return $v->TermsOfferedID; },$LookupResult[117]);
        $PropertyModel->ListingModel->UnitFace = array_map(function ($v)  { return $v->UnitFaceID; },$LookupResult[118]);
        $PropertyModel->ListingModel->UpperLevel = array_map(function ($v)  { return $v->UpperLevelID; },$LookupResult[119]);
        $PropertyModel->ListingModel->WaterEfficiency = array_map(function ($v)  { return $v->WaterEfficiencyID; },$LookupResult[120]);
        $PropertyModel->ListingModel->Water = array_map(function ($v)  { return $v->WaterID; },$LookupResult[121]);
        $PropertyModel->ListingModel->WaterRight = array_map(function ($v)  { return $v->WaterRightID; },$LookupResult[122]);
        $PropertyModel->ListingModel->AllowableUses = array_map(function ($v)  { return $v->AllowableUsesID; },$LookupResult[126]);
        /* get data for edit property */
        /* image*/
        $PropertyModel->ListingModel->UploadedFile = isset($LookupResult[123]) ? $LookupResult[123] : '';

        $PropertyModel->FileUploadSettings = $this->FileUploadSettings(Constants::$AWSRequestType_Listing, $SiteID, $loginUserID);

        $PropertyModel->IsShowUploadNote = $LookupResult[124][0]->IsShowUploadNote;
        /* image*/

        $Model->PropertyModel = $PropertyModel;
        $response->Data = $Model;
        return $response;
    }

    public function COGetClassPropertyLookUps($ClassID){
        $response = new ServiceResponse();
        $Model = new stdClass();
        $PropertyModel = new stdClass();
        $LookupResult = $this->CallRawForMultipleTable('co_classpropertylookup', array($ClassID));

        $PropertyModel->HoaAmenities=$LookupResult[0];
        $PropertyModel->Accesses=$LookupResult[1];
        $PropertyModel->Amenities=$LookupResult[2];
        $PropertyModel->ApprovalFeatures=$LookupResult[3];
        $PropertyModel->BuildingSqFt=$LookupResult[4];
        $PropertyModel->Carports=$LookupResult[5];
        $PropertyModel->Conditions=$LookupResult[6];
        $PropertyModel->ConstructExterior=$LookupResult[7];
        $PropertyModel->Construction=$LookupResult[8];
        $PropertyModel->Coolings=$LookupResult[9];
        $PropertyModel->CurrentUses=$LookupResult[10];
        $PropertyModel->Deeds=$LookupResult[11];
        $PropertyModel->Disclousures=$LookupResult[12];
        $PropertyModel->Electrics=$LookupResult[13];
        $PropertyModel->EnergyEfficiency=$LookupResult[14];
        $PropertyModel->Exclusions=$LookupResult[15];
        $PropertyModel->Exteriors=$LookupResult[16];
        $PropertyModel->Extras=$LookupResult[17];
        $PropertyModel->FirePlaces=$LookupResult[18];
        $PropertyModel->Furnishes=$LookupResult[19];
        $PropertyModel->Garages=$LookupResult[20];
        $PropertyModel->Gases=$LookupResult[21];
        $PropertyModel->GreenFeatures=$LookupResult[22];
        $PropertyModel->HeatingAndCoolings=$LookupResult[23];
        $PropertyModel->Heatings=$LookupResult[24];
        $PropertyModel->SubStructures=$LookupResult[25];
        $PropertyModel->HowSold=$LookupResult[26];
        $PropertyModel->Inclusion=$LookupResult[27];
        $PropertyModel->IndoorAirQuality=$LookupResult[28];
        $PropertyModel->Laundry=$LookupResult[29];
        $PropertyModel->LeedCertified=$LookupResult[30];
        $PropertyModel->LeedForHome=$LookupResult[31];
        $PropertyModel->LocationAmenity=$LookupResult[32];
        $PropertyModel->LotDescription=$LookupResult[33];
        $PropertyModel->LotSize=$LookupResult[34];
        $PropertyModel->LowerLevel=$LookupResult[35];
        $PropertyModel->MainLevel=$LookupResult[36];
        $PropertyModel->OtherCooling=$LookupResult[37];
        $PropertyModel->OwnershipInterest=$LookupResult[38];
        $PropertyModel->ParkingArea=$LookupResult[39];
        $PropertyModel->Parking=$LookupResult[40];
        $PropertyModel->PossibleUse=$LookupResult[41];
        $PropertyModel->PreFabricatedHome=$LookupResult[42];
        $PropertyModel->RentalTerms=$LookupResult[43];
        $PropertyModel->Roofs=$LookupResult[44];
        $PropertyModel->Sanitation=$LookupResult[45];
        $PropertyModel->SeasonalInterest=$LookupResult[46];
        $PropertyModel->State=$LookupResult[47];
        $PropertyModel->Style=$LookupResult[48];
        $PropertyModel->SubType=$LookupResult[49];
        $PropertyModel->SustainableMaterial=$LookupResult[50];
        $PropertyModel->TermsOffered=$LookupResult[51];
        $PropertyModel->Type=$LookupResult[52];
        $PropertyModel->UnitFace=$LookupResult[53];
        $PropertyModel->Unit=$LookupResult[54];
        $PropertyModel->UnitSqFtRange=$LookupResult[55];
        $PropertyModel->UpperLevel=$LookupResult[56];
        $PropertyModel->WaterEfficiency=$LookupResult[57];
        $PropertyModel->WaterRight=$LookupResult[58];
        $PropertyModel->Water=$LookupResult[59];
        $PropertyModel->LotImprovements=$LookupResult[60];
        $PropertyModel->MineralRights=$LookupResult[61];
        $PropertyModel->ShowingInstructions=$LookupResult[62];
        $PropertyModel->ListingModel= new stdClass();
        $PropertyModel->ListingModel->StateID = $LookupResult[63][0]->StateID;
        /* get Property detail */

        $Model->PropertyModel = $PropertyModel;
        $response->Data = $Model;
        return $response;
    }

    public function CoSaveProperty($propModel, $siteID, $loggedInUserID){

        
        $dateTime = date(Constants::$DefaultDateTimeFormat);
        $response = new ServiceResponse();
        $messages = array(
            'required' => trans('messages.PropertyRequired'),
            'min' => trans('messages.PropertyMin'),
            'max' => trans('messages.PropertyMax'),
        );
        $isEditMode = false;
        if ($propModel->CoListingID > 0) {
            $isEditMode = true;
        }
        $entity = new CoPropertyListingsEntity();

        if((property_exists($propModel,'IsWBProperty') && $propModel->IsWBProperty ==0)) {
            // to skip server side validation for cron mls property
        }
        else {
            $validator = Validator::make((array)$propModel, $isEditMode == true ? CoPropertyListingsEntity::$Edit_rules : CoPropertyListingsEntity::$Add_rules, $messages);
            $validator->setAttributeNames(PropertyListingsEntity::$niceNameArray);
            if ($validator->fails()) {
                $response->Message = Common::getValidationMessagesFormat($validator->messages());
                return $response;
            }
        }
        $propModel = $this->SetEntityAttributes($entity, $propModel, true);
        if(!$isEditMode) {
            $propModel['CreatedByID'] = $loggedInUserID;
        }
        $propModel['ModifiedByID']=$loggedInUserID;
        $propModel['ModifiedDate']=$dateTime;
        $propModel['CreatedDate']=$dateTime;

        /* manage image names */
        if(array_key_exists('ImagesNameModel',$propModel)) {
            if (is_array($propModel['ImagesNameModel'])) {
                $keys = array_flip($propModel['ImagesNameModel']);
            } else {
                $keys = $propModel['ImagesNameModel'];
            }
        }

        if(array_key_exists('ImagesModel',$propModel) && is_array($propModel['ImagesModel'])) {
            usort($propModel['ImagesModel'], function ($a, $b) use ($keys) {
                return $keys[@array_pop(explode("/", $a['FilePath']))] - $keys[@array_pop(explode("/", $b['FilePath']))];
            });
        }
        $uploadImages = (array_key_exists('ImagesModel',$propModel) && is_array($propModel['ImagesModel']))?$propModel['ImagesModel']:array();
        $StreetSuffixName='';
        $stateName='';
        $StateISO='';
        $StreetDirectionPfxName='';
        if($propModel['StreetSuffixID']!='') {
            $StreetSuffix = $this->RunQueryStatement('select `StreetSuffix` from `co_lu_streetsuffixes` where StreetSuffixID='.$propModel['StreetSuffixID'],Constants::$QueryType_Select);
            if(count($StreetSuffix)>0) {
                $StreetSuffixName = $StreetSuffix[0]->StreetSuffix;
            }
        }
        if($propModel['StreetDirectionPfxID']!='') {
            $propModel['StreetDirectionPfxID'] = (int) $propModel['StreetDirectionPfxID'];
            $StreetDirectionPfx = $this->RunQueryStatement('select `StreetDirectionPfx` from `co_lu_streetdirectionpfx` where StreetDirectionPfxID='.$propModel['StreetDirectionPfxID'],Constants::$QueryType_Select);
            if(count($StreetDirectionPfx)>0) {
                $StreetDirectionPfxName = $StreetDirectionPfx[0]->StreetDirectionPfx;
            }
        }
        if($propModel['StateID']!='') {
            $state = $this->RunQueryStatement('select `State`,`StateISO` from `co_lu_states` where StateID='.$propModel['StateID'],Constants::$QueryType_Select);
            if(count($state)>0) {
                $stateName = $state[0]->State;
                $StateISO= $state[0]->StateISO;
            }
        }

        // street# (street direction pfx) Street (Street Suffix)#(Address 2/Unit #), City, State, Postal Code
        $propModel['FullStreetAddress']=$propModel['StreetNo']." ";
        if($StreetDirectionPfxName!='')
            $propModel['FullStreetAddress'].=$StreetDirectionPfxName." ";
        $propModel['FullStreetAddress'] .= $propModel['Street'];

        if($StreetSuffixName!='')
            $propModel['FullStreetAddress'].=" ".$StreetSuffixName;

        $propModel['FullAddress2']=$propModel['FullStreetAddress'];
        if($propModel['Address2ORUnit']!='')
            $propModel['FullAddress2'].='#'.$propModel['Address2ORUnit'];

        $slugAddress=$propModel['FullAddress2'].", ".$propModel['City'].', '.$StateISO." ".$propModel['ZipCode'];
        $propModel['FullAddressSlug'] = Common::GetFullAddressSlug($slugAddress); // slug

        $propModel['FullAddress2'].=", ".$propModel['City'].', '.$stateName;
        $propModel['FullAddress1'] = $propModel['FullAddress2']." ".$propModel['ZipCode'];


        if(empty($propModel['GeoLat']) && empty($propModel['GeoLon'])){
            $address = str_replace(' ', '',trim($propModel['FullStreetAddress']));
            if(isset($stateName)){
                $sateName = str_replace(' ','',$stateName);
            }else{
                $sateName='';
            }
            if(!empty($propModel['City'])){
                $city = str_replace(' ','',trim($propModel['City']));
            }else{
                $city='';
            }
            if(!empty($propModel['ZipCode'])){
                $zip = str_replace(' ','',trim($propModel['ZipCode']));
            }else{
                $zip='';
            }
            $data = DB::table('sites')->where('SiteID','=',Constants::$ColoradoSiteID)->select('GeoAPIKey')->get();
            $geoAPIKey = $data[0]->GeoAPIKey;
            $latLong = Common::getLatLong($address.','.$city.','.$sateName.'-'.$zip, $geoAPIKey);

            if(isset($latLong->Latitude))
                $propModel['GeoLat'] = $latLong->Latitude;
            if(isset($latLong->Longitude))
                $propModel['GeoLon'] = $latLong->Longitude;
        }
        if(array_key_exists('IsWBProperty',$propModel)){
             if($propModel['IsWBProperty']==null && $propModel['IsWBProperty']!==0) {
                $propModel['IsWBProperty'] = 1;
             }
             else if ($propModel['IsWBProperty']==1){
                 $propModel['IsWBProperty'] = 1;
             }
            else {
                $propModel['IsWBProperty'] = 0;
            }
        }
        else {
            $propModel['IsWBProperty'] = 1;
        }
        /*if(array_key_exists('IsWBProperty',$propModel) && ($propModel['IsWBProperty'] !=0 || $propModel['IsWBProperty']=='')){
           $propModel['IsWBProperty']=1;
        }*/

        unset($propModel['ImagesModel']);
        unset($propModel['ImagesNameModel']);
        unset($propModel['ViewedCount']);
        //unset($propModel['IsWBProperty']);
        unset($propModel['UploadedFile']);
        unset($propModel['fetchImage']);
        unset($propModel['FilePath']);

        $arrayParam = array_values(array_map(function ($a) {
            return implode(".", (array)$a);
        }, (array)$propModel));
        
        $result = $this->CallRawForSingleTable('co_saveproperty', $arrayParam);

        if(isset($arrayParam[0]) && !empty($arrayParam[0]) && $arrayParam[0] > 0 ){
            CacheHelper::CacheManage($siteID,Constants::$cachePropertyID,Constants::$cacheActionUpdate,$arrayParam[0]);
        }else{
            if(isset($result[0]->CoListingID) && !empty($result[0]->CoListingID) && $result[0]->CoListingID > 0 ) {
                CacheHelper::CacheManage($siteID, Constants::$cachePropertyID, Constants::$cacheActionInsert, $result[0]->CoListingID);
            }
        }

        if ($result[0]->ResultStatus == 1) {
            //Duplicate
            $response->Message = trans('messages.PropertyDuplicate');
        }
        else if ($result[0]->ResultStatus == 2) {

            if (!$isEditMode) {
                $propModel['CoListingID'] = $result[0]->CoListingID;
            }

            //Upload images
            $data = array();
            if (is_array($uploadImages)) {
                foreach ($uploadImages as $key => $imageData) {

                    if (!is_null($imageData['FileName'])) {
                        $processData = array(
                            'CoListingID' => $propModel['CoListingID'],
                            'FileName' => $imageData['FileName'],
                            'FilePath' => $imageData['FilePath'],
                            'FileSize' => $imageData['FileSize'],
                            'SortOrder' => $key + 1,
                            'CreatedDate' => $dateTime,
                            'ModifiedDate' => $dateTime,
                            'CreatedByID' => $loggedInUserID,
                            'ModifiedByID' => $loggedInUserID,
                        );
                        if ($imageData['IsSavedInDB'] != 1)
                            array_push($data, $processData);
                        else
                            $this->CustomUpdateEntity(new CoPropertyListingImagesEntity(), 'ImageID', $imageData['ImageID'], $processData);
                    }
                }
                if (count($data))
                    $this->MultipleInsert(new CoPropertyListingImagesEntity(), $data);
            }
            $interventionData = array();
            if($propModel['IsWBProperty']==1)
                $imagePriority = Constants::$Value_True;
            else
                $imagePriority=2;

            if (is_array($uploadImages) && $siteID==Constants::$ColoradoSiteID) {
                foreach ($uploadImages as $key => $imageData) {
                    if ($key + 1 <= 4 && (!isset($imageData['isIntervention']) or $imageData['isIntervention'] == 0)) {
                        if (!is_null($imageData['FileName'])) {
                            $processData = array(
                                'CoListingID' => $propModel['CoListingID'],
                                'ImageURL' => $imageData['FilePath'],
                                'IsWBProperty' => $propModel['IsWBProperty'],//Constants::$isWoodBridge
                                'imagePriority'=>$imagePriority
                            );
                            array_push($interventionData, $processData);
                        }
                    }
                }
                if (count($interventionData))
                    $this->MultipleInsert(new CoPropertyImagesInterventionEntity(), $interventionData);
            }

            $response->RedirectUrl = URL::to('/') . "/listing/" . Common::getEncryptedValue(Constants::$QueryStringSiteID . '=' . $siteID);
            if ($isEditMode) {
                $response->IsSuccess = true;
                $response->Message = trans('messages.PropertyUpdateSuccess');
            } else {
                $response->IsSuccess = true;
                $response->Message = trans('messages.PropertyAddedSuccess');
            }
        } else {
            $response->Message = trans('messages.ErrorOccured');
        }
        return $response;
    }

    public function getColoradoPropertyFormatted($propModel,$ClassID){
        $property = new stdClass();
        $Features = array();
        $property->CoListingID = '';
        $property->MLSNo = $propModel->LIST_105;  //Listing ID //LIST_105
        $property->ClassID=$ClassID;
        $property->Price=$propModel->LIST_22;
        $property->NoOf3by4Baths=(property_exists($propModel,'LIST_70'))?$propModel->LIST_70:0;
        $property->NoOfFullBaths =(property_exists($propModel,'LIST_68'))?$propModel->LIST_68:0;
        $property->NoOfHalfBaths =(property_exists($propModel,'LIST_69'))?$propModel->LIST_69:0;
        $property->NoOfBeds=(property_exists($propModel,'LIST_66'))?$propModel->LIST_66:0;
        $property->Street=$propModel->LIST_34;
        $property->StreetNo=(property_exists($propModel,'LIST_31'))?$propModel->LIST_31:'';
        $property->Address2ORUnit=(property_exists($propModel,'LIST_35'))?$propModel->LIST_35:'';
        $property->City=$propModel->LIST_39;
        $property->County=$propModel->LIST_41;
        $property->ZipCode=$propModel->LIST_43;
        $property->IsHidden=(property_exists($propModel,'LIST_104'))?($propModel->LIST_104==Constants::$CoISHiddenNo?Constants::$Value_True:($propModel->LIST_104==Constants::$CoISHiddenYes?Constants::$Value_False:'')):'';
        $property->ListingDate=date("Y-m-d",strtotime($propModel->LIST_132));
        $property->Auction = (property_exists($propModel,'LIST_96'))?($propModel->LIST_96==Constants::$checkForNo?Constants::$NoValue:($propModel->LIST_96==Constants::$checkForYes?Constants::$YesValue:'')):'';
        $property->GarageSqFt = (property_exists($propModel,'LIST_50') && ($ClassID!=5 && $ClassID!=6))?$propModel->LIST_50:'';
        $property->ListingKey=$propModel->LIST_1;
        $property->Legal=$propModel->LIST_81;
        $property->NoOfStories = (property_exists($propModel,'LIST_64'))?$propModel->LIST_64:'';
        $property->ListNumberMain=$propModel->LIST_3;
        $property->LotSqFt = (property_exists($propModel,'LIST_122'))?$propModel->LIST_122:'';
        $property->SoldDate=(property_exists($propModel,'LIST_12') && $ClassID!=7)?$propModel->LIST_12:'';
        $property->SpecialAssessments = (property_exists($propModel,'LIST_108'))?$propModel->LIST_108:'';
        $property->YearBuilt = (property_exists($propModel,'LIST_53'))?$propModel->LIST_53:'';
        $property->YearRemodeled = (property_exists($propModel,'LIST_118'))?(int)$propModel->LIST_118:'';
        $property->Zoning=$propModel->LIST_83;
        if(property_exists($propModel,'LIST_93') && ($ClassID==4 || $ClassID==3 || $ClassID==2))
            $property->UnderConstruction = (property_exists($propModel,'LIST_93'))?($propModel->LIST_93==Constants::$checkForNo?Constants::$NoValue:($propModel->LIST_93==Constants::$checkForYes?Constants::$YesValue:'')):'';
        $property->Crops = ($ClassID==5)?((property_exists($propModel,'GF20081110191919894376000000'))?($propModel->GF20081110191919894376000000==Constants::$checkForNo?Constants::$NoValue:($propModel->GF20081110191919894376000000==Constants::$checkForYes?Constants::$YesValue:'')):''):((property_exists($propModel,'GF20081217201426823177000000'))?($propModel->GF20081217201426823177000000==Constants::$checkForNo?Constants::$NoValue:($propModel->GF20081217201426823177000000==Constants::$checkForYes?Constants::$YesValue:'')):'');
        $property->FAR = (property_exists($propModel,'LIST_92'))?($propModel->LIST_92==Constants::$checkForNo?Constants::$NoValue:($propModel->LIST_92==Constants::$checkForYes?Constants::$YesValue:'')):'';
        $property->VacationTrading = (property_exists($propModel,'LIST_32'))?$propModel->LIST_32:'';
        $property->DaysOnMarket = (property_exists($propModel,'LIST_137'))?$propModel->LIST_137:'';
        $property->OfficeID=$propModel->LIST_106;
        $property->BusinessName = ($ClassID==3 or $ClassID==4)?(property_exists($propModel,'LIST_56'))?$propModel->LIST_56:'':'';
        $property->PUD = (property_exists($propModel,'LIST_94') && $ClassID==6)?($propModel->LIST_94==Constants::$checkForNo?Constants::$NoValue:($propModel->LIST_94==Constants::$checkForYes?Constants::$YesValue:'')):'';
/*        $property->Condominiumized = ($ClassID==3)?((property_exists($propModel, 'GF20081219161050672348000000')) ? ($propModel->GF20081219161050672348000000==Constants::$checkForNo?Constants::$NoValue:($propModel->GF20081219161050672348000000==Constants::$checkForYes?Constants::$YesValue:'')): ''):((property_exists($propModel, 'GF20081219161050672348000000')) ?  ($propModel->GF20081219161050672348000000==Constants::$checkForNo?Constants::$NoValue:($propModel->GF20081219161050672348000000==Constants::$checkForYes?Constants::$YesValue:'')) : '');*/

        

        if($ClassID==3){
            $property->Condominiumized = (property_exists($propModel,'GF20081219161050672348000000'))?$propModel->GF20081219161050672348000000:'';
        }
        else if($ClassID==4){
            $property->Condominiumized = (property_exists($propModel,'GF20081219172532090256000000'))?$propModel->GF20081219172532090256000000:'';
        }
        else{
            $property->Condominiumized = '';
        }
        
        if($property->Condominiumized == Constants::$checkForNo){
            $property->Condominiumized = Constants::$NoValue;
        }
        else if($property->Condominiumized == Constants::$checkForYes){
            $property->Condominiumized = Constants::$YesValue;
        }
        $property->Inventory = (property_exists($propModel,'LIST_111'))?($propModel->LIST_111==Constants::$checkForNo?Constants::$NoValue:($propModel->LIST_111==Constants::$checkForYes?Constants::$YesValue:'')):'';
        $property->UnitSqFt = (property_exists($propModel,'LIST_119') && ($ClassID!=1 && $ClassID!=2 && $ClassID!=7))?$propModel->LIST_119:'';
        $property->ADU = (property_exists($propModel,'LIST_55'))?($propModel->LIST_55==Constants::$checkForNo?Constants::$NoValue:($propModel->LIST_55==Constants::$checkForYes?Constants::$YesValue:'')):'';
        $property->Pets = (property_exists($propModel,'LIST_97') && $ClassID==7)?($propModel->LIST_97==Constants::$checkForNo?Constants::$NoValue:($propModel->LIST_97==Constants::$checkForYes?Constants::$YesValue:'')):'';
        $property->EnergyStarRated =(property_exists($propModel,'LIST_59'))?($propModel->LIST_59==Constants::$checkForNo?Constants::$NoValue:($propModel->LIST_59==Constants::$checkForYes?Constants::$YesValue:'')):'';
        $property->IndoorAirPlus = (property_exists($propModel,'LIST_93') && $ClassID==1)?($propModel->LIST_93==Constants::$checkForNo?Constants::$NoValue:($propModel->LIST_93==Constants::$checkForYes?Constants::$YesValue:'')):'';
        $property->MaxNumberOccupants = (property_exists($propModel,'LIST_65'))?$propModel->LIST_65:'';
        $property->ListingOfficeName=(property_exists($propModel,'listing_office_name'))?$propModel->listing_office_name:'';
        $property->TotalSqFt=(property_exists($propModel,'LIST_48'))?$propModel->LIST_48:'';
        $property->NbrOfAcres=(property_exists($propModel,'LIST_57'))?$propModel->LIST_57:'';
        $property->WorkShopNoofRooms = ($ClassID==1)?((property_exists($propModel, 'ROOM_WK_room_nbr')) ? $propModel->ROOM_WK_room_nbr : ''):((property_exists($propModel, 'ROOM_WS_room_nbr')) ? $propModel->ROOM_WS_room_nbr : '');
        $property->WorkShopRoomLevel = ($ClassID==1)?((property_exists($propModel, 'ROOM_WK_room_level')) ? $propModel->ROOM_WK_room_level : ''):((property_exists($propModel, 'ROOM_WS_room_level')) ? $propModel->ROOM_WS_room_level : '');

        $UnfinishedSqFt=$this->getFieldID(Constants::$UnfinishedSqFt,$ClassID);
        $property->UnfinishedSqFt=property_exists($propModel,$UnfinishedSqFt)?$propModel->{$UnfinishedSqFt}:'';
        $Bedroom1RoomLevel=$this->getFieldID(Constants::$Bedroom1RoomLevel,$ClassID);
        $property->Bedroom1RoomLevel=property_exists($propModel,$Bedroom1RoomLevel)?$propModel->{$Bedroom1RoomLevel}:'';
        $Bedroom2RoomLevel=$this->getFieldID(Constants::$Bedroom2RoomLevel,$ClassID);
        $property->Bedroom2RoomLevel=property_exists($propModel,$Bedroom2RoomLevel)?$propModel->{$Bedroom2RoomLevel}:'';
        $Bedroom3RoomLevel=$this->getFieldID(Constants::$Bedroom3RoomLevel,$ClassID);
        $property->Bedroom3RoomLevel=property_exists($propModel,$Bedroom3RoomLevel)?$propModel->{$Bedroom3RoomLevel}:'';
        $Bedroom4PlusRoomLevel=$this->getFieldID(Constants::$Bedroom4PlusRoomLevel,$ClassID);
        $property->Bedroom4PlusRoomLevel=property_exists($propModel,$Bedroom4PlusRoomLevel)?$propModel->{$Bedroom4PlusRoomLevel}:'';
        $Bedroom4PlusRoomRemarks=$this->getFieldID(Constants::$Bedroom4PlusRoomRemarks,$ClassID);
        $property->Bedroom4PlusRoomRemarks=property_exists($propModel,$Bedroom4PlusRoomRemarks)?$propModel->{$Bedroom4PlusRoomRemarks}:'';
        $FamilyRoomRoomLevel=$this->getFieldID(Constants::$FamilyRoomRoomLevel,$ClassID);
        $property->FamilyRoomRoomLevel=property_exists($propModel,$FamilyRoomRoomLevel)?$propModel->{$FamilyRoomRoomLevel}:'';
        $FullBathRoomLevel=$this->getFieldID(Constants::$FullBathRoomLevel,$ClassID);
        $property->FullBathRoomLevel=property_exists($propModel,$FullBathRoomLevel)?$propModel->{$FullBathRoomLevel}:'';
        $LaundryOrUtilityRoomRoomLevel=$this->getFieldID(Constants::$LaundryOrUtilityRoomRoomLevel,$ClassID);
        $property->LaundryOrUtilityRoomRoomLevel=property_exists($propModel,$LaundryOrUtilityRoomRoomLevel)?$propModel->{$LaundryOrUtilityRoomRoomLevel}:'';
        $LivingRoomRoomLevel=$this->getFieldID(Constants::$LivingRoomRoomLevel,$ClassID);
        $property->LivingRoomRoomLevel=property_exists($propModel,$LivingRoomRoomLevel)?$propModel->{$LivingRoomRoomLevel}:'';
        $Bedroom1Width=$this->getFieldID(Constants::$Bedroom1Width,$ClassID);
        $property->Bedroom1Width=property_exists($propModel,$Bedroom1Width)?$propModel->{$Bedroom1Width}:'';
        $DiningRoomLength=$this->getFieldID(Constants::$DiningRoomLength,$ClassID);
        $property->DiningRoomLength=property_exists($propModel,$DiningRoomLength)?$propModel->{$DiningRoomLength}:'';
        $DiningRoomWidth=$this->getFieldID(Constants::$DiningRoomWidth,$ClassID);
        $property->DiningRoomWidth=property_exists($propModel,$DiningRoomWidth)?$propModel->{$DiningRoomWidth}:'';
        $DiningRoomNoofRooms=$this->getFieldID(Constants::$DiningRoomNoofRooms,$ClassID);
        $property->DiningRoomNoofRooms=property_exists($propModel,$DiningRoomNoofRooms)?$propModel->{$DiningRoomNoofRooms}:'';
        $DiningRoomRoomLevel=$this->getFieldID(Constants::$DiningRoomRoomLevel,$ClassID);
        $property->DiningRoomRoomLevel=property_exists($propModel,$DiningRoomRoomLevel)?$propModel->{$DiningRoomRoomLevel}:'';
        $KitchenLength=$this->getFieldID(Constants::$KitchenLength,$ClassID);
        $property->KitchenLength=property_exists($propModel,$KitchenLength)?$propModel->{$KitchenLength}:'';
        $KitchenWidth=$this->getFieldID(Constants::$KitchenWidth,$ClassID);
        $property->KitchenWidth=property_exists($propModel,$KitchenWidth)?$propModel->{$KitchenWidth}:'';
        $KitchenNoofRooms=$this->getFieldID(Constants::$KitchenNoofRooms,$ClassID);
        $property->KitchenNoofRooms=property_exists($propModel,$KitchenNoofRooms)?$propModel->{$KitchenNoofRooms}:'';
        $KitchenRoomLevel=$this->getFieldID(Constants::$KitchenRoomLevel,$ClassID);
        $property->KitchenRoomLevel=property_exists($propModel,$KitchenRoomLevel)?$propModel->{$KitchenRoomLevel}:'';
        $LivingRoomNoofRooms=$this->getFieldID(Constants::$LivingRoomNoofRooms,$ClassID);
        $property->LivingRoomNoofRooms=property_exists($propModel,$LivingRoomNoofRooms)?$propModel->{$LivingRoomNoofRooms}:'';
        $LivingRoomWidth=$this->getFieldID(Constants::$LivingRoomWidth,$ClassID);
        $property->LivingRoomWidth=property_exists($propModel,$LivingRoomWidth)?$propModel->{$LivingRoomWidth}:'';
        $LivingRoomLength=$this->getFieldID(Constants::$LivingRoomLength,$ClassID);
        $property->LivingRoomLength=property_exists($propModel,$LivingRoomLength)?$propModel->{$LivingRoomLength}:'';
        $property->FireplaceNoofFireplaces=property_exists($propModel,'FEAT20120320195813682239000000')?$propModel->{'FEAT20120320195813682239000000'}:'';
        $property->GeoLat=property_exists($propModel,'LIST_46')?$propModel->LIST_46:'';
        $property->GeoLon=property_exists($propModel,'LIST_47')?$propModel->LIST_47:'';
        $property->PublicRemark=property_exists($propModel,'LIST_78')?$propModel->LIST_78:'';
        $property->HeatedSqFt=property_exists($propModel,'LIST_125')?$propModel->LIST_125:'';
        $property->HeatedSqFtAbvGrnd=(property_exists($propModel,'LIST_51') && $ClassID!=4)?$propModel->LIST_51:'';
        $property->HeatedSqFtBlwGrnd=(property_exists($propModel,'LIST_52') && $ClassID!=4)?$propModel->LIST_52:'';
        $property->GreenBuilt=(property_exists($propModel,'LIST_45') && $ClassID!=7)?$propModel->LIST_45:'';
        $property->WeeklyRent=(property_exists($propModel,'LIST_45') && $ClassID!=1)?$propModel->LIST_45:'';
        $property->PtDkSqFt=(property_exists($propModel,'LIST_49') && ($ClassID==1 || $ClassID==2 || $ClassID==7))?$propModel->LIST_49:'';
        $property->NOI=(property_exists($propModel,'LIST_49') && ($ClassID==3 || $ClassID==4))?$propModel->LIST_49:'';
        $property->Directions=(property_exists($propModel,'LIST_82'))?$propModel->LIST_82:'';
        $property->PriceLvHSqFt=(property_exists($propModel,'LIST_119') && ($ClassID==1 || $ClassID==2 || $ClassID==7))?$propModel->LIST_119:'';
        $property->OrigListPricePerSF=(property_exists($propModel,'LIST_120') && ($ClassID!=5 && $ClassID!=6))?$propModel->LIST_120:'';
        $property->ListPricePerAcre=(property_exists($propModel,'LIST_120') && ($ClassID==5 || $ClassID==6))?$propModel->LIST_120:'';
        $property->HERS=(property_exists($propModel,'LIST_126') && ($ClassID==1))?$propModel->LIST_126:'';
        $property->AllowableFAR=(property_exists($propModel,'LIST_97') && ($ClassID==5))?$propModel->LIST_97:'';
        $property->ProposedCloseDate=(property_exists($propModel,'LIST_127'))?$propModel->LIST_127:'';
        $property->TotalExpensePerYear = (property_exists($propModel,'LIST_50') && ($ClassID==5 || $ClassID==6))?$propModel->LIST_50:'';
        $property->OccupancyDate =(property_exists($propModel,'LIST_128'))?$propModel->LIST_128:'';
        $property->ShortTermRentDate=(property_exists($propModel,'LIST_129'))?$propModel->LIST_129:'';
        $property->RentalTerms=(property_exists($propModel,'LIST_143'))?$propModel->LIST_143:'';
        $property->RentedPrice=(property_exists($propModel,'LIST_23') && $ClassID==7)?$propModel->LIST_23:'';
        $property->RentedDate=(property_exists($propModel,'LIST_12') && $ClassID==7)?$propModel->LIST_12:'';
        $property->RentalPricePerSF=(property_exists($propModel,'LIST_117'))?$propModel->LIST_117:'';
        $property->HOADuesYN=(property_exists($propModel,'LIST_95'))?$propModel->LIST_95:'';
        $property->HERSEnergyRating =(property_exists($propModel,'LIST_126') && ($ClassID!=7 && $ClassID!=1))?$propModel->LIST_126:'';
        $property->FloatingUnit =(property_exists($propModel,'LIST_112') && ($ClassID==2))?$propModel->LIST_112:'';
        $property->RotationSystem =(property_exists($propModel,'LIST_111') && ($ClassID==2))?$propModel->LIST_111:'';
        $property->MiscellaneousUnderConstruction=(property_exists($propModel,'FEAT20110110165016765894000000'))?$propModel->FEAT20110110165016765894000000:'';
        $property->HeatingAndCoolingHighSEERSAC=(property_exists($propModel,'FEAT20101206143207806268000000'))?$propModel->FEAT20101206143207806268000000:'';
        $property->HeatingAndCoolingHighEfficientBoilr=(property_exists($propModel,'FEAT20110110171311577483000000'))?$propModel->FEAT20110110171311577483000000:'';;
        $property->HeatingAndCoolingHighEfficientFurn=(property_exists($propModel,'FEAT20101206142843631509000000'))?$propModel->FEAT20101206142843631509000000:'';
        $property->HeatingAndCoolingEStarWaterHeater=(property_exists($propModel,'FEAT20101206143410523350000000'))?$propModel->FEAT20101206143410523350000000:'';
        $property->BldgCertificationBldgCertification=(property_exists($propModel,'FEAT20101206150331044186000000'))?$propModel->FEAT20101206150331044186000000:'';
        $property->BldgCertificationCertifyingBody=(property_exists($propModel,'FEAT20101206150419108719000000'))?$propModel->FEAT20101206150419108719000000:'';
        $property->BldgCertificationYearCertified=(property_exists($propModel,'FEAT20101206150441337677000000'))?$propModel->FEAT20101206150441337677000000:'';
        $property->BldgCertificationCertificationRating=(property_exists($propModel,'FEAT20101206150652246090000000'))?$propModel->FEAT20101206150652246090000000:'';
        $SignFieldName=$this->getFieldID(Constants::$SignFieldName,$ClassID);
        $property->Sign=property_exists($propModel,$SignFieldName)?$propModel->{$SignFieldName}:'';

        $property->{'3By4BathRoomLevel'}=property_exists($propModel,'ROOM_3/4_room_level')?$propModel->{'ROOM_3/4_room_level'}:'';
        $property->{'3By4BathWidth'}=property_exists($propModel,'ROOM_3/4_room_level')?$propModel->{'ROOM_3/4_room_width'}:'';
        $property->{'3By4BathRoomRemarks'}=property_exists($propModel,'ROOM_3/4_room_rem')?$propModel->{'ROOM_3/4_room_rem'}:'';
        $property->{'3By4BathNoofRooms'}=property_exists($propModel,'ROOM_3/4_room_nbr')?$propModel->{'ROOM_3/4_room_nbr'}:'';
        $property->{'3By4BathLength'}=property_exists($propModel,'ROOM_3/4_room_length')?$propModel->{'ROOM_3/4_room_length'}:'';
        $property->{'3By4BathArea'}=property_exists($propModel,'ROOM_3/4_room_area')?$propModel->{'ROOM_3/4_room_area'}:'';

        $Bedroom1RoomRemarksFieldName=$this->getFieldID(Constants::$Bedroom1RoomRemarksFieldName,$ClassID);
        $property->Bedroom1RoomRemarks=property_exists($propModel,$Bedroom1RoomRemarksFieldName)?$propModel->{$Bedroom1RoomRemarksFieldName}:'';
        $Bedroom1NoofRoomsFieldName=$this->getFieldID(Constants::$Bedroom1NoofRoomsFieldName,$ClassID);
        $property->Bedroom1NoofRooms=property_exists($propModel,$Bedroom1NoofRoomsFieldName)?$propModel->{$Bedroom1NoofRoomsFieldName}:'';
        $Bedroom1LengthFieldName=$this->getFieldID(Constants::$Bedroom1LengthFieldName,$ClassID);
        $property->Bedroom1Length=property_exists($propModel,$Bedroom1RoomRemarksFieldName)?$propModel->{$Bedroom1LengthFieldName}:'';
        $Bedroom1AreaFieldName=$this->getFieldID(Constants::$Bedroom1AreaFieldName,$ClassID);
        $property->Bedroom1Area=property_exists($propModel,$Bedroom1AreaFieldName)?$propModel->{$Bedroom1AreaFieldName}:'';

        $Bedroom2WidthFieldName=$this->getFieldID(Constants::$Bedroom2WidthFieldName,$ClassID);
        $property->Bedroom2Width=property_exists($propModel,$Bedroom2WidthFieldName)?$propModel->{$Bedroom2WidthFieldName}:'';
        $Bedroom2RoomRemarksFieldName=$this->getFieldID(Constants::$Bedroom2RoomRemarksFieldName,$ClassID);
        $property->Bedroom2RoomRemarks=property_exists($propModel,$Bedroom2RoomRemarksFieldName)?$propModel->{$Bedroom2RoomRemarksFieldName}:'';
        $Bedroom2LengthFieldName=$this->getFieldID(Constants::$Bedroom2LengthFieldName,$ClassID);
        $property->Bedroom2Length=property_exists($propModel,$Bedroom2LengthFieldName)?$propModel->{$Bedroom2LengthFieldName}:'';
        $Bedroom2AreaFieldName=$this->getFieldID(Constants::$Bedroom2AreaFieldName,$ClassID);
        $property->Bedroom2Area=property_exists($propModel,$Bedroom2AreaFieldName)?$propModel->{$Bedroom2AreaFieldName}:'';

        $Bedroom3WidthFieldName=$this->getFieldID(Constants::$Bedroom3WidthFieldName,$ClassID);
        $property->Bedroom3Width=property_exists($propModel,$Bedroom3WidthFieldName)?$propModel->{$Bedroom3WidthFieldName}:'';
        $Bedroom3RoomRemarksFieldName=$this->getFieldID(Constants::$Bedroom3RoomRemarksFieldName,$ClassID);
        $property->Bedroom3RoomRemarks=property_exists($propModel,$Bedroom3RoomRemarksFieldName)?$propModel->{$Bedroom3RoomRemarksFieldName}:'';
        $Bedroom3NoofRoomsFieldName=$this->getFieldID(Constants::$Bedroom3NoofRoomsFieldName,$ClassID);
        $property->Bedroom3NoofRooms=property_exists($propModel,$Bedroom3NoofRoomsFieldName)?$propModel->{$Bedroom3NoofRoomsFieldName}:'';
        $Bedroom3LengthFieldName=$this->getFieldID(Constants::$Bedroom3LengthFieldName,$ClassID);
        $property->Bedroom3Length=property_exists($propModel,$Bedroom3LengthFieldName)?$propModel->{$Bedroom3LengthFieldName}:'';
        $Bedroom3AreaFieldName=$this->getFieldID(Constants::$Bedroom3AreaFieldName,$ClassID);
        $property->Bedroom3Area=property_exists($propModel,$Bedroom3AreaFieldName)?$propModel->{$Bedroom3AreaFieldName}:'';

        $property->Bedroom4PlusWidth=property_exists($propModel,'ROOM_4+_room_width')?$propModel->{'ROOM_4+_room_width'}:'';
        $property->Bedroom4PlusNoofRooms=property_exists($propModel,'ROOM_4+_room_nbr')?$propModel->{'ROOM_4+_room_nbr'}:'';
        $property->Bedroom4PlusLength=property_exists($propModel,'ROOM_4+_room_length')?$propModel->{'ROOM_4+_room_length'}:'';
        $property->Bedroom4PlusArea=property_exists($propModel,'ROOM_4+_room_area')?$propModel->{'ROOM_4+_room_area'}:'';

        $property->DenStudyLibraryRoomLevel=property_exists($propModel,'ROOM_DSL_room_level')?$propModel->{'ROOM_DSL_room_level'}:'';
        $property->DenStudyLibraryWidth=property_exists($propModel,'ROOM_DSL_room_width')?$propModel->{'ROOM_DSL_room_width'}:'';
        $property->DenStudyLibraryRoomRemarks=property_exists($propModel,'ROOM_DSL_room_rem')?$propModel->{'ROOM_DSL_room_rem'}:'';
        $property->DenStudyLibraryNoofRooms=property_exists($propModel,'ROOM_DSL_room_nbr')?$propModel->{'ROOM_DSL_room_nbr'}:'';
        $property->DenStudyLibraryLength=property_exists($propModel,'ROOM_DSL_room_length')?$propModel->{'ROOM_DSL_room_length'}:'';
        $property->DenStudyLibraryArea=property_exists($propModel,'ROOM_DSL_room_area')?$propModel->{'ROOM_DSL_room_area'}:'';

        $DiningRoomRoomRemarksFieldName=$this->getFieldID(Constants::$DiningRoomRoomRemarksFieldName,$ClassID);
        $property->DiningRoomRoomRemarks=property_exists($propModel,$DiningRoomRoomRemarksFieldName)?$propModel->{$DiningRoomRoomRemarksFieldName}:'';
        $DiningRoomAreaFieldName=$this->getFieldID(Constants::$DiningRoomAreaFieldName,$ClassID);
        $property->DiningRoomArea=property_exists($propModel,$DiningRoomAreaFieldName)?$propModel->{$DiningRoomAreaFieldName}:'';

        $property->FamilyRoomWidth=property_exists($propModel,'ROOM_FR_room_width')?$propModel->{'ROOM_FR_room_width'}:'';
        $property->FamilyRoomNoofRooms=property_exists($propModel,'ROOM_FR_room_nbr')?$propModel->{'ROOM_FR_room_nbr'}:'';
        $property->FamilyRoomLength=property_exists($propModel,'ROOM_FR_room_length')?$propModel->{'ROOM_FR_room_length'}:'';
        $property->FamilyRoomArea=property_exists($propModel,'ROOM_FR_room_area')?$propModel->{'ROOM_FR_room_area'}:'';

        $property->FullBathWidth=property_exists($propModel,'ROOM_FB_room_width')?$propModel->{'ROOM_FB_room_width'}:'';
        $property->FullBathRoomRemarks=property_exists($propModel,'ROOM_FB_room_rem')?$propModel->{'ROOM_FB_room_rem'}:'';
        $property->FullBathNoofRooms=property_exists($propModel,'ROOM_FB_room_nbr')?$propModel->{'ROOM_FB_room_nbr'}:'';
        $property->FullBathLength=property_exists($propModel,'ROOM_FB_room_length')?$propModel->{'ROOM_FB_room_length'}:'';
        $property->FullBathArea=property_exists($propModel,'ROOM_FB_room_area')?$propModel->{'ROOM_FB_room_area'}:'';

        $property->HalfBathRoomLevel=property_exists($propModel,'ROOM_HB_room_level')?$propModel->{'ROOM_HB_room_level'}:'';
        $property->HalfBathWidth=property_exists($propModel,'ROOM_HB_room_width')?$propModel->{'ROOM_HB_room_width'}:'';
        $property->HalfBathRoomRemarks=property_exists($propModel,'ROOM_HB_room_rem')?$propModel->{'ROOM_HB_room_rem'}:'';
        $property->HalfBathNoofRooms=property_exists($propModel,'ROOM_HB_room_nbr')?$propModel->{'ROOM_HB_room_nbr'}:'';
        $property->HalfBathLength=property_exists($propModel,'ROOM_HB_room_length')?$propModel->{'ROOM_HB_room_length'}:'';
        $property->HalfBathArea=property_exists($propModel,'ROOM_HB_room_area')?$propModel->{'ROOM_HB_room_area'}:'';

        $KitchenRoomRemarksFieldName=$this->getFieldID(Constants::$KitchenRoomRemarksFieldName,$ClassID);
        $property->KitchenRoomRemarks=property_exists($propModel,$KitchenRoomRemarksFieldName)?$propModel->{$KitchenRoomRemarksFieldName}:'';
        $KitchenAreaFieldName=$this->getFieldID(Constants::$KitchenAreaFieldName,$ClassID);
        $property->KitchenArea=property_exists($propModel,$KitchenAreaFieldName)?$propModel->{$KitchenAreaFieldName}:'';

        $property->LaundryOrUtilityRoomWidth=property_exists($propModel,'ROOM_LD_room_width')?$propModel->{'ROOM_LD_room_width'}:'';
        $property->LaundryOrUtilityRoomRoomRemarks=property_exists($propModel,'ROOM_LD_room_rem')?$propModel->{'ROOM_LD_room_rem'}:'';
        $property->LaundryOrUtilityRoomNoofRooms=property_exists($propModel,'ROOM_LD_room_nbr')?$propModel->{'ROOM_LD_room_nbr'}:'';
        $property->LaundryOrUtilityRoomLength=property_exists($propModel,'ROOM_LD_room_length')?$propModel->{'ROOM_LD_room_length'}:'';
        $property->LaundryOrUtilityRoomArea=property_exists($propModel,'ROOM_LD_room_area')?$propModel->{'ROOM_LD_room_area'}:'';

        $property->LivingRoomRoomRemarks=property_exists($propModel,'ROOM_LV_room_rem')?$propModel->{'ROOM_LV_room_rem'}:'';
        $property->LivingRoomArea=property_exists($propModel,'ROOM_LV_room_area')?$propModel->{'ROOM_LV_room_area'}:'';

        $property->MediaRoomRoomLevel=property_exists($propModel,'ROOM_MR_room_level')?$propModel->{'ROOM_MR_room_level'}:'';
        $property->MediaRoomWidth=property_exists($propModel,'ROOM_MR_room_width')?$propModel->{'ROOM_MR_room_width'}:'';
        $property->MediaRoomRoomRemarks=property_exists($propModel,'ROOM_MR_room_rem')?$propModel->{'ROOM_MR_room_rem'}:'';
        $property->MediaRoomNoofRooms=property_exists($propModel,'ROOM_MR_room_nbr')?$propModel->{'ROOM_MR_room_nbr'}:'';
        $property->MediaRoomLength=property_exists($propModel,'ROOM_MR_room_length')?$propModel->{'ROOM_MR_room_length'}:'';
        $property->MediaRoomArea=property_exists($propModel,'ROOM_MR_room_area')?$propModel->{'ROOM_MR_room_area'}:'';

        $property->RecRoomRoomLevel=property_exists($propModel,'ROOM_RR_room_level')?$propModel->{'ROOM_RR_room_level'}:'';
        $property->RecRoomWidth=property_exists($propModel,'ROOM_RR_room_width')?$propModel->{'ROOM_RR_room_width'}:'';
        $property->RecRoomRoomRemarks=property_exists($propModel,'ROOM_RR_room_rem')?$propModel->{'ROOM_RR_room_rem'}:'';
        $property->RecRoomNoofRooms=property_exists($propModel,'ROOM_RR_room_nbr')?$propModel->{'ROOM_RR_room_nbr'}:'';
        $property->RecRoomLength=property_exists($propModel,'ROOM_RR_room_length')?$propModel->{'ROOM_RR_room_length'}:'';
        $property->RecRoomArea=property_exists($propModel,'ROOM_RR_room_area')?$propModel->{'ROOM_RR_room_area'}:'';

        $WorkShopWidthFieldName=$this->getFieldID(Constants::$WorkShopWidthFieldName,$ClassID);
        $property->WorkShopWidth=property_exists($propModel,$WorkShopWidthFieldName)?$propModel->{$WorkShopWidthFieldName}:'';
        $WorkShopRoomRemarksFieldName=$this->getFieldID(Constants::$WorkShopRoomRemarksFieldName,$ClassID);
        $property->WorkShopRoomRemarks=property_exists($propModel,$WorkShopRoomRemarksFieldName)?$propModel->{$WorkShopRoomRemarksFieldName}:'';
        $WorkShopLengthFieldName=$this->getFieldID(Constants::$WorkShopLengthFieldName,$ClassID);
        $property->WorkShopLength=property_exists($propModel,$WorkShopLengthFieldName)?$propModel->{$WorkShopLengthFieldName}:'';
        $WorkShopAreaFieldName=$this->getFieldID(Constants::$WorkShopAreaFieldName,$ClassID);
        $property->WorkShopArea=property_exists($propModel,$WorkShopAreaFieldName)?$propModel->{$WorkShopAreaFieldName}:'';

        $property->Bedroom4Area=property_exists($propModel,'ROOM_BR4_room_area')?$propModel->{'ROOM_BR4_room_area'}:'';
        $property->Bedroom4Width=property_exists($propModel,'ROOM_BR4_room_width')?$propModel->{'ROOM_BR4_room_width'}:'';
        $property->Bedroom4RoomRemarks=property_exists($propModel,'ROOM_BR4_room_rem ')?$propModel->{'ROOM_BR4_room_rem '}:'';
        $property->Bedroom4RoomLevel=property_exists($propModel,'ROOM_BR4_room_level')?$propModel->{'ROOM_BR4_room_level'}:'';
        $property->Bedroom4NoofRooms=property_exists($propModel,'ROOM_BR4_room_nbr')?$propModel->{'ROOM_BR4_room_nbr'}:'';
        $property->Bedroom4Length=property_exists($propModel,'ROOM_BR4_room_length')?$propModel->{'ROOM_BR4_room_length'}:'';

        $property->Bedroom5Area=property_exists($propModel,'ROOM_BR5_room_area')?$propModel->{'ROOM_BR5_room_area'}:'';
        $property->Bedroom5Width=property_exists($propModel,'ROOM_BR5_room_width')?$propModel->{'ROOM_BR5_room_width'}:'';
        $property->Bedroom5RoomRemarks=property_exists($propModel,'ROOM_BR5_room_rem')?$propModel->{'ROOM_BR5_room_rem'}:'';
        $property->Bedroom5RoomLevel=property_exists($propModel,'ROOM_BR5_room_level')?$propModel->{'ROOM_BR5_room_level'}:'';
        $property->Bedroom5NoofRooms=property_exists($propModel,'ROOM_BR5_room_nbr')?$propModel->{'ROOM_BR5_room_nbr'}:'';
        $property->Bedroom5Length=property_exists($propModel,'ROOM_BR5_room_length ')?$propModel->{'ROOM_BR5_room_length '}:'';

        $property->Bedroom6PlusArea=property_exists($propModel,'ROOM_BR6_room_area')?$propModel->{'ROOM_BR6_room_area'}:'';
        $property->Bedroom6PlusWidth=property_exists($propModel,'ROOM_BR6_room_width')?$propModel->{'ROOM_BR6_room_width'}:'';
        $property->Bedroom6PlusRoomRemarks=property_exists($propModel,'ROOM_BR6_room_rem')?$propModel->{'ROOM_BR6_room_rem'}:'';
        $property->Bedroom6PlusRoomLevel=property_exists($propModel,'ROOM_BR6_room_level')?$propModel->{'ROOM_BR6_room_level'}:'';
        $property->Bedroom6PlusNoofRooms=property_exists($propModel,'ROOM_BR6_room_nbr')?$propModel->{'ROOM_BR6_room_nbr'}:'';
        $property->Bedroom6PlusLength=property_exists($propModel,'ROOM_BR6_room_length')?$propModel->{'ROOM_BR6_room_length'}:'';

        $property->FamilyOrRecRoomArea=property_exists($propModel,'ROOM_FR_room_area')?$propModel->{'ROOM_FR_room_area'}:'';
        $property->FamilyOrRecRoomWidth=property_exists($propModel,'ROOM_FR_room_width')?$propModel->{'ROOM_FR_room_width'}:'';
        $property->FamilyOrRecRoomRoomRemarks=property_exists($propModel,'ROOM_FR_room_rem')?$propModel->{'ROOM_FR_room_rem'}:'';
        $property->FamilyOrRecRoomRoomLevel=property_exists($propModel,'ROOM_FR_room_level')?$propModel->{'ROOM_FR_room_level'}:'';
        $property->FamilyOrRecRoomNoofRooms=property_exists($propModel,'ROOM_FR_room_nbr')?$propModel->{'ROOM_FR_room_nbr'}:'';
        $property->FamilyOrRecRoomLength=property_exists($propModel,'ROOM_FR_room_length')?$propModel->{'ROOM_FR_room_length'}:'';

        $property->FireplaceArea=property_exists($propModel,'ROOM_FP_room_area')?$propModel->{'ROOM_FP_room_area'}:'';
        $property->FireplaceWidth=property_exists($propModel,'ROOM_FP_room_width')?$propModel->{'ROOM_FP_room_width'}:'';
        $property->FireplaceRoomRemarks=property_exists($propModel,'ROOM_FP_room_rem')?$propModel->{'ROOM_FP_room_rem'}:'';
        $property->FireplaceRoomLevel=property_exists($propModel,'ROOM_FP_room_level')?$propModel->{'ROOM_FP_room_level'}:'';
        $property->FireplaceNoofRooms=property_exists($propModel,'ROOM_FP_room_nbr')?$propModel->{'ROOM_FP_room_nbr'}:'';
        $property->FireplaceLength=property_exists($propModel,'ROOM_FP_room_length')?$propModel->{'ROOM_FP_room_length'}:'';

        $property->FlexArea=property_exists($propModel,'ROOM_FLEX_room_area')?$propModel->{'ROOM_FLEX_room_area'}:'';
        $property->FlexWidth=property_exists($propModel,'ROOM_FLEX_room_width')?$propModel->{'ROOM_FLEX_room_width'}:'';
        $property->FlexRoomRemarks=property_exists($propModel,'ROOM_FLEX_room_rem')?$propModel->{'ROOM_FLEX_room_rem'}:'';
        $property->FlexRoomLevel=property_exists($propModel,'ROOM_FLEX_room_level')?$propModel->{'ROOM_FLEX_room_level'}:'';
        $property->FlexNoofRooms=property_exists($propModel,'ROOM_FLEX_room_nbr')?$propModel->{'ROOM_FLEX_room_nbr'}:'';
        $property->FlexLength=property_exists($propModel,'ROOM_FLEX_room_length')?$propModel->{'ROOM_FLEX_room_length'}:'';

        $property->HomeTheatersArea=property_exists($propModel,'ROOM_HT_room_area')?$propModel->{'ROOM_HT_room_area'}:'';
        $property->HomeTheatersWidth=property_exists($propModel,'ROOM_HT_room_width')?$propModel->{'ROOM_HT_room_width'}:'';
        $property->HomeTheatersRoomRemarks=property_exists($propModel,'ROOM_HT_room_rem')?$propModel->{'ROOM_HT_room_rem'}:'';
        $property->HomeTheatersRoomLevel=property_exists($propModel,'ROOM_HT_room_level')?$propModel->{'ROOM_HT_room_level'}:'';
        $property->HomeTheatersNoofRooms=property_exists($propModel,'ROOM_HT_room_nbr')?$propModel->{'ROOM_HT_room_nbr'}:'';
        $property->HomeTheatersLength=property_exists($propModel,'ROOM_HT_room_length')?$propModel->{'ROOM_HT_room_length'}:'';

        $property->HotTubOrSpaArea=property_exists($propModel,'ROOM_HTS_room_area')?$propModel->{'ROOM_HTS_room_area'}:'';
        $property->HotTubOrSpaWidth=property_exists($propModel,'ROOM_HTS_room_width')?$propModel->{'ROOM_HTS_room_width'}:'';
        $property->HotTubOrSpaRoomRemarks=property_exists($propModel,'ROOM_HTS_room_rem')?$propModel->{'ROOM_HTS_room_rem'}:'';
        $property->HotTubOrSpaRoomLevel=property_exists($propModel,'ROOM_HTS_room_level')?$propModel->{'ROOM_HTS_room_level'}:'';
        $property->HotTubOrSpaNoofRooms=property_exists($propModel,'ROOM_HTS_room_nbr')?$propModel->{'ROOM_HTS_room_nbr'}:'';
        $property->HotTubOrSpaLength=property_exists($propModel,'ROOM_HTS_room_length')?$propModel->{'ROOM_HTS_room_length'}:'';

        $property->MudArea=property_exists($propModel,'ROOM_MUD_room_area')?$propModel->{'ROOM_MUD_room_area'}:'';
        $property->MudWidth=property_exists($propModel,'ROOM_MUD_room_width')?$propModel->{'ROOM_MUD_room_width'}:'';
        $property->MudRoomRemarks=property_exists($propModel,'ROOM_MUD_room_rem')?$propModel->{'ROOM_MUD_room_rem'}:'';
        $property->MudRoomLevel=property_exists($propModel,'ROOM_MUD_room_level')?$propModel->{'ROOM_MUD_room_level'}:'';
        $property->MudNoofRooms=property_exists($propModel,'ROOM_MUD_room_nbr')?$propModel->{'ROOM_MUD_room_nbr'}:'';
        $property->MudLength=property_exists($propModel,'ROOM_MUD_room_length')?$propModel->{'ROOM_MUD_room_length'}:'';

        $property->OfficeWidth=property_exists($propModel,'ROOM_OFF_room_width')?$propModel->{'ROOM_OFF_room_width'}:'';
        $property->OfficeRoomRemarks=property_exists($propModel,'ROOM_OFF_room_rem')?$propModel->{'ROOM_OFF_room_rem'}:'';
        $property->OfficeRoomLevel=property_exists($propModel,'ROOM_OFF_room_level')?$propModel->{'ROOM_OFF_room_level'}:'';
        $property->OfficeNoofRooms=property_exists($propModel,'ROOM_OFF_room_nbr')?$propModel->{'ROOM_OFF_room_nbr'}:'';
        $property->OfficeLength=property_exists($propModel,'ROOM_OFF_room_length')?$propModel->{'ROOM_OFF_room_length'}:'';

        $property->WoodStoveArea=property_exists($propModel,'ROOM_WS_room_area')?$propModel->{'ROOM_WS_room_area'}:'';
        $property->WoodStoveWidth=property_exists($propModel,'ROOM_WS_room_width')?$propModel->{'ROOM_WS_room_width'}:'';
        $property->WoodStoveRoomRemarks=property_exists($propModel,'ROOM_WS_room_rem')?$propModel->{'ROOM_WS_room_rem'}:'';
        $property->WoodStoveRoomLevel=property_exists($propModel,'ROOM_WS_room_level')?$propModel->{'ROOM_WS_room_level'}:'';
        $property->WoodStoveNoofRooms=property_exists($propModel,'ROOM_WS_room_nbr')?$propModel->{'ROOM_WS_room_nbr'}:'';
        $property->WoodStoveLength=property_exists($propModel,'ROOM_WS_room_length')?$propModel->{'ROOM_WS_room_length'}:'';

        $config = new \PHRETS\Configuration;
        $config->setloginurl(Config::get('config.Aspen_Login_URL'));
        $config->setHttpAuthenticationMethod(Config::get('config.CLAW_Authentication_Method'));
        $config->setOption('use_post_method', false);
        $config->setOption('disable_follow_location', false);

        // get credentials from database settings table. We kept them in db so user can change easily if there is any change.
        $Credentials = $this->GetCLAWCredentials(Constants::$ColoradoSiteID);

        $config->setusername(Config::get('config.Aspen_UserName'));
        $config->setpassword(Config::get('config.Aspen_Password'));

        $rets = new \PHRETS\Session($config);
        $login = $rets->Login();
        if(property_exists($propModel,'LIST_5')) {

            //For Agent and Co-list agent
            $resource = 'ActiveAgent';
            $class = 'Agent';
            $query = '(MEMBER_0=' . $propModel->LIST_5 . ')';
            $result = $rets->Search(
                $resource,
                $class,
                $query,
                [
                    'QueryType' => 'DMQL2',
                    'Count' => 1, // only records
                    'Format' => 'COMPACT-DECODED',
                    'Limit' => 10,
                    'StandardNames' => 0
                ]
            );
            $AgentData = json_decode($result->toJSON());
            $property->MLSAgentName = (isset($AgentData[0])) ? $AgentData[0]->MEMBER_19 : '';
            $Features['Agent'] = (isset($AgentData[0])) ? $AgentData[0]->LICENSE : '';
        }
        if(property_exists($propModel,'LIST_6') &&  $propModel->LIST_6!='') {
            $resource = 'ActiveAgent';
            $class = 'Agent';
            $query = '(MEMBER_0=' . $propModel->LIST_6 . ')';
            $result = $rets->Search(
                $resource,
                $class,
                $query,
                [
                    'QueryType' => 'DMQL2',
                    'Count' => 1, // only records
                    'Format' => 'COMPACT-DECODED',
                    'Limit' => 10,
                    'StandardNames' => 0
                ]
            );
            $AgentData = json_decode($result->toJSON());
            $property->CoMLSAgentName=(isset($AgentData[0]))?$AgentData[0]->MEMBER_19:'';
            $property->CoMLSAgentLicense=(isset($AgentData[0]))?$AgentData[0]->LICENSE:'';
        }

        if($ClassID!=3 or $ClassID!=4)
            $Features['LotSize'] = (property_exists($propModel,'LIST_56'))?$propModel->LIST_56:'';
        else
            $Features['LotSize'] = '';

        $Features['Type']=$propModel->LIST_9;
        $Features['SubType']=($ClassID==1 || $ClassID==5)?(property_exists($propModel,'LIST_112'))?$propModel->LIST_112:'':''; //residential land, residential
        $Features['Status']=$propModel->LIST_15;
        $Features['Area']=$propModel->LIST_88;
        $Features['State']=$propModel->LIST_40;
        $Features['MajorArea']=$propModel->LIST_115;
        $Features['MemberAssociation']=$propModel->LIST_86;
        $Features['SubLoc']=(property_exists($propModel,'LIST_77'))?$propModel->LIST_77:'';
        $Features['OwnershipInterest']=(property_exists($propModel,'LIST_59') && $ClassID==2)?$propModel->LIST_59:'';
        $Features['PreFabricatedHome']=($ClassID==1 || $ClassID==7)?(property_exists($propModel,'LIST_92'))?$propModel->LIST_92:'':'';
        $Features['SeasonalInterest']=($ClassID==2)?(property_exists($propModel,'LIST_92'))?$propModel->LIST_92:'':'';
        $Features['RentalTerm']=(property_exists($propModel,'LIST_143'))?$propModel->LIST_143:'';
        $Features['StreetSuffix']=$propModel->LIST_37;
        $Features['Unit']=($ClassID==3 || $ClassID==4)?(property_exists($propModel,'LIST_113'))?$propModel->LIST_113:'':'';
        $Features['UnitSqFtRange']=($ClassID==3 || $ClassID==4)?(property_exists($propModel,'LIST_112'))?$propModel->LIST_112:'':'';
        $Features['ApprovalFeatures']= (property_exists($propModel,'GF20081217205431610475000000'))?$propModel->GF20081217205431610475000000:'';
        $Features['BuildingSqFt']=($ClassID==3)?(property_exists($propModel,'LIST_94'))?$propModel->LIST_94:'':'';


        $Features['Furnish']=(property_exists($propModel,'LIST_91'))?$propModel->LIST_91:'';
        $Features['Cooling']=($ClassID==1)?((property_exists($propModel,'GF20081113193951743297000000'))?$propModel->GF20081113193951743297000000:''):((property_exists($propModel,'GF20081210185300516047000000'))?$propModel->GF20081210185300516047000000:'');

        $Features['UpperLevel']=property_exists($propModel,'GF20110517210052383432000000')?$propModel->GF20110517210052383432000000:'';
        $Features['LowerLevel']=property_exists($propModel,'GF20110517210045034949000000')?$propModel->GF20110517210045034949000000:'';
        $Features['MainLevel']=property_exists($propModel,'GF20110517210050691618000000')?$propModel->GF20110517210050691618000000:'';
        $Features['OtherCooling']=property_exists($propModel,'GF20110517210041708217000000')?$propModel->GF20110517210041708217000000:'';
        $Features['IndoorAirQuality']=property_exists($propModel,'GF20101203215615511014000000')?$propModel->GF20101203215615511014000000:'';
        $Features['LeedCertified']=(property_exists($propModel,'LIST_71') && $ClassID!=1)?$propModel->LIST_71:'';
        $Features['WaterEfficiency']=property_exists($propModel,'GF20101203215643343824000000')?$propModel->GF20101203215643343824000000:'';
        $Features['ConstructExterior']=property_exists($propModel,'GF20110517210040899122000000')?$propModel->GF20110517210040899122000000:'';
        $Features['EnergyEfficiency']=property_exists($propModel,'GF20101203215546926447000000')?$propModel->GF20101203215546926447000000:'';
        $Features['CurrentUses']=($ClassID==3)?((property_exists($propModel,'GF20081219154511900227000000'))?$propModel->GF20081219154511900227000000:''):((property_exists($propModel,'GF20081219172543861244000000'))?$propModel->GF20081219172543861244000000:'');
        $Features['Deeds']=property_exists($propModel,'LIST_102')?$propModel->LIST_102:'';
        $Features['Exclusions']=($ClassID==1)?((property_exists($propModel,'GF20081113195050653150000000'))?$propModel->GF20081113195050653150000000:''):((property_exists($propModel,'GF20081210185303236712000000'))?$propModel->GF20081210185303236712000000:'');
        $Features['Garages']=property_exists($propModel,'LIST_73')?$propModel->LIST_73:'';
        $Features['HowSold']=property_exists($propModel,'LIST_28')?$propModel->LIST_28:'';
        $Features['Inclusion']=($ClassID==1)?((property_exists($propModel,'GF20081113195001529466000000'))?$propModel->GF20081113195001529466000000:''):((property_exists($propModel,'GF20081210185306867671000000'))?$propModel->GF20081210185306867671000000:'');
        $Features['LeedForHome']=(property_exists($propModel,'LIST_71') && $ClassID==1)?$propModel->LIST_71:'';
        $Features['LotDescription']=($ClassID==5)?((property_exists($propModel,'GF20081110191919894586000000'))?$propModel->GF20081110191919894586000000:''):((property_exists($propModel,'GF20081217201431401065000000'))?$propModel->GF20081217201431401065000000:'');
        $Features['LotImprovements']=(property_exists($propModel,'GF20081217205443280047000000'))?$propModel->GF20081217205443280047000000:'';
        $Features['Parking']=($ClassID==3)?((property_exists($propModel,'GF20081219153705631823000000'))?$propModel->GF20081219153705631823000000:''):((property_exists($propModel,'GF20081219172541229841000000'))?$propModel->GF20081219172541229841000000:'');
        $Features['PossibleUse']=($ClassID==5)?((property_exists($propModel,'GF20081110191919892496000000'))?$propModel->GF20081110191919892496000000:''):((property_exists($propModel,'GF20081217201430318443000000'))?$propModel->GF20081217201430318443000000:'');
        $Features['SustainableMaterial']=property_exists($propModel,'GF20101203215725594534000000')?$propModel->GF20101203215725594534000000:'';
        /*$Features['HeatingAndCoolings']=property_exists($propModel,'GF20101203215602102494000000')?$propModel->GF20101203215602102494000000:'';*/

        $HeatingAndCollingName=$this->getFieldID(Constants::$HeatingAndCollingName,$ClassID);
        $Features['HeatingAndCoolings']=property_exists($propModel,$HeatingAndCollingName)?$propModel->{$HeatingAndCollingName}:'';

        $WaterFieldName=$this->getFieldID(Constants::$WaterFieldName,$ClassID);
        $Features['Water']=property_exists($propModel,$WaterFieldName)?$propModel->{$WaterFieldName}:'';

        $CarportFieldName=$this->getFieldID(Constants::$CarportFieldName,$ClassID);
        $Features['Carports']=property_exists($propModel,$CarportFieldName)?$propModel->{$CarportFieldName}:'';

        $AccessFieldName=$this->getFieldID(Constants::$AccessFieldName,$ClassID);
        $Features['Accesses']=property_exists($propModel,$AccessFieldName)?$propModel->{$AccessFieldName}:'';

        $AmenitiesFieldName=$this->getFieldID(Constants::$AmenitiesFieldName,$ClassID);
        $Features['Amenities']=property_exists($propModel,$AmenitiesFieldName)?$propModel->{$AmenitiesFieldName}:'';

        $ConditionsFieldName=$this->getFieldID(Constants::$ConditionsFieldName,$ClassID);
        $Features['Conditions']=property_exists($propModel,$ConditionsFieldName)?$propModel->{$ConditionsFieldName}:'';

        $ConstructionFieldName=$this->getFieldID(Constants::$ConstructionFieldName,$ClassID);
        $Features['Construction']=property_exists($propModel,$ConstructionFieldName)?$propModel->{$ConstructionFieldName}:'';

        $DisclosureFieldName=$this->getFieldID(Constants::$DisclosureFieldName,$ClassID);
        $Features['Disclousures']=property_exists($propModel,$DisclosureFieldName)?$propModel->{$DisclosureFieldName}:'';

        $ElectricFieldName=$this->getFieldID(Constants::$ElectricFieldName,$ClassID);
        $Features['Electrics']=property_exists($propModel,$ElectricFieldName)?$propModel->{$ElectricFieldName}:'';

        $ExteriorFieldName=$this->getFieldID(Constants::$ExteriorFieldName,$ClassID);
        $Features['Exteriors']=property_exists($propModel,$ExteriorFieldName)?$propModel->{$ExteriorFieldName}:'';

        $ExtraFieldName=$this->getFieldID(Constants::$ExtraFieldName,$ClassID);
        $Features['Extras']=property_exists($propModel,$ExtraFieldName)?$propModel->{$ExtraFieldName}:'';

        $FireplaceFieldName=$this->getFieldID(Constants::$FireplaceFieldName,$ClassID);
        $Features['Fireplaces']=property_exists($propModel,$FireplaceFieldName)?$propModel->{$FireplaceFieldName}:'';

        $GasFieldName=$this->getFieldID(Constants::$GasFieldName,$ClassID);
        $Features['Gases']=property_exists($propModel,$GasFieldName)?$propModel->{$GasFieldName}:'';

        $GreenFeaturesFieldName=$this->getFieldID(Constants::$GreenFeaturesFieldName,$ClassID);
        $Features['GreenFeatures']=property_exists($propModel,$GreenFeaturesFieldName)?$propModel->{$GreenFeaturesFieldName}:'';

        $HeatingFieldName=$this->getFieldID(Constants::$HeatingFieldName,$ClassID);
        $Features['Heatings']=property_exists($propModel,$HeatingFieldName)?$propModel->{$HeatingFieldName}:'';

        $HoaAmenitiesFieldName=$this->getFieldID(Constants::$HoaAmenitiesFieldName,$ClassID);
        $Features['HoaAmenities']=property_exists($propModel,$HoaAmenitiesFieldName)?$propModel->{$HoaAmenitiesFieldName}:'';

        $HoaAmenitiesFieldName=$this->getFieldID(Constants::$HoaAmenitiesFieldName,$ClassID);
        $Features['HoaAmenities']=property_exists($propModel,$HoaAmenitiesFieldName)?$propModel->{$HoaAmenitiesFieldName}:'';

        $LaundryFieldName=$this->getFieldID(Constants::$LaundryFieldName,$ClassID);
        $Features['Laundries']=property_exists($propModel,$LaundryFieldName)?$propModel->{$LaundryFieldName}:'';

        $MineralRightsFieldName=$this->getFieldID(Constants::$MineralRightsFieldName,$ClassID);
        $Features['MineralRights']=property_exists($propModel,$MineralRightsFieldName)?$propModel->{$MineralRightsFieldName}:'';

        $ParkingAreaFieldName=$this->getFieldID(Constants::$ParkingAreaFieldName,$ClassID);
        $Features['ParkingArea']=property_exists($propModel,$ParkingAreaFieldName)?$propModel->{$ParkingAreaFieldName}:'';

        $PossessionFieldName=$this->getFieldID(Constants::$PossessionFieldName,$ClassID);
        $Features['Possessions']=property_exists($propModel,$PossessionFieldName)?$propModel->{$PossessionFieldName}:'';

        $RoofFieldName=$this->getFieldID(Constants::$RoofFieldName,$ClassID);
        $Features['Roofs']=property_exists($propModel,$RoofFieldName)?$propModel->{$RoofFieldName}:'';

        $SanitationFieldName=$this->getFieldID(Constants::$SanitationFieldName,$ClassID);
        $Features['Sanitation']=property_exists($propModel,$SanitationFieldName)?$propModel->{$SanitationFieldName}:'';

        $ShowingInstructionsFieldName=$this->getFieldID(Constants::$ShowingInstructionsFieldName,$ClassID);
        $Features['ShowingInstructions']=property_exists($propModel,$ShowingInstructionsFieldName)?$propModel->{$ShowingInstructionsFieldName}:'';

        $StyleFieldName=$this->getFieldID(Constants::$StyleFieldName,$ClassID);
        $Features['Styles']=property_exists($propModel,$StyleFieldName)?$propModel->{$StyleFieldName}:'';

        $SubStructureFieldName=$this->getFieldID(Constants::$SubStructureFieldName,$ClassID);
        $Features['SubStructures']=property_exists($propModel,$SubStructureFieldName)?$propModel->{$SubStructureFieldName}:'';

        $TermsOfferedFieldName=$this->getFieldID(Constants::$TermsOfferedFieldName,$ClassID);
        $Features['TermsOffered']=property_exists($propModel,$TermsOfferedFieldName)?$propModel->{$TermsOfferedFieldName}:'';

        $UnitFacesFieldName=$this->getFieldID(Constants::$UnitFacesFieldName,$ClassID);
        $Features['UnitFaces']=property_exists($propModel,$UnitFacesFieldName)?$propModel->{$UnitFacesFieldName}:'';

        $WaterRightsFieldName=$this->getFieldID(Constants::$WaterRightsFieldName,$ClassID);
        $Features['WaterRights']=property_exists($propModel,$WaterRightsFieldName)?$propModel->{$WaterRightsFieldName}:'';

        $Features['StreetDirectionPfx']=property_exists($propModel,'LIST_33')?$propModel->LIST_33:'';
        $Features['Acreage']=(property_exists($propModel,'LIST_90') && $ClassID!=3 && $ClassID!=4)?$propModel->LIST_90:'';

        $AllowableUsesFieldName=$this->getFieldID(Constants::$AllowableUsesFieldName,$ClassID);
        $Features['AllowableUses']=property_exists($propModel,$AllowableUsesFieldName)?$propModel->{$AllowableUsesFieldName}:'';

        $LocationAmenityFieldName=$this->getFieldID(Constants::$LocationAmenityFieldName,$ClassID);
        $Features['LocationAmenity']=property_exists($propModel,$LocationAmenityFieldName)?$propModel->{$LocationAmenityFieldName}:'';

        array_unshift($Features, Constants::$Agent_Role_ID);
        array_unshift($Features, $ClassID);
        $FeatureData = $this->CallRawForMultipleTable('co_propertyfeaturedetails', array_values($Features));

        $property->AgentID = (property_exists($FeatureData[0][0],'Agent'))?$FeatureData[0][0]->Agent:'';
        $property->LotSizeID = (property_exists($FeatureData[1][0],'LotSizeID'))?$FeatureData[1][0]->LotSizeID:'';
        $property->TypeID = (property_exists($FeatureData[2][0],'TypeID'))?$FeatureData[2][0]->TypeID:'';
        $property->SubTypeID = (property_exists($FeatureData[3][0],'SubTypeID'))?$FeatureData[3][0]->SubTypeID:'';
        $property->StatusID = (property_exists($FeatureData[4][0],'StatusID'))?$FeatureData[4][0]->StatusID:'';
        $property->AreaID = (property_exists($FeatureData[5][0],'AreaID'))?$FeatureData[5][0]->AreaID:'';
        $property->StateID = (property_exists($FeatureData[6][0],'StateID'))?$FeatureData[6][0]->StateID:'';
        $property->MajorAreaID = (property_exists($FeatureData[7][0],'MajorAreaID'))?$FeatureData[7][0]->MajorAreaID:'';
        $property->MemberAssociationID = (property_exists($FeatureData[8][0],'MemberAssociationID'))?$FeatureData[8][0]->MemberAssociationID:'';
        $property->SubLocID = (isset($FeatureData[9][0]))?((property_exists($FeatureData[9][0],'SubLocID'))?$FeatureData[9][0]->SubLocID:''):'';
        $property->OwnershipInterestID = (property_exists($FeatureData[10][0],'OwnershipInterestID'))?$FeatureData[10][0]->OwnershipInterestID:'';
        $property->PreFabricatedHomeID = (property_exists($FeatureData[11][0],'PreFabricatedHomeID'))?$FeatureData[11][0]->PreFabricatedHomeID:'';
        $property->SeasonalInterestID = (property_exists($FeatureData[12][0],'SeasonalInterestID'))?$FeatureData[12][0]->SeasonalInterestID:'';
        $property->RentalTermID = (property_exists($FeatureData[13][0],'RentalTermID'))?$FeatureData[13][0]->RentalTermID:'';
        $property->StreetSuffixID = (property_exists($FeatureData[14][0],'StreetSuffixID'))?$FeatureData[14][0]->StreetSuffixID:'';
        $property->UnitID = (property_exists($FeatureData[15][0],'UnitID'))?$FeatureData[15][0]->UnitID:'';
        $property->UnitSqFtRangeID = (property_exists($FeatureData[16][0],'UnitSqFtRangeID'))?$FeatureData[16][0]->UnitSqFtRangeID:'';
        $property->ApprovalFeatureID = (property_exists($FeatureData[17][0],'ApprovalFeatureID'))?$FeatureData[17][0]->ApprovalFeatureID:'';
        $property->BuildingSqFtID = (property_exists($FeatureData[18][0],'BuildingSqFtID'))?$FeatureData[18][0]->BuildingSqFtID:'';
        $property->FurnishID = (property_exists($FeatureData[19][0],'FurnishID'))?$FeatureData[19][0]->FurnishID:'';
        $property->CoolingID = (property_exists($FeatureData[20][0],'CoolingID'))?$FeatureData[20][0]->CoolingID:'';

        // multiple selection lookups
        $property->UpperLevel = (property_exists($FeatureData[21][0],'UpperLevel'))?(explode(',', $FeatureData[21][0]->UpperLevel)):'';
        $property->LowerLevel = (property_exists($FeatureData[22][0],'LowerLevel'))?(explode(',', $FeatureData[22][0]->LowerLevel)):'';
        $property->MainLevel = (property_exists($FeatureData[23][0],'MainLevel'))?(explode(',', $FeatureData[23][0]->MainLevel)):'';
        $property->OtherCooling = (property_exists($FeatureData[24][0],'OtherCooling'))?(explode(',', $FeatureData[24][0]->OtherCooling)):'';
        $property->IndoorAirQuality =(property_exists($FeatureData[25][0],'IndoorAirQuality'))?( explode(',', $FeatureData[25][0]->IndoorAirQuality)):'';
        $property->LeedCertified =(property_exists($FeatureData[26][0],'LeedCertified'))?( explode(',', $FeatureData[26][0]->LeedCertified)):'';
        $property->WaterEfficiency = (property_exists($FeatureData[27][0],'WaterEfficiency'))?(explode(',', $FeatureData[27][0]->WaterEfficiency)):'';
        $property->ConstructExterior = (property_exists($FeatureData[28][0],'ConstructExterior'))?(explode(',', $FeatureData[28][0]->ConstructExterior)):'';
        $property->EnergyEfficiency = (property_exists($FeatureData[29][0],'EnergyEfficiency'))?(explode(',', $FeatureData[29][0]->EnergyEfficiency)):'';
        $property->CurrentUses = (property_exists($FeatureData[30][0],'CurrentUses'))?(explode(',', $FeatureData[30][0]->CurrentUses)):'';
        $property->Deeds = (property_exists($FeatureData[31][0],'Deeds'))?(explode(',', $FeatureData[31][0]->Deeds)):'';
        $property->Exclusions = (property_exists($FeatureData[32][0],'Exclusions'))?(explode(',', $FeatureData[32][0]->Exclusions)):'';
        $property->Garages = (property_exists($FeatureData[33][0],'Garages'))?(explode(',', $FeatureData[33][0]->Garages)):'';
        $property->HowSold = (property_exists($FeatureData[34][0],'HowSold'))?(explode(',', $FeatureData[34][0]->HowSold)):'';
        $property->Inclusion = (property_exists($FeatureData[35][0],'Inclusion'))?(explode(',', $FeatureData[35][0]->Inclusion)):'';
        $property->LeedForHome = (property_exists($FeatureData[36][0],'LeedForHome'))?(explode(',', $FeatureData[36][0]->LeedForHome)):'';
        $property->LotDescription = (property_exists($FeatureData[37][0],'LotDescription'))?(explode(',', $FeatureData[37][0]->LotDescription)):'';
        $property->LotImprovements = (property_exists($FeatureData[38][0],'LotImprovements'))?(explode(',', $FeatureData[38][0]->LotImprovements)):'';
        $property->Parking = (property_exists($FeatureData[39][0],'Parking'))?(explode(',', $FeatureData[39][0]->Parking)):'';
        $property->PossibleUse = (property_exists($FeatureData[40][0],'PossibleUse'))?(explode(',', $FeatureData[40][0]->PossibleUse)):'';
        $property->SustainableMaterial = (property_exists($FeatureData[41][0],'SustainableMaterial'))?(explode(',', $FeatureData[41][0]->SustainableMaterial)):'';
        $property->HeatingAndCoolings = (property_exists($FeatureData[42][0],'HeatingAndCoolings'))?(explode(',', $FeatureData[42][0]->HeatingAndCoolings)):'';
        $property->Water = (property_exists($FeatureData[43][0],'Water'))?(explode(',', $FeatureData[43][0]->Water)):'';
        $property->Carports = (property_exists($FeatureData[44][0],'Carports'))?(explode(',', $FeatureData[44][0]->Carports)):'';
        $property->Accesses = (property_exists($FeatureData[45][0],'Accesses'))?(explode(',', $FeatureData[45][0]->Accesses)):'';
        $property->Amenities = (property_exists($FeatureData[46][0],'Amenities'))?(explode(',', $FeatureData[46][0]->Amenities)):'';
        $property->Conditions = (property_exists($FeatureData[47][0],'Conditions'))?(explode(',', $FeatureData[47][0]->Conditions)):'';
        $property->Construction = (property_exists($FeatureData[48][0],'Construction'))?(explode(',', $FeatureData[48][0]->Construction)):'';
        $property->Disclousures = (property_exists($FeatureData[49][0],'Disclousures'))?(explode(',', $FeatureData[49][0]->Disclousures)):'';
        $property->Electrics = (property_exists($FeatureData[50][0],'Electrics'))?(explode(',', $FeatureData[50][0]->Electrics)):'';
        $property->Exteriors = (property_exists($FeatureData[51][0],'Exteriors'))?(explode(',', $FeatureData[51][0]->Exteriors)):'';
        $property->Extras = (property_exists($FeatureData[52][0],'Extras'))?(explode(',', $FeatureData[52][0]->Extras)):'';
        $property->FirePlaces = (property_exists($FeatureData[53][0],'Fireplaces'))?(explode(',', $FeatureData[53][0]->Fireplaces)):'';
        $property->Gases = (property_exists($FeatureData[54][0],'Gases'))?(explode(',', $FeatureData[54][0]->Gases)):'';
        $property->GreenFeatures = (property_exists($FeatureData[55][0],'GreenFeatures'))?(explode(',', $FeatureData[55][0]->GreenFeatures)):'';
        $property->Heatings = (property_exists($FeatureData[56][0],'Heatings'))?(explode(',', $FeatureData[56][0]->Heatings)):'';
        $property->HoaAmenities = (property_exists($FeatureData[57][0],'HoaAmenities'))?(explode(',', $FeatureData[57][0]->HoaAmenities)):'';
        $property->Laundry = (property_exists($FeatureData[58][0],'Laundries'))?(explode(',', $FeatureData[58][0]->Laundries)):'';
        $property->MineralRights = (property_exists($FeatureData[59][0],'MineralRights'))?(explode(',', $FeatureData[59][0]->MineralRights)):'';
        $property->ParkingArea = (property_exists($FeatureData[60][0],'ParkingArea'))?(explode(',', $FeatureData[60][0]->ParkingArea)):'';
        $property->Possessions = (property_exists($FeatureData[61][0],'Possessions'))?(explode(',', $FeatureData[61][0]->Possessions)):'';
        $property->Roofs = (property_exists($FeatureData[62][0],'Roofs'))?(explode(',', $FeatureData[62][0]->Roofs)):'';
        $property->Sanitation = (property_exists($FeatureData[63][0],'Sanitation'))?(explode(',', $FeatureData[63][0]->Sanitation)):'';
        $property->ShowingInstructions = (property_exists($FeatureData[64][0],'ShowingInstructions'))?(explode(',', $FeatureData[64][0]->ShowingInstructions)):'';
        $property->Style = (property_exists($FeatureData[65][0],'Styles'))?(explode(',', $FeatureData[65][0]->Styles)):'';
        $property->SubStructures = (property_exists($FeatureData[66][0],'SubStructures'))?(explode(',', $FeatureData[66][0]->SubStructures)):'';
        $property->TermsOffered = (property_exists($FeatureData[67][0],'TermsOffered'))?(explode(',', $FeatureData[67][0]->TermsOffered)):'';
        $property->UnitFace = (property_exists($FeatureData[68][0],'UnitFaces'))?(explode(',', $FeatureData[68][0]->UnitFaces)):'';
        $property->WaterRight = (property_exists($FeatureData[69][0],'WaterRights'))?(explode(',', $FeatureData[69][0]->WaterRights)):'';
        $property->StreetDirectionPfxID =(property_exists($FeatureData[70][0],'StreetDirectionPfxID'))?$FeatureData[70][0]->StreetDirectionPfxID:'';
        $property->AcreageID =(property_exists($FeatureData[71][0],'AcreageID'))?$FeatureData[71][0]->AcreageID:'';
        $property->AllowableUses =(property_exists($FeatureData[72][0],'AllowableUses'))?$FeatureData[72][0]->AllowableUses:'';

        $property->LocationAmenity =(property_exists($FeatureData[73][0],'LocationAmenity'))?(explode(',', $FeatureData[73][0]->LocationAmenity)):'';

        $HoaDuesFieldName=$this->getFieldID(Constants::$HoaDuesFieldName,$ClassID);
        //$property->HoaDues=(property_exists($propModel,'LIST_121') && $ClassID == 3 )?$propModel->LIST_121:(property_exists($propModel,'LIST_113') && ($ClassID == 1 || $ClassID == 2 || $ClassID == 5 || $ClassID == 6) )?$propModel->LIST_113:'';
        $property->HoaDues = (property_exists($propModel,'LIST_121') && $ClassID==3)?$propModel->LIST_121:((property_exists($propModel,'LIST_113') && ($ClassID == 1 || $ClassID == 2 || $ClassID == 5 || $ClassID == 6))?$propModel->LIST_113:'');        

        
        $property->BuildingSqFtCommLease=($ClassID==4)?(property_exists($propModel,'LIST_94'))?$propModel->LIST_94:'':'';

     
        return $property;

    }

    public function getFieldID($fieldName,$class) {
        switch($fieldName)
        {
            case Constants::$WaterFieldName:
                switch($class)
                {
                    case 1:
                        return 'GF20081113193939865339000000';
                        break;
                    case 2:
                        return 'GF20081210185311858974000000';
                        break;
                    case 5:
                        return 'GF20081110191919894979000000';
                        break;
                    case 6:
                        return 'GF20081217201434947638000000';
                        break;
                    case 3:
                        return 'GF20081219153708824108000000';
                        break;
                    case 4:
                        return 'GF20081219172547201776000000';
                        break;
                    case 7:
                        return 'GF20110517210101202279000000';
                        break;
                }
                break;
            case Constants::$CarportFieldName:
                switch($class) {
                    case 1:
                        return 'GF20081113194118467016000000';
                        break;
                    case 2:
                        return 'GF20081210185301036979000000';
                        break;
                    case 7:
                        return 'GF20110517210042296771000000';
                        break;
                    default:
                        return 'Carport';
                }
                break;
            case Constants::$AccessFieldName:
                switch($class){
                    case 5:
                        return 'GF20081110191919894239000000';
                        break;
                    case 6:
                        return 'GF20081217201426179205000000';
                        break;
                    case 3:
                        return 'GF20081219154436690740000000';
                        break;
                    case 4:
                        return 'GF20081219172531130376000000';
                        break;
                    default:
                        return 'Access';
                }
                break;
            case Constants::$AmenitiesFieldName:
                switch($class) {
                    case 3:
                        return 'GF20081219154500792884000000';
                        break;
                    case 4:
                        return 'GF20081219172531622371000000';
                        break;
                    default:
                        return 'Amenities';
                }
                break;
            case Constants::$ConditionsFieldName:
                switch($class){
                    case 1:
                        return 'GF20081113193854378255000000';
                        break;
                    case 2:
                        return 'GF20081210185300721452000000';
                        break;
                    case 3:
                        return 'GF20081219153657873757000000';
                        break;
                    case 4:
                        return 'GF20081219172532781805000000';
                        break;
                    case 7:
                        return 'GF20110517210041953199000000';
                        break;
                    default:
                        return 'Conditions';
                }
                break;
            case Constants::$ConstructionFieldName:
                switch($class){
                    case 1:
                        return 'GF20081113193814521314000000';
                        break;
                    case 2:
                        return 'GF20081210185300056643000000';
                        break;
                    case 3:
                        return 'GF20081219153657226619000000';
                        break;
                    case 4:
                        return 'GF20081219172532247053000000';
                        break;
                    default:
                        return 'Construction';
                }
                break;
            case Constants::$DisclosureFieldName:
                switch($class){
                    case 1:
                        return 'GF20081113194233984568000000';
                        break;
                    case 2:
                        return 'GF20081210185302024496000000';
                        break;
                    case 5:
                        return 'GF20081110191919894410000000';
                        break;
                    case 6:
                        return 'GF20081217201427750131000000';
                        break;
                    case 3:
                        return 'GF20081219153659154889000000';
                        break;
                    case 4:
                        return 'GF20081219172533957614000000';
                        break;
                    default:
                        return 'Disclosures';
                }
                break;
            case Constants::$ElectricFieldName:
                switch($class){
                    case 1:
                        return 'GF20081113193916554539000000';
                        break;
                    case 2:
                        return 'GF20081210185303082775000000';
                        break;
                    case 5:
                        return 'GF20081110191919894478000000';
                        break;
                    case 6:
                        return 'GF20081217201428753571000000';
                        break;
                    case 3:
                        return 'GF20081219153700033021000000';
                        break;
                    case 4:
                        return 'GF20081219172535578670000000';
                        break;
                    case 7:
                        return 'GF20110517210045830580000000';
                        break;
                }
                break;
            case Constants::$ExteriorFieldName:
                switch($class){
                    case 1:
                        return 'GF20100401183654367603000000';
                        break;
                    case 2:
                        return 'GF20100401184140204030000000';
                        break;
                    default:
                        return 'Exterior';
                }
                break;
            case Constants::$ExtraFieldName:
                switch($class){
                    case 1:
                        return 'GF20081113194200562715000000';
                        break;
                    case 2:
                        return 'GF20081210185303882964000000';
                        break;
                    case 5:
                        return 'GF20081110191919894511000000';
                        break;
                    case 6:
                        return 'GF20081217201428907549000000';
                        break;
                    case 3:
                        return 'GF20081219153700849129000000';
                        break;
                    case 4:
                        return 'GF20081219172535696215000000';
                        break;
                    case 7:
                        return 'GF20110517210047466764000000';
                        break;
                }
                break;
            case Constants::$FireplaceFieldName:
                switch($class) {
                    case 1:
                        return 'GF20081113194107612667000000';
                        break;
                    case 2:
                        return 'GF20081210185304836276000000';
                        break;
                    case 7:
                        return 'GF20110517210048835582000000';
                        break;
                    default:
                        return 'Fireplace';
                }
                break;
            case Constants::$GasFieldName:
                switch($class){
                    case 1:
                        return 'GF20081113193929101310000000';
                        break;
                    case 2:
                        return 'GF20081210185305023579000000';
                        break;
                    case 5:
                        return 'GF20081110191919894625000000';
                        break;
                    case 6:
                        return 'GF20081217201429985492000000';
                        break;
                    case 3:
                        return 'GF20081219153702163057000000';
                        break;
                    case 4:
                        return 'GF20081219172537780375000000';
                        break;
                    case 7:
                        return 'GF20110517210049997056000000';
                        break;
                }
                break;
            case Constants::$GreenFeaturesFieldName:
                switch($class){
                    case 1:
                        return 'GF20090108141240934717000000';
                        break;
                    case 2:
                        return 'GF20081212154319339593000000';
                        break;
                    case 3:
                        return 'GF20081219154359775859000000';
                        break;
                    case 4:
                        return 'GF20081219172536997197000000';
                        break;
                    case 7:
                        return 'GF20110517210049224636000000';
                        break;
                    default:
                        return 'GreenFeatures';
                }
                break;
            case Constants::$HeatingFieldName:
                switch($class){
                    case 1:
                        return 'GF20081113193905566715000000';
                        break;
                    case 2:
                        return 'GF20081210185306357696000000';
                        break;
                    case 7:
                        return 'GF20110517210051810577000000';
                        break;
                    default:
                        return 'Heating';
                }
                break;
            case Constants::$HoaAmenitiesFieldName:
                switch($class){
                    case 1:
                        return 'GF20081113194809194714000000';
                        break;
                    case 2:
                        return 'GF20081210185305226834000000';
                        break;
                    case 5:
                        return 'GF20081110191919894658000000';
                        break;
                    case 7:
                        return 'GF20110517210050175682000000';
                        break;
                }
                break;
            case Constants::$LaundryFieldName:
                switch($class){
                    case 1:
                        return 'GF20081113193734255015000000';
                        break;
                    case 2:
                        return 'GF20081210185308244928000000';
                        break;
                    case 7:
                        return 'GF20110517210055312869000000';
                        break;
                    default:
                        return 'Laundry';
                }
                break;
            case Constants::$MineralRightsFieldName:
                switch($class){
                    case 1:
                        return 'GF20081113194306059346000000';
                        break;
                    case 5:
                        return 'GF20081216214746847734000000';
                        break;
                    case 6:
                        return 'GF20081217201432755708000000';
                        break;
                    case 3:
                        return 'GF20081219153705428227000000';
                        break;
                    case 4:
                        return 'GF20081219172539159718000000';
                        break;
                    default:
                        return 'MineralRights';
                }
                break;
            case Constants::$ParkingAreaFieldName:
               switch($class){
                   case 1:
                       return 'GF20081113194130890449000000';
                        break;
                   case 2:
                       return 'GF20081210185308703644000000';
                        break;
                   case 7:
                       return 'GF20110517210056412039000000';
                        break;
                   default:
                       return 'ParkingArea';
               }
               break;
            case Constants::$PossessionFieldName:
                switch($class){
                    case 1:
                        return 'GF20081113194147552696000000';
                        break;
                    case 2:
                        return 'GF20081210185309008911000000';
                        break;
                    case 5:
                        return 'GF20081217162756791019000000';
                        break;
                    case 6:
                        return 'GF20081217201432960729000000';
                        break;
                    case 3:
                        return 'GF20081219153706001936000000';
                        break;
                    case 4:
                        return 'GF20081219172541952491000000';
                        break;
                    case 7:
                        return 'GF20110517210056761047000000';
                        break;
                }
                break;
            case Constants::$RoofFieldName:
               switch($class){
                   case 1:
                       return 'GF20081113193838229693000000';
                       break;
                   case 2:
                       return 'GF20081210185309212909000000';
                       break;
                   case 3:
                       return 'GF20081219153706208865000000';
                       break;
                   case 4:
                       return 'GF20081219172542161974000000';
                       break;
                   case 7:
                       return 'GF20110517210057040156000000';
                       break;
                   default;
                       return 'Roof';
               }
               break;
            case Constants::$SanitationFieldName:
                switch($class){
                    case 1:
                        return 'GF20081113194011590415000000';
                        break;
                    case 2:
                        return 'GF20081210185310506492000000';
                        break;
                    case 5:
                        return 'GF20081110191919894908000000';
                        break;
                    case 6:
                        return 'GF20081217201434039081000000';
                        break;
                    case 3:
                        return 'GF20081219153707482534000000';
                        break;
                    case 4:
                        return 'GF20081219172543504333000000';
                        break;
                    case 7:
                        return 'GF20110517210058712569000000';
                        break;
                }
                break;
            case Constants::$ShowingInstructionsFieldName:
                switch($class){
                    case 2:
                        return 'GF20081210185310088891000000';
                        break;
                    case 5:
                        return 'GF20081217162823927274000000';
                        break;
                    case 6:
                        return 'GF20081217201433647983000000';
                        break;
                    case 3:
                        return 'GF20081219153707073132000000';
                        break;
                    case 4:
                        return 'GF20081219172543098715000000';
                        break;
                    case 7:
                        return 'GF20110517210058286860000000';
                        break;
                    default:
                        return 'ShowingInstructions';
                }
                break;
            case Constants::$StyleFieldName:
                switch($class){
                    case 1:
                        return 'GF20081113193745023142000000';
                        break;
                    case 2:
                        return 'GF20081210185310660831000000';
                        break;
                    case 7:
                        return 'GF20110517210059399265000000';
                        break;
                    default:
                        return 'Style';
                }
                break;
            case Constants::$SubStructureFieldName:
                switch($class){
                    case 1:
                        return 'GF20081113193829424476000000';
                        break;
                    case 2:
                        return 'GF20081210185309571418000000';
                        break;
                    case 3: 
                        return 'GF20081219153706564858000000';
                        break;

                    case 4:
                        return 'GF20081219172542571611000000';
                        break;               
                    case 7:
                        return 'GF20110517210057507579000000';
                        break;
                    default:
                        return 'SubStructure';
                }
                break;
            case Constants::$TermsOfferedFieldName:
                switch($class){
                    case 1:
                        return 'GF20081113194216286181000000';
                        break;
                    case 2:
                        return 'GF20081210185311081667000000';
                        break;
                    case 5:
                        return 'GF20081217162740939049000000';
                        break;
                    case 6:
                        return 'GF20081217201434281928000000';
                        break;
                    case 3:
                        return 'GF20081219153708060601000000';
                        break;
                    case 4:
                        return 'GF20081219172544914032000000';
                        break;
                    default:
                        return 'TermsOffered';
                }
                break;
            case Constants::$UnitFacesFieldName:
                switch($class){
                    case 1:
                        return 'GF20081113194857277334000000';
                        break;
                    case 2:
                        return 'GF20081210185311436464000000';
                        break;
                    case 7:
                        return 'GF20110517210100297323000000';
                        break;
                    default:
                        return 'UnitFaces';
                }
                break;
            case Constants::$WaterRightsFieldName:
                switch($class){
                    case 1:
                        return 'GF20081113194316331093000000';
                        break;
                    case 5:
                        return 'GF20081110191919894310000000';
                        break;
                    case 6:
                        return 'GF20081217201434589033000000';
                        break;
                    case 3:
                        return 'GF20081219153708663521000000';
                        break;
                    case 4:
                        return 'GF20081219172547052426000000';
                        break;
                    default:
                        return 'WaterRights';
                }
                break;
            case Constants::$UnfinishedSqFt:
                switch($class){
                    case 1:
                        return 'LIST_121';
                        break;
                    case 2:
                        return 'LIST_121';
                        break;
                    case 7:
                        return 'LIST_121';
                        break;
                    default:
                        return 'UnfinishedSqFt';
                }
                break;
            case Constants::$Bedroom1RoomLevel:
                switch($class){
                    case 1:
                        return 'ROOM_1B_room_level';
                        break;
                    case 2:
                        return 'ROOM_BR1_room_level';
                        break;
                    default:
                        return 'Bedroom1RoomLevel';
                }
                break;
            case Constants::$Bedroom2RoomLevel:
                switch($class){
                    case 1:
                        return 'ROOM_2B_room_level';
                        break;
                    case 2:
                        return 'ROOM_BR2_room_level';
                        break;
                    default:
                        return 'Bedroom2RoomLevel';
                }
                break;
            case Constants::$Bedroom3RoomLevel:
                switch($class){
                    case 1:
                        return 'ROOM_3B_room_level';
                        break;
                    case 2:
                        return 'ROOM_BR3_room_level';
                        break;
                    default:
                        return 'Bedroom3RoomLevel';
                }
                break;
            case Constants::$Bedroom4PlusRoomLevel:
                switch($class){
                    case 1:
                        return 'ROOM_4+_room_level';
                        break;
                    default:
                        return 'Bedroom4PlusRoomLevel';
                }
                break;
            case Constants::$Bedroom4PlusRoomRemarks:
                switch($class){
                    case 1:
                        return 'ROOM_4+_room_rem';
                        break;
                    default:
                        return 'Bedroom4PlusRoomRemarks';
                }
                break;
            case Constants::$FamilyRoomRoomLevel:
                switch($class){
                    case 1:
                        return 'ROOM_FR_room_level';
                        break;
                    default:
                        return 'FamilyRoomRoomLevel';
                }
                break;
            case Constants::$FullBathRoomLevel:
                switch($class){
                    case 1:
                        return 'ROOM_FB_room_level';
                        break;
                    case 2:
                        return 'ROOM_FB_room_level';
                        break;
                    default:
                        return 'FullBathRoomLevel';
                }
                break;
            case Constants::$LaundryOrUtilityRoomRoomLevel:
                switch($class){
                    case 1:
                        return 'ROOM_LD_room_level';
                        break;
                    default:
                        return 'LaundryOrUtilityRoomRoomLevel';
                }
                break;
            case Constants::$LivingRoomRoomLevel:
                switch($class){
                    case 1:
                        return 'ROOM_LV_room_level';
                        break;
                    case 2:
                        return 'ROOM_LV_room_level';
                    default:
                        return 'LivingRoomRoomLevel';
                }
                break;
            case Constants::$Bedroom1Width:
                switch($class){
                    case 1:
                        return 'ROOM_1B_room_width';
                        break;
                    case 2:
                        return 'ROOM_BR1_room_width';
                        break;
                    default:
                        return 'Bedroom1Width';
                }
                break;
            case Constants::$DiningRoomLength:
                switch($class){
                    case 1:
                        return 'ROOM_DN_room_length';
                        break;
                    case 2:
                        return 'ROOM_DR_room_length';
                        break;
                    default:
                        return 'DiningRoomLength';
                }
                break;
            case Constants::$DiningRoomWidth:
                switch($class){
                    case 1:
                        return 'ROOM_DN_room_width';
                        break;
                    case 2:
                        return 'ROOM_DR_room_width';
                        break;
                    default:
                        return 'DiningRoomWidth';
                }
                break;
            case Constants::$DiningRoomNoofRooms:
                switch($class){
                    case 1:
                        return 'ROOM_DN_room_nbr';
                        break;
                    case 2:
                        return 'ROOM_DR_room_nbr';
                    default:
                        return 'DiningRoomNoofRooms';
                }
                break;
            case Constants::$DiningRoomRoomLevel:
                switch($class){
                    case 1:
                        return 'ROOM_DN_room_level';
                        break;
                    case 2:
                        return 'ROOM_DR_room_level';
                        break;
                    default:
                        return 'DiningRoomRoomLevel';
                }
                break;
            case Constants::$KitchenLength:
                switch($class){
                    case 1:
                        return 'ROOM_KT_room_length';
                        break;
                    case 2:
                        return 'ROOM_KIT_room_length';
                        break;
                    default:
                        return 'KitchenLength';
                }
                break;
            case Constants::$KitchenWidth:
                switch($class){
                    case 1:
                        return 'ROOM_KT_room_width';
                        break;
                    case 2:
                        return 'ROOM_KT_room_width';
                        break;
                    default:
                        return 'KitchenWidth';
                }
                break;
            case Constants::$KitchenNoofRooms:
                switch($class){
                    case 1:
                        return 'ROOM_KT_room_nbr';
                        break;
                    case 2:
                        return 'ROOM_KIT_room_nbr';
                        break;
                    default:
                        return 'KitchenNoofRooms';
                }
                break;
            case Constants::$KitchenRoomLevel:
                switch($class){
                    case 1:
                        return 'ROOM_KT_room_level';
                        break;
                    case 2:
                        return 'ROOM_KIT_room_level';
                    default:
                        return 'KitchenRoomLevel';
                }
                break;
            case Constants::$LivingRoomNoofRooms:
                switch($class){
                    case 1:
                        return 'ROOM_LV_room_nbr';
                        break;
                    case 2:
                        return 'ROOM_LV_room_nbr';
                        break;
                    default:
                        return 'LivingRoomNoofRooms';
                }
                break;
            case Constants::$LivingRoomWidth:
                switch($class){
                    case 1:
                        return 'ROOM_LV_room_width';
                        break;
                    case 2:
                        return 'ROOM_LV_room_width';
                        break;
                    default:
                        return 'LivingRoomWidth';
                }
                break;
            case Constants::$LivingRoomLength:
                switch($class){
                    case 1:
                        return 'ROOM_LV_room_length';
                        break;
                    case 2:
                        return 'ROOM_LV_room_length';
                        break;
                    default:
                        return 'LivingRoomLength';
                }
                break;
            case Constants::$SignFieldName:
                switch($class){
                    case 1:
                        return 'GF20081113194840111335000000';
                        break;
                    case 2:
                        return 'GF20081210185309935910000000';
                        break;
                    case 5:
                        return 'GF20081110191919894343000000';
                        break;
                    case 6:
                        return 'GF20081217201433498066000000';
                        break;
                    case 3:
                        return 'GF20081219153706923695000000';
                        break;
                    case 4:
                        return 'GF20081219172542945043000000';
                        break;
                    case 7:
                        return 'GF20110517210058052353000000';
                        break;
                }
                break;
            case Constants::$AllowableUsesFieldName:
                switch($class){
                    case 6:
                        return 'GF20081217201433183071000000';
                        break;
                    case 3:
                        return 'GF20081219154331348617000000';
                        break;
                    case 4:
                        return 'GF20081219172546384546000000';
                        break;
                    default:
                        return 'AllowableUses';
                }
                break;

             case Constants::$HoaDuesFieldName:
                switch($class){
                    case 1:
                        return 'LIST_113';
                        break;
                    case 2:
                        return 'LIST_113';
                        break;
                    case 5:
                        return 'LIST_113';
                        break;
                    case 6:
                        return 'LIST_113';
                        break;
                    case 3:
                        return 'LIST_121';
                        break;
                    default:
                        return 'LIST_113';
                }
                break;
            case Constants::$Bedroom1RoomRemarksFieldName:
                switch($class){
                    case 1:
                        return 'ROOM_1B_room_rem';
                        break;
                    case 2:
                        return 'ROOM_1BR_room_rem';
                        break;
                    default:
                        return 'Bedroom1RoomRemarks';
                }
                break;
            case Constants::$Bedroom1NoofRoomsFieldName:
                switch($class){
                    case 1:
                        return 'ROOM_1B_room_nbr';
                        break;
                    case 2:
                        return 'ROOM_1BR_room_nbr';
                        break;
                    default:
                        return 'Bedroom1NoofRooms';
                }
                break;
            case Constants::$Bedroom1LengthFieldName:
               switch($class){
                   case 1:
                       return 'ROOM_1B_room_length';
                       break;
                   case 2:
                       return 'ROOM_1BR_room_length';
                       break;
                   default:
                       return 'Bedroom1Length';
               }
                break;
            case Constants::$Bedroom1AreaFieldName:
                switch($class){
                    case 1:
                        return 'ROOM_1B_room_area';
                        break;
                    case 2:
                        return 'ROOM_1BR_room_area';
                        break;
                    default:
                        return 'Bedroom1Area';
                }
                break;
            case Constants::$Bedroom2WidthFieldName:
                switch($class){
                    case 1:
                        return 'ROOM_2B_room_width';
                        break;
                    case 2:
                        return 'ROOM_BR2_room_width';
                        break;
                    default:
                        return 'Bedroom2Width';
                }
                break;
            case Constants::$Bedroom2RoomRemarksFieldName:
                switch($class){
                    case 1:
                        return 'ROOM_2B_room_rem';
                        break;
                    case 2:
                        return 'ROOM_BR2_room_rem';
                        break;
                    default:
                        return 'Bedroom2RoomRemarks';
                }
                break;
            case Constants::$Bedroom2LengthFieldName:
                switch($class){
                    case 1:
                        return 'ROOM_2B_room_length';
                        break;
                    case 2:
                        return 'ROOM_BR2_room_length';
                        break;
                    default:
                        return 'Bedroom2Length';
                }
                break;
            case Constants::$Bedroom2AreaFieldName:
                switch($class){
                    case 1:
                        return 'ROOM_2B_room_area';
                        break;
                    case 2:
                        return 'ROOM_BR2_room_area';
                        break;
                    default:
                        return 'Bedroom2Area';
                }
                break;
            case Constants::$Bedroom3WidthFieldName:
                switch($class){
                    case 1:
                        return 'ROOM_3B_room_width';
                        break;
                    case 2:
                        return 'ROOM_BR3_room_width';
                        break;
                    default:
                        return 'Bedroom3Width';
                }
                break;
            case Constants::$Bedroom3RoomRemarksFieldName:
                switch($class){
                    case 1:
                        return 'ROOM_3B_room_rem';
                        break;
                    case 2:
                        return 'ROOM_BR3_room_rem';
                        break;
                    default:
                        return 'Bedroom3RoomRemarks';
                }
            break;
            case Constants::$Bedroom3NoofRoomsFieldName:
                switch($class){
                    case 1:
                        return 'ROOM_3B_room_nbr';
                        break;
                    case 2:
                        return 'ROOM_BR3_room_nbr';
                        break;
                    default:
                        return 'Bedroom3NoofRooms';
                }
                break;
            case Constants::$Bedroom3LengthFieldName:
                switch($class){
                    case 1:
                        return 'ROOM_3B_room_length';
                        break;
                    case 2:
                        return 'ROOM_BR3_room_length';
                        break;
                    default:
                        return 'Bedroom3Length';
                }
                break;
            case Constants::$Bedroom3AreaFieldName:
                switch($class){
                    case 1:
                        return 'ROOM_3B_room_area';
                        break;
                    case 2:
                        return 'ROOM_BR3_room_area';
                        break;
                    default:
                        return 'Bedroom3Area';
                }
                break;
            case Constants::$DiningRoomRoomRemarksFieldName:
                switch($class) {
                    case 1:
                        return 'ROOM_DN_room_rem';
                        break;
                    case 2:
                        return 'ROOM_DR_room_rem';
                        break;
                    default:
                        return 'DiningRoomRoomRemarks';
                }
                break;
            case Constants::$DiningRoomAreaFieldName:
                switch($class) {
                    case 1:
                        return 'ROOM_DN_room_area';
                        break;
                    case 2:
                        return 'ROOM_DR_room_area';
                        break;
                    default:
                        return 'DiningRoomArea';
                }
                break;
            case Constants::$KitchenRoomRemarksFieldName:
                switch($class) {
                    case 1:
                        return 'ROOM_KT_room_rem';
                        break;
                    case 2:
                        return 'ROOM_KIT_room_rem';
                        break;
                    default:
                        return 'KitchenRoomRemarks';
                }
                break;
            case Constants::$KitchenAreaFieldName:
                switch($class) {
                    case 1:
                        return 'ROOM_KT_room_area';
                        break;
                    case 2:
                        return 'ROOM_KIT_room_area';
                        break;
                    default:
                        return 'KitchenArea';
                }
                break;
            case Constants::$WorkShopWidthFieldName:
                switch($class) {
                    case 1:
                        return 'ROOM_WK_room_width';
                        break;
                    case 2:
                        return 'ROOM_WS_room_width';
                        break;
                    default:
                        return 'WorkShopWidth';
                }
                break;
            case Constants::$WorkShopRoomRemarksFieldName:
                switch($class) {
                    case 1:
                        return 'ROOM_WK_room_rem';
                        break;
                    case 2:
                        return 'ROOM_WS_room_rem';
                        break;
                    default:
                        return 'WorkShopRoomRemarks';
                }
                break;
            case Constants::$WorkShopLengthFieldName:
                switch($class) {
                    case 1:
                        return 'ROOM_WK_room_length';
                        break;
                    case 2:
                        return 'ROOM_WS_room_length';
                        break;
                    default:
                        return 'WorkShopLength';
                }
                break;
            case Constants::$WorkShopAreaFieldName:
                switch($class) {
                    case 1:
                        return 'ROOM_WK_room_area';
                        break;
                    case 2:
                        return 'ROOM_WS_room_area';
                        break;
                    default:
                        return 'WorkShopArea';
                }
                break;
            case Constants::$LocationAmenityFieldName:
                switch($class) {
                    case 1:
                        return 'GF20081113194820734159000000';
                        break;
                    case 2:
                        return 'GF20081210185307520531000000';
                        break;
                    case 3:
                        return 'GF20081219153704720037000000';
                        break;
                    case 4:
                        return 'GF20081219172538545444000000';
                        break;
                    case 7:
                        return 'GF20110517210054239926000000';
                        break;
                    default:
                        return 'WorkShopArea';
                    }
                    break;
            case Constants::$HeatingAndCollingName:
                switch($class) {
                    case 1:
                        return 'GF20101203215602102494000000';
                        break;
                    case 3:
                        return 'GF20081219153703535794000000';
                        break;
                    case 4:
                        return 'GF20081219172537984022000000';
                        break;
                    default:
                        return 'HeatingAndColling';

                }
                break;
        }
    }

    public function getCoSearchModelForPropertyList($SiteID)
    {
        $response = new ServiceResponse();
        $model = new stdClass();
        $PropertyResults = $this->CallRawForMultipleTable('co_propertymodel', [$SiteID]);
        $searchModel = new stdClass();
        $searchModel->StatusID = Constants::$Property_Status_Active;
        $searchModel->SiteID = $SiteID;
        $searchModel->IsHidden = Constants::$ShowHidden;
        $searchModel->MLSNo = "";
        $searchModel->Street = "";
        $searchModel->AgentID = "";
        $searchModel->ClassID = "";
        $searchModel->City = "";
        $searchModel->ZipCode = "";
        $model->StatusLookup = $PropertyResults[0];
        $model->AgentLookup = $PropertyResults[1];
        $model->ClassLookup = $PropertyResults[2];
        $model->frontSearchModel = $searchModel;
        $model->backSearchModel = $searchModel;
        $response->Data = $model;
        return $response;
    }
    /* co cron jobs */
    public function addCoAllProperties() {
        $response = new ServiceResponse();
        $config = new \PHRETS\Configuration;
        $LogArray=[];
        try {
            $config->setloginurl(Config::get('config.Aspen_Login_URL'));
            $config->setHttpAuthenticationMethod(Config::get('config.CLAW_Authentication_Method'));
            $config->setOption('use_post_method', false);
            $config->setOption('disable_follow_location', false);

            // get credentials from database settings table. We kept them in db so user can change easily if there is any change.
            $Credentials = $this->GetCLAWCredentials(Constants::$ColoradoSiteID);

            $config->setusername(Config::get('config.Aspen_UserName'));
            $config->setpassword(Config::get('config.Aspen_Password'));

            $rets = new \PHRETS\Session($config);
            $login = $rets->Login();

            $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
            if(!$getSettings->{Constants::$Co_AllPropertyCronJobFlag}) {
                $getSettings->{Constants::$Co_AllPropertyCronJobFlag} = true; // set flag to running
                $updateCounter=0;
                $this->SaveEntity($getSettings);
                if ($getSettings->CoCronAbbreviation == '') { // check if class if null then will add first and get class id abbreviation
                    $ClassData = $this->CallRawForSingleTable("co_getclassinfo",['',-1]);
                    $ClassID = $ClassData[0]->ClassID;
                    $ClassAbbreviation = $ClassData[0]->ClassAbriviation;
                    $getSettings->CoCronAbbreviation = $ClassAbbreviation;
                    $this->SaveEntity($getSettings);
                } else { // select class id and abbreviation
                    //$ClassData = $this->RunQueryStatement("select * from co_lu_classes where ClassAbriviation='".$getSettings->CoCronAbbreviation."'", Constants::$QueryType_Select);
                    $ClassData=$this->CallRawForSingleTable('co_getclassinfo',[$getSettings->CoCronAbbreviation,-1]);
                    $ClassID = $ClassData[0]->ClassID;
                    $ClassAbbreviation = $getSettings->CoCronAbbreviation;
                }

                if ($login) {
                    // Search property with user given listingID(MLS#)
                    $resource = 'Property';
                    $class = $ClassAbbreviation;
                    $query = '(LIST_15=|'.$this->getClassStatusSearch($ClassID).')';// '(LIST_105=' . $MlsNo . ')'; //LIST_105 = 146308 //LIST_22=1+

                    $result = $rets->Search(
                        $resource,
                        $class,
                        $query,
                        [
                            'QueryType' => 'DMQL2',
                            'Count' => 1, // only records
                            'Format' => 'COMPACT-DECODED',
                            'Limit' => Config::get('config.CoAllPropertyCount'),
                            'Offset' => $getSettings->CoAllPropertyCronCount,
                            'StandardNames' => 0
                        ]
                    );

                    // Add log for rets search property.
                    $LogArray = $this->StoreRetsLog(Constants::$Value_False, Constants::$ColoradoSiteID, Constants::$RETSActionSearch, $result->URL, '', serialize($result->toArray()), $LogArray, true);
                    $data = json_decode($result->toJSON());
                    if ($data) {
                        foreach($data as $singleProperty) {
                            $searchParam = array();
                            $searchValues = Common::SetSearchArray('MLSNo', $singleProperty->LIST_105, Constants::$Value_True);
                            array_push($searchParam, $searchValues);
                            $duplicate = $this->GetEntity(new CoPropertyListingsEntity(), $searchParam);
                            if($duplicate){
                                $responseArray[] = trans('messages.PropertyDuplicate');
                                continue;
                            }

                            /*$CheckForIsWB = Common::getPropertyOfficeID($singleProperty->LIST_106, Constants::$ColoradoSiteID);
                            if ($CheckForIsWB) {
                                $IsWBProperty = Constants::$Value_True;
                            }*/

                            $PropertyModel = new stdClass();
                            // map value with database
                            $PropertyModel->ListingModel = $this->getColoradoPropertyFormatted($singleProperty, $ClassID);

                            $PropertyModel->ListingModel->IsWBProperty=Constants::$Value_False;

                            $CheckForIsWB = Common::getPropertyOfficeID($singleProperty->LIST_106, Constants::$ColoradoSiteID);
                            if ($CheckForIsWB) {
                                $PropertyModel->ListingModel->IsWBProperty = Constants::$Value_True;
                            }

                            if ($singleProperty->LIST_133 > 0) { //check for images
                                $objects = $rets->GetObject(
                                    'Property',
                                    '640x480', //Photo,HiRes
                                    $PropertyModel->ListingModel->ListingKey,
                                    '*', '1'
                                );
                                $checkArrayValue = $objects->toArray();

                                if (count($checkArrayValue) > 0) {
                                    $MediaArray = array();
                                    $this->CustomDeleteEntity(new CoTempRetsImagesEntity(), 'PropertyListingID', $singleProperty->LIST_105);
                                    /*foreach ($objects->toArray() as $key => $object) {
                                        if ($object->getObjectId() == '1') {
                                            // upload first image
                                            $PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing, Constants::$Value_False, Constants::$ColoradoSiteID, $object->getLocation());
                                            $PropertyModel->ListingModel->UploadedFile[0]->SortOrder = 1;
                                            $PropertyModel->ListingModel->UploadedFile[0]->IsSavedInDB = 2;

                                            // set array for first uploaded image to store in co_propertylistings table
                                            foreach ($PropertyModel->ListingModel->UploadedFile[0] as $key => $value) {
                                                $PropertyModel->ListingModel->ImagesModel[0][$key] = $value;
                                                if ($key == 'FilePath') {
                                                    $getnameArray = explode('/', $value);
                                                    $PropertyModel->ListingModel->ImagesNameModel[0] = $getnameArray[count($getnameArray) - 1];
                                                }
                                            }
                                        }
                                        if ($object->getObjectId() != '1') {
                                            $MediaData = array();
                                            $MediaData['PropertyListingID'] = $singleProperty->LIST_105;
                                            $MediaData['UserID'] = Constants::$Value_False;
                                            $MediaData['SiteID'] = Constants::$ColoradoSiteID;
                                            $MediaData['ListingKey'] = $PropertyModel->ListingModel->ListingKey;
                                            $MediaData['PropObjectKey'] = $object->getObjectId();
                                            $MediaData['PropMediaKey'] = $object->getContentId();
                                            $MediaData['PropMediaURL'] = $object->getLocation();
                                            array_push($MediaArray, $MediaData);
                                        }
                                    }
                                    if (count($MediaArray) > 0) {
                                        $PropertyModel->IsShowUploadNote = 1;
                                    } else {
                                        $PropertyModel->IsShowUploadNote = 0;
                                    }*/
                                    $ignoreImg = 0;
                                    if (count($objects->toArray()) > 0) {
                                        try {
                                            //$PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing,Constants::$Value_False, Constants::$MercerVineSiteID, $GetFirstImage[0]['PropMediaURL']);
                                            // upload first image
                                            $PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing, Constants::$Value_False, Constants::$ColoradoSiteID, $objects->toArray()[0]->getLocation());
                                                
                                        } 
                                        catch (Exception $e) {
                                            Log::info('In first catch block of first image for Co Listing ID: ' . $singleProperty->LIST_105);

                                            $addToUploadImage=new CoImageUploadErrorEntity();
                                            $addToUploadImage->MLSNo=$singleProperty->LIST_105;
                                            $addToUploadImage->ImagePath=$objects->toArray()[0]->getLocation();
                                            $addToUploadImage->Errortype=Constants::$Value_True;
                                            $addToUploadImage->AddedDateTime=date(Constants::$DefaultDateTimeFormat);
                                            $this->SaveEntity($addToUploadImage);

                                            $PropertyModel->ListingModel->UploadedFile[0]->SortOrder = 1;
                                            $PropertyModel->ListingModel->UploadedFile[0]->IsSavedInDB = 2;

                                            // set array for first uploaded image to store in co_propertylistings table
                                            foreach ($PropertyModel->ListingModel->UploadedFile[0] as $key => $value) {
                                                $PropertyModel->ListingModel->ImagesModel[0][$key] = $value;
                                                if ($key == 'FilePath') {
                                                    $getnameArray = explode('/', $value);
                                                    $PropertyModel->ListingModel->ImagesNameModel[0] = $getnameArray[count($getnameArray) - 1];
                                                }
                                            }
                                            $ignoreImg = 1;
                                            try {
                                                if (count($objects->toArray()) > 1)
                                                   // $PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing, Constants::$Value_False, Constants::$MercerVineSiteID, $GetFirstImage[1]['PropMediaURL']);
                                                    $PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing, Constants::$Value_False, Constants::$ColoradoSiteID, $objects->toArray()[1]->getLocation());
                                            } catch (Exception $e) {
                                                Log::info('In second catch block of first image for Listing ID: ' . $singleProperty->LIST_105);

                                                $addToUploadImage=new CoImageUploadErrorEntity();
                                                $addToUploadImage->MLSNo=$singleProperty->LIST_105;
                                                $addToUploadImage->ImagePath=$objects->toArray()[1]->getLocation();
                                                $addToUploadImage->Errortype=Constants::$Value_True;
                                                $addToUploadImage->AddedDateTime=date(Constants::$DefaultDateTimeFormat);
                                                $this->SaveEntity($addToUploadImage);

                                                $PropertyModel->ListingModel->UploadedFile[0]->SortOrder = 1;
                                                $PropertyModel->ListingModel->UploadedFile[0]->IsSavedInDB = 2;

                                                // set array for first uploaded image to store in co_propertylistings table
                                                foreach ($PropertyModel->ListingModel->UploadedFile[0] as $key => $value) {
                                                    $PropertyModel->ListingModel->ImagesModel[0][$key] = $value;
                                                    if ($key == 'FilePath') {
                                                        $getnameArray = explode('/', $value);
                                                        $PropertyModel->ListingModel->ImagesNameModel[0] = $getnameArray[count($getnameArray) - 1];
                                                    }
                                                }
                                                $ignoreImg = 2;
                                            }
                                        }
                                        if ($ignoreImg != 2) {
                                            $PropertyModel->ListingModel->UploadedFile[0]->SortOrder = 1;
                                            $PropertyModel->ListingModel->UploadedFile[0]->IsSavedInDB = 2;

                                            // set array for first uploaded image to store in co_propertylistings table
                                            foreach ($PropertyModel->ListingModel->UploadedFile[0] as $key => $value) {
                                                $PropertyModel->ListingModel->ImagesModel[0][$key] = $value;
                                                if ($key == 'FilePath') {
                                                    $getnameArray = explode('/', $value);
                                                    $PropertyModel->ListingModel->ImagesNameModel[0] = $getnameArray[count($getnameArray) - 1];
                                                }
                                            }
                                        }
                                    }
                                

                                    foreach ($objects->toArray() as $key => $object) {
                                        if ($key > $ignoreImg ) {
                                            $MediaData = array();
                                            $MediaData['PropertyListingID'] = $singleProperty->LIST_105;
                                            $MediaData['UserID'] = Constants::$Value_False;
                                            $MediaData['SiteID'] = Constants::$ColoradoSiteID;
                                            $MediaData['ListingKey'] = $PropertyModel->ListingModel->ListingKey;
                                            $MediaData['PropObjectKey'] = $object->getObjectId();
                                            $MediaData['PropMediaKey'] = $object->getContentId();
                                            $MediaData['PropMediaURL'] = $object->getLocation();
                                            array_push($MediaArray, $MediaData);
                                        }
                                    }
                                    if (count($MediaArray) > 0) {
                                        $PropertyModel->IsShowUploadNote = 1;
                                    } else {
                                        $PropertyModel->IsShowUploadNote = 0;
                                    }
                                    
                                    $this->MultipleInsert(new CoTempRetsImagesEntity(), $MediaArray);
                                }
                            }
                            $propertyAdded = $this->CoSaveProperty($PropertyModel->ListingModel, Constants::$ColoradoSiteID, Constants::$StaticNullUserID);
                            $responseArray[] = $propertyAdded->Message.": ".$singleProperty->LIST_105;
                        }
                        $response->IsSuccess = true;
                        $response->Message=$responseArray;
                        Log::info('Co - Add all property: '.date('Y-m-d H:i:s'));
                        // update flag and counter
                        $updateCounter = Config::get('config.CoAllPropertyCount') + $getSettings->CoAllPropertyCronCount;
                        $getSettings->CoAllPropertyCronCount = $updateCounter;
                    } else {
                        //update class abbreviation in settings
                        $ClassData=$this->CallRawForSingleTable('co_getclassinfo',['',$ClassID+1]);
                        $ClassAbbreviation = $ClassData[0]->ClassAbriviation;
                        $getSettings->CoCronAbbreviation = $ClassAbbreviation;
                        $getSettings->CoAllPropertyCronCount = Constants::$Value_False;
                        $response->Message = trans('messages.NoRETSPropertyFound');
                    }
                } else {
                    $response->Message = trans('messages.RETSCredentialsInvalid');
                }
                $getSettings->{Constants::$Co_AllPropertyCronJobFlag} = Constants::$Value_False;
                $this->SaveEntity($getSettings);
            }
            else {
                // if cron job is running
                $response->IsSuccess=false;
                $response->Message='Colorado Property cron job already running';
            }
        } catch (Exception $e) {
            Log::info('Co Exception - Add all property :' . date('Y-m-d H:i:s'));
            Log::error($e);
        }
        return $response;
    }

    public function getClassStatusSearch($ClassID){
        switch($ClassID){
            case 1:
                return Constants::$Residential;
                break;
            case 2:
                return Constants::$Fractional;
                break;
            case 5:
                return Constants::$LandResidential;
                break;
            case 6:
                return Constants::$LandCommercial;
                break;
            case 3:
                return Constants::$CommercialIndustrial;
                break;
            case 4:
                return Constants::$CommercialLease;
                break;
            case 7:
                return Constants::$Rentals;
                break;
        }
    }

    public function getCoImageCron() {
        $response = new ServiceResponse();
        $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
        try { //'IsPropertyImageCronJobRunning'
            if(!$getSettings->{Constants::$Co_ImageUploadCronJob}) {
                $getSettings->{Constants::$Co_ImageUploadCronJob} = true; // set flag to running
                $this->SaveEntity($getSettings);
                try {
                    $dateTime = date(Constants::$DefaultDateTimeFormat);
                    /* get temporary image from temporary table*/
                    $imageCount = Config::get('config.Co_NumberOfPropertyImageToUpload');
                    $getImagesForUpload = $this->CallRawForSingleTable('co_propertyimagecron', [$imageCount]);
                    foreach ($getImagesForUpload as $imageInfo) {
                        /* AWS upload */
                        try {
                            $awsImageUpload = $this->FileUpload(Constants::$AWSRequestType_Listing, $imageInfo->UserID, Constants::$ColoradoSiteID, $imageInfo->PropMediaURL);
                            if (($imageInfo->SortOrder <= $imageInfo->noOfListing)) {
                                $addToIntervention = new CoPropertyImagesInterventionEntity();
                                $addToIntervention->CoListingID = $imageInfo->CoListingID;
                                $addToIntervention->ImageURL = $awsImageUpload->FilePath;
                                $addToIntervention->IsWBProperty = $imageInfo->IsWBProperty;
                                $addToIntervention->ImagePriority=($imageInfo->IsWBProperty==Constants::$Value_True?Constants::$Value_True:2);
                                $this->SaveEntity($addToIntervention);
                            }
                        }
                        catch(Exception $e){
                            $updateUploadAttempt=$this->GetEntityForUpdateByPrimaryKey(new CoTempRetsImagesEntity(),$imageInfo->CoTempID);
                            if($updateUploadAttempt->ImageUploadAttempt<Constants::$maxImageUploadAttempt) {
                                $updateUploadAttempt->ImageUploadAttempt = $updateUploadAttempt->ImageUploadAttempt + 1;
                                $this->SaveEntity($updateUploadAttempt);
                                if ($updateUploadAttempt->ImageUploadAttempt == Constants::$maxImageUploadAttempt) {
                                    $addToUploadImage = new CoImageUploadErrorEntity();
                                    $addToUploadImage->CoListingID = $imageInfo->CoListingID;
                                    $addToUploadImage->ImagePath = $imageInfo->PropMediaURL;
                                    $addToUploadImage->Errortype = Constants::$Value_True;
                                    $addToUploadImage->AddedDateTime = date(Constants::$DefaultDateTimeFormat);
                                    $this->SaveEntity($addToUploadImage);
                                }
                            }
                        }
                        if(isset($awsImageUpload)) {
                            /* save data to property image */
                            $singlePropertyImage = new CoPropertyListingImagesEntity();
                            $singlePropertyImage->CoListingID = $imageInfo->CoListingID;
                            $singlePropertyImage->FileName = $awsImageUpload->FileName;
                            $singlePropertyImage->FilePath = $awsImageUpload->FilePath;
                            $singlePropertyImage->CreatedDate = $dateTime;
                            $singlePropertyImage->ModifiedDate = $dateTime;
                            $singlePropertyImage->CreatedByID = $imageInfo->UserID != 0 ? $imageInfo->UserID : NULL;
                            $singlePropertyImage->ModifiedByID = $imageInfo->UserID != 0 ? $imageInfo->UserID : NULL;
                            $singlePropertyImage->SortOrder = $imageInfo->SortOrder;
                            $singlePropertyImage->Filesize = $awsImageUpload->FileSize;
                            $storePropertyImage = $this->SaveEntity($singlePropertyImage);
                            if ($storePropertyImage) {
                                /* on success delete from temporary table */
                                $this->CustomDeleteEntity(new CoTempRetsImagesEntity(), 'CoTempID', $imageInfo->CoTempID);
                                $response->IsSuccess = true;
                            } else {
                                $response->IsSuccess = false;
                                Log::info(' could not connect to AWS :' . date('Y-m-d H:i:s'));
                            }
                        }
                    }
                } catch (Exception $e) {
                    Log::info(' co - Property image cron :' . date('Y-m-d H:i:s'));
                    Log::error($e);
                }
                $getSettings->{Constants::$Co_ImageUploadCronJob} = false;
                $this->SaveEntity($getSettings);
            }
        } catch (Exception $e) {
            Log::info(' co Exception - Property image cron :' . date('Y-m-d H:i:s'));
            Log::error($e);
            $getSettings->{Constants::$Co_ImageUploadCronJob} = false;
            $this->SaveEntity($getSettings);
        }
        return $response;
    }

    public function getCoPropertyImagesInterventionCron(){
        $response = new ServiceResponse();
        $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
        try {
            if(!$getSettings->{Constants::$Co_ImageInterventionCronJobFlag}) {
                $getSettings->{Constants::$Co_ImageInterventionCronJobFlag} = true; // set flag to running
                $this->SaveEntity($getSettings);
                try {
                    $imageCount = Config::get('config.Co_NumberOfPropertyInterventionImagesToUpload');
                    $imagesInterventionData = $this->CallRawForSingleTable('co_propertyimagesinterventioncron', [$imageCount]);

                    if(!empty($imagesInterventionData)){

                        foreach ($imagesInterventionData as $imageInfo) {
                            $counter=0;
                            $imageDimensionArray = Common::getImageInterventionDimensionArray(Constants::$ColoradoSiteID, $imageInfo->IsWBProperty);
                            if ($imageDimensionArray) {
                                foreach ($imageDimensionArray as $dimension) {
                                    $fullImagePath = Common::getAWSUrl(Constants::$ColoradoSiteID) . Common::getAWSBucketName(Constants::$ColoradoSiteID) . '/' . $imageInfo->ImageURL;
                                    try {
                                        Common::CoImageIntervention($fullImagePath, $dimension, '', 0);
                                    } catch (Exception $e) {
                                        $counter=1;
                                        $updateCropAttempt = $this->GetEntityForUpdateByPrimaryKey(new CoPropertyImagesInterventionEntity(), $imageInfo->ID);
                                        if ($updateCropAttempt->CropAttempt < Constants::$maxImageUploadAttempt) {
                                            $updateCropAttempt->CropAttempt = $updateCropAttempt->CropAttempt + 1;
                                            $this->SaveEntity($updateCropAttempt);
                                            if ($updateCropAttempt->CropAttempt == Constants::$maxImageUploadAttempt) {
                                                $addToUploadImage = new CoImageUploadErrorEntity();
                                                $addToUploadImage->CoListingID = $imageInfo->CoListingID;
                                                $addToUploadImage->ImagePath = Common::getAWSUrl(Constants::$ColoradoSiteID) . Common::getAWSBucketName(Constants::$ColoradoSiteID) . '/' . $imageInfo->ImageURL;
                                                $addToUploadImage->Errortype = 2;
                                                $addToUploadImage->AddedDateTime = date(Constants::$DefaultDateTimeFormat);
                                                $this->SaveEntity($addToUploadImage);
                                            }
                                        }
                                    }
                                }
                                if($counter==0) {
                                    $this->CallRawForSingleTable('co_deletepropertyimagesintervention', [$imageInfo->ID]);
                                }
                            }
                        }
                        $response->IsSuccess=true;
                    }
                } catch (Exception $e) {
                    Log::info(' Co - Property Images Intervention cron :' . date('Y-m-d H:i:s'));
                    Log::error($e);
                }
                $getSettings->{Constants::$Co_ImageInterventionCronJobFlag} = false;
                $this->SaveEntity($getSettings);
            }
        } catch (Exception $e) {
            $getSettings->{Constants::$Co_ImageInterventionCronJobFlag} = false;
            $this->SaveEntity($getSettings);
            Log::info(' Co Exception- Property Images Intervention cron :' . date('Y-m-d H:i:s'));
            Log::error($e);
        }
        return $response;
    }
    /* co cron jobs */
    /* Dev_KT Region end */

    /* Dev_UP Region Start */
    // cron job for non CO Properties Management

    public function COPropertyManagement(){
        $response=new ServiceResponse();

        if(Common::SetCronJobRunning(Constants::$COPropertyManagementCronCheck)) {
            $datetime = DB::select("SELECT DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%d') as todayDate");
            $searchParam = array();
            $searchValues = Common::SetSearchArray('COcronDate', $datetime[0]->todayDate);



            array_push($searchParam, $searchValues);
            $getLastData = $this->GetEntityList(new COCronJobEntity(), $searchParam);
           

            if(count($getLastData)==0){
                //then we will add csv property
                Log::info('CO Added insertCSV From MLS: ' ."FOR Class 1". date('Y-m-d H:i:s'));
                $response=$this->addCOCSVtoDb($class = 1);
                Common::UnsetCronJobRunning(Constants::$COPropertyManagementCronCheck);
            }
            else {
                $getLastDataArray = json_decode(json_encode($getLastData),true);
                $getLastDataStatus = array_column($getLastDataArray, 'COcronClass');
                $maxClassStatus = max($getLastDataStatus);

                foreach($getLastData as $functionFor) {
                    /* $functionFor = $getLastData[count($getLastData) - 1];*/
                    if($maxClassStatus == $functionFor->COcronClass && $functionFor->COcronCSVStatus == 7){
                         

                         $chekCronJobFinished = $this->CallRawForMultipleTable('co_chekcronjobfinished', [Constants::$ColoradoSiteID]);
                         

                         if($chekCronJobFinished[0][0]->totlalStatus == $functionFor->COcronClass &&  $functionFor->COcronCSVStatus>= 7)
                         {
                            Common::UnsetCronJobRunning(Constants::$COPropertyManagementCronCheck);
                            $response->IsSuccess=true;
                            $response->Message="Cron job Completed For All Class .";
                            Log::info('Cron job Completed For All Class '.date('Y-m-d H:i:s'));
                            return $response;
                         }

                        $response=$this->addCOCSVtoDb($functionFor->COcronClass + 1 );
                        Log::info('CO Added insertCSV From MLS: ' ."FOR Class ". ($functionFor->COcronClass + 1).date('Y-m-d H:i:s'));
                        Common::UnsetCronJobRunning(Constants::$COPropertyManagementCronCheck);
                    }
                    else{
                        
                        Common::UnsetCronJobRunning(Constants::$COPropertyManagementCronCheck);
                        if( $maxClassStatus == $functionFor->COcronClass && $functionFor->COcronFor==Constants::$CronCSVInsert && $functionFor->COcronCSVStatus<=1) {
                            switch ($functionFor->COcronCSVStatus) {
                                case "0":
                                    $response=$this->COAddCSVProperties($functionFor->COcronClass);
                                    break;
                                case "1":
                                    Log::info('CO Insert CSV processing Ended: ' . date('Y-m-d H:i:s'));
                                    Log::info('CO Added updateCSV from MLS: ' . date('Y-m-d H:i:s'));
                                    $response=$this->COaddUpdateCSVtoDb($functionFor->COcronClass);
                                    break;
                            }
                        }
                        if( $maxClassStatus == $functionFor->COcronClass && $functionFor->COcronFor==Constants::$COCronCSVUpdate && $functionFor->COcronCSVStatus<=3) {                                switch ($functionFor->COcronCSVStatus) {
                                case "2":
                                    $response=$this->COUpdateCSVProperties($functionFor->COcronClass);
                                    break;
                                case "3":
                                    Log::info('CO Delete CSV added: ' . date('Y-m-d H:i:s'));
                                    
                                    $response=$this->COaddCSVPropertyStatus($functionFor->COcronClass);
                                    break;
                            }
                        }
                        if( $maxClassStatus == $functionFor->COcronClass && $functionFor->COcronFor==Constants::$COCronCSVDelete && $functionFor->COcronCSVStatus<=5){
                            switch ($functionFor->COcronCSVStatus) {
                                case "4":
                                    $response = $this->COUpdateCSVStatusProperties($functionFor->COcronClass);
                                    break;
                                case "5":
                                    /*Log::info('CO Update Status CSV Processing ended: ' . date('Y-m-d H:i:s'));
                                    //Log::info('Added DeleteCSV from MLS: ' . date('Y-m-d H:i:s'));
                                    //$response = $this->addDeleteCSVtoDB($functionFor->COcronClass);
                                     $response->IsSuccess=true;
                                     $response->Message="Cron job Completed For update status and delete.";
                                    break;*/

                                    Log::info('CO New insert csv added: ' . date('Y-m-d H:i:s'));
                                    $response=$this->COaddCSVNewPropertyStatus($functionFor->COcronClass);
                                    break;
                            }
                        }
                        if( $maxClassStatus == $functionFor->COcronClass && $functionFor->COcronFor==Constants::$COCronCSVInsertStatus && $functionFor->COcronCSVStatus<=7){
                            switch ($functionFor->COcronCSVStatus) {
                                case "6":
                                    $response = $this->addNewCSVProperty($functionFor->COcronClass);
                                    break;
                                case "7":
                                    Log::info('CO Cron job Completed For Class ' . date('Y-m-d H:i:s'));
                                    $response->IsSuccess=true;
                                    $response->Message="CO Cron job Completed For Class .".$functionFor->COcronClass;
                            }
                        }

                    }
                }
                   
            }
            Common::UnsetCronJobRunning(Constants::$COPropertyManagementCronCheck);
        }
        return $response;
    }
    /* Dev_UP Region End */

    public function addCOCSVtoDb($Propertyclass){
        $response = new ServiceResponse();
        $config = new \PHRETS\Configuration;
        $LogArray=[];
        try {
            $datetimePrev =  DB::select("SELECT DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%d') as todayDate");
           
            $searchParam = array();
            $searchValues = Common::SetSearchArray('COcronDate', $datetimePrev[0]->todayDate);
            array_push($searchParam, $searchValues);
            $searchValues = Common::SetSearchArray('COcronFor', Constants::$CronCSVUpdate);
            array_push($searchParam, $searchValues);
            

            $getPrevData = $this->CallRawForSingleTable('co_getPrevCronData', array(Constants::$COCronCSVInsert, $datetimePrev[0]->todayDate,$Propertyclass));            
            $prevCSV = "";

            
            $prevCSVCount = 0;
            if(isset($getPrevData[0]) && $getPrevData[0]->COcronLastIndex < $getPrevData[0]->COcronPropertyCount){
                $lastCronData = $getPrevData[0]->COcronCSV;

                $prevCSV = substr($lastCronData, Common::strposnth($lastCronData, ',', $getPrevData[0]->COcronLastIndex) + 1);
                $prevCSVArray = explode(",", $prevCSV);
                $prevCSVCount = count($prevCSVArray);
                
                $savePrevData = $this->CallRawForSingleTable('co_savePrevCronData', array($getPrevData[0]->COcronId));

            }


            $config->setloginurl(Config::get('config.Aspen_Login_URL'));
            $config->setHttpAuthenticationMethod(Config::get('config.CLAW_Authentication_Method'));
            $config->setOption('use_post_method', false);
            $config->setOption('disable_follow_location', false);

            // get credentials from database settings table. We kept them in db so user can change easily if there is any change.
            $Credentials = $this->GetCLAWCredentials(Constants::$ColoradoSiteID);

            $config->setusername(Config::get('config.Aspen_UserName'));
            $config->setpassword(Config::get('config.Aspen_Password'));

            $rets = new \PHRETS\Session($config);
            $login = $rets->Login();

            $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');

            $getSettings->{Constants::$COPropertyManagementCronCheck} = true; // set flag to running
            $updateCounter=0;
            $this->SaveEntity($getSettings);
            
            $ClassData = $this->CallRawForSingleTable("co_getPropertyClassInfo",[$Propertyclass]);
            $ClassID = $ClassData[0]->ClassID;
            $ClassAbbreviation = $ClassData[0]->ClassAbriviation;
            $getSettings->CoCronAbbreviation = $ClassAbbreviation;
            $this->SaveEntity($getSettings);

            if ($login) {
                // Search property with user given listingID(MLS#)
                $resource = 'Property';
                $class = $ClassAbbreviation;
                $getDataBaseValue = DB::select("SELECT DATE_FORMAT(CONVERT_TZ(MAX(COcronDate), @@session.time_zone, 'UTC' ), '%Y-%m-%dT%H:%i:%s') AS modifiedDate, DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%dT%H:%i:%s') AS todayDate FROM `co_cronjobhistory` WHERE COcronFor='insert' AND COcronClass = ".$Propertyclass);
                
                if(!$getDataBaseValue[0]->modifiedDate)
                {
                    $getDataBaseValue[0]->modifiedDate = Constants::$CheckForLastDate;// "2016-10-28T18:30:00";
                }
                //$query = '(LIST_15=|'.$this->getClassStatusSearch($ClassID).')';// '(LIST_105=' . $MlsNo . ')'; //LIST_105 = 146308 //LIST_22=1+
                $query = '(LIST_15=|'.$this->getClassStatusSearch($ClassID).'),(LIST_87=' . $getDataBaseValue[0]->modifiedDate . '-' . $getDataBaseValue[0]->todayDate . ')';
                $result = $rets->Search(
                    $resource,
                    $class,
                    $query,
                    [
                        'QueryType' => 'DMQL2',
                        'Count' => 1, // only records
                        'Format' => 'COMPACT-DECODED',
                        'Limit' => 'NONE',
                        'z' => 0,
                        'Select' => 'LIST_105'//,ModificationTimestamp'
                         
                    ]
                    
                );

                $LogArray = $this->StoreRetsLog(Constants::$Value_False, Constants::$ColoradoSiteID, Constants::$RETSActionSearch, $result->URL, '', serialize($result->toArray()),$LogArray,false);
                $Alldata = json_decode($result->toJSON());

                $totalCount = count($Alldata);
                $csv = implode(',', array_map(function ($n) {
                    return $n->LIST_105;
                }, $Alldata));

                if($prevCSVCount > 0){
                    $csv = $csv.",".$prevCSV;
                }


                $GetUniqueData = $this->CallRawForSingleTable('co_processcsvforcron', [$csv]);
                //process csv to get none existing data from database
                $csv = Common::GetUniqueCSVFromArray($csv, $GetUniqueData);
                $csvCount = explode(",", $csv);
                $insertCSV = new COCronJobEntity();
                $insertCSV->COcronDate = $getDataBaseValue[0]->todayDate;
                $insertCSV->COcronCSV = $csv;
                $insertCSV->COCronPropertyCount = count($csvCount);
                //$insertCSV->COCronPropertyCount = $totalCount + $prevCSVCount -count($GetUniqueData);
                $insertCSV->COcronFor=Constants::$CronCSVInsert;
                $insertCSV->COcronCSVStatus=Constants::$Value_False;
                $insertCSV->COcronClass=$Propertyclass;
                $insertCSV->COcronLastIndex=Constants::$Value_False;
                $saveCSV = $this->SaveEntity($insertCSV);
                if ($saveCSV) {
                    $response->IsSuccess = true;
                    $response->Message = "CVS added for :" . $getDataBaseValue[0]->todayDate;
                } else {
                    $response->IsSuccess = false;
                    $response->Message = "CVS failed for :" . $getDataBaseValue[0]->todayDate;
                }

                
            } 
            else {
                $response->Message = trans('messages.RETSCredentialsInvalid');
            }
            $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
            $getSettings->{Constants::$COPropertyManagementCronCheck} = Constants::$Value_False;
            $this->SaveEntity($getSettings);
            
        } catch (Exception $e) {
            Log::info('Co Exception - Add all property :' . date('Y-m-d H:i:s'));
            Log::error($e);
        }
        return $response;
    }

    public function COAddCSVProperties($COcronClass){
        try {
            $response = new ServiceResponse();
            $datetime = DB::select("SELECT DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%d') as todayDate");
            $searchParam = array();
            $searchValues = Common::SetSearchArray('COcronDate', $datetime[0]->todayDate);
            array_push($searchParam, $searchValues);
            $searchValues = Common::SetSearchArray('COcronFor', Constants::$CronCSVInsert);
            array_push($searchParam, $searchValues);
            $searchValues = Common::SetSearchArray('COcronClass', $COcronClass);
            array_push($searchParam, $searchValues);
            $getLastData = $this->GetEntityForUpdateByFilter(new COCronJobEntity(), $searchParam);
            if (count($getLastData) > 0) {
                $csv = $getLastData->COcronCSV;

                $Propertyclass = $getLastData->COcronClass;
                
                $lastIndex = $getLastData->COcronLastIndex;
                $MaxIndex = $getLastData->COcronPropertyCount;
                //$matches = preg_split('/((?:[^,]*,){15})/', $csv, -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);
                if ($lastIndex != 0 && $lastIndex <= $MaxIndex) {
                    if($MaxIndex-$lastIndex <= Config::get('config.AddPropertiesFromCSV')){
                        $finalCSV = substr($csv, Common::strposnth($csv, ',', $lastIndex) + 1);
                    }
                    else {
                        $ReducedCSV = substr($csv, Common::strposnth($csv, ',', $lastIndex) + 1);
                        $finalCSV = substr($ReducedCSV, 0, Common::strposnth($ReducedCSV, ',', Config::get('config.AddPropertiesFromCSV')));
                    }
                } else {
                    Log::info('CO Insert CSV processing started: ' . date('Y-m-d H:i:s'));
                    if(Config::get('config.AddPropertiesFromCSV')> $MaxIndex){
                        $finalCSV = $csv;
                    }else {
                        $finalCSV = substr($csv, 0, Common::strposnth($csv, ',', Config::get('config.AddPropertiesFromCSV')));
                    }
                }

                
                $GetUniqueData = $this->CallRawForSingleTable('co_processcsvforcron', [$finalCSV]);

                
                //process csv to get none existing data from database
                $finalCSV = Common::GetUniqueCSVFromArray($finalCSV, $GetUniqueData);

                Log::info('CO Insert Final CSV: ' . $finalCSV);
                if ($finalCSV) {
                    $response = new ServiceResponse();
                    $config = new \PHRETS\Configuration;

                    $config->setloginurl(Config::get('config.Aspen_Login_URL'));
                    $config->setHttpAuthenticationMethod(Config::get('config.CLAW_Authentication_Method'));
                    $config->setOption('use_post_method', false);
                    $config->setOption('disable_follow_location', false);

                    // get credentials from database settings table. We kept them in db so user can change easily if there is any change.
                    $Credentials = $this->GetCLAWCredentials(Constants::$ColoradoSiteID);

                    $config->setusername(Config::get('config.Aspen_UserName'));
                    $config->setpassword(Config::get('config.Aspen_Password'));

                    $rets = new \PHRETS\Session($config);
                    $login = $rets->Login();



                    $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');

                    $getSettings->{Constants::$COPropertyManagementCronCheck} = true; // set flag to running
                    $updateCounter=0;
                    $this->SaveEntity($getSettings);
                    
                    $ClassData = $this->CallRawForSingleTable("co_getPropertyClassInfo",[$Propertyclass]);
                    $ClassID = $ClassData[0]->ClassID;
                    $ClassAbbreviation = $ClassData[0]->ClassAbriviation;
                    $getSettings->CoCronAbbreviation = $ClassAbbreviation;
                    $this->SaveEntity($getSettings);

                    $LogArray=array();
                    $LogArray=$this->StoreRetsLog(Constants::$Value_False, Constants::$ColoradoSiteID, Constants::$RETSActionLogin, Config::get('config.CLAW_Login_URL'), '', $login,$LogArray,false);
                    $resource = 'Property';

                    $class = $ClassAbbreviation;
                    $query = '(LIST_15=|'.$this->getClassStatusSearch($ClassID).'),(LIST_105='.$finalCSV.')';// '(LIST_105=' . $MlsNo . ')'; //LIST_105 = 146308 //LIST_22=1+

                    $result = $rets->Search(
                        $resource,
                        $class,
                        $query,
                        [
                            'QueryType' => 'DMQL2',
                            'Count' => 1, // only records
                            'Format' => 'COMPACT-DECODED',
                            'Limit' => 'NONE',
                            'StandardNames' => 0
                        ]
                    );

                    $LogArray = $this->StoreRetsLog(Constants::$Value_False, Constants::$ColoradoSiteID, Constants::$RETSActionSearch, $result->URL, '', serialize($result->toArray()),$LogArray,false);
                    $data = json_decode($result->toJSON());

                    $responseArray = [];
                    

                    foreach($data as $singleProperty) {
                        $searchParam = array();
                        $searchValues = Common::SetSearchArray('MLSNo', $singleProperty->LIST_105, Constants::$Value_True);
                        array_push($searchParam, $searchValues);
                        
                        $duplicate = $this->GetEntity(new CoPropertyListingsEntity(), $searchParam);
                        
                        
                        
                        if($duplicate){
                            $responseArray[] = trans('messages.PropertyDuplicate');
                            continue;
                        }

                        


                        $PropertyModel = new stdClass();
                        // map value with database
                        $PropertyModel->ListingModel = $this->getColoradoPropertyFormatted($singleProperty, $ClassID);

                        $PropertyModel->ListingModel->IsWBProperty=Constants::$Value_False;

                        $CheckForIsWB = Common::getPropertyOfficeID($singleProperty->LIST_106, Constants::$ColoradoSiteID);
                        if ($CheckForIsWB) {
                            $PropertyModel->ListingModel->IsWBProperty = Constants::$Value_True;
                        }

                        if ($singleProperty->LIST_133 > 0) { //check for images
                            $objects = $rets->GetObject(
                                'Property',
                                '640x480', //Photo,HiRes
                                $PropertyModel->ListingModel->ListingKey,
                                '*', '1'
                            );
                            $checkArrayValue = $objects->toArray();

                            if (count($checkArrayValue) > 0) {
                                $MediaArray = array();
                                $this->CustomDeleteEntity(new CoTempRetsImagesEntity(), 'PropertyListingID', $singleProperty->LIST_105);

                                $ignoreImg = 0;
                                if (count($objects->toArray()) > 0) {
                                    try {
                                        //$PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing,Constants::$Value_False, Constants::$MercerVineSiteID, $GetFirstImage[0]['PropMediaURL']);
                                        // upload first image
                                        $PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing, Constants::$Value_False, Constants::$ColoradoSiteID, $objects->toArray()[0]->getLocation());
                                            
                                    } 
                                    catch (Exception $e) {
                                        Log::info('CO In first catch block of first image for Co Listing ID: ' . $singleProperty->LIST_105);

                                        $addToUploadImage=new CoImageUploadErrorEntity();
                                        $addToUploadImage->MLSNo=$singleProperty->LIST_105;
                                        $addToUploadImage->ImagePath=$objects->toArray()[0]->getLocation();
                                        $addToUploadImage->Errortype=Constants::$Value_True;
                                        $addToUploadImage->AddedDateTime=date(Constants::$DefaultDateTimeFormat);
                                        $this->SaveEntity($addToUploadImage);

                                        $PropertyModel->ListingModel->UploadedFile[0]->SortOrder = 1;
                                        $PropertyModel->ListingModel->UploadedFile[0]->IsSavedInDB = 2;

                                        // set array for first uploaded image to store in co_propertylistings table
                                        foreach ($PropertyModel->ListingModel->UploadedFile[0] as $key => $value) {
                                            $PropertyModel->ListingModel->ImagesModel[0][$key] = $value;
                                            if ($key == 'FilePath') {
                                                $getnameArray = explode('/', $value);
                                                $PropertyModel->ListingModel->ImagesNameModel[0] = $getnameArray[count($getnameArray) - 1];
                                            }
                                        }
                                        $ignoreImg = 1;
                                        try {
                                            if (count($objects->toArray()) > 1)
                                               // $PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing, Constants::$Value_False, Constants::$MercerVineSiteID, $GetFirstImage[1]['PropMediaURL']);
                                                $PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing, Constants::$Value_False, Constants::$ColoradoSiteID, $objects->toArray()[1]->getLocation());
                                        } catch (Exception $e) {
                                            Log::info('CO In second catch block of first image for Listing ID: ' . $singleProperty->LIST_105);

                                            $addToUploadImage=new CoImageUploadErrorEntity();
                                            $addToUploadImage->MLSNo=$singleProperty->LIST_105;
                                            $addToUploadImage->ImagePath=$objects->toArray()[1]->getLocation();
                                            $addToUploadImage->Errortype=Constants::$Value_True;
                                            $addToUploadImage->AddedDateTime=date(Constants::$DefaultDateTimeFormat);
                                            $this->SaveEntity($addToUploadImage);

                                            $PropertyModel->ListingModel->UploadedFile[0]->SortOrder = 1;
                                            $PropertyModel->ListingModel->UploadedFile[0]->IsSavedInDB = 2;

                                            // set array for first uploaded image to store in co_propertylistings table
                                            foreach ($PropertyModel->ListingModel->UploadedFile[0] as $key => $value) {
                                                $PropertyModel->ListingModel->ImagesModel[0][$key] = $value;
                                                if ($key == 'FilePath') {
                                                    $getnameArray = explode('/', $value);
                                                    $PropertyModel->ListingModel->ImagesNameModel[0] = $getnameArray[count($getnameArray) - 1];
                                                }
                                            }
                                            $ignoreImg = 2;
                                        }
                                    }
                                    if ($ignoreImg != 2) {
                                        $PropertyModel->ListingModel->UploadedFile[0]->SortOrder = 1;
                                        $PropertyModel->ListingModel->UploadedFile[0]->IsSavedInDB = 2;

                                        // set array for first uploaded image to store in co_propertylistings table
                                        foreach ($PropertyModel->ListingModel->UploadedFile[0] as $key => $value) {
                                            $PropertyModel->ListingModel->ImagesModel[0][$key] = $value;
                                            if ($key == 'FilePath') {
                                                $getnameArray = explode('/', $value);
                                                $PropertyModel->ListingModel->ImagesNameModel[0] = $getnameArray[count($getnameArray) - 1];
                                            }
                                        }
                                    }
                                }
                            

                                foreach ($objects->toArray() as $key => $object) {
                                    if ($key > $ignoreImg ) {
                                        $MediaData = array();
                                        $MediaData['PropertyListingID'] = $singleProperty->LIST_105;
                                        $MediaData['UserID'] = Constants::$Value_False;
                                        $MediaData['SiteID'] = Constants::$ColoradoSiteID;
                                        $MediaData['ListingKey'] = $PropertyModel->ListingModel->ListingKey;
                                        $MediaData['PropObjectKey'] = $object->getObjectId();
                                        $MediaData['PropMediaKey'] = $object->getContentId();
                                        $MediaData['PropMediaURL'] = $object->getLocation();
                                        array_push($MediaArray, $MediaData);
                                    }
                                }
                                if (count($MediaArray) > 0) {
                                    $PropertyModel->IsShowUploadNote = 1;
                                } else {
                                    $PropertyModel->IsShowUploadNote = 0;
                                }
                                
                                $this->MultipleInsert(new CoTempRetsImagesEntity(), $MediaArray);
                            }
                        }
                        $propertyAdded = $this->CoSaveProperty($PropertyModel->ListingModel, Constants::$ColoradoSiteID, Constants::$StaticNullUserID);
                        $responseArray[] = $propertyAdded->Message.": ".$singleProperty->LIST_105;
                    }

                    $getLastData->COcronLastIndex = $lastIndex + Config::get('config.AddPropertiesFromCSV'); 
                    if($lastIndex + Config::get('config.AddPropertiesFromCSV') >= $MaxIndex){
                        // changed to 1 for finished
                        $getLastData->COcronCSVStatus=1;
                    }
                    $this->SaveEntity($getLastData);

                }
                else{
                    $getLastData->COcronLastIndex = $lastIndex + Config::get('config.AddPropertiesFromCSV'); 
                    if($lastIndex + Config::get('config.AddPropertiesFromCSV') >= $MaxIndex){
                        // changed to 1 for finished
                        $getLastData->COcronCSVStatus=1;
                    }
                }
                
                $this->SaveEntity($getLastData);
                $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
                $getSettings->{Constants::$COPropertyManagementCronCheck} = false;
                $this->SaveEntity($getSettings);

                $response->IsSuccess = true;

            } else {
                $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
                $getSettings->{Constants::$COPropertyManagementCronCheck} = false;
                $this->SaveEntity($getSettings);

                $response->IsSuccess = false;
                $response->Message="CO CSV not added or all properties added successfully.";
            }
        }
        catch(Exception $e) {
            Log::info('CO Adding CSV Property Issue :' . date('Y-m-d H:i:s'));
            Log::error($e);
        }
        return $response;
    }


    // { csv for update
    public function COaddUpdateCSVtoDb($COcronClass) {
        $response = new ServiceResponse();
        try {
            $datetimePrev =  DB::select("SELECT DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%d') as todayDate");
           
            $searchParam = array();
            $searchValues = Common::SetSearchArray('COcronDate', $datetimePrev[0]->todayDate);
            array_push($searchParam, $searchValues);
            $searchValues = Common::SetSearchArray('COcronFor', Constants::$CronCSVUpdate);
            array_push($searchParam, $searchValues);
            

            $getPrevData = $this->CallRawForSingleTable('co_getPrevCronData', array(Constants::$COCronCSVUpdate, $datetimePrev[0]->todayDate,$COcronClass));            
            $prevCSV = "";

            
            $prevCSVCount = 0;
            if(isset($getPrevData[0]) && $getPrevData[0]->COcronLastIndex < $getPrevData[0]->COcronPropertyCount){
                $lastCronData = $getPrevData[0]->COcronCSV;

                $prevCSV = substr($lastCronData, Common::strposnth($lastCronData, ',', $getPrevData[0]->COcronLastIndex) + 1);
                $prevCSVArray = explode(",", $prevCSV);
                $prevCSVCount = count($prevCSVArray);
                
                $savePrevData = $this->CallRawForSingleTable('co_savePrevCronData', array($getPrevData[0]->COcronId));

            }


            $config = new \PHRETS\Configuration;
            

            $config->setloginurl(Config::get('config.Aspen_Login_URL'));
            $config->setHttpAuthenticationMethod(Config::get('config.CLAW_Authentication_Method'));
            $config->setOption('use_post_method', false);
            $config->setOption('disable_follow_location', false);

            // get credentials from database settings table. We kept them in db so user can change easily if there is any change.
            $Credentials = $this->GetCLAWCredentials(Constants::$ColoradoSiteID);

            $config->setusername(Config::get('config.Aspen_UserName'));
            $config->setpassword(Config::get('config.Aspen_Password'));

            $rets = new \PHRETS\Session($config);
            $login = $rets->Login();


            $LogArray=array();
            $LogArray=$this->StoreRetsLog(Constants::$Value_False, Constants::$ColoradoSiteID, Constants::$RETSActionLogin, Config::get('config.CLAW_Login_URL'), '', $login,$LogArray,false);
            //$getDataBaseValue = DB::select("SELECT DATE_FORMAT(DATE_SUB(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), INTERVAL 24 HOUR), '%Y-%m-%dT%H:%i:%s') AS modifiedDate,DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%dT%H:%i:%s') AS todayDate, DATE_FORMAT(DATE_SUB(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), INTERVAL 48 HOUR), '%Y-%m-%d') as listDate");
            $getDataBaseValue=DB::select("SELECT DATE_FORMAT(CONVERT_TZ( MAX(COcrondate), @@session.time_zone, 'UTC' ), '%Y-%m-%dT%H:%i:%s') AS modifiedDate, DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%dT%H:%i:%s') AS todayDate, DATE_FORMAT(CONVERT_TZ( MAX(COcrondate), @@session.time_zone, 'UTC' ), '%Y-%m-%d') AS listDate FROM `co_cronjobhistory` WHERE COcronFor='update' AND COcronClass =".$COcronClass);
            $resource = 'Property';
            $class = 'ALL';


            if(!$getDataBaseValue[0]->modifiedDate)
            {
                $getDataBaseValue[0]->modifiedDate = "2016-10-28T18:30:00";
            }
            if(!$getDataBaseValue[0]->listDate)
            {
                $getDataBaseValue[0]->listDate = Constants::$CheckForLastDate;
            }
            


            $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
            $getSettings->{Constants::$COPropertyManagementCronCheck} = true; // set flag to running
            $updateCounter=0;
            $this->SaveEntity($getSettings);

            $ClassData = $this->CallRawForSingleTable("co_getPropertyClassInfo",[$COcronClass]);
            $ClassID = $ClassData[0]->ClassID;
            $ClassAbbreviation = $ClassData[0]->ClassAbriviation;
            $getSettings->CoCronAbbreviation = $ClassAbbreviation;
            $this->SaveEntity($getSettings);

            $LogArray=array();
            $LogArray=$this->StoreRetsLog(Constants::$Value_False, Constants::$ColoradoSiteID, Constants::$RETSActionLogin, Config::get('config.CLAW_Login_URL'), '', $login,$LogArray,false);
            $resource = 'Property';

            $class = $ClassAbbreviation;
            

            $query = '(LIST_15=|'.$this->getClassStatusSearch($ClassID).'),(LIST_87=' . $getDataBaseValue[0]->modifiedDate . '-' . $getDataBaseValue[0]->todayDate . '),(LIST_132=' . $getDataBaseValue[0]->listDate . '-)';


            $result = $rets->Search(
                $resource,
                $class,
                $query,
                [
                    'QueryType' => 'DMQL2',
                    'Count' => 1, // only records
                    'Format' => 'COMPACT-DECODED',
                    'Limit' => 'NONE',
                    'z' => 0,
                    'Select' => 'LIST_105'
                ]
            );

            $LogArray = $this->StoreRetsLog(Constants::$Value_False, Constants::$ColoradoSiteID, Constants::$RETSActionSearch, $result->URL, '', serialize($result->toArray()),$LogArray,false);
            $Alldata = json_decode($result->toJSON());
            $totalCount=count($Alldata);
            $csv = implode(',', array_map(function ($n) {
                return $n->LIST_105;
            }, $Alldata));
            if($prevCSVCount > 0){
                $csv = $csv.",".$prevCSV;
            }


            $insertCSV = new COCronJobEntity();
            $insertCSV->COcronDate = $getDataBaseValue[0]->todayDate;
            $insertCSV->COcronCSV = $csv;
            $insertCSV->COCronPropertyCount = $totalCount + $prevCSVCount;
            $insertCSV->COcronFor=Constants::$CronCSVUpdate;
            $insertCSV->COcronCSVStatus=2;
            $insertCSV->COcronClass=$COcronClass;
            $insertCSV->COcronLastIndex=Constants::$Value_False;

            $saveCSV = $this->SaveEntity($insertCSV);
            if ($saveCSV) {
                $searchParam = array();
                $searchValues = Common::SetSearchArray('COcronDate', date(Constants::$YMDDateFormatServerSide,strtotime($getDataBaseValue[0]->todayDate)));
                array_push($searchParam, $searchValues);
                $searchValues = Common::SetSearchArray('COcronFor',Constants::$CronCSVInsert );
                array_push($searchParam, $searchValues);
                $searchValues = Common::SetSearchArray('COcronClass', $COcronClass);
                array_push($searchParam, $searchValues);
                $getLastData = $this->GetEntityForUpdateByFilter(new COCronJobEntity(), $searchParam);
                $getLastData->COcronCSVStatus=2;

                $this->SaveEntity($getLastData);
                $response->IsSuccess = true;
                $response->Message = "CVS added for Update :" . $getDataBaseValue[0]->todayDate;

                $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
                $getSettings->{Constants::$COPropertyManagementCronCheck} = false;
                $this->SaveEntity($getSettings);
            } else {
                $response->IsSuccess = false;
                $response->Message = "CVS failed for Update:" . $getDataBaseValue[0]->todayDate;

                $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
                $getSettings->{Constants::$COPropertyManagementCronCheck} = false;
                $this->SaveEntity($getSettings);
            }
        } catch(Exception $e){
            Log::info('CO Adding Update CSV Issue :' . date('Y-m-d H:i:s'));
            Log::error($e);
        }
        return $response;
    }

    // update property from update CSV }
    public function COUpdateCSVProperties($COcronClass){

        $datetime = DB::select("SELECT DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%d') as todayDate");
        $searchParam = array();
        $searchValues = Common::SetSearchArray('COcronDate', $datetime[0]->todayDate);
        array_push($searchParam, $searchValues);
        $searchValues = Common::SetSearchArray('COcronFor', Constants::$CronCSVUpdate);
        array_push($searchParam, $searchValues);
        $searchValues = Common::SetSearchArray('COcronClass', $COcronClass);
        array_push($searchParam, $searchValues);
        $getLastData = $this->GetEntityForUpdateByFilter(new COCronJobEntity(), $searchParam);
        $response = new ServiceResponse();

        $responseArray = [];

        if (count($getLastData) > 0) {
            $csv = $getLastData->COcronCSV;
            $lastIndex = $getLastData->COcronLastIndex;
            $MaxIndex = $getLastData->COcronPropertyCount;
            //$matches = preg_split('/((?:[^,]*,){15})/', $csv, -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);
            if ($lastIndex != 0 && $lastIndex <= $MaxIndex) {
                if($MaxIndex-$lastIndex <= Config::get('config.UpdatePropertiesFromCSV')){
                    $finalCSV = substr($csv, Common::strposnth($csv, ',', $lastIndex) + 1);
                }
                else {
                    $ReducedCSV = substr($csv, Common::strposnth($csv, ',', $lastIndex) + 1);
                    $finalCSV = substr($ReducedCSV, 0, Common::strposnth($ReducedCSV, ',', Config::get('config.UpdatePropertiesFromCSV')));
                }
            } else {
                Log::info('CO Update CSV Processing Started: ' . date('Y-m-d H:i:s'));
                if(Config::get('config.UpdatePropertiesFromCSV') > $MaxIndex){
                    $finalCSV = $csv;
                }else {
                    $finalCSV = substr($csv, 0, Common::strposnth($csv, ',', Config::get('config.UpdatePropertiesFromCSV')));
                }
            }

            
            Log::info('CO Update Final CSV: ' . $finalCSV);
            if ($finalCSV) {
                $response = new ServiceResponse();
               
                $config = new \PHRETS\Configuration;
                $config->setloginurl(Config::get('config.Aspen_Login_URL'));
                $config->setHttpAuthenticationMethod(Config::get('config.CLAW_Authentication_Method'));
                $config->setOption('use_post_method', false);
                $config->setOption('disable_follow_location', false);

                // get credentials from database settings table. We kept them in db so user can change easily if there is any change.
                $Credentials = $this->GetCLAWCredentials(Constants::$ColoradoSiteID);

                $config->setusername(Config::get('config.Aspen_UserName'));
                $config->setpassword(Config::get('config.Aspen_Password'));

                $rets = new \PHRETS\Session($config);
                $login = $rets->Login();


                $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');

                $getSettings->{Constants::$COPropertyManagementCronCheck} = true; // set flag to running
                $updateCounter=0;
                $this->SaveEntity($getSettings);
                
                $ClassData = $this->CallRawForSingleTable("co_getPropertyClassInfo",[$COcronClass]);
                $ClassID = $ClassData[0]->ClassID;
                $ClassAbbreviation = $ClassData[0]->ClassAbriviation;
                $getSettings->CoCronAbbreviation = $ClassAbbreviation;
                $this->SaveEntity($getSettings);

                $LogArray=array();
                $LogArray=$this->StoreRetsLog(Constants::$Value_False, Constants::$ColoradoSiteID, Constants::$RETSActionLogin, Config::get('config.CLAW_Login_URL'), '', $login,$LogArray,false);
                $resource = 'Property';

                $class = $ClassAbbreviation;
                $query = '(LIST_15=|'.$this->getClassStatusSearch($ClassID).'),(LIST_105='.$finalCSV.')';// '(LIST_105=' . $MlsNo . ')'; //LIST_105 = 146308 //LIST_22=1+

                $result = $rets->Search(
                    $resource,
                    $class,
                    $query,
                    [
                        'QueryType' => 'DMQL2',
                        'Count' => 1, // only records
                        'Format' => 'COMPACT-DECODED',
                        'Limit' => 'NONE',
                        'StandardNames' => 0
                    ]
                );



                $LogArray = $this->StoreRetsLog(Constants::$Value_False, Constants::$ColoradoSiteID, Constants::$RETSActionSearch, $result->URL, '', serialize($result->toArray()),$LogArray,false);
                $data = json_decode($result->toJSON());
                
                
                foreach($data as $singleProperty) {
                    $searchParam = array();
                    $searchValues = Common::SetSearchArray('MLSNo', $singleProperty->LIST_105, Constants::$Value_True);
                    array_push($searchParam, $searchValues);
                    
                    $duplicate = $this->GetEntity(new CoPropertyListingsEntity(), $searchParam);

                    

                    $PropertyModel = new stdClass();
                    
                    // map value with database
                    $PropertyModel->ListingModel = $this->getColoradoPropertyFormatted($singleProperty, $ClassID);

                    $PropertyModel->ListingModel->IsWBProperty=Constants::$Value_False;

                    $CheckForIsWB = Common::getPropertyOfficeID($singleProperty->LIST_106, Constants::$ColoradoSiteID);
                    if ($CheckForIsWB) {
                        $PropertyModel->ListingModel->IsWBProperty = Constants::$Value_True;
                    }


                    if(count($duplicate) > 0) {
                        if ($duplicate->CoListingID) {
                            $PropertyModel->ListingModel->CoListingID = $duplicate->CoListingID;
                        }
                    }

                    if(count($duplicate) == 0) {
                        if ($singleProperty->LIST_133 > 0) { //check for images
                            $objects = $rets->GetObject(
                                'Property',
                                '640x480', //Photo,HiRes
                                $PropertyModel->ListingModel->ListingKey,
                                '*', '1'
                            );
                            $checkArrayValue = $objects->toArray();

                            if (count($checkArrayValue) > 0) {
                                $MediaArray = array();
                                $this->CustomDeleteEntity(new CoTempRetsImagesEntity(), 'PropertyListingID', $singleProperty->LIST_105);

                                $ignoreImg = 0;
                                if (count($objects->toArray()) > 0) {
                                    try {
                                        //$PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing,Constants::$Value_False, Constants::$MercerVineSiteID, $GetFirstImage[0]['PropMediaURL']);
                                        // upload first image
                                        $PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing, Constants::$Value_False, Constants::$ColoradoSiteID, $objects->toArray()[0]->getLocation());
                                            
                                    } 
                                    catch (Exception $e) {
                                        Log::info('CO In first catch block of first image for Co Listing ID: ' . $singleProperty->LIST_105);

                                        $addToUploadImage=new CoImageUploadErrorEntity();
                                        $addToUploadImage->MLSNo=$singleProperty->LIST_105;
                                        $addToUploadImage->ImagePath=$objects->toArray()[0]->getLocation();
                                        $addToUploadImage->Errortype=Constants::$Value_True;
                                        $addToUploadImage->AddedDateTime=date(Constants::$DefaultDateTimeFormat);
                                        $this->SaveEntity($addToUploadImage);

                                        $PropertyModel->ListingModel->UploadedFile[0]->SortOrder = 1;
                                        $PropertyModel->ListingModel->UploadedFile[0]->IsSavedInDB = 2;

                                        // set array for first uploaded image to store in co_propertylistings table
                                        foreach ($PropertyModel->ListingModel->UploadedFile[0] as $key => $value) {
                                            $PropertyModel->ListingModel->ImagesModel[0][$key] = $value;
                                            if ($key == 'FilePath') {
                                                $getnameArray = explode('/', $value);
                                                $PropertyModel->ListingModel->ImagesNameModel[0] = $getnameArray[count($getnameArray) - 1];
                                            }
                                        }
                                        $ignoreImg = 1;
                                        try {
                                            if (count($objects->toArray()) > 1)
                                               // $PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing, Constants::$Value_False, Constants::$MercerVineSiteID, $GetFirstImage[1]['PropMediaURL']);
                                                $PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing, Constants::$Value_False, Constants::$ColoradoSiteID, $objects->toArray()[1]->getLocation());
                                        } catch (Exception $e) {
                                            Log::info('In second catch block of first image for Listing ID: ' . $singleProperty->LIST_105);

                                            $addToUploadImage=new CoImageUploadErrorEntity();
                                            $addToUploadImage->MLSNo=$singleProperty->LIST_105;
                                            $addToUploadImage->ImagePath=$objects->toArray()[1]->getLocation();
                                            $addToUploadImage->Errortype=Constants::$Value_True;
                                            $addToUploadImage->AddedDateTime=date(Constants::$DefaultDateTimeFormat);
                                            $this->SaveEntity($addToUploadImage);

                                            $PropertyModel->ListingModel->UploadedFile[0]->SortOrder = 1;
                                            $PropertyModel->ListingModel->UploadedFile[0]->IsSavedInDB = 2;

                                            // set array for first uploaded image to store in co_propertylistings table
                                            foreach ($PropertyModel->ListingModel->UploadedFile[0] as $key => $value) {
                                                $PropertyModel->ListingModel->ImagesModel[0][$key] = $value;
                                                if ($key == 'FilePath') {
                                                    $getnameArray = explode('/', $value);
                                                    $PropertyModel->ListingModel->ImagesNameModel[0] = $getnameArray[count($getnameArray) - 1];
                                                }
                                            }
                                            $ignoreImg = 2;
                                        }
                                    }
                                    if ($ignoreImg != 2) {
                                        $PropertyModel->ListingModel->UploadedFile[0]->SortOrder = 1;
                                        $PropertyModel->ListingModel->UploadedFile[0]->IsSavedInDB = 2;

                                        // set array for first uploaded image to store in co_propertylistings table
                                        foreach ($PropertyModel->ListingModel->UploadedFile[0] as $key => $value) {
                                            $PropertyModel->ListingModel->ImagesModel[0][$key] = $value;
                                            if ($key == 'FilePath') {
                                                $getnameArray = explode('/', $value);
                                                $PropertyModel->ListingModel->ImagesNameModel[0] = $getnameArray[count($getnameArray) - 1];
                                            }
                                        }
                                    }
                                }
                            

                                foreach ($objects->toArray() as $key => $object) {
                                    if ($key > $ignoreImg ) {
                                        $MediaData = array();
                                        $MediaData['PropertyListingID'] = $singleProperty->LIST_105;
                                        $MediaData['UserID'] = Constants::$Value_False;
                                        $MediaData['SiteID'] = Constants::$ColoradoSiteID;
                                        $MediaData['ListingKey'] = $PropertyModel->ListingModel->ListingKey;
                                        $MediaData['PropObjectKey'] = $object->getObjectId();
                                        $MediaData['PropMediaKey'] = $object->getContentId();
                                        $MediaData['PropMediaURL'] = $object->getLocation();
                                        array_push($MediaArray, $MediaData);
                                    }
                                }
                                if (count($MediaArray) > 0) {
                                    $PropertyModel->IsShowUploadNote = 1;
                                } else {
                                    $PropertyModel->IsShowUploadNote = 0;
                                }
                                
                                $this->MultipleInsert(new CoTempRetsImagesEntity(), $MediaArray);
                            }
                        }
                    }
                    $propertyAdded = $this->CoSaveProperty($PropertyModel->ListingModel, Constants::$ColoradoSiteID, Constants::$StaticNullUserID);
                    $responseArray[] = $propertyAdded->Message.": ".$singleProperty->LIST_105;
                }

                $getLastData->COcronLastIndex = $lastIndex + Config::get('config.UpdatePropertiesFromCSV');
                if($lastIndex + Config::get('config.UpdatePropertiesFromCSV') >= $MaxIndex){
                    // changed to 3 for finished
                    $getLastData->COcronCSVStatus=3;
                }
                $this->SaveEntity($getLastData);
            }
            else{
                $getLastData->COcronLastIndex = $lastIndex + Config::get('config.UpdatePropertiesFromCSV');
                if($lastIndex + Config::get('config.UpdatePropertiesFromCSV') >= $MaxIndex){
                    // changed to 3 for finished
                    $getLastData->COcronCSVStatus=3;
                }
                $this->SaveEntity($getLastData);
            }
            $response->IsSuccess = true;
            $response->Message=$responseArray;
        }
        $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
        $getSettings->{Constants::$COPropertyManagementCronCheck} = false;
        $this->SaveEntity($getSettings);
        return $response;
    }

    // { CSV for Update property status
    public function COaddCSVPropertyStatus($COcronClass){
        $datetimePrev =  DB::select("SELECT DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%d') as todayDate");
           
        $searchParam = array();
        $searchValues = Common::SetSearchArray('COcronDate', $datetimePrev[0]->todayDate);
        array_push($searchParam, $searchValues);
        $searchValues = Common::SetSearchArray('COcronFor', Constants::$CronCSVUpdate);
        array_push($searchParam, $searchValues);
        

        $getPrevData = $this->CallRawForSingleTable('co_getPrevCronData', array(Constants::$COCronCSVDelete, $datetimePrev[0]->todayDate,$COcronClass));            
        $prevCSV = "";

        
        $prevCSVCount = 0;
        if(isset($getPrevData[0]) && $getPrevData[0]->COcronLastIndex < $getPrevData[0]->COcronPropertyCount){
            $lastCronData = $getPrevData[0]->COcronCSV;

            $prevCSV = substr($lastCronData, Common::strposnth($lastCronData, ',', $getPrevData[0]->COcronLastIndex) + 1);
            $prevCSVArray = explode(",", $prevCSV);
            $prevCSVCount = count($prevCSVArray);
            
            $savePrevData = $this->CallRawForSingleTable('co_savePrevCronData', array($getPrevData[0]->COcronId));

        }


        $datetime = DB::select("SELECT DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%d') as todayDate");
        $searchParam = array();
        $searchValues = Common::SetSearchArray('COcronDate', $datetime[0]->todayDate);
        array_push($searchParam, $searchValues);
        $searchValues = Common::SetSearchArray('COcronFor', Constants::$COCronCSVDelete);
        array_push($searchParam, $searchValues);
        $searchValues = Common::SetSearchArray('COcronClass', $COcronClass);
        array_push($searchParam, $searchValues);
        $getLastDataDelete = $this->GetEntityForUpdateByFilter(new COCronJobEntity(), $searchParam);

        /*$searchParam = array();
        $searchValues = Common::SetSearchArray('COcronDate', $datetime[0]->todayDate);
        array_push($searchParam, $searchValues);
        $searchValues = Common::SetSearchArray('COcronFor', Constants::$COCronCSVInsertStatus);
        array_push($searchParam, $searchValues);
        $searchValues = Common::SetSearchArray('COcronClass', $COcronClass);
        array_push($searchParam, $searchValues);
        $getLastDataInsert = $this->GetEntityForUpdateByFilter(new COCronJobEntity(), $searchParam);
*/


        $response = new ServiceResponse();

        $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
        $getSettings->{Constants::$COPropertyManagementCronCheck} = false;
        $this->SaveEntity($getSettings);


        $config = new \PHRETS\Configuration;
        $config->setloginurl(Config::get('config.Aspen_Login_URL'));
        $config->setHttpAuthenticationMethod(Config::get('config.CLAW_Authentication_Method'));
        $config->setOption('use_post_method', false);
        $config->setOption('disable_follow_location', false);

        // get credentials from database settings table. We kept them in db so user can change easily if there is any change.
        $Credentials = $this->GetCLAWCredentials(Constants::$ColoradoSiteID);

        $config->setusername(Config::get('config.Aspen_UserName'));
        $config->setpassword(Config::get('config.Aspen_Password'));

        $rets = new \PHRETS\Session($config);
        $login = $rets->Login();
        $LogArray=array();

        $LogArray=$this->StoreRetsLog(Constants::$Value_False, Constants::$ColoradoSiteID, Constants::$RETSActionLogin, Config::get('config.CLAW_Login_URL'), '', $login,$LogArray,false);
        //$getDataBaseValue = DB::select("SELECT DATE_FORMAT(DATE_SUB(CONVERT_TZ(CURDATE(), @@session.time_zone, 'UTC' ), INTERVAL 24 HOUR), '%Y-%m-%dT%H:%i:%s') AS modifiedDate,DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%dT%H:%i:%s') AS todayDate");
        $getDataBaseValue=DB::select("SELECT DATE_FORMAT(CONVERT_TZ(MAX(COcrondate), @@session.time_zone, 'UTC' ), '%Y-%m-%dT%H:%i:%s') AS modifiedDate,DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%dT%H:%i:%s') AS todayDate FROM `co_cronjobhistory` WHERE COcronFor='updateStatus'");
        
        if(!$getDataBaseValue[0]->modifiedDate)
        {
            $getDataBaseValue[0]->modifiedDate = Constants::$CheckForLastDate;
        }

        $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
        $getSettings->{Constants::$COPropertyManagementCronCheck} = false; // set flag to running
        $updateCounter=0;
        $this->SaveEntity($getSettings);

        $ClassData = $this->CallRawForSingleTable("co_getPropertyClassInfo",[$COcronClass]);
        $ClassID = $ClassData[0]->ClassID;
        $ClassAbbreviation = $ClassData[0]->ClassAbriviation;
        $getSettings->CoCronAbbreviation = $ClassAbbreviation;
        $this->SaveEntity($getSettings);

        $LogArray=array();
        $LogArray=$this->StoreRetsLog(Constants::$Value_False, Constants::$ColoradoSiteID, Constants::$RETSActionLogin, Config::get('config.CLAW_Login_URL'), '', $login,$LogArray,false);
        $resource = 'Property';

        $class = $ClassAbbreviation;
        $query = '(LIST_15=|'.$this->getClassStatusSearch($ClassID).')';

        $result = $rets->Search(
            $resource,
            $class,
            $query,
            [
                'QueryType' => 'DMQL2',
                'Count' => 1, // only records
                'Format' => 'COMPACT-DECODED',
                'Limit' => 'NONE',
                'z' => 0,
                'Select' => 'LIST_105'
            ]
        );

        $LogArray = $this->StoreRetsLog(Constants::$Value_False, Constants::$ColoradoSiteID, Constants::$RETSActionSearch, $result->URL, '', serialize($result->toArray()),$LogArray,false);
        $Alldata = json_decode($result->toJSON());
        $totalCount=count($Alldata);
        $csv = implode(',', array_map(function ($n) {
            return $n->LIST_105;
        }, $Alldata));

        if($prevCSVCount > 0){
            $csv = $csv.",".$prevCSV;
        }

        $csvArray = explode(",", $csv);

        $DbMLSNoList = $this->CallRawForMultipleTable('co_getMLSNO', [Constants::$ColoradoSiteID,  $COcronClass]);
        $DbMLSNoListArray = json_decode(json_encode($DbMLSNoList[0]),true);
        $DbMLSNoListArray = array_column($DbMLSNoListArray, 'MLSNo');

        $saveCSV = $saveCSVDelete = "";
        if (!count($getLastDataDelete)  ) {
             /*  Deleted  start*/
            $DeletedMlsNo = array_diff($DbMLSNoListArray,$csvArray);
            $DeletedMlsNoCSV = implode(",", $DeletedMlsNo);
            $insertCSV = new COCronJobEntity();
            $insertCSV->COcronDate = $getDataBaseValue[0]->todayDate;
            $insertCSV->COcronCSV = $DeletedMlsNoCSV;
            $insertCSV->COCronPropertyCount = count($DeletedMlsNo) + $prevCSVCount;
            $insertCSV->COcronFor=Constants::$COCronCSVDelete;
            $insertCSV->COcronCSVStatus=4;
            $insertCSV->COcronClass=$COcronClass;
            $insertCSV->COcronLastIndex=Constants::$Value_False;
            $saveCSVDelete = $this->SaveEntity($insertCSV);

        /*  Deleted  End*/
        } 
        
        else {
            $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
            $getSettings->{Constants::$COPropertyManagementCronCheck} = false;
            $this->SaveEntity($getSettings);

             $response->Message="CSV not added or all properties added successfully.";

            $response->IsSuccess = false;
            $response->Message="CSV not added or all properties added successfully.";
            return $response;
        }


        
        if ( $saveCSVDelete) {
            
            $response->IsSuccess = true;
            $response->Message = "CVS added for Update :" . $getDataBaseValue[0]->todayDate;

            $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
            $getSettings->{Constants::$COPropertyManagementCronCheck} = false;
            $this->SaveEntity($getSettings);
        } else {
            $response->IsSuccess = false;
            $response->Message = "CVS failed for Update:" . $getDataBaseValue[0]->todayDate;

            $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
            $getSettings->{Constants::$COPropertyManagementCronCheck} = false;
            $this->SaveEntity($getSettings);
        }
       
       
        $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
        $getSettings->{Constants::$COPropertyManagementCronCheck} = false;
        $this->SaveEntity($getSettings);
        return $response;
    }

    // Update property from status update }
    public function COUpdateCSVStatusProperties($COcronClass) {
        $response = new ServiceResponse();
        $datetime = DB::select("SELECT DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%d') as todayDate");
        $searchParam = array();
        $searchValues = Common::SetSearchArray('COcronDate', $datetime[0]->todayDate);
        array_push($searchParam, $searchValues);
        $searchValues = Common::SetSearchArray('COcronFor', Constants::$COCronCSVDelete);
        array_push($searchParam, $searchValues);
        $searchValues = Common::SetSearchArray('COcronClass', $COcronClass);
        array_push($searchParam, $searchValues);
        $getLastData = $this->GetEntityForUpdateByFilter(new COCronJobEntity(), $searchParam);
        if (count($getLastData) > 0) {
            $csv = $getLastData->COcronCSV;
            $lastIndex = $getLastData->COcronLastIndex;
            $MaxIndex = $getLastData->COcronPropertyCount;
            //$matches = preg_split('/((?:[^,]*,){15})/', $csv, -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);
            if ($lastIndex != 0 && $lastIndex <= $MaxIndex) {
                if($MaxIndex-$lastIndex <= Config::get('config.UpdatePropertiesStatusFromCSV')){
                    $finalCSV = substr($csv, Common::strposnth($csv, ',', $lastIndex) + 1);
                }
                else {
                    $ReducedCSV = substr($csv, Common::strposnth($csv, ',', $lastIndex) + 1);
                    $finalCSV = substr($ReducedCSV, 0, Common::strposnth($ReducedCSV, ',', Config::get('config.UpdatePropertiesStatusFromCSV')));
                }
            } else {
                Log::info('Update Status CSV Processing started: ' . date('Y-m-d H:i:s'));
                if(Config::get('config.UpdatePropertiesStatusFromCSV') > $MaxIndex){
                    $finalCSV = $csv;
                }else {
                    $finalCSV = substr($csv, 0, Common::strposnth($csv, ',', Config::get('config.UpdatePropertiesStatusFromCSV')));
                }
            }

            if ($finalCSV) {
                $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
                $getSettings->{Constants::$COPropertyManagementCronCheck} = true;
                $this->SaveEntity($getSettings);

               
                $finalCSVArray = explode(",", $finalCSV);

                foreach ($finalCSVArray as $deletedProperty) {

                    $getCOListingId =  $this->CallRawForSingleTable('co_getcolistingid', array($deletedProperty,Constants::$ColoradoSiteID));

                    if(count($getCOListingId)){
                        $DeleteCOListingID = $getCOListingId[0]->CoListingID;
                        $this->DeleteProperty($DeleteCOListingID, Constants::$ColoradoSiteID);
                    }
                    
                }
                

                $getLastData->COcronLastIndex = $lastIndex + Config::get('config.UpdatePropertiesStatusFromCSV');
                if($lastIndex + Config::get('config.UpdatePropertiesStatusFromCSV') >= $MaxIndex){
                    $getLastData->COcronCSVStatus=5;
                }
                $this->SaveEntity($getLastData);
                $response->IsSuccess=true;
            }
            else{
                $getLastData->COcronLastIndex = $lastIndex + Config::get('config.UpdatePropertiesStatusFromCSV');
                if($lastIndex + Config::get('config.UpdatePropertiesStatusFromCSV') >= $MaxIndex){
                    $getLastData->COcronCSVStatus=5;
                }
                $response->IsSuccess=true;
            }
        }
        else {
            $response->IsSuccess=false;
        }
        $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
        $getSettings->{Constants::$COPropertyManagementCronCheck} = false;
        $this->SaveEntity($getSettings);
        return $response;
    }

    public function addNewCSVProperty($COcronClass){
        try {            
            $response = new ServiceResponse();
            $datetime = DB::select("SELECT DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%d') as todayDate");
            $searchParam = array();
            $searchValues = Common::SetSearchArray('COcronDate', $datetime[0]->todayDate);
            array_push($searchParam, $searchValues);
            $searchValues = Common::SetSearchArray('COcronFor', Constants::$COCronCSVInsertStatus);
            array_push($searchParam, $searchValues);
            $searchValues = Common::SetSearchArray('COcronClass', $COcronClass);
            array_push($searchParam, $searchValues);
            $getLastData = $this->GetEntityForUpdateByFilter(new COCronJobEntity(), $searchParam);
            if (count($getLastData) > 0) {
                $csv = $getLastData->COcronCSV;

                $Propertyclass = $getLastData->COcronClass;
                
                $lastIndex = $getLastData->COcronLastIndex;
                $MaxIndex = $getLastData->COcronPropertyCount;
                //$matches = preg_split('/((?:[^,]*,){15})/', $csv, -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);
                if ($lastIndex != 0 && $lastIndex <= $MaxIndex) {
                    if($MaxIndex-$lastIndex <= Config::get('config.AddPropertiesFromCSV')){
                        $finalCSV = substr($csv, Common::strposnth($csv, ',', $lastIndex) + 1);
                    }
                    else {
                        $ReducedCSV = substr($csv, Common::strposnth($csv, ',', $lastIndex) + 1);
                        $finalCSV = substr($ReducedCSV, 0, Common::strposnth($ReducedCSV, ',', Config::get('config.AddPropertiesFromCSV')));
                    }
                } else {
                    Log::info('Insert CSV processing started: ' . date('Y-m-d H:i:s'));
                    if(Config::get('config.AddPropertiesFromCSV')> $MaxIndex){
                        $finalCSV = $csv;
                    }else {
                        $finalCSV = substr($csv, 0, Common::strposnth($csv, ',', Config::get('config.AddPropertiesFromCSV')));
                    }
                }

                
                $GetUniqueData = $this->CallRawForSingleTable('co_processcsvforcron', [$finalCSV]);

                
                //process csv to get none existing data from database
                $finalCSV = Common::GetUniqueCSVFromArray($finalCSV, $GetUniqueData);

                Log::info('Insert Final CSV: ' . $finalCSV);
                if ($finalCSV) {
                    $response = new ServiceResponse();
                    $config = new \PHRETS\Configuration;

                    $config->setloginurl(Config::get('config.Aspen_Login_URL'));
                    $config->setHttpAuthenticationMethod(Config::get('config.CLAW_Authentication_Method'));
                    $config->setOption('use_post_method', false);
                    $config->setOption('disable_follow_location', false);

                    // get credentials from database settings table. We kept them in db so user can change easily if there is any change.
                    $Credentials = $this->GetCLAWCredentials(Constants::$ColoradoSiteID);

                    $config->setusername(Config::get('config.Aspen_UserName'));
                    $config->setpassword(Config::get('config.Aspen_Password'));

                    $rets = new \PHRETS\Session($config);
                    $login = $rets->Login();



                $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');

                $getSettings->{Constants::$COPropertyManagementCronCheck} = true; // set flag to running
                $updateCounter=0;
                $this->SaveEntity($getSettings);
                
                $ClassData = $this->CallRawForSingleTable("co_getPropertyClassInfo",[$Propertyclass]);
                $ClassID = $ClassData[0]->ClassID;
                $ClassAbbreviation = $ClassData[0]->ClassAbriviation;
                $getSettings->CoCronAbbreviation = $ClassAbbreviation;
                $this->SaveEntity($getSettings);

                    $LogArray=array();
                    $LogArray=$this->StoreRetsLog(Constants::$Value_False, Constants::$ColoradoSiteID, Constants::$RETSActionLogin, Config::get('config.CLAW_Login_URL'), '', $login,$LogArray,false);
                    $resource = 'Property';

                    $class = $ClassAbbreviation;
                    $query = '(LIST_15=|'.$this->getClassStatusSearch($ClassID).'),(LIST_105='.$finalCSV.')';// '(LIST_105=' . $MlsNo . ')'; //LIST_105 = 146308 //LIST_22=1+

                    $result = $rets->Search(
                        $resource,
                        $class,
                        $query,
                        [
                            'QueryType' => 'DMQL2',
                            'Count' => 1, // only records
                            'Format' => 'COMPACT-DECODED',
                            'Limit' => 'NONE',
                            'StandardNames' => 0
                        ]
                    );

                    $LogArray = $this->StoreRetsLog(Constants::$Value_False, Constants::$ColoradoSiteID, Constants::$RETSActionSearch, $result->URL, '', serialize($result->toArray()),$LogArray,false);
                    $data = json_decode($result->toJSON());

                    $responseArray = [];


                    foreach($data as $singleProperty) {
                        $searchParam = array();
                        $searchValues = Common::SetSearchArray('MLSNo', $singleProperty->LIST_105, Constants::$Value_True);
                        array_push($searchParam, $searchValues);
                        
                        $duplicate = $this->GetEntity(new CoPropertyListingsEntity(), $searchParam);
                        
                        
                        
                        if($duplicate){
                            $responseArray[] = trans('messages.PropertyDuplicate');
                            continue;
                        }

                        /*$CheckForIsWB = Common::getPropertyOfficeID($singleProperty->LIST_106, Constants::$ColoradoSiteID);
                        if ($CheckForIsWB) {
                            $IsWBProperty = Constants::$Value_True;
                        }*/


                        $PropertyModel = new stdClass();
                        // map value with database
                        $PropertyModel->ListingModel = $this->getColoradoPropertyFormatted($singleProperty, $ClassID);

                        $PropertyModel->ListingModel->IsWBProperty=Constants::$Value_False;

                        $CheckForIsWB = Common::getPropertyOfficeID($singleProperty->LIST_106, Constants::$ColoradoSiteID);
                        if ($CheckForIsWB) {
                            $PropertyModel->ListingModel->IsWBProperty = Constants::$Value_True;
                        }

                        if ($singleProperty->LIST_133 > 0) { //check for images
                            $objects = $rets->GetObject(
                                'Property',
                                '640x480', //Photo,HiRes
                                $PropertyModel->ListingModel->ListingKey,
                                '*', '1'
                            );
                            $checkArrayValue = $objects->toArray();

                            if (count($checkArrayValue) > 0) {
                                $MediaArray = array();
                                $this->CustomDeleteEntity(new CoTempRetsImagesEntity(), 'PropertyListingID', $singleProperty->LIST_105);

                                $ignoreImg = 0;
                                if (count($objects->toArray()) > 0) {
                                    try {
                                        //$PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing,Constants::$Value_False, Constants::$MercerVineSiteID, $GetFirstImage[0]['PropMediaURL']);
                                        // upload first image
                                        $PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing, Constants::$Value_False, Constants::$ColoradoSiteID, $objects->toArray()[0]->getLocation());
                                            
                                    } 
                                    catch (Exception $e) {
                                        Log::info('In first catch block of first image for Co Listing ID: ' . $singleProperty->LIST_105);

                                        $addToUploadImage=new CoImageUploadErrorEntity();
                                        $addToUploadImage->MLSNo=$singleProperty->LIST_105;
                                        $addToUploadImage->ImagePath=$objects->toArray()[0]->getLocation();
                                        $addToUploadImage->Errortype=Constants::$Value_True;
                                        $addToUploadImage->AddedDateTime=date(Constants::$DefaultDateTimeFormat);
                                        $this->SaveEntity($addToUploadImage);
                                        
                                        $PropertyModel->ListingModel->UploadedFile[0]->SortOrder = 1;
                                        $PropertyModel->ListingModel->UploadedFile[0]->IsSavedInDB = 2;

                                        // set array for first uploaded image to store in co_propertylistings table
                                        foreach ($PropertyModel->ListingModel->UploadedFile[0] as $key => $value) {
                                            $PropertyModel->ListingModel->ImagesModel[0][$key] = $value;
                                            if ($key == 'FilePath') {
                                                $getnameArray = explode('/', $value);
                                                $PropertyModel->ListingModel->ImagesNameModel[0] = $getnameArray[count($getnameArray) - 1];
                                            }
                                        }
                                        $ignoreImg = 1;
                                        try {
                                            if (count($objects->toArray()) > 1)
                                               // $PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing, Constants::$Value_False, Constants::$MercerVineSiteID, $GetFirstImage[1]['PropMediaURL']);
                                                $PropertyModel->ListingModel->UploadedFile[0] = $this->FileUpload(Constants::$AWSRequestType_Listing, Constants::$Value_False, Constants::$ColoradoSiteID, $objects->toArray()[1]->getLocation());
                                        } catch (Exception $e) {
                                            Log::info('In second catch block of first image for Listing ID: ' . $singleProperty->LIST_105);

                                            $addToUploadImage=new CoImageUploadErrorEntity();
                                            $addToUploadImage->MLSNo=$singleProperty->LIST_105;
                                            $addToUploadImage->ImagePath=$objects->toArray()[1]->getLocation();
                                            $addToUploadImage->Errortype=Constants::$Value_True;
                                            $addToUploadImage->AddedDateTime=date(Constants::$DefaultDateTimeFormat);
                                            $this->SaveEntity($addToUploadImage);
                                            
                                            $PropertyModel->ListingModel->UploadedFile[0]->SortOrder = 1;
                                            $PropertyModel->ListingModel->UploadedFile[0]->IsSavedInDB = 2;

                                            // set array for first uploaded image to store in co_propertylistings table
                                            foreach ($PropertyModel->ListingModel->UploadedFile[0] as $key => $value) {
                                                $PropertyModel->ListingModel->ImagesModel[0][$key] = $value;
                                                if ($key == 'FilePath') {
                                                    $getnameArray = explode('/', $value);
                                                    $PropertyModel->ListingModel->ImagesNameModel[0] = $getnameArray[count($getnameArray) - 1];
                                                }
                                            }
                                            $ignoreImg = 2;
                                        }
                                    }
                                    if ($ignoreImg != 2) {
                                        $PropertyModel->ListingModel->UploadedFile[0]->SortOrder = 1;
                                        $PropertyModel->ListingModel->UploadedFile[0]->IsSavedInDB = 2;

                                        // set array for first uploaded image to store in co_propertylistings table
                                        foreach ($PropertyModel->ListingModel->UploadedFile[0] as $key => $value) {
                                            $PropertyModel->ListingModel->ImagesModel[0][$key] = $value;
                                            if ($key == 'FilePath') {
                                                $getnameArray = explode('/', $value);
                                                $PropertyModel->ListingModel->ImagesNameModel[0] = $getnameArray[count($getnameArray) - 1];
                                            }
                                        }
                                    }
                                }
                            

                                foreach ($objects->toArray() as $key => $object) {
                                    if ($key > $ignoreImg ) {
                                        $MediaData = array();
                                        $MediaData['PropertyListingID'] = $singleProperty->LIST_105;
                                        $MediaData['UserID'] = Constants::$Value_False;
                                        $MediaData['SiteID'] = Constants::$ColoradoSiteID;
                                        $MediaData['ListingKey'] = $PropertyModel->ListingModel->ListingKey;
                                        $MediaData['PropObjectKey'] = $object->getObjectId();
                                        $MediaData['PropMediaKey'] = $object->getContentId();
                                        $MediaData['PropMediaURL'] = $object->getLocation();
                                        array_push($MediaArray, $MediaData);
                                    }
                                }
                                if (count($MediaArray) > 0) {
                                    $PropertyModel->IsShowUploadNote = 1;
                                } else {
                                    $PropertyModel->IsShowUploadNote = 0;
                                }
                                
                                $this->MultipleInsert(new CoTempRetsImagesEntity(), $MediaArray);
                            }
                        }
                        
                        $propertyAdded = $this->CoSaveProperty($PropertyModel->ListingModel, Constants::$ColoradoSiteID, Constants::$StaticNullUserID);
                        $responseArray[] = $propertyAdded->Message.": ".$singleProperty->LIST_105;
                    }

                    $getLastData->COcronLastIndex = $lastIndex + Config::get('config.AddPropertiesFromCSV'); 
                    if($lastIndex + Config::get('config.AddPropertiesFromCSV') >= $MaxIndex){
                        // changed to 1 for finished
                        $getLastData->COcronCSVStatus=7;
                    }
                    $this->SaveEntity($getLastData);

                }
                else{
                    $getLastData->COcronLastIndex = $lastIndex + Config::get('config.AddPropertiesFromCSV'); 
                    if($lastIndex + Config::get('config.AddPropertiesFromCSV') >= $MaxIndex){
                        // changed to 1 for finished
                        $getLastData->COcronCSVStatus=7;
                    }
                    $this->SaveEntity($getLastData);
                }
                
                $this->SaveEntity($getLastData);
                $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
                $getSettings->{Constants::$COPropertyManagementCronCheck} = false;
                $this->SaveEntity($getSettings);

                $response->IsSuccess = true;

            } else {
                $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
                $getSettings->{Constants::$COPropertyManagementCronCheck} = false;
                $this->SaveEntity($getSettings);

                $response->IsSuccess = false;
                $response->Message="CSV not added or all properties added successfully.";
            }
        }
        catch(Exception $e) {
            Log::info('Adding CSV Property Issue :' . date('Y-m-d H:i:s'));
            Log::error($e);
        }
        return $response;
    }


    public function COaddCSVNewPropertyStatus($COcronClass){

        $datetimePrev =  DB::select("SELECT DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%d') as todayDate");
           
        $searchParam = array();
        $searchValues = Common::SetSearchArray('COcronDate', $datetimePrev[0]->todayDate);
        array_push($searchParam, $searchValues);
        $searchValues = Common::SetSearchArray('COcronFor', Constants::$CronCSVUpdate);
        array_push($searchParam, $searchValues);
        

        $getPrevData = $this->CallRawForSingleTable('co_getPrevCronData', array(Constants::$COCronCSVInsertStatus, $datetimePrev[0]->todayDate,$COcronClass));            
        $prevCSV = "";

        
        $prevCSVCount = 0;
        if(isset($getPrevData[0]) && $getPrevData[0]->COcronLastIndex < $getPrevData[0]->COcronPropertyCount){
            $lastCronData = $getPrevData[0]->COcronCSV;

            $prevCSV = substr($lastCronData, Common::strposnth($lastCronData, ',', $getPrevData[0]->COcronLastIndex) + 1);
            $prevCSVArray = explode(",", $prevCSV);
            $prevCSVCount = count($prevCSVArray);
            
            $savePrevData = $this->CallRawForSingleTable('co_savePrevCronData', array($getPrevData[0]->COcronId));

        }


        $datetime = DB::select("SELECT DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%d') as todayDate");
       /* $searchParam = array();
        $searchValues = Common::SetSearchArray('COcronDate', $datetime[0]->todayDate);
        array_push($searchParam, $searchValues);
        $searchValues = Common::SetSearchArray('COcronFor', Constants::$COCronCSVDelete);
        array_push($searchParam, $searchValues);
        $searchValues = Common::SetSearchArray('COcronClass', $COcronClass);
        array_push($searchParam, $searchValues);
        $getLastDataDelete = $this->GetEntityForUpdateByFilter(new COCronJobEntity(), $searchParam);
*/
        $searchParam = array();
        $searchValues = Common::SetSearchArray('COcronDate', $datetime[0]->todayDate);
        array_push($searchParam, $searchValues);
        $searchValues = Common::SetSearchArray('COcronFor', Constants::$COCronCSVInsertStatus);
        array_push($searchParam, $searchValues);
        $searchValues = Common::SetSearchArray('COcronClass', $COcronClass);
        array_push($searchParam, $searchValues);
        $getLastDataInsert = $this->GetEntityForUpdateByFilter(new COCronJobEntity(), $searchParam);



        $response = new ServiceResponse();

        $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
        $getSettings->{Constants::$COPropertyManagementCronCheck} = false;
        $this->SaveEntity($getSettings);


        $config = new \PHRETS\Configuration;
        $config->setloginurl(Config::get('config.Aspen_Login_URL'));
        $config->setHttpAuthenticationMethod(Config::get('config.CLAW_Authentication_Method'));
        $config->setOption('use_post_method', false);
        $config->setOption('disable_follow_location', false);

        // get credentials from database settings table. We kept them in db so user can change easily if there is any change.
        $Credentials = $this->GetCLAWCredentials(Constants::$ColoradoSiteID);

        $config->setusername(Config::get('config.Aspen_UserName'));
        $config->setpassword(Config::get('config.Aspen_Password'));

        $rets = new \PHRETS\Session($config);
        $login = $rets->Login();
        $LogArray=array();

        $LogArray=$this->StoreRetsLog(Constants::$Value_False, Constants::$ColoradoSiteID, Constants::$RETSActionLogin, Config::get('config.CLAW_Login_URL'), '', $login,$LogArray,false);
        //$getDataBaseValue = DB::select("SELECT DATE_FORMAT(DATE_SUB(CONVERT_TZ(CURDATE(), @@session.time_zone, 'UTC' ), INTERVAL 24 HOUR), '%Y-%m-%dT%H:%i:%s') AS modifiedDate,DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%dT%H:%i:%s') AS todayDate");
        $getDataBaseValue=DB::select("SELECT DATE_FORMAT(CONVERT_TZ(MAX(COcrondate), @@session.time_zone, 'UTC' ), '%Y-%m-%dT%H:%i:%s') AS modifiedDate,DATE_FORMAT(CONVERT_TZ( CURDATE(), @@session.time_zone, 'UTC' ), '%Y-%m-%dT%H:%i:%s') AS todayDate FROM `co_cronjobhistory` WHERE COcronFor='updateStatus'");
        
        if(!$getDataBaseValue[0]->modifiedDate)
        {
            $getDataBaseValue[0]->modifiedDate = Constants::$CheckForLastDate;
        }

        $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
        $getSettings->{Constants::$COPropertyManagementCronCheck} = false; // set flag to running
        $updateCounter=0;
        $this->SaveEntity($getSettings);

        $ClassData = $this->CallRawForSingleTable("co_getPropertyClassInfo",[$COcronClass]);
        $ClassID = $ClassData[0]->ClassID;
        $ClassAbbreviation = $ClassData[0]->ClassAbriviation;
        $getSettings->CoCronAbbreviation = $ClassAbbreviation;
        $this->SaveEntity($getSettings);

        $LogArray=array();
        $LogArray=$this->StoreRetsLog(Constants::$Value_False, Constants::$ColoradoSiteID, Constants::$RETSActionLogin, Config::get('config.CLAW_Login_URL'), '', $login,$LogArray,false);
        $resource = 'Property';

        $class = $ClassAbbreviation;
        $query = '(LIST_15=|'.$this->getClassStatusSearch($ClassID).')';

        $result = $rets->Search(
            $resource,
            $class,
            $query,
            [
                'QueryType' => 'DMQL2',
                'Count' => 1, // only records
                'Format' => 'COMPACT-DECODED',
                'Limit' => 'NONE',
                'z' => 0,
                'Select' => 'LIST_105'
            ]
        );

        $LogArray = $this->StoreRetsLog(Constants::$Value_False, Constants::$ColoradoSiteID, Constants::$RETSActionSearch, $result->URL, '', serialize($result->toArray()),$LogArray,false);
        $Alldata = json_decode($result->toJSON());
        $totalCount=count($Alldata);
        $csv = implode(',', array_map(function ($n) {
            return $n->LIST_105;
        }, $Alldata));

        $csvArray = explode(",", $csv);

        if($prevCSVCount > 0){
            $csv = $csv.",".$prevCSV;
        }

        $GetUniqueData = $this->CallRawForSingleTable('co_processcsvforcron', [$csv]);
        $csv = Common::GetUniqueCSVFromArray($csv, $GetUniqueData);
        $csvCount = explode(",", $csv);

        $DbMLSNoList = $this->CallRawForMultipleTable('co_getMLSNO', [Constants::$ColoradoSiteID, $COcronClass]);
        $DbMLSNoListArray = json_decode(json_encode($DbMLSNoList[0]),true);
        $DbMLSNoListArray = array_column($DbMLSNoListArray, 'MLSNo');

        
        if (!count($getLastDataInsert)  ) {
              /*  New Added  start*/
            $NewAddedMlsNo = array_diff($csvArray, $DbMLSNoListArray);
            $NewAddedMlsNoCSV = implode(",", $NewAddedMlsNo);
            $insertCSV = new COCronJobEntity();
            $insertCSV->COcronDate = $getDataBaseValue[0]->todayDate;
            $insertCSV->COcronCSV = $NewAddedMlsNoCSV;
            $insertCSV->COCronPropertyCount = count($csvCount);
            //$insertCSV->COCronPropertyCount = $totalCount + $prevCSVCount -count($GetUniqueData);
            $insertCSV->COcronFor=Constants::$COCronCSVInsertStatus;
            $insertCSV->COcronCSVStatus=6;
            $insertCSV->COcronClass=$COcronClass;
            $insertCSV->COcronLastIndex=Constants::$Value_False;
            $saveCSV = $this->SaveEntity($insertCSV);
            /*  New Added  End*/
        }
        else {
            $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
            $getSettings->{Constants::$COPropertyManagementCronCheck} = false;
            $this->SaveEntity($getSettings);

             $response->Message="CSV not added or all properties added successfully.";

            $response->IsSuccess = false;
            $response->Message="CSV not added or all properties added successfully.";
            return $response;
        }


        
        if ( $saveCSV) {
            
            $response->IsSuccess = true;
            $response->Message = "CVS added for Update :" . $getDataBaseValue[0]->todayDate;

            $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
            $getSettings->{Constants::$COPropertyManagementCronCheck} = false;
            $this->SaveEntity($getSettings);
        } else {
            $response->IsSuccess = false;
            $response->Message = "CVS failed for Update:" . $getDataBaseValue[0]->todayDate;

            $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
            $getSettings->{Constants::$COPropertyManagementCronCheck} = false;
            $this->SaveEntity($getSettings);
        }
       
       
        $getSettings= $this->GetEntityForUpdateByPrimaryKey(new SettingEntity(),'1');
        $getSettings->{Constants::$COPropertyManagementCronCheck} = false;
        $this->SaveEntity($getSettings);
        return $response;
    }

    /* Dev_KT Region start */
    public function CoGetFailedImageCron()
    {
        $response=new ServiceResponse();
        $dateTime = date(Constants::$DefaultDateTimeFormat);

        try{
            if (Common::SetCronJobRunning(Constants::$CoFailedImageCronJob)) {
                try {

                    $MLSNoArray = $this->CallRawForSingleTable('co_getremainingfailedimaged', [Config::get('config.NumberOfPropertiesToGet'),1]);

                    $data = array();
                    foreach ($MLSNoArray AS $keymls => $valmls) {

                        $ImageUploadErrorEntityEntity = $this->GetEntityForUpdateByPrimaryKey(new CoImageUploadErrorEntity(), $valmls->ImageUploadErrorID);
                        if ($valmls->IsProcessed == '') {
                            $checkAlreadyExistSingleImage = $this->CallRawForSingleTable('co_checkalreadyexistanyimage', [$valmls->CoListingID]);
                            if($checkAlreadyExistSingleImage[0]->totalImage == 0)
                            {
                                try {
                                    $ImageUploadErrorEntityEntity->isProcessed = 1;
                                    $this->SaveEntity($ImageUploadErrorEntityEntity);

                                    $PropertyModel = $this->FileUpload(Constants::$AWSRequestType_Listing, Constants::$Value_False, Constants::$MercerVineSiteID, $valmls->ImagePath);

                                    if (count($PropertyModel)) {
                                        //Upload images
                                        if (!is_null($PropertyModel->FileName)) {
                                            $processData = array(
                                                'CoListingID' => $valmls->CoListingID,
                                                'FileName' => $PropertyModel->FileName,
                                                'FilePath' => $PropertyModel->FilePath,
                                                'FileSize' => $PropertyModel->FileSize,
                                                'SortOrder' => $checkAlreadyExistSingleImage[0]->SortOrder + 1,
                                                'CreatedDate' => $dateTime,
                                                'ModifiedDate' => $dateTime,
                                                'CreatedByID' => NULL,
                                                'ModifiedByID' => NULL
                                            );
                                            array_push($data, $processData);
                                            $ImageUploadErrorEntityEntity->IsSuccess = 1;
                                            $this->SaveEntity($ImageUploadErrorEntityEntity);
                                        }
                                    }
                                }
                                catch (Exception $e) {
                                    Log::info(' Adding failed images :' . date('Y-m-d H:i:s'));
                                    Log::error($e);
                                }

                            }
                        }
                    }
                    if (count($data)) {
                        $propertyImageAdded = $this->MultipleInsert(new CoPropertyListingImagesEntity(), $data);

                        $response->IsSuccess = true;
                        $response->Message = count($data) . ' image uploaded';
                    }
                }catch (Exception $e){
                    Log::info(' Adding Co failed images :' . date('Y-m-d H:i:s'));
                    Log::error($e);
                }
                Common::UnsetCronJobRunning(Constants::$CoFailedImageCronJob);
            }
        }
        catch (Exception $e) {
            Log::info(' Adding Co failed images :' . date('Y-m-d H:i:s'));
            Log::error($e);
            Common::UnsetCronJobRunning(Constants::$CoFailedImageCronJob);
        }
        return $response;
    }

    public function CoGetFailedPropertyImagesInterventionCron(){
        $response=new ServiceResponse();

        try {

            if(Common::SetCronJobRunning(Constants::$CoFailedImageInterventionCronJob)) {
                try{
                    $imageCount = Config::get('config.NumberOfPropertyImagesIntervention');
                    $imagesInterventionData = $this->CallRawForSingleTable('co_getremainingfailedimaged', [$imageCount,2]);

                    if (!empty($imagesInterventionData)) {
                        foreach ($imagesInterventionData as $imageInfo) {

                            $imageDimensionArray = Common::getImageInterventionDimensionArray(Constants::$ColoradoSiteID, Constants::$Value_True);

                            if ($imageDimensionArray) {
                                $count = 0;
                                foreach ($imageDimensionArray as $dimension) {

                                    $fullImagePath = $imageInfo->ImagePath;
                                    try {

                                        $updateCropAttempt = $this->GetEntityForUpdateByPrimaryKey(new CoImageUploadErrorEntity(), $imageInfo->ImageUploadErrorID);
                                        $updateCropAttempt->isProcessed = 1;
                                        $this->SaveEntity($updateCropAttempt);

                                        Common::ImageIntervention($fullImagePath, $dimension, '', 0);
                                        $count++;

                                    } catch (Exception $e) {
                                        $updateCropAttempt = $this->GetEntityForUpdateByPrimaryKey(new CoImageUploadErrorEntity(), $imageInfo->ImageUploadErrorID);
                                        if ($updateCropAttempt->CropAttempt < Constants::$maxImageUploadAttempt && $count == count($imageDimensionArray)) {
                                            $updateCropAttempt->CropAttempt = $updateCropAttempt->CropAttempt + 1;
                                            $this->SaveEntity($updateCropAttempt);
                                        }
                                    }
                                }
                                if ($count == count($imageDimensionArray)) {
                                    $updateCropAttempt = $this->GetEntityForUpdateByPrimaryKey(new CoImageUploadErrorEntity(), $imageInfo->ImageUploadErrorID);
                                    $updateCropAttempt->IsSuccess = 1;
                                    $this->SaveEntity($updateCropAttempt);
                                }
                            }
                        }
                        $response->IsSuccess = true;
                    }
                }
                catch (Exception $e) {
                    Log::info(' Adding failed images :' . date('Y-m-d H:i:s'));
                    Log::error($e);
                }
                Common::UnsetCronJobRunning(Constants::$CoFailedImageInterventionCronJob);

            }

        }
        catch (Exception $e) {
            Log::info(' Adding failed images :' . date('Y-m-d H:i:s'));
            Log::error($e);
            Common::UnsetCronJobRunning(Constants::$CoFailedImageInterventionCronJob);
        }
        return $response;
    }
    /* Dev_KT Region end */
    /************* Colorado Property End **************/

}
