<?php 
namespace dataproviders;


Interface IFaqDataProvider{

    /*Start Region Dev_Vishal*/
    
    /*Stop Region Dev_Vishal*/

    /*RB Start*/
    
    /*RB End*/


    /*AD Start*/
    public function AddFaqData($FaqModel,$loginUserID,$siteID);
    public function getFaqTypeDetails($faqID,$siteID);
    public function getSearchModelForFaqList($siteID);
    public function DeleteFaq($FAQID,$siteID);
    public function UpdateSortOrderFaq($OldOrder,$newOrder,$siteID);
    /*AD  End*/


    /*DN Start*/

    /*DN  End*/
}
