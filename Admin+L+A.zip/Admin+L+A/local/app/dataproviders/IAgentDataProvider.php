<?php

namespace dataproviders;
Interface IAgentDataProvider{
    /* Start Region Dev_Drashtant */
    public function getSearchModelForAgentList($siteID);
    public function getAgentInfoList($agentData);
    public function postDisableAgent($agentData,$loggedInUserID,$siteID);
    public function postEnableAgent($agentData,$loggedInUserID,$siteID);
    /* Stop Region Dev_Drashtant */

    /* Start Region Dev_AD */

    public function getUserTypeDetails($userID,$siteID,$roleID,$updateProfile,$userSiteList);
    public function AddAgentData($AgentModel,$siteID,$loginUserID);
    public function AwsAgentFileDownload($data);
    public function DeleteAgentImageAmazon($data);
    /* End Region Dev_AD */
}