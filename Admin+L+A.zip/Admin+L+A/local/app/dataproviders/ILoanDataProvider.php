<?php 
namespace dataproviders;


Interface ILoanDataProvider{

    /*Dev_UP Start*/
    public function getSearchModelForLoanList($siteID);
    public function DeleteLoan($LoanID,$siteID);
    public function UpdateSortOrderLoan($OldOrder,$newOrder,$siteID);
    /*Dev_UP  End*/

    public function getLoanData($LoanID,$SiteID,$UserID);
    public function SaveLoan($LoanModel,$UserID,$SiteID);
}
