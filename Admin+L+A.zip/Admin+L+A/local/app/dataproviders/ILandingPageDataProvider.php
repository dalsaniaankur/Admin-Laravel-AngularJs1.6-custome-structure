<?php 
namespace dataproviders;


Interface ILandingPageDataProvider{

    /*RB Start*/
    public function getLandingPageDetails($siteID,$loginUserID);
    public function AwsFileDownload($data);
    public function DeleteLandingPageImageAmazon($data,$siteID);
    public function SaveLandingPageImage($data,$siteID);
    /*RB  End*/

}
