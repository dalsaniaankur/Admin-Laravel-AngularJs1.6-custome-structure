<?php
namespace dataproviders;
use Illuminate\Support\Facades\Validator;
use \ViewModels\ServiceResponse;
use \ViewModels\SearchValueModel;
use \Infrastructure\Constants;
use \Infrastructure\Common;
use \stdClass;
use \UserEntity;
use \StatusEntity;
use \UserRolesEntity;
use Illuminate\Support\Facades\URL;
use \TestimonialEntity;
use StateEntity;
use SitesEntity;
use StylisticInfluencesEntity;
use \Image;
use \File;
use Infrastructure\CacheHelper;

class AgentDataProvider extends BaseDataProvider implements IAgentDataProvider{

    /* Start Region Dev_Drashtant */
    public function getSearchModelForAgentList($siteID){
        $response = new ServiceResponse();
        $model = new stdClass();

        $statusData = $this->GetEntityList(new StatusEntity(),array());

        $allStatus = new StatusEntity();
        $allStatus->StatusID = Constants::$AllStatusValue;
        $allStatus->Status = Constants::$AllStatusText;
        array_unshift($statusData,$allStatus);

        $searchModel = new stdClass();
        $searchModel->LastName = "";
        $searchModel->Email = "";
        $searchModel->CalBRENo = "";
        $searchModel->StatusID =Constants::$Status_Active;
        $searchModel->SiteID = $siteID;

        $model->StatusLookup = $statusData;
        $model->frontSearchModel = $searchModel;
        $model->backSearchModel = $searchModel;
        $response->Data=$model;
        return $response;
    }
    public function getAgentInfoList($agentData){
        $response = new ServiceResponse();

        if(empty($agentData->SortIndex)){
            $agentData->SortIndex = Constants::$SortIndex;
        }

        if(empty($agentData->SortDirection)){
            $agentData->SortDirection = Constants::$SortIndexASC;
        }
        $sortIndex = $agentData->SortIndex;
        $sortDirection = $agentData->SortDirection;
        $pageIndex = $agentData->PageIndex;
        $pageSizeCount = $agentData->PageSize;

        $searchLastName = '';
        $searchEmail = '';
        $searchRoleID = Constants::$Agent_Role_ID;
        $searchStatus = '';
        $searchCalBRENo = '';
        $searchSiteID = '';

        if(isset($agentData->SearchParams)){

            if(isset($agentData->SearchParams['LastName'])){
                $searchLastName = $agentData->SearchParams['LastName'];
            }
            if(isset($agentData->SearchParams['Email'])){
                $searchEmail = $agentData->SearchParams['Email'];
            }
            if(isset($agentData->SearchParams['StatusID'])){
                $searchStatus = $agentData->SearchParams['StatusID'];
            }
            if(isset($agentData->SearchParams['CalBRENo'])){
                $searchCalBRENo = $agentData->SearchParams['CalBRENo'];
            }
            if(isset($agentData->SearchParams['SiteID'])){
                $searchSiteID = $agentData->SearchParams['SiteID'];
            }
        }
        $agentList = $this->GetPageRecordsUsingSP('agentlist',$pageIndex,$pageSizeCount, [$searchLastName,$searchEmail,$searchStatus,$searchRoleID,$searchCalBRENo,$pageIndex,$pageSizeCount,$sortIndex,$sortDirection,$searchSiteID]);

        if(is_null($agentList)){
            $response->Message = trans('messages.NoAgentRecordFound');
        }else{
            $response->IsSuccess = true;
            $response->Data = $agentList;
        }
        return $response;
    }
    public function postDisableAgent($agentData,$loggedInUserID,$siteID){
        $response = new ServiceResponse();
        $dateTime = date(Constants::$DefaultDateTimeFormat);
        $userID = $agentData->UserID;
        $previousRoleID = $agentData->RoleID;

        $roleNoAccess = Constants::$RoleNoAccess;
        $disableAgentRole = $this->CallRawForSingleTable('disableagent',[$userID,$dateTime,$loggedInUserID,$siteID,$roleNoAccess,$previousRoleID]);

        CacheHelper::CacheManage($siteID,Constants::$cacheAgentID,Constants::$cacheActionUpdate,$disableAgentRole[1][0]->agentSlug);
        if($siteID==Constants::$MercerVineSiteID) {
            $propertyList=$this->CallRawForSingleTable('getdisableagentproperty', [$userID]);
            foreach($propertyList as $property){
                CacheHelper::CacheManage($siteID,Constants::$cachePropertyID,Constants::$cacheActionUpdate,$property->ListingID);
            }
        }
        if($disableAgentRole){
            $response->IsSuccess = true;
            $response->Message = trans('messages.AgentDisableSuccess');
        }
        return $response;
    }

    public function postEnableAgent($agentData,$loggedInUserID,$siteID){
        $response = new ServiceResponse();
        $dateTime = date(Constants::$DefaultDateTimeFormat);
        $userID = $agentData->UserID;

        $roleAgent = Constants::$RoleAgent;
        $enableAgent = $this->CallRawForSingleTable('enableagent',[$userID,$dateTime,$loggedInUserID,$siteID,$roleAgent]);

        CacheHelper::CacheManage($siteID,Constants::$cacheAgentID,Constants::$cacheActionUpdate,$enableAgent[1][0]->agentSlug);
        if($siteID==Constants::$MercerVineSiteID) {
            $propertyList=$this->CallRawForSingleTable('getdisableagentproperty', [$userID]);
            foreach($propertyList as $property){
                CacheHelper::CacheManage($siteID,Constants::$cachePropertyID,Constants::$cacheActionUpdate,$property->ListingID);
            }
        }
        if($enableAgent){
            $response->IsSuccess = true;
            $response->Message = trans('messages.AgentEnableSuccess');
        }
        return $response;
    }

    /* Stop Region Dev_Drashtant */

    /*Dev_AD Region Start*/
    public function getUserTypeDetails($userID,$siteID,$roleID,$updateProfile,$userSiteList){
        $response = new ServiceResponse();
        $model = new StdClass();
        $agentModel = new StdClass();
        $testModel = new stdClass();
        $mvRole = new stdClass();
        $stylisticInfluencesModel = new stdClass();
        $mvRole->SiteID = Constants::$MercerVineSiteID;
        $model->MVModel = $mvRole;
        $response->Data = $model;
        if($userID >0) {
            $searchParams = array();
            $searchValueData = new SearchValueModel();
            $searchValueData->Name = "UserID";
            $searchValueData->Value = $userID;
            array_push($searchParams, $searchValueData);
            $AgentDetails = $this->GetEntity(new UserEntity(), $searchParams);
            $AgentDetails->IsAgent = intval($AgentDetails->IsAgent);
            $AgentDetails->IsFoundingMember = intval($AgentDetails->IsFoundingMember);
            $AgentDetails->IsTeamMember = intval($AgentDetails->IsTeamMember);
            $agentModel->AgentDetails = $AgentDetails;
            $testimonialEntity = new TestimonialEntity();
            $testimonialEntity->TestimonialID = Constants::$Value_False;
            $testimonialEntity->SiteID = $siteID;
            $testimonialEntity->AgentID = $userID;
            $testimonialEntity->IsVisible = Constants::$Value_True;
            $testDetails = $testimonialEntity;
            $testModel->TestDetails = $testDetails;
            $testModel->DefaultTestDetails = $testDetails;
            $testimonialData = $this->CallRawForMultipleTable('gettestimonials',[$userID, $siteID]);
            foreach($testimonialData[0] as $values){
                if($values->IsVisible ==0){
                    $values->VisibleText ='False';
                } else{
                    $values->VisibleText ='True';
                }
            }
            $columnName = array("IsVisible");
            $testModel->TestimonialListArray = Common::setSelectedPropertyValueToIntOfList($testimonialData[0],$columnName);
            $testModel->SiteID = $siteID;
            $testModel->AgentID = $userID;
            $testModel->RedirectUrl = URL::to('/') . "/agents/" . Common::getEncryptedValue(Constants::$QueryStringSiteID . '=' . $siteID);
            $model->TestimonialModel = $testModel;
            //$stylisticInfluencesDetail = $this->CallRawForMultipleTable('stylisticinfluenceslist',[$siteID,$userID]);
            //$stylisticInfluencesModel->stylisticInfluencesDetails = $stylisticInfluencesDetail[0];
            //$stylisticInfluencesModel->UserID = $userID;
            //$model->StylisticInfluencesModel = $stylisticInfluencesModel;
        }else{
            //$model->StylisticInfluencesModel = '';
        }
        $PropertyResults = $this->CallRawForMultipleTable('propertymodel', [$siteID]);

        $searchModel = new stdClass();
        $searchModel->StatusID = Constants::$Property_Default_Status;
        $searchModel->SiteID = $siteID;
        $searchModel->IsFeatured = Constants::$ShowHidden;
        $searchModel->MLSNo ="";
        $searchModel->Address ="";
        $searchModel->UserID ="";

        $model->ListModel['StatusLookup'] = $PropertyResults[0];
        $model->ListModel['frontSearchModel'] = $searchModel;
        $model->ListModel['backSearchModel'] = $searchModel;
        $model->ListModel['AgentID'] = $userID;
        $response->Data=$model;

        $model->AgentModel = $agentModel;
        $stateArray = $this->GetEntityList(new StateEntity(), "");

        if(isset($agentModel->AgentDetails)){
            if(!empty($model->AgentModel->AgentDetails->ImagePath)){
                $imageData = $this->Awsdownloadfile($model->AgentModel->AgentDetails->ImagePath,'',true);
                $model->AgentModel->AgentDetails->RealImagePath = $imageData->signedUrl;
            }else{
                $model->AgentModel->AgentDetails->RealImagePath ='';
            }
            if(!empty($model->AgentModel->AgentDetails->SmallerImagesPath)){
                $imageData = $this->Awsdownloadfile($model->AgentModel->AgentDetails->SmallerImagesPath,'',true);
                $model->AgentModel->AgentDetails->RealSmallerImagesPath = $imageData->signedUrl;
            }else{
                $model->AgentModel->AgentDetails->RealSmallerImagesPath = '';
            }
            $model->AgentModel->AgentDetails->Password = '';
            $model->AgentModel->AgentDetails->UploadFilesArray = '';
        }else{
            $agentModel->AgentDetails = new StdClass();
            $model->AgentModel->AgentDetails->StatusID = Constants::$UserStatusPending;
            $model->AgentModel->AgentDetails->UserID = Constants::$Value_False;
            $model->AgentModel->AgentDetails->RealImagePath = '';
            $model->AgentModel->AgentDetails->RealSmallerImagesPath = '';
            $model->AgentModel->AgentDetails->ImageName = '';
            $model->AgentModel->AgentDetails->UploadFilesArray = '';
            $model->AgentModel->AgentDetails->TempFilesArray = '';
        }

        if($userSiteList){
            $model->AgentModel->AgentDetails->MVUserRole = Common::GetRoleIDFromSessionRoles($userSiteList,Constants::$filedSiteID,Constants::$MercerVineSiteID);
            $model->AgentModel->AgentDetails->COUserRole = Common::GetRoleIDFromSessionRoles($userSiteList,Constants::$filedSiteID,Constants::$ColoradoSiteID);
            $model->AgentModel->AgentDetails->WWUserRole = Common::GetRoleIDFromSessionRoles($userSiteList,Constants::$filedSiteID,Constants::$WoodBridgeWealthSiteID);
            $model->AgentModel->AgentDetails->RDUserRole = Common::GetRoleIDFromSessionRoles($userSiteList,Constants::$filedSiteID,Constants::$RiverDaleFundingSiteID);
        }
        if($model->AgentModel->AgentDetails->MVUserRole== Constants::$RoleITAdmin && $model->AgentModel->AgentDetails->COUserRole==Constants::$RoleITAdmin &&$model->AgentModel->AgentDetails->WWUserRole== Constants::$RoleITAdmin && $model->AgentModel->AgentDetails->RDUserRole==Constants::$RoleITAdmin){
            $model->AgentModel->AgentDetails->MasterUserRole = Constants::$Value_True;
        }

        if(!empty($siteID) & !empty($roleID) && $updateProfile==0){
            $model->AgentModel->AgentDetails->RedirectURL = URL::to('/')."/agents/".Common::getEncryptedValue(Constants::$QueryStringSiteID.'='.$siteID);
        }else if(!empty($siteID) & !empty($roleID) && $updateProfile==1){
            $model->AgentModel->AgentDetails->RedirectURL = URL::to('/')."/dashboard/".Common::getEncryptedValue(Constants::$QueryStringSiteID.'='.$siteID);
        }else if(!isset($siteID) && !isset($roleID) && $updateProfile==1){
            $model->AgentModel->AgentDetails->RedirectURL = URL::to('/')."/choosesite";
        }
        $model->AgentModel->AgentDetails->Fileuploadsettings = $this->FileUploadSettingsForProfileImage(Constants::$AWSRequestType_Profile,0,'');
        $model->AgentModel->AgentDetails->encryptedSiteID = Common::getEncryptedValue(Constants::$QueryStringSiteID.'='.$siteID);
        $model->AgentModel->AgentDetails->SiteID = $siteID;
        $model->AgentModel->AgentDetails->IsUpdateProfile = $updateProfile;
        $model->AgentModel->AgentDetails->IsForMV = $siteID == Constants::$MercerVineSiteID;

        $searchParams = array();
        $searchValueData = new SearchValueModel();
        $searchValueData->Name = "SiteID";
        $searchValueData->Value = $siteID;
        array_push($searchParams, $searchValueData);
        $siteEntity = $this->GetEntity(new SitesEntity(), $searchParams);
        $model->AgentModel->AgentDetails->BaseURL = $siteEntity->WebsiteBaseURL;
        $model->AgentModel->AgentDetails->AgentSection = $siteEntity->AgentSection;

        if(isset($userID) && $userID == 0){
            $model->AgentModel->AgentDetails->StateID =(($siteID == Constants::$MercerVineSiteID ? Constants::$DefaultMVStateID :($siteID == Constants::$ColoradoSiteID ? Constants::$DefaultColoradoStateID : '')));
        }

        $columnName = array("StateID");
        $stateArray =Common::setSelectedPropertyValueToIntOfList($stateArray, $columnName);


        $model->AgentModel->AgentDetails->StateArray = $stateArray;
        $response->Data = $model;
        return $response;
    }
    public function AddAgentData($AgentModel,$siteID,$loginUserID){
        $response = new ServiceResponse();
        $messages = array(
            'required' => trans('messages.PropertyRequired'),
            'min' => trans('messages.PropertyMin'),
            'max' => trans('messages.PropertyMax')
        );
        $isEditMode = false;
        $userEntity = new UserEntity();
        if(($AgentModel->UserID) > 0) {
            $isEditMode = true;
        }
        $validator = Validator::make((array)$AgentModel,UserEntity::$Add_agent_rules,$messages);
        $validator->setAttributeNames(UserEntity::$niceNameArray);
        if($validator->fails()){
            $response->Message=Common::getValidationMessagesFormat($validator->messages());
            return $response;
        }
        $searchParamsEmail = array();
        $searchValueData=new SearchValueModel();
        $searchValueData->Name="Email";
        $searchValueData->Value=$AgentModel->Email;
        $searchValueData->CheckForExactMatch = Constants::$CheckForExactMatch;
        array_push($searchParamsEmail, $searchValueData);

        if(!isset($AgentModel->CalBRENo)){$AgentModel->CalBRENo ='';}

        $searchParamsCalBreNo = array();
        $searchValueData=new SearchValueModel();
        $searchValueData->Name="CalBRENo";
        $searchValueData->Value= $AgentModel->CalBRENo;
        $searchValueData->CheckForExactMatch = Constants::$CheckForExactMatch;
        array_push($searchParamsCalBreNo, $searchValueData);

        $searchParamsSlug = array();
        $searchValueData=new SearchValueModel();
        $searchValueData->Name="Slug";
        $searchValueData->Value=$AgentModel->Slug;
        $searchValueData->CheckForExactMatch = Constants::$CheckForExactMatch;
        array_push($searchParamsSlug, $searchValueData);

        if ($isEditMode) {
            $customWhere = "UserID NOT IN ($AgentModel->UserID) AND CalBRENo != ''";
        }else{
            $customWhere="CalBRENo != ''";
        }

        if($this->GetEntityCount($userEntity, $searchParamsEmail, "", "", $customWhere)){
            $response->Message ="".trans('messages.EmailAlreadyExist');
        }else if($this->GetEntityCount($userEntity, $searchParamsCalBreNo, "", "", $customWhere)){
            $response->Message ="".trans('messages.CalBreNoAlreadyExist');
        }else if($this->GetEntityCount($userEntity, $searchParamsSlug, "", "", $customWhere)){
            $response->Message ="".trans('messages.AgentSlugAlready');
        }else {
            if ($isEditMode) {
                $userEntity = $this->GetEntityForUpdateByPrimaryKey($userEntity, $AgentModel->UserID);
            } else {
                $userEntity->CreatedByID = $loginUserID;
                $userEntity->CreatedDate = date(Constants::$DefaultDateTimeFormat);
                $userEntity->IsVerified = Constants::$IsVerified_False;
            }
            $userEntity->FirstName = $AgentModel->FirstName;
            $userEntity->LastName = $AgentModel->LastName;
            $userEntity->ModifiedDate = date(Constants::$DefaultDateTimeFormat);
            $userEntity->ModifiedByID = $loginUserID;
            $userEntity->Email = $AgentModel->Email;
            $userEntity->AgentURL = $AgentModel->AgentURL;
            $userEntity->Slug = $AgentModel->Slug;

            /* Gery Scale images upload start */
            if(isset($AgentModel->RealSmallerImagesPath) && !empty($AgentModel->RealSmallerImagesPath) && (empty($AgentModel->ImagePath))){
                $greyscaleImg = Image::make($AgentModel->RealSmallerImagesPath)->greyscale();
                $ext = File::extension($AgentModel->RealSmallerImagesPath);
                $base64 = (string)$greyscaleImg->encode($ext);
                $filePath = explode('/', $AgentModel->RealSmallerImagesPath);
                $fileNm = $filePath[count($filePath) - 1];
                $name = pathinfo($fileNm, PATHINFO_FILENAME);
                $filename = $name .Constants::$AddGeryScale.'.' . $ext;
                $interventionImageUpload = $this->FileUpload(Constants::$AWSRequestType_Profile, $AgentModel->UserID, $siteID, $filename, $base64,true);
                $userEntity->ImagePath = $interventionImageUpload->FilePath;

            }else if(isset($AgentModel->ImagePath) && !empty($AgentModel->ImagePath)){
                $userEntity->ImagePath = $AgentModel->ImagePath;
            }else{
                $userEntity->ImagePath = '';
            }
            if (isset($AgentModel->SmallerImagesPath)) {
                $userEntity->SmallerImagesPath = $AgentModel->SmallerImagesPath;
            }else{
                $userEntity->SmallerImagesPath = "";
            }
            /* Gery Scale images upload end */
            if (isset($AgentModel->Bio)) {
                $userEntity->Bio = $AgentModel->Bio;
            }
            if (isset($AgentModel->Address)) {
                $userEntity->Address = $AgentModel->Address;
            }
            if (isset($AgentModel->City)) {
                $userEntity->City = $AgentModel->City;
            }
            if (!empty($AgentModel->Zip)) {
                $userEntity->Zip = $AgentModel->Zip;
            }
            else {
                $userEntity->Zip = '';
            }
            $userEntity->StateID = $AgentModel->StateID;

            if (!empty($AgentModel->CalBRENo)) {
                $userEntity->CalBRENo = $AgentModel->CalBRENo;
            }else {
                $userEntity->CalBRENo = '';
            }
            $userEntity->JivePhone = $AgentModel->JivePhone;
            $userEntity->MobilePhone = $AgentModel->MobilePhone;
            $userEntity->Fax = $AgentModel->Fax;
            $userEntity->Title = $AgentModel->Title;
            if (isset($AgentModel->FacebookName)) {
                $userEntity->FacebookName = $AgentModel->FacebookName;
            }
            if (isset($AgentModel->LinkedInName)) {
                $userEntity->LinkedInName = $AgentModel->LinkedInName;
            }
            if (isset($AgentModel->TwitterName)) {
                $userEntity->TwitterName = $AgentModel->TwitterName;
            }
            if (isset($AgentModel->InstagramName)) {
                $userEntity->InstagramName = $AgentModel->InstagramName;
            }
            if (isset($AgentModel->PinterestName)) {
                $userEntity->PinterestName = $AgentModel->PinterestName;
            }
            if (isset($AgentModel->YoutubeName)) {
                $userEntity->YoutubeName = $AgentModel->YoutubeName;
            }
            if (isset($AgentModel->SnapchatName)) {
                $userEntity->SnapchatName = $AgentModel->SnapchatName;
            }
            if (isset($AgentModel->WebsiteURL)) {
                $userEntity->WebsiteURL = $AgentModel->WebsiteURL;
            }
            if(isset($AgentModel->ConfirmPassword) AND ($AgentModel->ConfirmPassword != "" )) {
                $userEntity->Password = md5($AgentModel->ConfirmPassword);
            }


            if(isset($AgentModel->IsAgent)){
                $userEntity->IsAgent = $AgentModel->IsAgent;
            }else{
                $userEntity->IsAgent ='';
            }

            if(isset($AgentModel->IsFoundingMember)){
                $userEntity->IsFoundingMember = $AgentModel->IsFoundingMember;
            }else{
                $userEntity->IsFoundingMember ='';
            }

            if(isset($AgentModel->IsTeamMember)){
                $userEntity->IsTeamMember = $AgentModel->IsTeamMember;
            }else{
                $userEntity->IsTeamMember ='';
            }

            $saveEntity = $this->SaveEntity($userEntity);
            if ($saveEntity) {
                if ($isEditMode && $AgentModel->IsUpdateProfile==0) {
                    if(isset($userEntity->UserID) && !empty($userEntity->UserID) && $userEntity->UserID > 0 ){
                        CacheHelper::CacheManage($siteID,Constants::$cacheAgentID,Constants::$cacheActionUpdate,$AgentModel->Slug);
                        if($AgentModel->Slug!=$AgentModel->OldSlug) {
                            CacheHelper::CacheManage($siteID, Constants::$cacheAgentID, Constants::$cacheActionUpdate, $AgentModel->OldSlug);
                        }
                        if($siteID==Constants::$MercerVineSiteID) {
                            $propertyList=$this->CallRawForSingleTable('getdisableagentproperty', [$userEntity->UserID]);
                            foreach($propertyList as $property){
                                CacheHelper::CacheManage($siteID,Constants::$cachePropertyID,Constants::$cacheActionUpdate,$property->ListingID);
                            }
                        }
                    }
                    
                    if(!$saveEntity->IsVerified){
                        $securityDataProvider = new SecurityDataProvider();
                        $securityDataProvider->SendVerificationEmail($saveEntity->UserID,$siteID,$loginUserID);    
                    }
                    

                    $response->IsSuccess = true;
                    $response->Message = trans('messages.AgentUpdateSuccess');
                    $response->RedirectUrl = URL::to('/') . "/agents/" . Common::getEncryptedValue(Constants::$QueryStringSiteID . '=' . $siteID);
                } elseif(!$isEditMode){
                    $userRoleEntity = new UserRolesEntity();
                    $userRoleEntity->UserID=$saveEntity->UserID;
                    $userRoleEntity->RoleID=Constants::$RoleAgent;
                    $userRoleEntity->SiteID= $siteID;
                    $this->SaveEntity($userRoleEntity);
                    CacheHelper::CacheManage($siteID,Constants::$cacheAgentID,Constants::$cacheActionInsert,'');

                    $securityDataProvider = new SecurityDataProvider();
                    $securityDataProvider->SendVerificationEmail($saveEntity->UserID,$siteID,$loginUserID);

                    $response->IsSuccess = true;
                    $response->Message = trans('messages.AgentAddedSuccess');
                    $response->RedirectUrl = URL::to('/') . "/agents/" . Common::getEncryptedValue(Constants::$QueryStringSiteID . '=' . $siteID);
                }else{
                    $response->IsSuccess = true;
                    $response->Data = $AgentModel->IsUpdateProfile;
                    $response->Message = trans('messages.ProfileUpdated');
                }

            } else {
                $response->Message = trans('messages.ErrorOccured');
            }
        }
        return $response;
    }
    public function AwsAgentFileDownload($data){
        $response = new ServiceResponse();
        $response->Data = $this->Awsdownloadfile($data->ImagePath,'',true);
        $response->IsSuccess=true;
        return $response;
    }

    public function DeleteAgentImageAmazon($data){
        $response = new ServiceResponse();
        $Model=new stdClass();
        if($data->UserID == 0){
            if(isset($data->ImagePath) && !empty($data->ImagePath)){
                $this->Awsdeletefile($data->ImagePath,'',true);
            }
            if(isset($data->GeryScaleImageURL) && !empty($data->GeryScaleImageURL)){
                $this->Awsdeletefile($data->GeryScaleImageURL,'',true);
            }
        }
        $response->IsSuccess=true;
        return $response;
    }
    public function postFeaturedChange($data,$siteID){
        $response = new ServiceResponse();
        $propertyFeaturedChange = $this->CallRawForMultipleTable('propertyfeaturedchange', [$data->IsFeatured,$data->ListingID,$siteID],false,['IsFeatured']);
        if ($propertyFeaturedChange[0][0]->ResultStatus) {
            CacheHelper::CacheManage($siteID,Constants::$cacheHomeID,Constants::$cacheActionInsert,'');
            $response->IsSuccess = true;
            if($data->IsFeatured == 1){
                $response->Message = trans('messages.FeatureUpdated');
            }else{
                $response->Message = trans('messages.UnFeatureUpdated');
            }
        } else {
            $response->Message = trans('messages.ErrorOccurred');
        }
        return $response;
    }
    public function postCheckUniqueLicense($data){
        $response = new ServiceResponse();
        $propertyFeaturedChange = $this->CallRawForMultipleTable('checkuniquelicense', [$data->CalBRENo,$data->UserID]);
        if ($propertyFeaturedChange[0][0]->ResultStatus) {
            $response->IsSuccess = true;
        }
        return $response;
    }
    public function postCheckUniqueEmail($data){
        $response = new ServiceResponse();
        $propertyFeaturedChange = $this->CallRawForMultipleTable('checkuniqueemail', [$data->Email,$data->UserID]);
        if ($propertyFeaturedChange[0][0]->ResultStatus) {
            $response->IsSuccess = true;
        }
        return $response;
    }
    public function UpdateSortOrderStylisticInfluences($OldOrder, $newOrder, $UserID, $SiteID){
        $response = new ServiceResponse();
        $results = $this->CallRawForMultipleTable('sortorderstylisticinfluenceslist',[$OldOrder, $newOrder, $UserID, $SiteID]);
        if($results[0][0]->ResultStatus){
            $response->IsSuccess=true;
            $response->Message= trans('messages.StylisticInfluencesOrder');
        }
        return $response;
    }
    public function deleteStylisticInfluences($StylisticInfluencesID,$UserID,$siteID){
        $response = new ServiceResponse();
        $results = $this->CallRawForMultipleTable('deletestylisticinfluences',[$StylisticInfluencesID,$UserID, $siteID]);
        if($results[0][0]->ResultStatus) {
            if(isset($results[1][0])){
                $response->Data = $results[1];
            }
            $response->IsSuccess=true;
            $response->Message= trans('messages.StylisticInfluencesDeleted');
        } else {
            $response->Message= trans('messages.ErrorOccured');
        }
        return $response;
    }

    public function postSaveStylisticInfluences($Model,$siteID){
        $response = new ServiceResponse();
        $messages = array(
            'required' => trans('messages.PropertyRequired'),
            'min' => trans('messages.PropertyMin'),
            'max' => trans('messages.PropertyMax')
        );
        $validator = Validator::make((array)$Model->StylisticInfluences,StylisticInfluencesEntity::$Add_Edit_rules,$messages);
        $validator->setAttributeNames(StylisticInfluencesEntity::$niceNameArray);
        if($validator->fails()){
            $response->Message=Common::getValidationMessagesFormat($validator->messages());
            return $response;
        }
        $stylisticInfluencesID ='';
        if(isset($Model->StylisticInfluences['StylisticInfluencesID'])){ $stylisticInfluencesID = $Model->StylisticInfluences['StylisticInfluencesID'];}
        $results = $this->CallRawForMultipleTable('savestylisticinfluences', [$stylisticInfluencesID, $Model->StylisticInfluences['StylisticInfluences'], $siteID, $Model->UserID]);
        if ($results[0][0]->ResultStatus) {
            if (isset($Model->StylisticInfluences['StylisticInfluencesID']) AND $Model->StylisticInfluences['StylisticInfluencesID'] > 0) {
                $response->IsSuccess = true;

                $response->Message = trans('messages.StylisticInfluencesUpdateSuccess');
            } else {
                $response->IsSuccess = true;
                $response->Message = trans('messages.StylisticInfluencesAddedSuccess');
            }
            $response->Data = $results[1];
        } else {
            $response->Message = trans('messages.ErrorOccured');
        }
        return $response;
    }
    /*Dev_AD Region End*/

    /*Start Dev_VA*/
    public function saveTestimonialDetails($testModel,$loggedInUserID,$siteID){
        $response = new ServiceResponse();
        $messages = array(
            'required' => trans('messages.PropertyRequired'),
            'min' => trans('messages.PropertyMin'),
            'max' => trans('messages.PropertyMax')
        );
        $TestimonialID = $testModel->TestimonialID;
        $isEditMode = false;
        if($TestimonialID>0){
            $isEditMode = true;
        }
        $validator = Validator::make((array) $isEditMode ? TestimonialEntity::$Edit_rules : TestimonialEntity::$Add_rules,$messages);
        $validator->setAttributeNames(TestimonialEntity::$niceNameArray);
        if ($validator->fails()) {
            $response->Message = Common::getValidationMessagesFormat($validator->messages());
            return $response;
        }
        $testModel->Attribution=isset($testModel->Attribution) ? $testModel->Attribution : "";
        $saveTestimonialResults= $this->CallRawForMultipleTable('savetestimonial', [$testModel->TestimonialID,$testModel->Testimonial, $testModel->Attribution, $testModel->IsVisible, $testModel->AgentID, $testModel->SiteID, $loggedInUserID]);
        if ($saveTestimonialResults[0][0]->ResultStatus) {
            if($isEditMode){
                if(isset($testModel->AgentID) && !empty($testModel->AgentID) && $testModel->AgentID > 0 ){
                    CacheHelper::CacheManage($siteID,Constants::$cacheAgentID,Constants::$cacheActionUpdate,$testModel->AgentID);
                }
            }else{
                if(isset($testModel->AgentID) && !empty($testModel->AgentID) && $testModel->AgentID > 0 ){
                    CacheHelper::CacheManage($siteID,Constants::$cacheAgentID,Constants::$cacheActionInsert,$testModel->AgentID);
                }
            }
            $response->IsSuccess = true;
            /*Here used columnName and setSelectedPropertyValueToIntOfList() for set true and false value in integer using intVal()*/
            $columnName = array("IsVisible");
            $response->Data =  Common::setSelectedPropertyValueToIntOfList($saveTestimonialResults[1],$columnName);
            $response->Message = $isEditMode ? trans('messages.UpdateTestimonial') : trans('messages.AddTestimonial');
            $response->RedirectUrl = URL::to('/')."/addtestimonial/".Common::getEncryptedValue(Constants::$QueryStringUserID.'='.$testModel->AgentID.'&'.Constants::$QueryStringSiteID.'='.$siteID);
        } else {
            $response->Message = trans('messages.ErrorOccurred');
        }
        return $response;
    }
    public function postDeleteTestimonialData($testimonialData,$siteID){
        $response = new ServiceResponse();
        $deleteTestimonialResults = $this->CallRawForSingleTable('deletetestimonial',[$testimonialData->TestimonialID,$siteID,$testimonialData->AgentID]);
        /*Here used columnName and setSelectedPropertyValueToIntOfList() for set true and false value in integer using intVal()*/
        if(isset($testimonialData->AgentID) && !empty($testimonialData->AgentID) && $testimonialData->AgentID > 0 ){
            CacheHelper::CacheManage($siteID,Constants::$cacheAgentID,Constants::$cacheActionDelete,$testimonialData->AgentID);
        }
        $columnName = array("IsVisible");
        $response->Data = Common::setSelectedPropertyValueToIntOfList($deleteTestimonialResults,$columnName);
        $response->IsSuccess = true;
        $response->RedirectUrl = URL::to('/')."/addtestimonial/".Common::getEncryptedValue(Constants::$QueryStringUserID.'='.$testimonialData->AgentID.'&'.Constants::$QueryStringSiteID.'='.$siteID);
        $response->Message = trans('messages.DeleteTestimonial');
        return $response;
}
    public function postSortOrderTestimonialData($oldOrder,$newOrder,$AgentID,$siteID){
        $response = new ServiceResponse();
        $this->CallRawForMultipleTable('sortordertestimoniallist',[$oldOrder,$newOrder,$siteID,$AgentID]);
        $response->IsSuccess=true;
        $response->Message= trans('messages.TestimonialOrder');
        return $response;
    }
    /*Stop Dev_VA*/
}