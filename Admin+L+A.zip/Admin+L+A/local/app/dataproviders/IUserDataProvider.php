<?php 
namespace dataproviders;

Interface IUserDataProvider{

    /*Start Region Dev_Vishal*/
    public function getUserInfoList($userData,$loggedInUserID);
    public function getSearchModelForUserList($SiteID);
    public function postDisableUser($userData,$loggedInUserID,$siteID);
    public function postEnableUser($userData,$loggedInUserID,$siteID);
    /*Stop Region Dev_Vishal*/

    /*RB Start*/
    public function getUserDetail($userID,$siteID,$roleID,$updateProfile,$userSiteList);
    public function SaveUser($userModel,$loginUserID,$siteID);
    public function DeleteProfileImageAmazon($data,$SiteID);
    /*RB End*/


    /*AD Start*/

    /*AD  End*/


    /*DN Start*/

    /*DN  End*/
}
