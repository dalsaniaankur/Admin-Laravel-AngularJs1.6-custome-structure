<?php 
namespace dataproviders;


Interface IHomeDataProvider{

    /*AD Start*/
    public function getHomeView($siteID,$loginUserID);
    public function postDeleteSliderImagesFile($fileRemoveData,$siteID);
    public function postSaveHomePage($homeModel,$loginUserID,$siteID);
    public function AwsDownloadFileImages($data,$siteID);
    public function DeleteImageAmazon($data,$siteID);
    public function postDeleteVideoAmazon($data,$siteID);
    public function postHomeChangeSection($firstSectionType, $siteID);
    public function deleteStory($HomePageStoryID);
    public function UpdateSortOrderStory($OldOrder,$newOrder);
    public function postSaveStory($Model,$siteID);
    public function postDeleteStoryImagesFile($fileRemoveData,$siteID);
    public function postGetStoryImagesFile($homePageStoryID);
    public function getRD_HomeView($siteID,$loginUserID);
    public function postSaveRDHomePage($homeModel,$siteID);
    public function UpdateSortOrderSlider($OldOrder,$newOrder);
    public function deleteSlider($HomePageSliderID,$siteID);
    public function postSaveSlider($SliderModel,$siteID);
    public function getCO_HomeView($siteID,$loginUserID);
    public function postSaveCOHomePage($homeModel,$siteID);
    /*AD  End*/

}
