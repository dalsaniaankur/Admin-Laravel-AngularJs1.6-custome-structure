<?php
namespace dataproviders;
use Illuminate\Support\Facades\Validator;
use \ViewModels\ServiceResponse;
use \Infrastructure\Constants;
use \Infrastructure\Common;
use \stdClass;
use \Crypt;
use \Mail;
use \DevelopmentEntity;
use StateEntity;
use DevelopmentImagesEntity;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Config;
use DevelopmentFeaturesEntity;
use Infrastructure\CacheHelper;
class DevelopmentDataProvider extends BaseDataProvider implements IDevelopmentDataProvider {
	
    /*Start Dev_VA*/
    public function getDevelopmentData($developmentID,$siteID,$loginUserID){
        $response = new ServiceResponse();
        $model = new StdClass();
        $devModel = new StdClass();
        if($developmentID>0) {
            $searchParams = Array();
            $searchValueData = Common::SetSearchArray('DevelopmentID',$developmentID);
            array_push($searchParams, $searchValueData);
            $devDetails = $this->GetEntity(new DevelopmentEntity(), $searchParams);
            $devDetails->UploadedFileArray = $this->GetEntityList(new DevelopmentImagesEntity(),$searchParams);
            $devDetails->ListingModel = new stdClass();
            $devDetails->ListingModel->UploadedFileOfDevelopmentFeatures = $this->GetEntityList(new DevelopmentFeaturesEntity(),$searchParams);
            foreach ($devDetails->UploadedFileArray as $fileArray) {
                $fileArray->IsSavedInDB=1;
                if($fileArray->IsDefaultImage==1){
                    $devDetails->IsDefaultImage ="1"; // For check if user remove "default selected" image and go to any other page and come back again development page and save then set "default image required"
                    }else{
                    $devDetails->IsDefaultImage='';
                }
            }
            foreach ($devDetails->ListingModel->UploadedFileOfDevelopmentFeatures as $fileArray) {
                $fileArray->IsSavedInDB=1;
            }

        }else{
            $developmentEntity = new DevelopmentEntity();
            $developmentEntity->DevelopmentID = Constants::$Value_False;
            $developmentEntity->SiteID = $siteID;
            $devDetails = $developmentEntity;
            $devDetails->RealTopImagePath ='';
        }

        $stateList = $this->GetEntityList(new StateEntity(),'');
        $devDetails->StateListArray = $stateList;

        $devModel->DevDetails = $devDetails;
        $devModel->DevDetails->FileUploadSettings = $this->FileUploadSettings(Constants::$AWSRequestType_Development,$siteID,$loginUserID);
        $devModel->DevDetails->UploadFilesArray ='';

        if(is_null( $devModel->DevDetails->StateID) ||  $devModel->DevDetails->StateID == '')
            $devModel->DevDetails->StateID =(($siteID == Constants::$MercerVineSiteID?Constants::$DefaultMVStateID:($siteID == Constants::$ColoradoSiteID?Constants::$DefaultColoradoStateID:'')));


        /* For Delete Development check is used in menu or not Start*/
        if($developmentID>0){
            $searchMenuParams = Array();
            $searchValueData = Common::SetSearchArray('DevelopmentID',$developmentID,Constants::$ExactMatch);
            array_push($searchMenuParams, $searchValueData);
            $searchValueData1 = Common::SetSearchArray('SiteID',$siteID,Constants::$ExactMatch);
            array_push($searchMenuParams, $searchValueData1);
            $devModel->DevDetails->IsUsedInMenu = $this->GetEntityCount(new \MenuItemsEntity(),$searchMenuParams);
        }
        /* For Delete Development */

        /* For Development Properties Listing Page Start*/
        $searchModel = new stdClass();
        $searchModel->SiteID = $siteID;
        $searchModel->MLSNo ="";
        $searchModel->DevelopmentID =$developmentID;
        $devModel->DevDetails->frontSearchModel = $searchModel;
        $devModel->DevDetails->backSearchModel = $searchModel;
        /* For Development Properties Listing Page End */


        $model->DevelopmentModel = $devModel;
        $response->Data = $model;
        return $response;
    }
    public function SaveDevelopment($devModel,$loggedInUserID,$siteID){

        $response = new ServiceResponse();
        $messages = array(
            'required' => trans('messages.PropertyRequired'),
            'min' => trans('messages.PropertyMin'),
            'max' => trans('messages.PropertyMax'),
        );
        $developmentID = $devModel->DevelopmentID;
        $validator = Validator::make((array)$devModel, $developmentID > 0 ? DevelopmentEntity::$Edit_rules : DevelopmentEntity::$Add_rules, $messages);
        $validator->setAttributeNames(DevelopmentEntity::$niceNameArray);
        if ($validator->fails()) {
            $response->Message = Common::getValidationMessagesFormat($validator->messages());
            return $response;
        }
        $isEditMode = false;
        if($devModel->DevelopmentID>0){
            $isEditMode = true;
        }

        $developmentEntity = new DevelopmentEntity();
        if($isEditMode){
            $searchParams = Array();
            $searchValueData = Common::SetSearchArray('DevelopmentID',$developmentID);
            array_push($searchParams, $searchValueData);

            $developmentEntity = $this->GetEntityForUpdateByPrimaryKey($developmentEntity,$devModel->DevelopmentID);
        }

        $searchParamsUnique = Array();
        $searchValueData = Common::SetSearchArray('Name',trim($devModel->Name),Constants::$ExactMatch);
        array_push($searchParamsUnique,$searchValueData);
        $searchValueData1 = Common::SetSearchArray('SiteID',$siteID,Constants::$ExactMatch);
        array_push($searchParamsUnique, $searchValueData1);

        if($isEditMode){
            $customWhere = "DevelopmentID != $devModel->DevelopmentID";
        }else{
            $customWhere = "";
        }
        $checkUniqueDevelopmentName = $this->GetEntityCount($developmentEntity, $searchParamsUnique,"","",$customWhere);
        if($checkUniqueDevelopmentName == 0) {
            $developmentEntity->SiteID = $siteID;
            $developmentEntity->Name = trim($devModel->Name);
            if(isset($devModel->ShortDescription))
                $developmentEntity->ShortDescription = $devModel->ShortDescription;
            if(isset($devModel->Address))
                $developmentEntity->Address = $devModel->Address;
            if(isset($devModel->City))
                $developmentEntity->City = $devModel->City;
            if(!empty($devModel->StateID))
                $developmentEntity->StateID = $devModel->StateID;
            if(empty($devModel->Zip))
                $developmentEntity->Zip = null;
            else
                $developmentEntity->Zip = $devModel->Zip;

            if(isset($devModel->Latitude))
                $developmentEntity->Latitude = $devModel->Latitude;
            if(isset($devModel->Longitude))
                $developmentEntity->Longitude = $devModel->Longitude;
            $developmentEntity->Description = $devModel->Description;

            if($isEditMode){
                if(isset($devModel->CaseStudies))
                    $developmentEntity->CaseStudies = Common::CkeditorContent($devModel->CaseStudies);
                if(isset($devModel->ServiceResults))
                    $developmentEntity->ServiceResults = Common::CkeditorContent($devModel->ServiceResults);
            }

            if(!empty($devModel->Address) && (empty($devModel->Latitude) ||($devModel->Longitude))){

                if(!empty($devModel->StateID)){
                    $stateID = $devModel->StateID;
                    $stateDetails = array_values(array_filter($devModel->StateListArray,function($data) use ($stateID){
                        return	$data['StateID'] == $stateID;
                    }));
                    $sateName = $stateDetails[0]['StateName'];
                }
                $address = str_replace(' ', '',$devModel->Address);
                if(isset($sateName)){
                    $sateName = str_replace(' ','',$sateName);
                }else{
                    $sateName='';
                }
                if(!empty($devModel->City)){
                    $city = str_replace(' ','',$devModel->City);
                }else{
                    $city='';
                }
                if(!empty($devModel->Zip)){
                    $zip = str_replace(' ','',$devModel->Zip);
                }else{
                    $zip='';
                }

                $data = DB::table('sites')->where('SiteID','=',$siteID)->select('GeoAPIKey')->get();
                $geoAPIKey = $data[0]->GeoAPIKey;
                $latLong = Common::getLatLong($address.','.$city.','.$sateName.'-'.$zip, $geoAPIKey);

                if(isset($latLong->Latitude))
                    $developmentEntity->Latitude = $latLong->Latitude;
                if(isset($latLong->Longitude))
                    $developmentEntity->Longitude = $latLong->Longitude;
            }

            $date = date(Constants::$DefaultDateTimeFormat);

            if(!$isEditMode){
                $developmentEntity->CreatedByID = $loggedInUserID;
                $developmentEntity->CreatedDate = $date;
            }
            if(!isset($devModel->ListingModel['ImagesModelOfDevelopmentFeatures']) OR empty($devModel->ListingModel['ImagesModelOfDevelopmentFeatures']))
            {
              $uploadImagesOfDevelopmentFeatures =  $devModel->DevelopmentFeatures;
            }else{
              $uploadImagesOfDevelopmentFeatures =  $devModel->ListingModel['ImagesModelOfDevelopmentFeatures'];
            }
            $developmentEntity->ModifiedByID = $loggedInUserID;
            $developmentEntity->ModifiedDate = $date;


            /* Full Address start */
            $StateISO ='';
            if(isset($developmentEntity->StateID) && !empty($developmentEntity->StateID) && $developmentEntity->StateID != '') {
                $SearchParam = array();
                $SearchValue = Common::SetSearchArray('StateID', $developmentEntity->StateID);
                array_push($SearchParam, $SearchValue);
                $stateResult = $this->GetEntity(new \StateEntity(), $SearchParam);
                if(count($stateResult)>0) {
                    $StateISO = $stateResult->StateISO;
                }
            }
            $developmentEntity->FullAddressSlug = Common::GetFullAddressSlug($developmentEntity->Address."-".$developmentEntity->City.'-'.$StateISO."-".$developmentEntity->Zip);
            /* Full Address end */

            $results = $this->SaveEntity($developmentEntity);
            if(!$isEditMode){
                $devModel->DevelopmentID = $results->DevelopmentID;
            }

            /* Featured image upload start */
            $dateTime = date(Constants::$DefaultDateTimeFormat);
            $data1 = array();
            if (is_array($uploadImagesOfDevelopmentFeatures)) {
                foreach ($uploadImagesOfDevelopmentFeatures as $key => $imageData) {
                    if (!is_null($imageData['FileName'])) {
                        $processData1 = array(
                            'DevelopmentID' => $devModel->DevelopmentID,
                            'SiteID' => $siteID,
                            'FileName' => $imageData['FileName'],
                            'FilePath' => $imageData['FilePath'],
                            'FileSize' => $imageData['FileSize'],
                            'Title' => $imageData['Title'],
                            'Description' => $imageData['Description'],
                            'CreatedDate' => $dateTime,
                            'ModifiedDate' => $dateTime,
                            'CreatedByID' => $loggedInUserID,
                            'ModifiedByID' => $loggedInUserID,
                        );

                        if ($imageData['IsSavedInDB'] != 1){
                            array_push($data1, $processData1);
                        }
                        else{
                            $this->CustomUpdateEntity(new DevelopmentFeaturesEntity(), 'ID', $imageData['ID'], $processData1);
                        }
                    }
                }
                if (count($data1))
                    $this->MultipleInsert(new DevelopmentFeaturesEntity(), $data1);
            }
            /* Featured image upload End */

            /* For Image Upload Section start */
            if($results && !empty($devModel->UploadFilesArray)){

                // Deleted deleted images from database during edit page.
                if($isEditMode){
                    $filteredImageFile = array_values(array_filter($devModel->UploadFilesArray,function($site){
                        return	isset($site['ImageID']);
                    }));
                    $imageIDCsv = implode(',',array_map(create_function('$o', 'return $o["ImageID"];'), $filteredImageFile));
                    if(isset($imageIDCsv)){
                        $this->CallRawForMultipleTable('deletedevelopmentimages',[$devModel->DevelopmentID,$imageIDCsv]);
                    }
                }

                // instead of array_filter keep condition while processing data in foreach.
                // Filter array  for during add page upload all the images. and during edit time only newly added images save in DB.
                if($isEditMode){
                    $isSavedInDB = Constants::$Value_False;
                    $uploadFileArray = array_values(array_filter($devModel->UploadFilesArray,function($site) use ($isSavedInDB){
                        return	$site['IsSavedInDB'] == $isSavedInDB;
                    }));
                }else{
                    $uploadFileArray = $devModel->UploadFilesArray;
                }

               /* Sort Image Array */
                if(is_array($devModel->ImagesNameModel)) {
                    $keys = array_flip($devModel->ImagesNameModel);
                }
                else {
                    $keys=$devModel->ImagesNameModel;
                }
                usort($uploadFileArray, function($a, $b) use($keys)
                {
                    return $keys[@array_pop(explode("/",$a['FilePath']))] - $keys[@array_pop(explode("/",$b['FilePath']))];
                });


                foreach ($uploadFileArray as $fileArray) {
                    $developmentImageEntity = new DevelopmentImagesEntity();
                    $developmentImageEntity->DevelopmentID = $results->DevelopmentID;
                    $developmentImageEntity->SiteID = $devModel->SiteID;
                    $developmentImageEntity->FileName = $fileArray['FileName'];
                    if(isset($devModel->IsDefaultImage)){  // set default image to 1 if default image and upload file path are same.
                        if($devModel->IsDefaultImage == $fileArray['FilePath']){
                            $developmentImageEntity->IsDefaultImage= Constants::$Value_True;
                        }
                    }
                    $developmentImageEntity->FilePath = $fileArray['FilePath'];
                    $developmentImageEntity->FileSize = $fileArray['FileSize'];
                    if($isEditMode){
                        $developmentImageEntity->ModifiedByID = $loggedInUserID;
                        $developmentImageEntity->ModifiedDate = $date;
                    }
                    $developmentImageEntity->CreatedByID = $loggedInUserID;
                    $developmentImageEntity->CreatedDate = $date;
                    $developmentImageEntity->ModifiedByID = $loggedInUserID;
                    $developmentImageEntity->ModifiedDate = $date;

                    $this->SaveEntity($developmentImageEntity);
                }

                if($isEditMode){  // For Delete old default selected image and set new default selected image during edit page.
                    if(isset($devModel->IsDefaultImage)){
                         $this->CallRawForMultipleTable('updatedevelopmentdefaultimage',[$devModel->DevelopmentID,$devModel->IsDefaultImage]);
                    }
                }

            }
            /* For Image Upload Section End */

            if(empty($results)){
                $response->Message = trans('messages.ErrorOccured');
            }else{
                $response->IsSuccess = true;
                $response->Data = $results;
                if($isEditMode){
                    if(isset($developmentEntity->DevelopmentID) && !empty($developmentEntity->DevelopmentID) && $developmentEntity->DevelopmentID > 0 ){
                        CacheHelper::CacheManage($siteID,Constants::$cacheDevelopmentID,Constants::$cacheActionUpdate,$developmentEntity->DevelopmentID);
                    }
                    $response->Message = trans('messages.DevelopmentUpdate');
                }else{
                    if(isset($developmentEntity->DevelopmentID) && !empty($developmentEntity->DevelopmentID) && $developmentEntity->DevelopmentID > 0 ){
                        CacheHelper::CacheManage($siteID,Constants::$cacheDevelopmentID,Constants::$cacheActionInsert,$developmentEntity->DevelopmentID);
                    }
                    $response->Message = trans('messages.DevelopmentInsert');
                }
            }
        }else{
            $response->Message = trans('messages.DevelopmentName');
        }
        return $response;
    }
    /*End Dev_VA*/

    /* Dev_RB Region Start */
    public function getSearchModelForDevelopmentList($SiteID){
        $response = new ServiceResponse();
        $model = new stdClass();
        $searchModel = new stdClass();
        $searchModel->Name = "";

        $model->frontSearchModel = $searchModel;
        $model->backSearchModel = $searchModel;
        $response->Data=$model;
        return $response;
    }

    public function getDevelopmentInfoList($developmentData,$loggedInUserID,$siteID){
        $response = new ServiceResponse();
        if(empty($developmentData->SortIndex)){
            $developmentData->SortIndex ='Name';
        }
        if(empty($developmentData->SortDirection)){
            $developmentData->SortDirection = Constants::$SortIndexASC;
        }
        $sortIndex = $developmentData->SortIndex;
        $sortDirection = $developmentData->SortDirection;
        $pageIndex = $developmentData->PageIndex;
        $pageSizeCount = $developmentData->PageSize;

        $searchName = '';
        if(isset($developmentData->SearchParams)){
            if(isset($developmentData->SearchParams['Name'])){
                $searchName = $developmentData->SearchParams['Name'];
            }
        }
        $AWSUrl = Common::getAWSUrl($siteID);
        $AWSBucketName = Common::getAWSBucketName($siteID); //Config::get('aws.AWSBucketName');
        $developmentList = $this->GetPageRecordsUsingSP('developmentlist',$pageIndex,$pageSizeCount,[$searchName,$pageIndex,$pageSizeCount,$sortIndex,$sortDirection,$siteID,$loggedInUserID,$AWSUrl,$AWSBucketName]);
        if(is_null($developmentList)){
            $response->Message = trans('messages.NoRecordFound');
        }else{
            $response->IsSuccess = true;
            $response->Data = $developmentList;
        }
        return $response;
    }

    public function RemoveImage($fileRemoveData,$siteID){
        $response = new ServiceResponse();
        $deleteModel = new StdClass();
        if (isset($fileRemoveData)) {
            $data = $this->Awsdeletefile($fileRemoveData->filePath,$siteID);  // Remove Image from AWS
            if ($data && isset($fileRemoveData->ImageID)) {  // Delete images from database if ImageID found during edit page.
                $query = "delete from developmentimages where ImageID=$fileRemoveData->ImageID";
                $this->RunQueryStatement($query, Constants::$QueryType_Delete);
            }
            if(isset($fileRemoveData->filePath) && isset($fileRemoveData->IsDefaultImage)){ // set variable IsDeleteDefaultImages to 1 if use delete the default selected image.
                if($fileRemoveData->IsDefaultImage == $fileRemoveData->filePath){
                    $deleteModel->IsDeleteDefaultImages = Constants::$Value_True;
                }
            }
            $response->IsSuccess = true;
            $deleteModel->Key = $fileRemoveData->fileToRemoveKey;  //send the removed array KEY.
            $response->Data = $deleteModel;
            $response->Message = trans('messages.ImageRemovedSuccess');
        } else {
            $response->Message = trans('messages.ErrorOccured');
        }
        return $response;
    }

    public function getDevelopmentVideoList($developmentData,$siteID){
        $response = new ServiceResponse();
        if(empty($developmentData->SortIndex)){
            $developmentData->SortIndex = Constants::$sortIndexTitle;
        }
        if(empty($developmentData->SortDirection)){
            $developmentData->SortDirection = Constants::$SortIndexASC;
        }
        $sortIndex = $developmentData->SortIndex;
        $sortDirection = $developmentData->SortDirection;
        $pageIndex = $developmentData->PageIndex;
        $pageSizeCount = $developmentData->PageSize;

        $developmentID = '';
        if(isset($developmentData->SearchParams)){
            if(isset($developmentData->SearchParams)){
                $developmentID = $developmentData->SearchParams;
            }
        }
        $AWSUrl = Common::getAWSUrl($siteID);
        $AWSBucketName = Common::getAWSBucketName($siteID);
        $developmentVideoList = $this->GetPageRecordsUsingSP('developmentvideolist',$pageIndex,$pageSizeCount,[$developmentID,$pageIndex,$pageSizeCount,$sortIndex,$sortDirection,$siteID,$AWSUrl,$AWSBucketName]);
        if(is_null($developmentVideoList)){
            $response->Message = trans('messages.NoRecordFound');
        }else{
            $response->IsSuccess = true;
            $response->Data = $developmentVideoList;
        }
        return $response;
    }

    public function RemoveDevelopmentVideo($videoID,$siteID){
        $response = new ServiceResponse();
        $videoEntity = $this->GetEntityForUpdateByPrimaryKey(new \VideoEntity(),$videoID);
        $developmentID = $videoEntity->DevelopmentID;
        $videoEntity->DevelopmentID = null;
        $data = $this->SaveEntity($videoEntity);
        if($data) {
            CacheHelper::CacheManage($siteID,Constants::$cacheDevelopmentID,Constants::$cacheActionUpdate,$developmentID);
            $response->IsSuccess=true;
            $response->Message= trans('messages.DevelopmentVideoDelete');
        } else {
            $response->Message= trans('messages.ErrorOccured');
        }
        return $response;

    }
    public function DeleteDevelopmentListing($listingID,$siteID){
        $response = new ServiceResponse();
        $listingEntity = $this->GetEntityForUpdateByPrimaryKey(new \PropertyListingsEntity(),$listingID);
        $developmentID = $listingEntity->DevelopmentID;
        $listingEntity->DevelopmentID = null;
        $data = $this->SaveEntity($listingEntity);
        if($data) {
            CacheHelper::CacheManage($siteID,Constants::$cacheDevelopmentID,Constants::$cacheActionUpdate,$developmentID);
            $response->IsSuccess=true;
            $response->Message= trans('messages.DevelopmentListingDelete');
        } else {
            $response->Message= trans('messages.ErrorOccured');
        }
        return $response;

    }

    public function geDevelopmentListing($userData,$siteID){
        $response = new ServiceResponse();
        if(empty($userData->SortIndex)){
            $userData->SortIndex = Constants::$SortIndex;
        }
        if(empty($userData->SortDirection)){
            $userData->SortDirection = Constants::$SortIndexASC;
        }
        $sortIndex = $userData->SortIndex;
        $sortDirection = $userData->SortDirection;
        $pageIndex = $userData->PageIndex;
        $pageSizeCount = $userData->PageSize;

        $searchMLSNo = -1;
        $searchDevelopmentID = -1;

        if(isset($userData->SearchParams)){

            if(!empty($userData->SearchParams['MLSNo'])){
                $searchMLSNo = $userData->SearchParams['MLSNo'];
            }
            if(!empty($userData->SearchParams['DevelopmentID'])){
                $searchDevelopmentID = $userData->SearchParams['DevelopmentID'];
            }
        }
        $propertyList = $this->GetPageRecordsUsingSP('developmentlisting',$pageIndex,$pageSizeCount, [$searchMLSNo,$pageIndex,$pageSizeCount,$sortIndex,$sortDirection,$siteID,$searchDevelopmentID]);

        if(is_null($propertyList)){
            $response->Message = trans('messages.NoRecordFound');
        }else{
            $response->IsSuccess = true;
            $response->Data = $propertyList;
        }
        return $response;
    }

    public function DeleteDevelopment($developmentID,$siteID){
        $response = new ServiceResponse();
        $deleteDevelopmentResults = $this->CallRawForMultipleTable('deletedevelopment',[$developmentID,$siteID]);
        if($deleteDevelopmentResults) {
            if(isset($developmentID) && !empty($developmentID) && $developmentID > 0 ){
                CacheHelper::CacheManage($siteID,Constants::$cacheDevelopmentID,Constants::$cacheActionDelete,$developmentID);
            }
            $response->IsSuccess=true;
            $response->Message= trans('messages.DevelopmentDelete');
        } else {
            $response->Message= trans('messages.ErrorOccured');
        }
        return $response;
    }
    public function AwsDownloadFileImages($data,$siteID){
        $response = new ServiceResponse();
        $response->Data = $this->Awsdownloadfile($data->ImagePath,$siteID);
        $response->IsSuccess=true;
        return $response;
    }
    public function DeleteDevelopmentImageAmazon($data,$siteID){
        $response = new ServiceResponse();
        if($data->DevelopmentID == 0){
            $this->Awsdeletefile($data->ImagePath,$siteID);
        }
        $response->IsSuccess=true;
        return $response;
    }

    /* Dev_RB Region End */

    /* Dev_AD Region Start */

    public function RemoveDevelopmentFeaturesFiles($fileRemoveData,$siteID)
    {
        $response = new ServiceResponse();
        $deleteModel = new StdClass();
        if (isset($fileRemoveData)) {
            $data = $this->Awsdeletefile($fileRemoveData->filePath,$siteID);  // Remove Image from AWS
            if ($data && isset($fileRemoveData->ImageID)) {  // Delete images from database if ImageID found during edit page.
                $query = "delete from developmentfeatures where ID = $fileRemoveData->ImageID";
                $this->RunQueryStatement($query, Constants::$QueryType_Delete);
            }
            $response->IsSuccess = true;
            $deleteModel->Key = $fileRemoveData->fileToRemoveKey;  //send the removed array KEY.
            $response->Data = $deleteModel;
            $response->Message = trans('messages.ImageRemovedSuccess');
        } else {
            $response->Message = trans('messages.ErrorOccured');
        }
        return $response;
    }
    /* Dev_AD Region End */
}