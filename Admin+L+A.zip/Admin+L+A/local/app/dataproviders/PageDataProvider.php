<?php
namespace dataproviders;
use Infrastructure\Constants;
use \PageEntity;
use Illuminate\Support\Facades\URL;
use \ViewModels\DeleteModel;
use \ViewModels\WorkFlowDetailModel;
use Infrastructure\Common;
use \ViewModels\ServiceResponse;
use PageSliderImagesEntity;
use Illuminate\Support\Facades\Config;
class PageDataProvider extends IWorkflowDataProvider
{
    /* Start Dev_DN */
    public function getCategories($siteID){
        return null;
    }
	
    public function getDetailForDeleteData(){
        $deleteModel = new DeleteModel();
        $deleteModel->Procedure = 'deletepages';
        $deleteModel->SuccessMessage = 'messages.PageDeleteSuccess';
        $deleteModel->FailMessage = 'messages.PageDeleteError';
        return $deleteModel;
    }
    public function getDetailForList(){
        $detailModel = new WorkFlowDetailModel();
        $detailModel->Procedure = 'pageslist';
        $detailModel->ErrorMessage = 'messages.NoPageRecordFound';
        return $detailModel;
    }
    /* End Dev_DN */

    /*Start Dev_VA*/
    public function getSPNameToFetchDetailsOnAddWorkflow(){
        return "getpagedetails";
    }
    public function getWorkflowEntity(){
        $workFlowEntity = new PageEntity();
        return $workFlowEntity;
    }
    public function getWorkflowDetailsName(){
        return "PageDetails";
    }
    public function getWorkflowModelName(){
        return "PageModel";
    }
    public function getWorkflowID(){
        return "PageID";
    }
    public function getWorkflowRedirectUrl(){
        return URL::to('/')."/pages/";
    }
    public function isWorkflowBlogPost(){
        return false;
    }
    public function saveWorkflowDataSPName(){
        return "savepage";
    }
    public function getAwsRequestType(){
        return Constants::$AWSRequestType_Pages;
    }
    public  function getUniqueMessage(){
        $message = trans('messages.PageSlugAlreadyExist');
        return $message;
    }
    public  function getAddMessage(){
        $message = trans('messages.SavePage');
        return $message;
    }
    public  function getUpdateMessage(){
        $message = trans('messages.UpdatePage');
        return $message;
    }
    public  function getApproveWorkFlowMessage(){
        $message = trans('messages.SaveApprovePage');
        return $message;
    }
    public  function getDenyWorkFlowMessage(){
        $message = trans('messages.SaveDenyPage');
        return $message;
    }
    public  function getPublishWorkFlowMessage(){
        $message = trans('messages.SavePublishPage');
        return $message;
    }
    public function getWorkFlowResponseRedirectURL(){
        return 'pages';
    }
    public function getSaveWorkFlowSPParameter($workFlowID,$workflowModel,$loggedInUserID,$siteID,$loggedInUserRoleID){
        

        if(!isset($workflowModel->IsOverlay)){ $workflowModel->IsOverlay ='';}
        if(!isset($workflowModel->Opacity)){ $workflowModel->Opacity ='';}
        if(!isset($workflowModel->HeaderText)){$workflowModel->HeaderText = '';}
        if(!isset($workflowModel->IsShowBrokerPackageCTA)){$workflowModel->IsShowBrokerPackageCTA = 0;}
        if(isset($workflowModel->SiteID) && ($workflowModel->SiteID == Constants::$RiverDaleFundingSiteID || $workflowModel->SiteID == Constants::$ColoradoSiteID || $workflowModel->SiteID == Constants::$WoodBridgeWealthSiteID)){
            if(!isset($workflowModel->TopImageName)){ $workflowModel->TopImageName = ''; }
            if(!isset($workflowModel->BottomRightImageName)){ $workflowModel->BottomRightImageName = ''; }
            if(isset($workflowModel->TopImagePath) && $workflowModel->TopImagePath != ''){
                if(isset($workflowModel->previousTopImagePath) && $workflowModel->TopImagePath != $workflowModel->previousTopImagePath) {
                    $fullImagePath = Common::getAWSUrl($siteID) . Common::getAWSBucketName($siteID) . '/' . $workflowModel->TopImagePath;
                    Common::createSmallSizeImage(Constants::$postfixSmallImage, $fullImagePath, Constants::$smallImageWidth, Constants::$smallImageHeight, $loggedInUserID);
                }
            }else{ $workflowModel->TopImagePath = '';}

            if(isset($workflowModel->BottomRightImagePath) && $workflowModel->BottomRightImagePath != ''){
                if(isset($workflowModel->previousBottomRightImagePath) && $workflowModel->BottomRightImagePath != $workflowModel->previousBottomRightImagePath) {
                    $fullImagePath = Common::getAWSUrl($siteID) . Common::getAWSBucketName($siteID) . '/' . $workflowModel->BottomRightImagePath;
                    Common::createSmallSizeImage(Constants::$postfixSmallImage, $fullImagePath, Constants::$smallImageWidth, Constants::$smallImageHeight, $loggedInUserID);
                }
            }else{ $workflowModel->BottomRightImagePath = '';}

        }else{
            $workflowModel->TopImagePath ='';
            $workflowModel->TopImageName ='';
            $workflowModel->BottomRightImagePath ='';
            $workflowModel->BottomRightImageName ='';
        }
        return [$workFlowID, $workflowModel->Title,$workflowModel->BrowserTitle, $workflowModel->Slug,$workflowModel->CanonicalURL, $workflowModel->Content, $workflowModel->AuthorID, $workflowModel->AssignedID, $workflowModel->StatusID, $loggedInUserID,$siteID, $workflowModel->MetaDescription, $workflowModel->FBTitle, $workflowModel->FBDescription, $workflowModel->FBImage, $workflowModel->TwitterCard, $workflowModel->TwitterSite, $workflowModel->TwitterTitle, $workflowModel->TwitterDescription, $workflowModel->TwitterImage, $workflowModel->Headline, $workflowModel->Description, $workflowModel->Image, $workflowModel->ImageHeight, $workflowModel->ImageWidth,$loggedInUserRoleID,$loggedInUserID,$workflowModel->Message,$workflowModel->ActionType,$workflowModel->HeaderText,$workflowModel->IsOverlay, $workflowModel->Opacity
                ,$workflowModel->TopImagePath, $workflowModel->TopImageName,$workflowModel->BottomRightImagePath, $workflowModel->BottomRightImageName, $workflowModel->IsShowBrokerPackageCTA];
    }
    public function getWorkFlowAssignedMail($email,$data){
        return Common::SendEmail(Constants::$Email_PageAssignedEmail,$data, Constants::$Email_PageAssignedEmailSubject,$email, "", "","",$sendInstantEmail=1);
    }
    public function getRoleCSV(){
    return Constants::$RoleCSVForAuthor;
    }
    /*End Dev_VA*/
    public function postDeletePageSliderImage($fileRemoveData,$siteID)
    {
        $response = new ServiceResponse();
        if (isset($fileRemoveData)) {
            $data = $this->Awsdeletefile($fileRemoveData->FilePath,$siteID);  // Remove Image from AWS
            if ($data && isset($fileRemoveData->ImageID)) {  // Delete images from database if ImageID found during edit page.
                $this->DeleteEntity(new PageSliderImagesEntity(), $fileRemoveData->ImageID);
            }
            $response->IsSuccess = true;
            $response->Message = trans('messages.ImageRemovedSuccess');
        } else {
            $response->Message = trans('messages.ErrorOccured');
        }
        return $response;
    }
}