<?php 
namespace dataproviders;


Interface IPropertyListingDataProvider{
    /* Dev_AYS Region Start */
    public function GetPropertyLookUps($ListingID,$SiteID,$AgentRoleID,$userActiveStatus,$loginUserID);
    public function ProcessRETSCall($MlsNo,$UserID,$SiteID,$fetchImage,$ClassID);
    public function GetCLAWCredentials($SiteID);
    public function GetPropertyFeatureDetails($agentRoleID,$Features);
    public function DeletePropertyImage($fileRemoveData,$siteID);
    public function SaveProperty($propModel,$siteID,$loggedInUserID);
    public function DeleteProperty($ListingID,$siteID);
    /* Dev_AYS Region End */
    /* property image cron */
    public function getImageCron($offset,$field);
    /* property image cron */
    public function RemovePropertyFeaturesFiles($fileRemoveData,$siteID);
    public function addPropertiesFromMLSDb();
    public function getPropertyImagesInterventionCron();
    public function PropertyManagement();

    /******* Colorado Start *********/
    public function COGetPropertyLookUps($ListingID,$SiteID,$AgentRoleID,$userActiveStatus,$loginUserID);
    public function CoSaveProperty($propModel,$siteID,$loggedInUserID);
    /******* Colorado End ***********/
}
