<?php
namespace dataproviders;
use Infrastructure\Common;
use ViewModels\SearchValueModel;
use \Infrastructure\Constants;
use Illuminate\Support\Facades\URL;
use \CategoriesEntity;
use \ViewModels\DeleteModel;
use \ViewModels\WorkFlowDetailModel;
use \BlogPostsEntity;

class BlogPostDataProvider extends IWorkflowDataProvider{
	
    /*Start Dev_DN*/
    public function getCategories($siteID)
    {
        $searchValueModel = new SearchValueModel();
        $searchParams = Array();
        $searchValueModel->Name = "SiteID";
        $searchValueModel->Value = $siteID;
        array_push($searchParams,$searchValueModel);
        $categoryData = $this->GetEntityList(new CategoriesEntity(), $searchParams);
        $allcategory = new CategoriesEntity();
        $allcategory->CategoryID = Constants::$AllStatusValue;
        $allcategory->Category = Constants::$AllStatusText;
        array_unshift($categoryData, $allcategory);
        return $categoryData;
    }
    public function getDetailForList(){
        $detailModel = new WorkFlowDetailModel();
        $detailModel->Procedure = 'blogpostslist';
        $detailModel->ErrorMessage = 'messages.NoBlogRecordFound';
        return $detailModel;
    }
    public function getDetailForDeleteData(){
        $deleteModel = new DeleteModel();
        $deleteModel->Procedure = 'deleteblogposts';
        $deleteModel->SuccessMessage = 'messages.BlogPostDeleteSuccess';
        $deleteModel->FailMessage = 'messages.BlogPOstDeleteError';
        return $deleteModel;
    }

    public function getAwsRequestType(){
        return Constants::$AWSRequestType_Blogs;
    }

    public  function getAddMessage(){
        $message = trans('messages.SaveBlog');
        return $message;
    }
    public  function getUpdateMessage(){
        $message = trans('messages.UpdateBlog');
        return $message;
    }
    /*End Dev_DN*/


    /*Start Dev_VA*/
    public  function getUniqueMessage(){
        $message = trans('messages.BlogSlugAlreadyExist');
        return $message;
    }

    public function getSPNameToFetchDetailsOnAddWorkflow(){
        return "getblogdetails";
    }
    public function getWorkflowEntity(){
        $workFlowEntity = new BlogPostsEntity();
        return $workFlowEntity;
    }
    public function getWorkflowDetailsName(){
        return "BlogDetails";
    }
    public function getWorkflowModelName(){
        return "BlogModel";
    }
    public function getWorkflowID(){
        return "BlogPostID";
    }
    public function getWorkflowRedirectUrl(){
        return URL::to('/')."/blogposts/";
    }
    public function isWorkflowBlogPost(){
        return true;
    }
    public function saveWorkflowDataSPName(){
        return "saveblogpost";
    }
    public  function getApproveWorkFlowMessage(){
        $message = trans('messages.SaveApproveBlog');
        return $message;
    }
    public  function getDenyWorkFlowMessage(){
        $message = trans('messages.SaveDenyBlog');
        return $message;
    }
    public  function getPublishWorkFlowMessage(){
        $message = trans('messages.SavePublishBlog');
        return $message;
    }
    public function getWorkFlowResponseRedirectURL(){
        return 'blogposts';
    }
    public function getSaveWorkFlowSPParameter($workFlowID,$workflowModel,$loggedInUserID,$siteID,$loggedInUserRoleID){
        $tagCSV = isset($workflowModel->Tag) ? Common::GetCsvFromArrayProperty($workflowModel->Tag,"TagID") : '';
        $categoryCSV = isset($workflowModel->Category) ? Common::GetCsvFromArray($workflowModel->Category) : '';
        $tagAgentCSV = isset($workflowModel->TagAgent) ? Common::GetCsvFromArray($workflowModel->TagAgent) : '';
        $featuredImage = isset($workflowModel->FeaturedImage) ? $workflowModel->FeaturedImage : '';

        $workflowModel->Summary = isset($workflowModel->Summary)?$workflowModel->Summary :'';
        $postDate =  date(Constants::$YMDDateFormatServerSide,strtotime($workflowModel->PostDate));

        return [$workFlowID, $workflowModel->Title, $workflowModel->BrowserTitle, $workflowModel->Slug,
        $postDate,$workflowModel->CanonicalURL, $workflowModel->Content,$workflowModel->Summary,
        $workflowModel->AuthorID, $workflowModel->AssignedID, $workflowModel->StatusID, $loggedInUserID,$siteID,
        $workflowModel->MetaDescription, $workflowModel->FBTitle, $workflowModel->FBDescription, $workflowModel->FBImage,
        $workflowModel->TwitterCard, $workflowModel->TwitterSite, $workflowModel->TwitterTitle, $workflowModel->TwitterDescription,
        $workflowModel->TwitterImage, $workflowModel->Headline, $workflowModel->Description, $workflowModel->Image,
        $workflowModel->ImageHeight, $workflowModel->ImageWidth,$loggedInUserRoleID,$loggedInUserID,$workflowModel->Message,
        $workflowModel->ActionType,$categoryCSV,$tagCSV,$tagAgentCSV,$featuredImage];
    }
    public function getWorkFlowAssignedMail($email,$data){
        return Common::SendEmail(Constants::$Email_BlogAssignedEmail,$data, Constants::$Email_BlogAssignedEmailSubject,$email, "", "","",$sendInstantEmail=1);
    }
    public function getRoleCSV(){
        return Constants::$getBlogRoleCSVForAuthor;
    }
    /*End Dev_VA*/
}