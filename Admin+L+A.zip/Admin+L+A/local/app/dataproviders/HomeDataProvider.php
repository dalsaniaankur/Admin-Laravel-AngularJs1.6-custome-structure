<?php
namespace dataproviders;
use Illuminate\Support\Facades\Validator;
use \ViewModels\ServiceResponse;
use \Infrastructure\Constants;
use \Infrastructure\Common;
use \stdClass;
use \Crypt;
use Illuminate\Support\Facades\URL;
use File;
use Illuminate\Support\Facades\Config;
use HomePageMediaItemsEntity;
use HomePagesEntity;
use HomePageStoryImagesEntity;
use HomePageStoryEntity;
use RDHomePagesEntity;
use RDHomePageSliderEntity;
use Infrastructure\CacheHelper;
use COHomePagesEntity;
use COHomePageSliderEntity;
use WWHomePagesEntity;
use WWHomePageSliderEntity;
class HomeDataProvider extends BaseDataProvider implements IHomeDataProvider {

    /* Dev_AD Region Start */
    public function getHomeView($siteID,$loginUserID){
        $response = new ServiceResponse();
        $model = new StdClass();
        $homeModel = new StdClass();
        $storyModel = new StdClass();
        $homeModel->HomeDetails = new StdClass();
        $AWSUrl = Common::getAWSUrl($siteID);
        $AWSBucketName = Common::getAWSBucketName($siteID);//Config::get('aws.AWSBucketName');
        $result = $this->CallRawForMultipleTable('homepagedetails',array($siteID, $AWSUrl, $AWSBucketName),false,["FirstSectionType","ShowMVSection","IsLight"]);
        if(isset($result[0][0]->FirstSectionType) AND ($result[0][0]->FirstSectionType == 1)){
            $homeModel->HomeDetails = (object) array_merge((array) $result[0][0], (array) $result[1][0]);
            $storyModel->StoryListArray=$result[2];
        }
        if(isset($result[0][0]->FirstSectionType ) AND ($result[0][0]->FirstSectionType == 2)){
            $homeModel->HomeDetails = (object) array_merge((array) $result[0][0], (array) $result[1][0], (array) $result[2][0], (array) $result[3][0]);
            $storyModel->StoryListArray=$result[4];
        }
        $homeModel->HomeDetails->encryptedSiteID = Common::getEncryptedValue(Constants::$QueryStringSiteID.'='.$siteID);
        $homeModel->HomeDetails->FileUploadSettings = $this->FileUploadSettings(Constants::$AWSRequestType_Home,$siteID,$loginUserID);
        $storyModel->FileUploadSettings = $this->FileUploadSettings(Constants::$AWSRequestType_Home,$siteID,$loginUserID);
        $storyModel->SiteID = $siteID;
        $model->HomeModel = $homeModel;
        $model->StoryModel = $storyModel;
        $response->Data = $model;
        return $response;
    }
    public function postDeleteSliderImagesFile($fileRemoveData,$siteID){
        $response = new ServiceResponse();
        if (isset($fileRemoveData)) {
            $data = $this->Awsdeletefile($fileRemoveData->FilePath,$siteID);  // Remove Image from AWS
            if ($data && isset($fileRemoveData->HomePageMediaItemID)) {  // Delete images from database if ImageID found during edit page.
                $this->DeleteEntity(new HomePageMediaItemsEntity(), $fileRemoveData->HomePageMediaItemID);
            }
            $response->IsSuccess = true;
            $response->Message = trans('messages.ImageRemovedSuccess');
        } else {
            $response->Message = trans('messages.ErrorOccured');
        }
        return $response;
    }
    public function postSaveHomePage($homeModel,$loginUserID,$siteID){

        $response = new ServiceResponse();
        $messages = array(
            'required' => trans('messages.PropertyRequired'),
            'min' => trans('messages.PropertyMin'),
            'max' => trans('messages.PropertyMax'),
        );

        $validator = Validator::make((array)$homeModel, HomePagesEntity::$Edit_rules, $messages);
        $validator->setAttributeNames(HomePagesEntity::$niceNameArray);
        if ($validator->fails()) {
            $response->Message = Common::getValidationMessagesFormat($validator->messages());
            return $response;
        }

        if(!isset($homeModel->FirstSectionType) OR $homeModel->FirstSectionType == 0 OR $homeModel->FirstSectionType == ''){$homeModel->FirstSectionType = 1;}
        if(!isset($homeModel->HoverImageURL)){$homeModel->HoverImageURL = '';}
        if(!isset($homeModel->HoverImageName)){$homeModel->HoverImageName = '';}

        if(!isset($homeModel->MP3VideoURL)){$homeModel->MP3VideoURL = '';}
        if(!isset($homeModel->MP3VideoName)){$homeModel->MP3VideoName = '';}

        if(!isset($homeModel->OggVideoURL)){$homeModel->OggVideoURL = '';}
        if(!isset($homeModel->OggVideoName)){$homeModel->OggVideoName = '';}

        if(!isset($homeModel->WebmVideoURL)){$homeModel->WebmVideoURL = '';}
        if(!isset($homeModel->WebmVideoName)){$homeModel->WebmVideoName = '';}

        if(!isset($homeModel->BackgroundImageURL)){$homeModel->BackgroundImageURL = '';}
        if(!isset($homeModel->BackgroundImageName)){$homeModel->BackgroundImageName = '';}
        if(!isset($homeModel->HeaderText)){$homeModel->HeaderText = '';}

        if(!isset($homeModel->BrowserTitle)){$homeModel->BrowserTitle = '';}
        if(!isset($homeModel->CanonicalURL)){$homeModel->CanonicalURL = '';}
        if(!isset($homeModel->MetaDescription)){$homeModel->MetaDescription = '';}

        if(!isset($homeModel->FBTitle)){$homeModel->FBTitle = '';}
        if(!isset($homeModel->FBDescription)){$homeModel->FBDescription = '';}
        if(!isset($homeModel->FBImage)){$homeModel->FBImage = '';}
        if(!isset($homeModel->FBImageName)){$homeModel->FBImageName = '';}

        if(!isset($homeModel->TwitterCard)){$homeModel->TwitterCard = '';}
        if(!isset($homeModel->TwitterSite)){$homeModel->TwitterSite = '';}
        if(!isset($homeModel->TwitterTitle)){$homeModel->TwitterTitle = '';}
        if(!isset($homeModel->TwitterDescription)){$homeModel->TwitterDescription = '';}
        if(!isset($homeModel->TwitterImage)){$homeModel->TwitterImage = '';}
        if(!isset($homeModel->TwitterImageName)){$homeModel->TwitterImageName = '';}

        if(!isset($homeModel->Headline)){$homeModel->Headline = '';}
        if(!isset($homeModel->Description)){$homeModel->Description = '';}
        if(!isset($homeModel->RichSnippetsImage)){$homeModel->RichSnippetsImage = '';}
        if(!isset($homeModel->RichSnippetsImageName)){$homeModel->RichSnippetsImageName = '';}
        if(!isset($homeModel->ShowMVSection)){$homeModel->ShowMVSection = 0;}

        $results = $this->CallRawForMultipleTable('savehomepage', [$homeModel->HoverImageURL,
                                                                    $homeModel->HoverImageName,
                                                                    $homeModel->BackgroundImageURL,
                                                                    $homeModel->BackgroundImageName,
                                                                    $homeModel->FirstSectionType,
                                                                    $homeModel->MVItem1Title,
                                                                    $homeModel->MVItem1Subtitle,
                                                                    $homeModel->MVItem1Link,
                                                                    $homeModel->MVItem1ImageName,
                                                                    $homeModel->MVItem1ImageURL,
                                                                    $homeModel->MVItem2Title,
                                                                    $homeModel->MVItem2Subtitle,
                                                                    $homeModel->MVItem2Link,
                                                                    $homeModel->MVItem2ImageName,
                                                                    $homeModel->MVItem2ImageURL,
                                                                    $homeModel->MVItem3Title,
                                                                    $homeModel->MVItem3Subtitle,
                                                                    $homeModel->MVItem3Link,
                                                                    $homeModel->MVItem3ImageName,
                                                                    $homeModel->MVItem3ImageURL,
                                                                    $homeModel->YoutubeURL,
                                                                    $homeModel->YoutubeVideoImageName,
                                                                    $homeModel->YoutubeVideoImageURL,
                                                                    $homeModel->MP3VideoURL,
                                                                    $homeModel->MP3VideoName,
                                                                    $homeModel->OggVideoURL,
                                                                    $homeModel->OggVideoName,
                                                                    $homeModel->WebmVideoURL,
                                                                    $homeModel->WebmVideoName,
                                                                    $homeModel->ShowMVSection,
                                                                    $homeModel->HeaderText,
                                                                    $homeModel->BrowserTitle,
                                                                    $homeModel->CanonicalURL,
                                                                    $homeModel->MetaDescription,
                                                                    $homeModel->FBTitle,
                                                                    $homeModel->FBDescription,
                                                                    $homeModel->FBImage,
                                                                    $homeModel->FBImageName,
                                                                    $homeModel->TwitterCard,
                                                                    $homeModel->TwitterSite,
                                                                    $homeModel->TwitterTitle,
                                                                    $homeModel->TwitterDescription,
                                                                    $homeModel->TwitterImage,
                                                                    $homeModel->TwitterImageName,
                                                                    $homeModel->Headline,
                                                                    $homeModel->Description,
                                                                    $homeModel->RichSnippetsImage,
                                                                    $homeModel->RichSnippetsImageName,
                                                                    $loginUserID,
                                                                    $siteID,
                                                                    $homeModel->HomepageID]);

        if($results[0][0]){
            if(isset($homeModel->HomepageID) && !empty($homeModel->HomepageID) && $homeModel->HomepageID > 0 ){
                CacheHelper::CacheManage($siteID,Constants::$cacheHomeID,Constants::$cacheActionUpdate,$homeModel->HomepageID);
            }
            $response->IsSuccess = true;
            $response->Message = trans('messages.HomePagesUpdated');
        }else{
            $response->Message = trans('messages.ErrorOccured');
        }
        return $response;
    }
    public function AwsDownloadFileImages($data,$siteID){
        $response = new ServiceResponse();
        $response->Data = $this->Awsdownloadfile($data->ImageURL,$siteID);
        $response->IsSuccess=true;
        return $response;
    }
    public function DeleteImageAmazon($data,$siteID){
        $response = new ServiceResponse();
        if($data->HomepageID == 0){
            $this->Awsdeletefile($data->ImageURL,$siteID);
        }
        $response->Data = $data->RemoveType;
        $response->IsSuccess=true;
        return $response;

    }
    public function postDeleteVideoAmazon($data,$siteID){
        $response = new ServiceResponse();
        if($data->HomepageID == 0){
            $this->Awsdeletefile($data->VideoURL,$siteID);
        }
        $response->Data = $data->RemoveType;
        $response->IsSuccess=true;
        return $response;
    }
    public function postHomeChangeSection($firstSectionType, $siteID){
        $response = new ServiceResponse();
        $model = new stdClass();
        $AWSUrl = Common::getAWSUrl($siteID);
        $AWSBucketName = Common::getAWSBucketName($siteID);//Config::get('aws.AWSBucketName');
        $result = $this->CallRawForMultipleTable('homepagechangesectiondetails',array($firstSectionType, $siteID, $AWSUrl, $AWSBucketName));
        if($firstSectionType == Constants::$HoverImageType){
            $model->HoverImage = $result[0][0];
            $model->BackgroundImage = $result[1][0];
            $response->Data = $model;
        }
        if($firstSectionType == Constants::$HomeSectionSliderType) {
            $model->MP3Video = $result[0][0];
            $model->OggVideo = $result[1][0];
            $model->WebmVideo = $result[2][0];
            $model->BackgroundImage = $result[3][0];
            $response->Data = $model;
        }
        $response->IsSuccess=true;
        return $response;
    }
    public function deleteStory($HomePageStoryID){
        $response = new ServiceResponse();
        $model = new StdClass();
        $deleteStoryResults = $this->CallRawForMultipleTable('deletestory',[$HomePageStoryID]);
        CacheHelper::CacheManage(Constants::$MercerVineSiteID,Constants::$cacheHomeID,Constants::$cacheActionUpdate,$HomePageStoryID);
        $model->StoryListArray = $deleteStoryResults[0];
        if($deleteStoryResults[1][0]->ResultStatus) {
            $response->Data = $model;
            $response->IsSuccess=true;
            $response->Message= trans('messages.StoryDeleted');
        } else {
            $response->Message= trans('messages.ErrorOccured');
        }
        return $response;
    }
    public function UpdateSortOrderStory($OldOrder,$newOrder){
        $response = new ServiceResponse();
        $results = $this->CallRawForMultipleTable('sortorderstorylist',[$OldOrder,$newOrder]);
        CacheHelper::CacheManage(Constants::$MercerVineSiteID,Constants::$cacheHomeID,Constants::$cacheActionUpdate,'');
        if($results[0][0]->ResultStatus){
            $response->IsSuccess=true;
            $response->Message= trans('messages.StoryOrder');
        }else{
            $response->Message= trans('messages.ErrorOccured');
        }
        return $response;
    }
    public function postSaveStory($StoryModel,$siteID){
        $response = new ServiceResponse();
        $model = new StdClass();
        $messages = array(
            'required' => trans('messages.PropertyRequired'),
            'min' => trans('messages.PropertyMin'),
            'max' => trans('messages.PropertyMax')
        );
        $validator = Validator::make((array) $StoryModel,HomePageStoryEntity::$Add_rules,$messages);
        $validator->setAttributeNames(HomePageStoryEntity::$niceNameArray);
        if($validator->fails()){
            $response->Message=Common::getValidationMessagesFormat($validator->messages());
            return $response;
        }
        if(!isset($StoryModel->HomePageStoryID)){$StoryModel->HomePageStoryID = '';}
        if(!isset($StoryModel->ImageURL)){$StoryModel->ImageURL = '';}
        if(!isset($StoryModel->ImageName)){$StoryModel->ImageName = '';}
        $AWSUrl = Common::getAWSUrl($siteID);
        $AWSBucketName = Common::getAWSBucketName($siteID);
        $results = $this->CallRawForMultipleTable('savestory',[$StoryModel->HomePageStoryID,
                                                                 $StoryModel->Title,
                                                                 $StoryModel->Link,
                                                                 $StoryModel->Description,
                                                                 $StoryModel->LinkText,
                                                                 $StoryModel->ImageURL,
                                                                 $StoryModel->ImageName,
                                                                 $StoryModel->IsLight,
                                                                 $AWSUrl,
                                                                 $AWSBucketName]);

        if(!isset($StoryModel->HomePageStoryID) OR $StoryModel->HomePageStoryID == 0 OR $StoryModel->HomePageStoryID =='')
        {
            if(isset($results[2][0]->HomePageStoryID)){
                $HomePageStoryID = $results[2][0]->HomePageStoryID;
                CacheHelper::CacheManage($siteID,Constants::$cacheHomeID,Constants::$cacheActionUpdate,$HomePageStoryID);
            }
        }else{
            $HomePageStoryID = $StoryModel->HomePageStoryID;
            CacheHelper::CacheManage($siteID,Constants::$cacheHomeID,Constants::$cacheActionUpdate,$HomePageStoryID);
        }
        if($results[0][0]->ResultStatus > 0) {
            if(isset($results[1])) { $model->StoryListArray = $results[1]; }
            $response->Data = $model;
            $response->IsSuccess=true;
            if($results[0][0]->ResultStatus == 1){
                $response->Message = trans('messages.StoryAddedSuccess');
            }
            if($results[0][0]->ResultStatus == 2){
                $response->Message = trans('messages.StoryUpdateSuccess');
            }
        } else {
            $response->Message= trans('messages.ErrorOccured');
        }
        return $response;
    }
    public function postDeleteStoryImagesFile($fileRemoveData,$siteID){
        $response = new ServiceResponse();
        if (isset($fileRemoveData)) {
            $data = $this->Awsdeletefile($fileRemoveData->FilePath,$siteID);  // Remove Image from AWS
            if ($data && isset($fileRemoveData->HomePageStoryImagesID)) {  // Delete images from database if ImageID found during edit page.
                $this->DeleteEntity(new HomePageStoryImagesEntity(), $fileRemoveData->HomePageStoryImagesID);
            }
            $response->IsSuccess = true;
            $response->Message = trans('messages.ImageRemovedSuccess');
        } else {
            $response->Message = trans('messages.ErrorOccured');
        }
        return $response;
    }
    public function postGetStoryImagesFile($homePageStoryID){
        $response = new ServiceResponse();
        $result = $this->CallRawForMultipleTable('gethomepahestoryimages',[$homePageStoryID]);
        if($result[1][0]){
            $response->Data = $result[0];
            $response->IsSuccess = true;
        }
        return $response;
    }
    public function getRD_HomeView($siteID,$loginUserID){
        $response = new ServiceResponse();
        $model = new StdClass();

        $AWSUrl = Common::getAWSUrl($siteID);
        $AWSBucketName = Common::getAWSBucketName($siteID);
        $result = $this->CallRawForMultipleTable('rd_homepagedetails',array($AWSUrl, $AWSBucketName),false,["IsLight"]);

        if(isset($result[0][0]) && !empty($result[0][0])){ $model->HomeModel = $result[0][0]; }else{ $model->HomeModel = new stdClass(); }
        $model->HomeModel->FileUploadSettings = $this->FileUploadSettings(Constants::$AWSRequestType_Home,$siteID,$loginUserID);
        $model->HomeModel->SiteID = $siteID;

        $model->SliderModel = new stdClass();
        $model->SliderModel->SliderListArray = $result[1];
        $model->SliderModel->FileUploadSettings = $this->FileUploadSettings(Constants::$AWSRequestType_Home,$siteID,$loginUserID);
        $model->SliderModel->SiteID = $siteID;

        $response->Data = $model;
        return $response;
    }
    public function postSaveRDHomePage($homeModel,$siteID){
        $response = new ServiceResponse();
        if(!isset($homeModel->HomepageID) || $homeModel->HomepageID == '' || $homeModel->HomepageID == NULL ){
            return $response;
        }
        $messages = array(
            'required' => trans('messages.PropertyRequired'),
            'min' => trans('messages.PropertyMin'),
            'max' => trans('messages.PropertyMax'),
        );

        $validator = Validator::make((array)$homeModel, RDHomePagesEntity::$Add_Edit_rules, $messages);
        $validator->setAttributeNames(RDHomePagesEntity::$niceNameArray);
        if ($validator->fails()) {
            $response->Message = Common::getValidationMessagesFormat($validator->messages());
            return $response;
        }

        if(!isset($homeModel->Block1LinkText2)){$homeModel->Block1LinkText2 = '';}
        if(!isset($homeModel->Block1URL2)){$homeModel->Block1URL2 = '';}

        if(!isset($homeModel->BrowserTitle)){$homeModel->BrowserTitle = '';}
        if(!isset($homeModel->CanonicalURL)){$homeModel->CanonicalURL = '';}
        if(!isset($homeModel->MetaDescription)){$homeModel->MetaDescription = '';}

        if(!isset($homeModel->FBTitle)){$homeModel->FBTitle = '';}
        if(!isset($homeModel->FBDescription)){$homeModel->FBDescription = '';}
        if(!isset($homeModel->FacebookImageName)){$homeModel->FacebookImageName = '';}
        if(!isset($homeModel->FacebookImagePath)){$homeModel->FacebookImagePath = '';}

        if(!isset($homeModel->TwitterCard)){$homeModel->TwitterCard = '';}
        if(!isset($homeModel->TwitterSite)){$homeModel->TwitterSite = '';}
        if(!isset($homeModel->TwitterTitle)){$homeModel->TwitterTitle = '';}
        if(!isset($homeModel->TwitterDescription)){$homeModel->TwitterDescription = '';}
        if(!isset($homeModel->TwitterImageName)){$homeModel->TwitterImageName = '';}
        if(!isset($homeModel->RealTwitterImagePath)){$homeModel->RealTwitterImagePath = '';}

        if(!isset($homeModel->Headline)){$homeModel->Headline = '';}
        if(!isset($homeModel->Description)){$homeModel->Description = '';}
        if(!isset($homeModel->RichSnippetImageName)){$homeModel->RichSnippetImageName = '';}
        if(!isset($homeModel->RichSnippetImagePath)){$homeModel->RichSnippetImagePath = '';}

        $results = $this->CallRawForMultipleTable('rd_savehomepage', [$homeModel->Block1ImageName,
                                                                     $homeModel->Block1ImagePath,
                                                                     $homeModel->Block1Title,
                                                                     $homeModel->Block1Description,
                                                                     $homeModel->Block1LinkText1,
                                                                     $homeModel->Block1URL1,
                                                                     $homeModel->Block1LinkText2,
                                                                     $homeModel->Block1URL2,

                                                                     $homeModel->Block2ImageName,
                                                                     $homeModel->Block2ImagePath,
                                                                     $homeModel->Block2Title,
                                                                     $homeModel->Block2Description,
                                                                     $homeModel->Block2LinkText1,
                                                                     $homeModel->Block2URL1,

                                                                     $homeModel->Block3ImageName,
                                                                     $homeModel->Block3ImagePath,
                                                                     $homeModel->Block3Title,
                                                                     $homeModel->Block3Description,
                                                                     $homeModel->Block3LinkText1,
                                                                     $homeModel->Block3URL1,

                                                                     $homeModel->BrowserTitle,
                                                                     $homeModel->CanonicalURL,
                                                                     $homeModel->MetaDescription,
                                                                     $homeModel->FBTitle,
                                                                     $homeModel->FBDescription,
                                                                     $homeModel->FacebookImageName,
                                                                     $homeModel->FacebookImagePath,

                                                                     $homeModel->TwitterCard,
                                                                     $homeModel->TwitterSite,
                                                                     $homeModel->TwitterTitle,
                                                                     $homeModel->TwitterDescription,
                                                                     $homeModel->TwitterImageName,
                                                                     $homeModel->TwitterImagePath,

                                                                     $homeModel->Headline,
                                                                     $homeModel->Description,
                                                                     $homeModel->RichSnippetImageName,
                                                                     $homeModel->RichSnippetImagePath,

                                                                     $homeModel->HomepageID]);

        if($results[0][0]){
            if(isset($homeModel->HomepageID) && !empty($homeModel->HomepageID) && $homeModel->HomepageID > 0 ){
                CacheHelper::CacheManage($siteID,Constants::$cacheHomeID,Constants::$cacheActionUpdate,$homeModel->HomepageID);
            }
            $response->IsSuccess = true;
            $response->Message = trans('messages.HomePagesUpdated');
        }else{
            $response->Message = trans('messages.ErrorOccured');
        }
        return $response;
    }
    public function UpdateSortOrderSlider($OldOrder,$newOrder){
        $response = new ServiceResponse();
        $results = $this->CallRawForMultipleTable('sortordersliderlist',[$OldOrder,$newOrder]);
        CacheHelper::CacheManage(Constants::$RiverDaleFundingSiteID,Constants::$cacheHomeID,Constants::$cacheActionUpdate,'');
        if($results[0][0]->ResultStatus){
            $response->IsSuccess=true;
            $response->Message= trans('messages.SliderOrder');
        }else{
            $response->Message= trans('messages.ErrorOccured');
        }
        return $response;
    }
    public function deleteSlider($HomePageSliderID,$siteID){
        $response = new ServiceResponse();
        $model = new StdClass();
        $AWSUrl = Common::getAWSUrl($siteID);
        $AWSBucketName = Common::getAWSBucketName($siteID);
        $results = $this->CallRawForMultipleTable('deleteslider',[$HomePageSliderID,$AWSUrl,$AWSBucketName],false,["IsLight"]);
        CacheHelper::CacheManage(Constants::$RiverDaleFundingSiteID,Constants::$cacheHomeID,Constants::$cacheActionDelete,'');
        $model->SliderListArray = $results[0];
        if($results[1][0]->ResultStatus) {
            $response->Data = $model;
            $response->IsSuccess=true;
            $response->Message= trans('messages.SliderDeleted');
        } else {
            $response->Message= trans('messages.ErrorOccured');
        }
        return $response;
    }
    public function postSaveSlider($SliderModel,$siteID){
        $response = new ServiceResponse();
        $model = new StdClass();
        $messages = array(
            'required' => trans('messages.PropertyRequired'),
            'min' => trans('messages.PropertyMin'),
            'max' => trans('messages.PropertyMax')
        );
        $validator = Validator::make((array) $SliderModel,RDHomePageSliderEntity::$Add_Edit_rules,$messages);
        $validator->setAttributeNames(RDHomePageSliderEntity::$niceNameArray);
        if($validator->fails()){
            $response->Message=Common::getValidationMessagesFormat($validator->messages());
            return $response;
        }

        if(!isset($SliderModel->HomePageSliderID)){$SliderModel->HomePageSliderID = '';}
        if(!isset($SliderModel->BackgroundImagePath)){$SliderModel->BackgroundImagePath = '';}
        if(!isset($SliderModel->BackgroundImageName)){$SliderModel->BackgroundImageName = '';}
        if(!isset($SliderModel->Description)){$SliderModel->Description = '';}
        if(!isset($SliderModel->LinkText)){$SliderModel->LinkText = '';}
        if(!isset($SliderModel->LinkURL)){$SliderModel->LinkURL = '';}
        if(!isset($SliderModel->Header)){$SliderModel->Header = '';}

        $AWSUrl = Common::getAWSUrl($siteID);
        $AWSBucketName = Common::getAWSBucketName($siteID);
        $results = $this->CallRawForMultipleTable('rd_saveslider',[$SliderModel->HomePageSliderID,
                                                                   $SliderModel->BackgroundImagePath,
                                                                   $SliderModel->BackgroundImageName,
                                                                   $SliderModel->Description,
                                                                   $SliderModel->LinkText,
                                                                   $SliderModel->LinkURL,
                                                                   $SliderModel->Header,
                                                                   $SliderModel->IsLight,
                                                                   $AWSUrl,
                                                                   $AWSBucketName],false,["IsLight"]);

        if($results[0][0]->ResultStatus > 0) {
            CacheHelper::CacheManage(Constants::$RiverDaleFundingSiteID,Constants::$cacheHomeID,Constants::$cacheActionInsert,'');
            if(isset($results[1])) { $model->SliderListArray = $results[1]; }
            $response->Data = $model;
            $response->IsSuccess=true;
            if($results[0][0]->ResultStatus == 1){ $response->Message = trans('messages.SliderAddedSuccess'); }
            if($results[0][0]->ResultStatus == 2){ $response->Message = trans('messages.SliderUpdateSuccess'); }
        } else {
            $response->Message= trans('messages.ErrorOccured');
        }
        return $response;
    }
    public function getCO_HomeView($siteID,$loginUserID){
        $response = new ServiceResponse();
        $model = new StdClass();
        $homeModel = new StdClass();
        $homeModel->HomeDetails = new StdClass();
        $AWSUrl = Common::getAWSUrl($siteID);
        $AWSBucketName = Common::getAWSBucketName($siteID);
        $result = $this->CallRawForMultipleTable('co_cms_homepagedetails',array($AWSUrl, $AWSBucketName),false,["ShowTopCTASection","ShowBottomCTASection"]);
        $homeModel->HomeDetails = $result[0][0];
        $homeModel->HomeDetails->encryptedSiteID = Common::getEncryptedValue(Constants::$QueryStringSiteID.'='.$siteID);
        $homeModel->HomeDetails->FileUploadSettings = $this->FileUploadSettings(Constants::$AWSRequestType_Home,$siteID,$loginUserID);
        $homeModel->HomeDetails->SiteID = $siteID;
        $model->HomeModel = $homeModel;

        /* slider list */
        $model->SliderModel = new stdClass();
        $model->SliderModel->SliderListArray = $result[1];
        $model->SliderModel->FileUploadSettings = $this->FileUploadSettings(Constants::$AWSRequestType_Home,$siteID,$loginUserID);
        $model->SliderModel->SiteID = $siteID;

        $response->Data = $model;
        return $response;
    }
    public function postSaveCOHomePage($homeModel,$siteID){
        $response = new ServiceResponse();
        if(!isset($homeModel->HomepageID) || $homeModel->HomepageID == '' || $homeModel->HomepageID == NULL ){
            return $response;
        }
        $messages = array(
            'required' => trans('messages.PropertyRequired'),
            'min' => trans('messages.PropertyMin'),
            'max' => trans('messages.PropertyMax'),
        );

        $validator = Validator::make((array)$homeModel, COHomePagesEntity::$Add_Edit_rules, $messages);
        $validator->setAttributeNames(COHomePagesEntity::$niceNameArray);
        if ($validator->fails()) {
            $response->Message = Common::getValidationMessagesFormat($validator->messages());
            return $response;
        }

        if(!isset($homeModel->BrowserTitle)){$homeModel->BrowserTitle = '';}
        if(!isset($homeModel->CanonicalURL)){$homeModel->CanonicalURL = '';}
        if(!isset($homeModel->MetaDescription)){$homeModel->MetaDescription = '';}

        if(!isset($homeModel->FBTitle)){$homeModel->FBTitle = '';}
        if(!isset($homeModel->FBDescription)){$homeModel->FBDescription = '';}
        if(!isset($homeModel->FacebookImageName)){$homeModel->FacebookImageName = '';}
        if(!isset($homeModel->FacebookImagePath)){$homeModel->FacebookImagePath = '';}

        if(!isset($homeModel->TwitterCard)){$homeModel->TwitterCard = '';}
        if(!isset($homeModel->TwitterSite)){$homeModel->TwitterSite = '';}
        if(!isset($homeModel->TwitterTitle)){$homeModel->TwitterTitle = '';}
        if(!isset($homeModel->TwitterDescription)){$homeModel->TwitterDescription = '';}
        if(!isset($homeModel->TwitterImageName)){$homeModel->TwitterImageName = '';}
        if(!isset($homeModel->RealTwitterImagePath)){$homeModel->RealTwitterImagePath = '';}

        if(!isset($homeModel->Headline)){$homeModel->Headline = '';}
        if(!isset($homeModel->Description)){$homeModel->Description = '';}
        if(!isset($homeModel->RichSnippetImageName)){$homeModel->RichSnippetImageName = '';}
        if(!isset($homeModel->RichSnippetImagePath)){$homeModel->RichSnippetImagePath = '';}

        if(!isset($homeModel->Content)){$homeModel->Content = '';}
        if(!isset($homeModel->OggVideoName)){$homeModel->OggVideoName = '';}
        if(!isset($homeModel->OggVideoURL)){$homeModel->OggVideoURL = '';}
        if(!isset($homeModel->WebmVideoName)){$homeModel->WebmVideoName = '';}
        if(!isset($homeModel->WebmVideoURL)){$homeModel->WebmVideoURL = '';}

        if(!isset($homeModel->VideoPosterName)){$homeModel->VideoPosterName = '';}
        if(!isset($homeModel->VideoPosterPath)){$homeModel->VideoPosterPath = '';}

        $results = $this->CallRawForMultipleTable('co_savehomepage', [
                                                                        $homeModel->BrowserTitle,
                                                                        $homeModel->CanonicalURL,
                                                                        $homeModel->MetaDescription,
                                                                        $homeModel->FBTitle,
                                                                        $homeModel->FBDescription,
                                                                        $homeModel->FacebookImageName,
                                                                        $homeModel->FacebookImagePath,

                                                                        $homeModel->TwitterCard,
                                                                        $homeModel->TwitterSite,
                                                                        $homeModel->TwitterTitle,
                                                                        $homeModel->TwitterDescription,
                                                                        $homeModel->TwitterImageName,
                                                                        $homeModel->TwitterImagePath,

                                                                        $homeModel->Headline,
                                                                        $homeModel->Description,
                                                                        $homeModel->RichSnippetImageName,
                                                                        $homeModel->RichSnippetImagePath,

                                                                        $homeModel->Content,

                                                                        $homeModel->TopCTAImageName1,
                                                                        $homeModel->TopCTAImagePath1,
                                                                        $homeModel->TopCTATitle1,
                                                                        $homeModel->TopCTALinkText1,
                                                                        $homeModel->TopCTALinkURL1,

                                                                        $homeModel->TopCTAImageName2,
                                                                        $homeModel->TopCTAImagePath2,
                                                                        $homeModel->TopCTATitle2,
                                                                        $homeModel->TopCTALinkText2,
                                                                        $homeModel->TopCTALinkURL2,

                                                                        $homeModel->BottomCTAImageName1,
                                                                        $homeModel->BottomCTAImagePath1,
                                                                        $homeModel->BottomCTATitle1,
                                                                        $homeModel->BottomCTALinkText1,
                                                                        $homeModel->BottomCTALinkURL1,

                                                                        $homeModel->BottomCTAImageName2,
                                                                        $homeModel->BottomCTAImagePath2,
                                                                        $homeModel->BottomCTATitle2,
                                                                        $homeModel->BottomCTALinkText2,
                                                                        $homeModel->BottomCTALinkURL2,

                                                                        $homeModel->BottomCTAImageName3,
                                                                        $homeModel->BottomCTAImagePath3,
                                                                        $homeModel->BottomCTATitle3,
                                                                        $homeModel->BottomCTALinkText3,
                                                                        $homeModel->BottomCTALinkURL3,

                                                                        $homeModel->MP4VideoName,
                                                                        $homeModel->MP4VideoURL,
                                                                        $homeModel->OggVideoName,
                                                                        $homeModel->OggVideoURL,
                                                                        $homeModel->WebmVideoName,
                                                                        $homeModel->WebmVideoURL,
                                                                        $homeModel->VideoPosterName,
                                                                        $homeModel->VideoPosterPath,

                                                                        $homeModel->ShowTopCTASection,
                                                                        $homeModel->ShowBottomCTASection,

                                                                        $homeModel->HomepageID]);

        if($results[0][0]){
            if(isset($homeModel->HomepageID) && !empty($homeModel->HomepageID) && $homeModel->HomepageID > 0 ){
                CacheHelper::CacheManage($siteID,Constants::$cacheHomeID,Constants::$cacheActionUpdate,$homeModel->HomepageID);
            }
            $response->IsSuccess = true;
            $response->Message = trans('messages.HomePagesUpdated');
        }else{
            $response->Message = trans('messages.ErrorOccured');
        }
        return $response;
    }
    public function deleteCoSlider($HomePageSliderID,$siteID){
        $response = new ServiceResponse();
        $model = new StdClass();
        $AWSUrl = Common::getAWSUrl($siteID);
        $AWSBucketName = Common::getAWSBucketName($siteID);
        $results = $this->CallRawForMultipleTable('deleteslider_co_cms',[$HomePageSliderID,$AWSUrl,$AWSBucketName],false,["IsLight"]);
        /* Colorado Home Page caching */
        CacheHelper::CacheManage($siteID,Constants::$cacheHomeID,Constants::$cacheActionUpdate,'');
        $model->SliderListArray = $results[0];
        if($results[1][0]->ResultStatus) {
            $response->Data = $model;
            $response->IsSuccess=true;
            $response->Message= trans('messages.SliderDeleted');
        } else {
            $response->Message= trans('messages.ErrorOccured');
        }
        return $response;
    }
    public function UpdateSortOrderCoSlider($OldOrder,$newOrder){
        $response = new ServiceResponse();
        $results = $this->CallRawForMultipleTable('sortordersliderlistcolorado',[$OldOrder,$newOrder]);
        /* Colorado Home Page caching */
        CacheHelper::CacheManage(Constants::$ColoradoSiteID,Constants::$cacheHomeID,Constants::$cacheActionUpdate,'');

        if($results[0][0]->ResultStatus){
            $response->IsSuccess=true;
            $response->Message= trans('messages.SliderOrder');
        }else{
            $response->Message= trans('messages.ErrorOccured');
        }
        return $response;
    }
    public function postSaveCoSlider($SliderModel,$siteID){
        $response = new ServiceResponse();
        $model = new StdClass();
        $messages = array(
            'required' => trans('messages.PropertyRequired'),
            'min' => trans('messages.PropertyMin'),
            'max' => trans('messages.PropertyMax')
        );
        $validator = Validator::make((array) $SliderModel,COHomePageSliderEntity::$Add_Edit_rules,$messages);
        $validator->setAttributeNames(COHomePageSliderEntity::$niceNameArray);
        if($validator->fails()){
            $response->Message=Common::getValidationMessagesFormat($validator->messages());
            return $response;
        }

        if(!isset($SliderModel->HomePageSliderID)){$SliderModel->HomePageSliderID = '';}
        if(!isset($SliderModel->BackgroundImagePath)){$SliderModel->BackgroundImagePath = '';}
        if(!isset($SliderModel->BackgroundImageName)){$SliderModel->BackgroundImageName = '';}
        if(!isset($SliderModel->Header)){$SliderModel->Header = '';}

        $AWSUrl = Common::getAWSUrl($siteID);
        $AWSBucketName = Common::getAWSBucketName($siteID);
        $results = $this->CallRawForMultipleTable('co_saveslider',[$SliderModel->HomePageSliderID,
            $SliderModel->BackgroundImagePath,
            $SliderModel->BackgroundImageName,
            $SliderModel->Header,
            $SliderModel->IsLight,
            $AWSUrl,
            $AWSBucketName],false,["IsLight"]);

        if($results[0][0]->ResultStatus > 0) {
            /* Colorado Home Page caching */
            CacheHelper::CacheManage($siteID,Constants::$cacheHomeID,Constants::$cacheActionUpdate,'');
            if(isset($results[1])) { $model->SliderListArray = $results[1]; }
            $response->Data = $model;
            $response->IsSuccess=true;
            if($results[0][0]->ResultStatus == 1){ $response->Message = trans('messages.SliderAddedSuccess'); }
            if($results[0][0]->ResultStatus == 2){ $response->Message = trans('messages.SliderUpdateSuccess'); }
        } else {
            $response->Message= trans('messages.ErrorOccured');
        }
        return $response;
    }
    /* Dev_AD Region End */
    public function getWW_HomeView($siteID,$loginUserID){
        $response = new ServiceResponse();
        $model = new StdClass();
        $homeModel = new StdClass();
        $homeModel->HomeDetails = new StdClass();
        $AWSUrl = Common::getAWSUrl($siteID);
        $AWSBucketName = Common::getAWSBucketName($siteID);
        $result = $this->CallRawForMultipleTable('ww_cms_homepagedetails',array($AWSUrl, $AWSBucketName),false,["ShowTopCTASection",
                                                                                                                "ShowBottomCTASection",
                                                                                                                "ShowTopCTASection1",
                                                                                                                "ShowTopCTASection2",
                                                                                                                "ShowTopCTASection3",
                                                                                                                "ShowTopCTASection4",
                                                                                                                "ShowBottomCTASection1",
                                                                                                                "ShowBottomCTASection2",
                                                                                                                "ShowSliderSection"]);
        $homeModel->HomeDetails = $result[0][0];

        //$homeModel->HomeDetails = new stdClass();
        $homeModel->HomeDetails->encryptedSiteID = Common::getEncryptedValue(Constants::$QueryStringSiteID.'='.$siteID);
        $homeModel->HomeDetails->FileUploadSettings = $this->FileUploadSettings(Constants::$AWSRequestType_Home,$siteID,$loginUserID);
        $homeModel->HomeDetails->SiteID = $siteID;
        $model->HomeModel = $homeModel;

        /* slider list */
        //$model->SliderModel = new stdClass();
        //$model->SliderModel->SliderListArray = $result[1];
        //$model->SliderModel->FileUploadSettings = $this->FileUploadSettings(Constants::$AWSRequestType_Home,$siteID,$loginUserID);
        //$model->SliderModel->SiteID = $siteID;
        $response->Data = $model;
            return $response;
    }
    public function postSaveWWHomePage($homeModel,$siteID){
        $response = new ServiceResponse();
        if(!isset($homeModel->HomepageID) || $homeModel->HomepageID == '' || $homeModel->HomepageID == NULL ){
            return $response;
        }
        $messages = array(
            'required' => trans('messages.PropertyRequired'),
            'min' => trans('messages.PropertyMin'),
            'max' => trans('messages.PropertyMax'),
        );

        $validator = Validator::make((array)$homeModel, WWHomePagesEntity::$Add_Edit_rules, $messages);
        $validator->setAttributeNames(WWHomePagesEntity::$niceNameArray);
        if ($validator->fails()) {
            $response->Message = Common::getValidationMessagesFormat($validator->messages());
            return $response;
        }

        if(!isset($homeModel->BrowserTitle)){$homeModel->BrowserTitle = '';}
        if(!isset($homeModel->CanonicalURL)){$homeModel->CanonicalURL = '';}
        if(!isset($homeModel->MetaDescription)){$homeModel->MetaDescription = '';}

        if(!isset($homeModel->FBTitle)){$homeModel->FBTitle = '';}
        if(!isset($homeModel->FBDescription)){$homeModel->FBDescription = '';}
        if(!isset($homeModel->FacebookImageName)){$homeModel->FacebookImageName = '';}
        if(!isset($homeModel->FacebookImagePath)){$homeModel->FacebookImagePath = '';}

        if(!isset($homeModel->TwitterCard)){$homeModel->TwitterCard = '';}
        if(!isset($homeModel->TwitterSite)){$homeModel->TwitterSite = '';}
        if(!isset($homeModel->TwitterTitle)){$homeModel->TwitterTitle = '';}
        if(!isset($homeModel->TwitterDescription)){$homeModel->TwitterDescription = '';}
        if(!isset($homeModel->TwitterImageName)){$homeModel->TwitterImageName = '';}
        if(!isset($homeModel->RealTwitterImagePath)){$homeModel->RealTwitterImagePath = '';}

        if(!isset($homeModel->Headline)){$homeModel->Headline = '';}
        if(!isset($homeModel->Description)){$homeModel->Description = '';}
        if(!isset($homeModel->RichSnippetImageName)){$homeModel->RichSnippetImageName = '';}
        if(!isset($homeModel->RichSnippetImagePath)){$homeModel->RichSnippetImagePath = '';}

        if(!isset($homeModel->TopCTATitle1)){$homeModel->TopCTATitle1 = '';}
        if(!isset($homeModel->TopCTADescription1)){$homeModel->TopCTADescription1 = '';}
        if(!isset($homeModel->TopCTALinkText1)){$homeModel->TopCTALinkText1 = '';}
        if(!isset($homeModel->TopCTALinkURL1)){$homeModel->TopCTALinkURL1 = '';}
        if(!isset($homeModel->TopCTAImageName1)){$homeModel->TopCTAImageName1 = '';}
        if(!isset($homeModel->TopCTAImagePath1)){$homeModel->TopCTAImagePath1 = '';}
        if(!isset($homeModel->TopCTAHoverImageName1)){$homeModel->TopCTAHoverImageName1 = '';}
        if(!isset($homeModel->TopCTAHoverImagePath1)){$homeModel->TopCTAHoverImagePath1 = '';}
        if(!isset($homeModel->ShowTopCTASection1)){$homeModel->ShowTopCTASection1 = 0;}

        if(!isset($homeModel->TopCTATitle2)){$homeModel->TopCTATitle2 = '';}
        if(!isset($homeModel->TopCTADescription2)){$homeModel->TopCTADescription2 = '';}
        if(!isset($homeModel->TopCTALinkText2)){$homeModel->TopCTALinkText2 = '';}
        if(!isset($homeModel->TopCTALinkURL2)){$homeModel->TopCTALinkURL2 = '';}
        if(!isset($homeModel->TopCTAImageName2)){$homeModel->TopCTAImageName2 = '';}
        if(!isset($homeModel->TopCTAImagePath2)){$homeModel->TopCTAImagePath2 = '';}
        if(!isset($homeModel->TopCTAHoverImageName2)){$homeModel->TopCTAHoverImageName2 = '';}
        if(!isset($homeModel->TopCTAHoverImagePath2)){$homeModel->TopCTAHoverImagePath2 = '';}
        if(!isset($homeModel->ShowTopCTASection2)){$homeModel->ShowTopCTASection2 = 0;}

        if(!isset($homeModel->TopCTATitle3)){$homeModel->TopCTATitle3 = '';}
        if(!isset($homeModel->TopCTADescription3)){$homeModel->TopCTADescription3 = '';}
        if(!isset($homeModel->TopCTALinkText3)){$homeModel->TopCTALinkText3 = '';}
        if(!isset($homeModel->TopCTALinkURL3)){$homeModel->TopCTALinkURL3 = '';}
        if(!isset($homeModel->TopCTAImageName3)){$homeModel->TopCTAImageName3 = '';}
        if(!isset($homeModel->TopCTAImagePath3)){$homeModel->TopCTAImagePath3 = '';}
        if(!isset($homeModel->TopCTAHoverImageName3)){$homeModel->TopCTAHoverImageName3 = '';}
        if(!isset($homeModel->TopCTAHoverImagePath3)){$homeModel->TopCTAHoverImagePath3 = '';}
        if(!isset($homeModel->ShowTopCTASection3)){$homeModel->ShowTopCTASection3 = 0;}

        if(!isset($homeModel->TopCTATitle4)){$homeModel->TopCTATitle4 = '';}
        if(!isset($homeModel->TopCTADescription4)){$homeModel->TopCTADescription4 = '';}
        if(!isset($homeModel->TopCTALinkText4)){$homeModel->TopCTALinkText4 = '';}
        if(!isset($homeModel->TopCTALinkURL4)){$homeModel->TopCTALinkURL4 = '';}
        if(!isset($homeModel->TopCTAImageName4)){$homeModel->TopCTAImageName4 = '';}
        if(!isset($homeModel->TopCTAImagePath4)){$homeModel->TopCTAImagePath4 = '';}
        if(!isset($homeModel->TopCTAHoverImageName4)){$homeModel->TopCTAHoverImageName4 = '';}
        if(!isset($homeModel->TopCTAHoverImagePath4)){$homeModel->TopCTAHoverImagePath4 = '';}
        if(!isset($homeModel->ShowTopCTASection4)){$homeModel->ShowTopCTASection4 = 0;}

        if(!isset($homeModel->BottomCTAHeaderText1)){$homeModel->BottomCTAHeaderText1 = '';}
        if(!isset($homeModel->BottomCTAHeaderTitle1)){$homeModel->BottomCTAHeaderTitle1 = '';}
        if(!isset($homeModel->BottomCTADescription1)){$homeModel->BottomCTADescription1 = '';}
        if(!isset($homeModel->BottomCTAButtonText1)){$homeModel->BottomCTAButtonText1 = '';}
        if(!isset($homeModel->BottomCTAButtonLink1)){$homeModel->BottomCTAButtonLink1 = '';}
        if(!isset($homeModel->BottomCTAImagePath1)){$homeModel->BottomCTAImagePath1 = '';}
        if(!isset($homeModel->BottomCTAImageName1)){$homeModel->BottomCTAImageName1 = '';}
        if(!isset($homeModel->ShowBottomCTASection1)){$homeModel->ShowBottomCTASection1 = 0;}

        if(!isset($homeModel->BottomCTAHeaderText2)){$homeModel->BottomCTAHeaderText2 = '';}
        if(!isset($homeModel->BottomCTAHeaderTitle2)){$homeModel->BottomCTAHeaderTitle2 = '';}
        if(!isset($homeModel->BottomCTADescription2)){$homeModel->BottomCTADescription2 = '';}
        if(!isset($homeModel->BottomCTAButtonText2)){$homeModel->BottomCTAButtonText2 = '';}
        if(!isset($homeModel->BottomCTAButtonLink2)){$homeModel->BottomCTAButtonLink2 = '';}
        if(!isset($homeModel->BottomCTAImagePath2)){$homeModel->BottomCTAImagePath2 = '';}
        if(!isset($homeModel->BottomCTAImageName2)){$homeModel->BottomCTAImageName2 = '';}
        if(!isset($homeModel->ShowBottomCTASection2)){$homeModel->ShowBottomCTASection2 = 0;}

        if(!isset($homeModel->SliderTitle)){$homeModel->SliderTitle = '';}
        if(!isset($homeModel->SliderDescription)){$homeModel->SliderDescription = '';}
        if(!isset($homeModel->SliderLinkText)){$homeModel->SliderLinkText = '';}
        if(!isset($homeModel->SliderLink)){$homeModel->SliderLink = '';}
        if(!isset($homeModel->SliderImagePath)){$homeModel->SliderImagePath = '';}
        if(!isset($homeModel->SliderImageName)){$homeModel->SliderImageName = '';}
        if(!isset($homeModel->ShowSliderSection)){$homeModel->ShowSliderSection = 0;}

        $results = $this->CallRawForMultipleTable('ww_savehomepage', [
                                                                        $homeModel->BrowserTitle,
                                                                        $homeModel->CanonicalURL,
                                                                        $homeModel->MetaDescription,
                                                                        $homeModel->FBTitle,
                                                                        $homeModel->FBDescription,
                                                                        $homeModel->FacebookImageName,
                                                                        $homeModel->FacebookImagePath,

                                                                        $homeModel->TwitterCard,
                                                                        $homeModel->TwitterSite,
                                                                        $homeModel->TwitterTitle,
                                                                        $homeModel->TwitterDescription,
                                                                        $homeModel->TwitterImageName,
                                                                        $homeModel->TwitterImagePath,

                                                                        $homeModel->Headline,
                                                                        $homeModel->Description,
                                                                        $homeModel->RichSnippetImageName,
                                                                        $homeModel->RichSnippetImagePath,


                                                                        $homeModel->TopCTATitle1,
                                                                        $homeModel->TopCTADescription1,
                                                                        $homeModel->TopCTALinkText1,
                                                                        $homeModel->TopCTALinkURL1,
                                                                        $homeModel->TopCTAImageName1,
                                                                        $homeModel->TopCTAImagePath1,
                                                                        $homeModel->TopCTAHoverImageName1,
                                                                        $homeModel->TopCTAHoverImagePath1,
                                                                        $homeModel->ShowTopCTASection1,

                                                                        $homeModel->TopCTATitle2,
                                                                        $homeModel->TopCTADescription2,
                                                                        $homeModel->TopCTALinkText2,
                                                                        $homeModel->TopCTALinkURL2,
                                                                        $homeModel->TopCTAImageName2,
                                                                        $homeModel->TopCTAImagePath2,
                                                                        $homeModel->TopCTAHoverImageName2,
                                                                        $homeModel->TopCTAHoverImagePath2,
                                                                        $homeModel->ShowTopCTASection2,

                                                                        $homeModel->TopCTATitle3,
                                                                        $homeModel->TopCTADescription3,
                                                                        $homeModel->TopCTALinkText3,
                                                                        $homeModel->TopCTALinkURL3,
                                                                        $homeModel->TopCTAImageName3,
                                                                        $homeModel->TopCTAImagePath3,
                                                                        $homeModel->TopCTAHoverImageName3,
                                                                        $homeModel->TopCTAHoverImagePath3,
                                                                        $homeModel->ShowTopCTASection3,

                                                                        $homeModel->TopCTATitle4,
                                                                        $homeModel->TopCTADescription4,
                                                                        $homeModel->TopCTALinkText4,
                                                                        $homeModel->TopCTALinkURL4,
                                                                        $homeModel->TopCTAImageName4,
                                                                        $homeModel->TopCTAImagePath4,
                                                                        $homeModel->TopCTAHoverImageName4,
                                                                        $homeModel->TopCTAHoverImagePath4,
                                                                        $homeModel->ShowTopCTASection4,

                                                                        $homeModel->BottomCTAHeaderText1,
                                                                        $homeModel->BottomCTAHeaderTitle1,
                                                                        $homeModel->BottomCTADescription1,
                                                                        $homeModel->BottomCTAButtonText1,
                                                                        $homeModel->BottomCTAButtonLink1,
                                                                        $homeModel->BottomCTAImagePath1,
                                                                        $homeModel->BottomCTAImageName1,
                                                                        $homeModel->ShowBottomCTASection1,

                                                                        $homeModel->BottomCTAHeaderText2,
                                                                        $homeModel->BottomCTAHeaderTitle2,
                                                                        $homeModel->BottomCTADescription2,
                                                                        $homeModel->BottomCTAButtonText2,
                                                                        $homeModel->BottomCTAButtonLink2,
                                                                        $homeModel->BottomCTAImagePath2,
                                                                        $homeModel->BottomCTAImageName2,
                                                                        $homeModel->ShowBottomCTASection2,

                                                                        $homeModel->ShowTopCTASection,
                                                                        $homeModel->ShowBottomCTASection,

                                                                        $homeModel->SliderTitle,
                                                                        $homeModel->SliderDescription,
                                                                        $homeModel->SliderLinkText,
                                                                        $homeModel->SliderLink,
                                                                        $homeModel->SliderImagePath,
                                                                        $homeModel->SliderImageName,
                                                                        $homeModel->ShowSliderSection,

                                                                        $homeModel->HomepageID]);
        if($results[0][0]){
            if(isset($homeModel->HomepageID) && !empty($homeModel->HomepageID) && $homeModel->HomepageID > 0 ){
                CacheHelper::CacheManage($siteID,Constants::$cacheHomeID,Constants::$cacheActionUpdate,$homeModel->HomepageID);
            }
            $response->IsSuccess = true;
            $response->Message = trans('messages.HomePagesUpdated');
        }else{
            $response->Message = trans('messages.ErrorOccured');
        }
        return $response;
    }
    public function UpdateSortOrderWWSlider($OldOrder,$newOrder){
        $response = new ServiceResponse();
        $results = $this->CallRawForMultipleTable('sortordersliderlistww',[$OldOrder,$newOrder]);
        /* Colorado Home Page caching */
        CacheHelper::CacheManage(Constants::$WoodBridgeWealthSiteID,Constants::$cacheHomeID,Constants::$cacheActionUpdate,'');

        if($results[0][0]->ResultStatus){
            $response->IsSuccess=true;
            $response->Message= trans('messages.SliderOrder');
        }else{
            $response->Message= trans('messages.ErrorOccured');
        }
        return $response;
    }
    public function postSaveWWSlider($SliderModel,$siteID){
        $response = new ServiceResponse();
        $model = new StdClass();
        $messages = array(
            'required' => trans('messages.PropertyRequired'),
            'min' => trans('messages.PropertyMin'),
            'max' => trans('messages.PropertyMax')
        );
        $validator = Validator::make((array) $SliderModel,WWHomePageSliderEntity::$Add_Edit_rules,$messages);
        $validator->setAttributeNames(WWHomePageSliderEntity::$niceNameArray);
        if($validator->fails()){
            $response->Message=Common::getValidationMessagesFormat($validator->messages());
            return $response;
        }

        if(!isset($SliderModel->HomePageSliderID)){$SliderModel->HomePageSliderID = '';}
        if(!isset($SliderModel->BackgroundImagePath)){$SliderModel->BackgroundImagePath = '';}
        if(!isset($SliderModel->BackgroundImageName)){$SliderModel->BackgroundImageName = '';}
        if(!isset($SliderModel->Title)){$SliderModel->Title = '';}
        if(!isset($SliderModel->Description)){$SliderModel->Description = '';}
        if(!isset($SliderModel->LinkText)){$SliderModel->LinkText = '';}
        if(!isset($SliderModel->LinkURL)){$SliderModel->LinkURL = '';}

        $AWSUrl = Common::getAWSUrl($siteID);
        $AWSBucketName = Common::getAWSBucketName($siteID);
        $results = $this->CallRawForMultipleTable('ww_saveslider',[$SliderModel->HomePageSliderID,
                                                                    $SliderModel->BackgroundImagePath,
                                                                    $SliderModel->BackgroundImageName,
                                                                    $SliderModel->Title,
                                                                    $SliderModel->Description,
                                                                    $SliderModel->LinkText,
                                                                    $SliderModel->LinkURL,
                                                                    $SliderModel->IsLight,
                                                                    $AWSUrl,
                                                                    $AWSBucketName],false,["IsLight"]);

        if($results[0][0]->ResultStatus > 0) {

            /* WW Home Page caching */
            CacheHelper::CacheManage($siteID,Constants::$cacheHomeID,Constants::$cacheActionUpdate,'');
            if(isset($results[1])) { $model->SliderListArray = $results[1]; }
            $response->Data = $model;
            $response->IsSuccess=true;
            if($results[0][0]->ResultStatus == 1){ $response->Message = trans('messages.SliderAddedSuccess'); }
            if($results[0][0]->ResultStatus == 2){ $response->Message = trans('messages.SliderUpdateSuccess'); }
        } else {
            $response->Message= trans('messages.ErrorOccured');
        }
        return $response;
    }
    public function deleteWWSlider($HomePageSliderID,$siteID){
        $response = new ServiceResponse();
        $model = new StdClass();
        $AWSUrl = Common::getAWSUrl($siteID);
        $AWSBucketName = Common::getAWSBucketName($siteID);
        $results = $this->CallRawForMultipleTable('deleteslider_ww_cms',[$HomePageSliderID,$AWSUrl,$AWSBucketName],false,["IsLight"]);

        /* WW Home Page caching */
        CacheHelper::CacheManage($siteID,Constants::$cacheHomeID,Constants::$cacheActionUpdate,'');
        $model->SliderListArray = $results[0];
        if($results[1][0]->ResultStatus) {
            $response->Data = $model;
            $response->IsSuccess=true;
            $response->Message= trans('messages.SliderDeleted');
        } else {
            $response->Message= trans('messages.ErrorOccured');
        }
        return $response;
    }
}