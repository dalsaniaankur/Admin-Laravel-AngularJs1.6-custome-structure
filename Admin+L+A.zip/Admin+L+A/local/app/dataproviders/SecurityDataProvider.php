<?php
namespace dataproviders;
use Illuminate\Support\Facades\Validator;
use \UserEntity;
use \ViewModels\ServiceResponse;
use \Infrastructure\Constants;
use \Infrastructure\Common;
use \stdClass;
use \DateTime;
use \Crypt;
use Illuminate\Support\Facades\URL;
use \Mail;
use \ViewModels\SearchValueModel;
use File;
use TokensEntity;
use \Infrastructure\CacheHelper;
class SecurityDataProvider extends BaseDataProvider implements ISecurityDataProvider {

    /* RB Region Start */
    public function AuthenticateUser($loginModel){
        $response = new ServiceResponse();
        $authModel=new StdClass();

        $messages = array(
            'required' => trans('messages.PropertyRequired')
        );

        $validator = Validator::make((array)$loginModel, array('Email'=>'required','Password'=>'required'),$messages);
        $validator->setAttributeNames(UserEntity::$niceNameArray);
        if ($validator->fails()){
            $response->Message = Common::getValidationMessagesFormat($validator->messages());
            return $response;
        }

        $hashedPassword = md5($loginModel->Password);

        $loggedUserResults = $this->CallRawForSingleTable('loginusers',[$loginModel->Email,$hashedPassword]);
        if(is_null($loggedUserResults)){
            $response->Message = trans('messages.ErrorOccured');
        }else{
            switch ($loggedUserResults[0]->LoginStatus) {
                case Constants::$LoginNotFound:
                    $response->Message = trans('messages.InvalidUserNamePassword');
                    break;
                case Constants::$UserNotVerified:
                    $authModel->PendingUserID = intval($loggedUserResults[1][0]->PendingUserID);
                    $authModel->IsPending = Constants::$Value_True;
                    $authModel->IsPendingSuccess = Constants::$Value_False;
                    break;
                case Constants::$UserStatusDisable:
                    $response->Message = trans('messages.AccountDisable');
                    break;
                case Constants::$UserHaveNoRole:
                    $response->Message = trans('messages.AccountDisable');
                    break;
                case Constants::$UserStatusActiveWithOneSiteAccess:
                    $userDetails = Common::getEloquentModel(new UserEntity(),$loggedUserResults[1][0]);
                    $authModel->roleList = $loggedUserResults[2];
                    $response->Message = trans('messages.LoginSuccess');
                    $response->IsSuccess = true;
                    break;
                case Constants::$UserStatusActive:
                    $userDetails = Common::getEloquentModel(new UserEntity(),$loggedUserResults[1][0]);
                    $authModel->roleList = $loggedUserResults[2];
                    $response->Message = trans('messages.LoginSuccess');
                    $response->IsSuccess = true;
                    break;
                case Constants::$LoginError:
                    $response->Message = trans('messages.ErrorOccured');
                    break;

            }
        }

        $authModel->redirectToChooseSite = $loggedUserResults[0]->LoginStatus == Constants::$UserStatusActive ?  Constants::$Value_True: Constants::$Value_False;
        $response->Data = $authModel;
        if(isset($userDetails)){
            $response->Data->UserDetails = $userDetails;
        }
        return $response;
    }

    public function SendVerificationEmail($userID,$siteID,$createByID){
        $response = new ServiceResponse();
        $verificationModel = new StdClass();

        $searchParams=Array();

        $searchValueData=new SearchValueModel();
        $searchValueData->Name="UserID";
        $searchValueData->Value=$userID;
        array_push($searchParams, $searchValueData);

        $pendingUserDetails = $this->GetEntity(new UserEntity(),$searchParams);

        $now =new DateTime("now");
        $token= $pendingUserDetails->Email."|".$now->format(Constants::$DefaultDateTimeFormat);
        $encrypted = Crypt::encrypt($token);

        $TokenEntity = new TokensEntity();

        $TokenEntity->EncryptedToken=$encrypted;
        $TokenEntity->UserID=$pendingUserDetails->UserID;
        $TokenEntity->IsUsed=Constants::$IsNotused;
        $TokenEntity->IsForVerification=Constants::$IsForVerification;

        $TokenEntity->save();

        $emailData = new stdClass();
        $emailData->FirstName = $pendingUserDetails->FirstName;
        $emailData->Link =URL::to('forgotpassword')."/".$encrypted;
        $emailData->CreatedBy = $createByID? $createByID:$userID;
        $emailData->SiteID = $siteID;
        $data = (array)$emailData;

        $LastSendEmail = common::SendEmail(Constants::$Email_VerificationEmail, $data, Constants::$Email_VerificationEmailSubject,$pendingUserDetails->Email, "", "","",$sendInstantEmail=1);

        $response->IsSuccess = true;
        $verificationModel->IsPendingSuccess = Constants::$Value_True;
        $response->Data = $verificationModel;
        $response->Message = trans('messages.ForgotEmailSent');
        return $response;
    }
    /* RB Region End */


    /* Dev_AD Region Start */
    public function SendResetPasswordEmail($userData){

        $response = new ServiceResponse();
        $ResetPasswordModel = new StdClass();
        $ResetEmailResults = $this->CallRawForSingleTable('resetpasswordmail',[$userData->Email]);
        if(is_null($ResetEmailResults)){
            $response->Message = trans('messages.ErrorOccured');
        }else {
            switch ($ResetEmailResults[0]->usersStatus) {
                case Constants::$UserNotFound:
                    $ResetPasswordModel->IsPending = Constants::$Value_False;
                    $response->Message = trans('messages.NoUserWithThisEmail');
                    break;
                case Constants::$IsVerified_False:
                    $ResetPasswordModel->PendingUserID = intval($ResetEmailResults[0]->UserID);
                    $ResetPasswordModel->IsPending = Constants::$Value_True;
                    $response->Message = trans('messages.UserPending');
                    break;
                case Constants::$IsVerified_True:  //case Constants::$UserActive:
                    $ResetEmailResults[0]->usersStatus;
                    $ResetEmailResults[0]->UserID;

                    if($ResetEmailResults[1][0]->NoAccessCount == 0){
                        $ResetPasswordModel->PendingUserID = "";
                        $ResetPasswordModel->IsPending = Constants::$Value_False;
                        $response->Message = trans('messages.AccountDisable');
                        break;
                    }else {
                        $now = new DateTime("now");
                        $token = $userData->Email . "|" . $now->format(Constants::$DefaultDateTimeFormat);
                        $encrypted = Crypt::encrypt($token);

                        $TokenEntity = new TokensEntity();

                        $TokenEntity->EncryptedToken = $encrypted;
                        $TokenEntity->UserID = $ResetEmailResults[0]->UserID;
                        $TokenEntity->IsUsed = Constants::$IsNotused;
                        $TokenEntity->save();

                        $emailData = new stdClass();
                        $emailData->FirstName = $ResetEmailResults[0]->FirstName;
                        $emailData->Link = URL::to('forgotpassword') . "/" . $encrypted;
                        $emailData->CreatedBy = $ResetEmailResults[0]->UserID;
                        $data = (array)$emailData;
                        $ResetPasswordSendEmail = Common::SendEmail(Constants::$Email_ResetPasswordEmail, $data, Constants::$Email_ResetPasswordEmailSubject, $userData->Email, "", "","",$sendInstantEmail=1);

                        if ($ResetPasswordSendEmail) {
                            $response->IsSuccess = true;
                            $response->Message = trans('messages.ForgotEmailSent');
                        }
                    }
                    break;
                }
            }
                $response->Data = $ResetPasswordModel;
                return $response;
    }

    public function GetForgotPassword($token){
        $response = new ServiceResponse();

        $searchParams = array();
        $searchValueData=new SearchValueModel();
        $searchValueData->Name="EncryptedToken";
        $searchValueData->Value=$token;
        array_push($searchParams, $searchValueData);

        $tokenDetail = $this->GetEntity(new TokensEntity(),$searchParams);

        if(empty($tokenDetail)){

            $response->IsSuccess=false;
            $response->Message = trans('messages.UserNotFound');
            return $response;

        }else if($tokenDetail->IsUsed == Constants::$Isused){

            $response->IsSuccess=false;
            $response->Message = trans('messages.ResetEmailUsed');
            return $response;

        }else{

            $tokenEntity=$this->GetEntityForUpdateByPrimaryKey(new TokensEntity(),$tokenDetail->TokenID);
            $tokenEntity->IsUsed=Constants::$Value_True;
            $IsForVerification = $tokenEntity->IsForVerification;
            $this->SaveEntity($tokenEntity);

            $data = new stdClass();
            $searchParams = array();
            $searchValueData=new SearchValueModel();
            $searchValueData->Name="UserID";
            $searchValueData->Value=$tokenEntity->UserID;
            array_push($searchParams, $searchValueData);

            $userEntity = $this->GetEntity(new UserEntity(),$searchParams);

            $data->ForgotModel = $userEntity;
            $data->ForgotModel->Password="";
            $data->ForgotModel->IsForVerification=$IsForVerification;
            $response->IsSuccess=true;
            $response->Data = $data;
        }
            return $response;
    }

    public function postResetPasswordEmail($userModel){
        $response = new ServiceResponse();
        $userEntity=$this->GetEntityForUpdateByPrimaryKey(new UserEntity(),$userModel->UserID);
        $userEntity->Password=md5($userModel->Password);
        if($userModel->IsForVerification == 1) {
            $userEntity->IsVerified = Constants::$IsVerified_True;
        }
        if($this->SaveEntity($userEntity)) {
            $IsAgent=$this->CallRawForMultipleTable('checkagentrole',array($userModel->UserID,Constants::$MercerVineSiteID));
            /* For MV */
            if($IsAgent && isset($IsAgent[0][0]->UserID)){
                    CacheHelper::CacheManage(Constants::$MercerVineSiteID,Constants::$cacheAgentID,Constants::$cacheActionInsert,'');
            }
            /* For colorado */
            if($IsAgent && isset($IsAgent[1][0]->UserID)){
                    CacheHelper::CacheManage(Constants::$ColoradoSiteID,Constants::$cacheAgentID,Constants::$cacheActionInsert,'');
            }
            if($userModel->IsForVerification != 1) {
                $emailData = new stdClass();
                $emailData->FirstName = $userEntity->FirstName;
                $emailData->LoginLink = URL::to('/');
                $emailData->CreatedBy = $userModel->UserID;
                $data = (array)$emailData;
                $PasswordResetConfirmation = common::SendEmail(Constants::$Email_ResetPassword_Confirmation_Email, $data, Constants::$Email_ResetPassword_Confirmation_EmailSubject, $userEntity->Email, "", "", "", $sendInstantEmail = 1);
            }
            $response->IsSuccess = true;
            $response->Message = $userModel->IsForVerification != 1 ? trans('messages.ResetPasswordSuccess'):trans('messages.VerificationSuccessMessage') ;
        }else{
            $response->IsSuccess = false;
            $response->Message = trans('messages.ResetPasswordError');
        }
        return $response;
    }
    /* Blog and page list Model */
    public function getSearchModelForBlogList()
    {
        $response = new ServiceResponse();
        $model = new stdClass();
        $ListModel = new stdClass();

        $searchModel = new stdClass();
        $model->frontSearchModel = $searchModel;
        $model->backSearchModel = $searchModel;
        $ListModel->BlogModel = $model;

        $model->frontSearchModel = $searchModel;
        $model->backSearchModel = $searchModel;
        $ListModel->PageModel = $model;

        $response->Data = $ListModel;
        return $response;
    }

    /* Blog List */
    public function getBlogInfoList($blogData, $loggedInUserID,$SiteID)
    {
        $response = new ServiceResponse();
        if (empty($blogData->SortIndex)) {
            $blogData->SortIndex = Constants::$SortIndex;
        }
        if (empty($blogData->SortDirection)) {
            $blogData->SortDirection = Constants::$SortIndexASC;
        }
        $sortIndex = $blogData->SortIndex;
        $sortDirection = $blogData->SortDirection;
        $pageIndex = $blogData->PageIndex;
        $pageSizeCount = $blogData->PageSize;

        $blogList = $this->GetPageRecordsUsingSP('dashboardblogpostlist', $pageIndex, $pageSizeCount, [$pageIndex, $pageSizeCount, $sortIndex, $sortDirection, $SiteID, $loggedInUserID]);
        if (is_null($blogList)) {
            $response->Message = trans('messages.NoRecordFound');
        } else {
            $response->IsSuccess = true;
            $response->Data = $blogList;
        }
        return $response;
    }

    /* Page List */
    public function getPageInfoList($pageData, $loggedInUserID,$SiteID)
    {
        $response = new ServiceResponse();
        if (empty($pageData->SortIndex)) {
            $pageData->SortIndex = Constants::$SortIndex;
        }
        if (empty($pageData->SortDirection)) {
            $pageData->SortDirection = Constants::$SortIndexASC;
        }
        $sortIndex = $pageData->SortIndex;
        $sortDirection = $pageData->SortDirection;
        $pageIndex = $pageData->PageIndex;
        $pageSizeCount = $pageData->PageSize;

        $pageList = $this->GetPageRecordsUsingSP('dashboardpagelist', $pageIndex, $pageSizeCount, [$pageIndex, $pageSizeCount, $sortIndex, $sortDirection, $SiteID, $loggedInUserID]);
        if (is_null($pageList)) {
            $response->Message = trans('messages.NoRecordFound');
        } else {
            $response->IsSuccess = true;
            $response->Data = $pageList;
        }
        return $response;
    }
    /* Dev_AD Region End */


    /* Dev_DN Region Start */


    /* Dev_DN Region End */
}