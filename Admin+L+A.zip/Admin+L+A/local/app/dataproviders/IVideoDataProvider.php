<?php 
namespace dataproviders;

Interface IVideoDataProvider{

    /*Start Region Dev_Vishal*/
    
    /*Stop Region Dev_Vishal*/

    /*RB Start*/
    
    /*RB End*/

    /*AD Start*/
    public function getVideoTypeDetails($videoID,$siteID);
    public function AddVideoData($VideoModel,$loginUserID,$siteID);
    public function DeleteVideo($VideoID,$siteID,$developmentID);
    public function getSearchModelForVideoList($SiteID);
    public function UpdateSortOrderVideo($OldOrder,$newOrder,$SiteID);
    /*AD  End*/


    /*DN Start*/

    /*DN  End*/
}
