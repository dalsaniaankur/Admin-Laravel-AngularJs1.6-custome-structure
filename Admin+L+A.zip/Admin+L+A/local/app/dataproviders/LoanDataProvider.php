<?php
namespace dataproviders;
use Illuminate\Support\Facades\Validator;
use Infrastructure\CacheHelper;
use \ViewModels\ServiceResponse;
use \Infrastructure\Constants;
use \Infrastructure\Common;
use \stdClass;
use \Crypt;
use Illuminate\Support\Facades\URL;
use \Mail;
use File;
use LoanEntity;
use LoanImagesEntity;
use Illuminate\Support\Facades\Config;

class LoanDataProvider extends BaseDataProvider implements ILoanDataProvider {

    /* Dev_UP Region Start */
    public function getSearchModelForLoanList($siteID){
        $response = new ServiceResponse();
        $model = new StdClass();
        $loanModel = new StdClass();

        $AWSUrl = Common::getAWSUrl($siteID);
        $AWSBucketName = Common::getAWSBucketName($siteID);

        $loanDetail = $this->CallRawForMultipleTable('loanlist',[$AWSUrl, $AWSBucketName]);
        $loanModel->LoanListArray = $loanDetail[0];
        $model->LoanModel = $loanModel;
        $response->Data = $model;
        return $response;
    }

    public function UpdateSortOrderLoan($OldOrder,$newOrder,$siteID){
        $response = new ServiceResponse();
        $addLoanResults = $this->CallRawForMultipleTable('sortorderloanlist',[$OldOrder,$newOrder,$siteID]);
        CacheHelper::CacheManage($siteID,Constants::$cacheLoansClosedID,Constants::$cacheActionUpdate,'');
        $response->IsSuccess=true;
        $response->Message= trans('messages.LoanOrder');
        return $response;
    }

    public function DeleteLoan($LoanID,$siteID){
        $response = new ServiceResponse();

         $getLoanImagesResults = $this->CallRawForMultipleTable('getloanimages',[$LoanID,$siteID]);

         foreach ($getLoanImagesResults[0] as $imageKey => $imageValue) {
             if(count($imageValue))
             {
                $data = $this->Awsdeletefile($imageValue->FilePath,$siteID);   // Remove Image from AWS
                
                if ($data && isset($imageValue->LoanImageId)) {
                    $deleteLoanImageResults = $this->CallRawForMultipleTable('deleteallloanimages',[$imageValue->LoanImageId]);
                }

             }
         }
        $deleteLoanResults = $this->CallRawForMultipleTable('deleteloan',[$LoanID,$siteID]);
        CacheHelper::CacheManage($siteID,Constants::$cacheLoansClosedID,Constants::$cacheActionDelete,$LoanID);
        if($deleteLoanResults[0][0]->ResultStatus) {
            $response->IsSuccess=true;
            $response->Message= trans('messages.LoanDeleted');
            $response->RedirectUrl= URL::to('/')."/loans/".Common::getEncryptedValue(Constants::$QueryStringSiteID.'='.$siteID);
        } else {
            $response->Message= trans('messages.ErrorOccured');
        }
        return $response;
    }

    public function RemoveImage($fileRemoveData,$siteID){
        $response = new ServiceResponse();
        $deleteModel = new StdClass();
        if (isset($fileRemoveData)) {
            $data = $this->Awsdeletefile($fileRemoveData->filePath,$siteID);  // Remove Image from AWS
            if ($data && isset($fileRemoveData->ImageID)) {  // Delete images from database if ImageID found during edit page.
                $query = "delete from loanimages where LoanImageID=$fileRemoveData->ImageID";
                $this->RunQueryStatement($query, Constants::$QueryType_Delete);
            }
            if(isset($fileRemoveData->filePath) && isset($fileRemoveData->IsDefaultImage)){ // set variable IsDeleteDefaultImages to 1 if use delete the default selected image.
                if($fileRemoveData->IsDefaultImage == $fileRemoveData->filePath){
                    $deleteModel->IsDeleteDefaultImages = Constants::$Value_True;
                }
            }
            $response->IsSuccess = true;
            $deleteModel->Key = $fileRemoveData->fileToRemoveKey;  //send the removed array KEY.
            $response->Data = $deleteModel;
            $response->Message = trans('messages.ImageRemovedSuccess');
        } else {
            $response->Message = trans('messages.ErrorOccured');
        }
        return $response;
    }
    /* Dev_UP Region End */

    public function getLoanData($LoanID,$SiteID,$UserID){
        $response = new ServiceResponse();
        $model = new StdClass();
        $LoanModel = new StdClass();
        if($LoanID>0){
            $searchParams = Array();
            $searchValueData = Common::SetSearchArray('LoanID',$LoanID);
            array_push($searchParams, $searchValueData);
            $LoanDetails = $this->GetEntity(new LoanEntity(), $searchParams);
            $LoanDetails->UploadedFileArray = $this->GetEntityList(new LoanImagesEntity(),$searchParams);
            foreach ($LoanDetails->UploadedFileArray as $fileArray) {
                $fileArray->IsSavedInDB=1;
                if($fileArray->IsDefaultImage==1){
                    $LoanDetails->IsDefaultImage ="1"; // For check if user remove "default selected" image and go to any other page and come back again development page and save then set "default image required"
                }else{
                    $LoanDetails->IsDefaultImage='';
                }
            }
        }
        else {
            $LoanEntity = new LoanEntity();
            $LoanEntity->LoanID = Constants::$Value_False;
            $LoanEntity->SiteID = $SiteID;
            $LoanDetails = $LoanEntity;
            $LoanDetails->RealTopImagePath ='';
        }
        $LoanModel= $LoanDetails;
        $LoanModel->FileUploadSettings = $this->FileUploadSettings(Constants::$AWSRequestType_Loan,$SiteID,$UserID);
        $LoanModel->UploadFilesArray ='';

        $model->LoanModel = $LoanModel;
        $response->Data = $model;
        return $response;
    }

    public function SaveLoan($LoanModel,$UserID,$SiteID){
        $response = new ServiceResponse();
        $messages = array(
            'required' => trans('messages.PropertyRequired'),
            'min' => trans('messages.PropertyMin'),
            'max' => trans('messages.PropertyMax'),
        );
        $LoanID = $LoanModel->LoanID;
        $validator = Validator::make((array)$LoanModel, $LoanID > 0 ? LoanEntity::$Edit_rules : LoanEntity::$Add_rules, $messages);
        $validator->setAttributeNames(LoanEntity::$niceNameArray);
        if ($validator->fails()) {
            $response->Message = Common::getValidationMessagesFormat($validator->messages());
            return $response;
        }
        $isEditMode = false;
        if($LoanModel->LoanID>0){
            $isEditMode = true;
        }
        $purpose='';
        $dateFunded=null;
        $propertyType='';
        $title=$LoanModel->Title;
        $amount=$LoanModel->LoanAmount;
        if(isset($LoanModel->Purpose))
            $purpose=$LoanModel->Purpose;
        if(isset($LoanModel->DateFunded) && $LoanModel->DateFunded!='')
            $dateFunded=date(Constants::$YMDDateFormatServerSide,strtotime($LoanModel->DateFunded));
        if(isset($LoanModel->PropertyType))
            $propertyType=$LoanModel->PropertyType;
        $CreatedByID = $UserID;
        $ModifiedByID = $UserID;

        $addLoanResults = $this->CallRawForMultipleTable('saveloan', [$LoanID,$title,$purpose,$amount,$dateFunded,$propertyType,$SiteID,$CreatedByID,$ModifiedByID]);

        if(!$isEditMode){
            $LoanID=$addLoanResults[0][0]->LoanID;
        }

        /* For Image Upload Section start */
        if($addLoanResults && !empty($LoanModel->UploadFilesArray)){

            // Deleted deleted images from database during edit page.
            if($isEditMode){
                $filteredImageFile = array_values(array_filter($LoanModel->UploadFilesArray,function($site){
                    return	isset($site['LoanImageID']);
                }));
                $imageIDCsv = implode(',',array_map(create_function('$o', 'return $o["LoanImageID"];'), $filteredImageFile));
                if(isset($imageIDCsv)){
                    $this->CallRawForMultipleTable('deleteloanimages',[$LoanModel->LoanID,$imageIDCsv]);
                }
            }

            // instead of array_filter keep condition while processing data in foreach.
            // Filter array  for during add page upload all the images. and during edit time only newly added images save in DB.
            if($isEditMode){
                $isSavedInDB = Constants::$Value_False;
                $uploadFileArray = array_values(array_filter($LoanModel->UploadFilesArray,function($site) use ($isSavedInDB){
                    return	$site['IsSavedInDB'] == $isSavedInDB;
                }));
            }else{
                $uploadFileArray = $LoanModel->UploadFilesArray;
            }

            /* Sort Image Array */
            if(is_array($LoanModel->ImagesNameModel)) {
                $keys = array_flip($LoanModel->ImagesNameModel);
            }
            else {
                $keys=$LoanModel->ImagesNameModel;
            }
            usort($uploadFileArray, function($a, $b) use($keys)
            {
                return $keys[@array_pop(explode("/",$a['FilePath']))] - $keys[@array_pop(explode("/",$b['FilePath']))];
            });

            $data = array();
            $date = date(Constants::$DefaultDateTimeFormat);
            if (is_array($uploadFileArray)) {
                foreach ($uploadFileArray as $fileArray) {
                    if (!is_null($fileArray['FileName'])) {
                        $isDefault =Constants::$Value_False;
                        if (isset($LoanModel->IsDefaultImage)) {  // set default image to 1 if default image and upload file path are same.
                            if ($LoanModel->IsDefaultImage == $fileArray['FilePath']) {
                                $isDefault = Constants::$Value_True;
                            }
                            else{
                                $isDefault =Constants::$Value_False;
                            }
                        }
                        $processData = array(
                            'LoanID' => $LoanID,
                            'SiteID' => $SiteID,
                            'FileName' => $fileArray['FileName'],
                            'FilePath' => $fileArray['FilePath'],
                            'FileSize' => $fileArray['FileSize'],
                            'ModifiedByID' => $UserID,
                            'ModifiedDate' => $date,
                            'CreatedByID' => $UserID,
                            'CreatedDate'=> $date,
                            'IsDefaultImage'=>$isDefault
                            );
                        $fullImagePath= Common::getAWSUrl($SiteID) . Common::getAWSBucketName($SiteID) . '/' .$fileArray['FilePath'];
                        $imageDimensionArray = Constants::$LoanInterventionDimension;
                        Common::RDImageIntervention($fullImagePath, $imageDimensionArray, '', 0);
                        array_push($data, $processData);
                    }
                }
                $this->MultipleInsert(new LoanImagesEntity,$data);
            }

            if($isEditMode){  // For Delete old default selected image and set new default selected image during edit page.
                if(isset($LoanModel->IsDefaultImage)){
                    $this->CallRawForMultipleTable('updateloandefaultimage',[$LoanModel->LoanID,$LoanModel->IsDefaultImage]);
                }
            }

        }
        /* For Image Upload Section End */
        if(!$isEditMode){
            CacheHelper::CacheManage($SiteID,Constants::$cacheLoansClosedID,Constants::$cacheActionUpdate,$LoanID);
        }else {
            CacheHelper::CacheManage($SiteID,Constants::$cacheLoansClosedID,Constants::$cacheActionInsert,'');
        }

        if(empty($addLoanResults)){
            $response->Message = trans('messages.ErrorOccured');
        }else{
            $response->IsSuccess = true;
            $response->Data = $addLoanResults[0][0];
            if($isEditMode){
                $response->Message = trans('messages.LoanUpdate');
                $response->RedirectUrl = URL::to('/') . "/loans/" . Common::getEncryptedValue(Constants::$QueryStringSiteID . '=' . $SiteID);
            }else{
                $response->Message = trans('messages.LoanInsert');
                $response->RedirectUrl = URL::to('/') . "/loans/" . Common::getEncryptedValue(Constants::$QueryStringSiteID . '=' . $SiteID);
            }
        }
        return $response;
    }
}