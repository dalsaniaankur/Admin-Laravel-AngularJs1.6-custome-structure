<?php 
namespace dataproviders;


Interface INavigationDataProvider{

    /*AD Start*/
    public function postNavigationMenuData($menuModel,$loginUserID,$siteID);
    public function buildTree(array $elements, $parentId = 0);
    public function postSaveNavigationMenu($Model,$loginUserID,$siteID);
    public function checkKeyExists($id,$output);
    /*AD  End*/


}
