<?php
namespace dataproviders;
use Illuminate\Support\Facades\Validator;
use \ViewModels\ServiceResponse;
use \Infrastructure\Constants;
use \Infrastructure\Common;
use \stdClass;
use ViewModels\SessionHelper;
use \WorkFlowStatusEntity;
use \URL;
use \ViewModels\BlogPostsListSearchModel;
use DB;
use \Config;
use PageSliderImagesEntity;
use Infrastructure\CacheHelper;
use UserEntity;

abstract class IWorkflowDataProvider extends BaseDataProvider
{
	
    /*Start Region Dev_Drashtant*/
    public abstract function getCategories($siteID);
    public abstract function getDetailForDeleteData();
    public abstract function getDetailForList();
    public function getSearchModelForWorkFlow($timezone, $siteID) // status list and parameters for filter data
    {
        $response = new ServiceResponse();
        $workFlowSearchModel = new BlogPostsListSearchModel($timezone);
        $statusData = $this->GetEntityList(new WorkFlowStatusEntity(), array());
        $allStatus = new WorkFlowStatusEntity();
        $allStatus->StatusID = Constants::$AllStatusValue;
        $allStatus->Status = Constants::$AllStatusText;
        array_unshift($statusData, $allStatus);
        $workFlowSearchModel->StatusLookup = $statusData;
        $workFlowSearchModel->CategoryLookup = $this->getCategories($siteID);

        $workFlowSearchModel->currentSiteUrl = $this->CallRawForMultipleTable("getSiteUrl",[$siteID]);

        $response->Data = $workFlowSearchModel;
        return $response;
    }
    public function postData($data, $siteID, $timezone){
        $response = new ServiceResponse();
        $detail = $this->getDetailForList();
        $checkDateFrom = Common::checkDateFromWithDateTo($timezone, $data->SearchParams['DateFrom']);
        if ($checkDateFrom > 0) {
            $response->IsSuccess = false;
            $response->Message = trans('messages.DateFromMaxFromCurrent');
            return $response;
        }
        $checkDateTo = Common::checkDateFromWithDateTo($timezone, $data->SearchParams['DateTo']);
        if ($checkDateTo > 0) {
            $response->IsSuccess = false;
            $response->Message = trans('messages.DateToMaxFromCurrent');
            return $response;
        }
        $checkDateFromTo = Common::checkDateFromWithDateTo($timezone, $data->SearchParams['DateFrom'], $data->SearchParams['DateTo']);
        if ($checkDateFromTo > 0) {
            $response->IsSuccess = false;
            $response->Message = trans('messages.DateFromMaxFromDateTo');
            return $response;
        }
        if (empty($data->SortIndex)) {
            $data->SortIndex = Constants::$SortIndex;
        }
        if (empty($data->SortDirection)) {
            $data->SortDirection = Constants::$SortIndexASC;
        }
        $sortIndex = $data->SortIndex;
        $sortDirection = $data->SortDirection;
        $pageIndex = $data->PageIndex;
        $pageSizeCount = $data->PageSize;
        $searchDateFrom = '';
        $searchDateTo = '';
        $searchStatus = '';
        $searchCategory = '';
        if (isset($data->SearchParams)) {
            if (isset($data->SearchParams['DateFrom'])) {
                $searchDateFrom = $data->SearchParams['DateFrom'];
            }
            if (isset($data->SearchParams['DateTo'])) {
                $DateTo = $data->SearchParams['DateTo'];
                $searchDateTo = date('m/d/Y',strtotime($DateTo . "+1 days"));
            }
            if (isset($data->SearchParams['StatusID'])) {
                $searchStatus = $data->SearchParams['StatusID'];
            }
            if (isset($data->SearchParams['CategoryID'])) {
                $searchCategory = $data->SearchParams['CategoryID'];
            }
        }
        $searchDateFrom = Common::ConvertDateFormatFromMDYToYMD($searchDateFrom);
        $searchDateTo = Common::ConvertDateFormatFromMDYToYMD($searchDateTo);
        $pageList = $this->GetPageRecordsUsingSP($detail->Procedure, $pageIndex, $pageSizeCount, [$searchDateFrom, $searchDateTo, $searchStatus, $searchCategory, $pageIndex, $pageSizeCount, $sortIndex, $sortDirection, $siteID]);
        if (is_null($pageList)) {
            $response->Message = trans($detail->ErrorMessage);
        } else {
            $response->IsSuccess = true;
            $response->Data = $pageList;
        }
        return $response;
    }
    public function deleteWorkFlow($data)  // delete page blog data
    {
        $siteID=SessionHelper::getSelectedSiteID();
        $response = new ServiceResponse();
        $SPName = $this->getDetailForDeleteData();
        $blogAgent='';
        if($SPName->Procedure!=Constants::$SPNameDeletePages && $siteID==Constants::$MercerVineSiteID){
            $blogAgent = $this->CallRawForSingleTable('getselectedblogagent', [$data->ID]);
        }
        $deletePage = $this->CallRawForSingleTable($SPName->Procedure, [$data->ID]);

        if ($deletePage) {
            if($SPName->Procedure == Constants::$SPNameDeletePages){
                if(isset($data->ID) && !empty($data->ID) && $data->ID){
                    if($siteID=='') {
                        $siteID = 1;
                    }
                    CacheHelper::CacheManage($siteID,Constants::$cachePagesID,Constants::$cacheActionDelete,$data->ID,$data->Slug);
                }
            }else {
                if($blogAgent){
                    foreach($blogAgent as $blogAgent){
                        CacheHelper::CacheManage($siteID,Constants::$cacheAgentID,Constants::$cacheActionUpdate,$blogAgent->Slug);
                    }
                }
                if(isset($data->ID) && !empty($data->ID) && $data->ID){
                    if($siteID=='') {
                        $siteID = 1;
                    }
                    CacheHelper::CacheManage($siteID,Constants::$cacheBlogID,Constants::$cacheActionDelete,$data->ID,$data->Slug);
                }
            }
            $response->IsSuccess = true;
            $response->Message = trans($SPName->SuccessMessage);
        } else {
            $response->Message = trans($SPName->FailMessage);
        }
        return $response;
    }
    /*Stop Region Dev_Drashtant*/

    /*Start Dev_VA*/
    public abstract function getSPNameToFetchDetailsOnAddWorkflow();
    public abstract function getWorkflowEntity();
    public abstract function getWorkflowDetailsName();
    public abstract function getWorkflowModelName();
    public abstract function getWorkflowID();
    public abstract function getWorkflowRedirectUrl();
    public abstract function isWorkflowBlogPost();
    public abstract function saveWorkflowDataSPName();
    public abstract function getAwsRequestType();
    public abstract function getUniqueMessage();
    public abstract function getAddMessage();
    public abstract function getUpdateMessage();
    public abstract function getApproveWorkFlowMessage();
    public abstract function getDenyWorkFlowMessage();
    public abstract function getPublishWorkFlowMessage();
    public abstract function getWorkFlowResponseRedirectURL();
    public abstract function getSaveWorkFlowSPParameter($workFlowID,$workflowModel,$loggedInUserID,$siteID,$loggedInUserRoleID);
    public abstract function getWorkFlowAssignedMail($email,$data);
    public abstract function getRoleCSV();

public function getAddWorkflowData($workflowID, $siteID,$loggedInUserID,$loggedInUserRoleID){ //$updateProfile,
        $response = new ServiceResponse();
        $model = new stdClass();
        $workflowDetails = new stdClass();
        $spName = $this->getSPNameToFetchDetailsOnAddWorkflow();
        $workflowDetailsName = $this->getWorkflowDetailsName();
        $workflowModel = $this->getWorkflowModelName();
        $workflowEntity = $this->getWorkflowEntity();

        $getWorkflowID = $this->getWorkFlowID();
        $workflowRedirectUrl = $this->getWorkflowRedirectUrl();
        $workflowBlogPost = $this->isWorkflowBlogPost();
        $roleCSV = $this->getRoleCSV();
        $activeStatusID = Constants::$Status_Active;

        $params = array($workflowID,$siteID,$roleCSV,$activeStatusID,$loggedInUserID,$loggedInUserRoleID);
        if($workflowBlogPost){
            array_push($params,Constants::$Agent_Role_ID);
        }

        $params[] = Common::getAWSUrl($siteID);
        $params[] = Common::getAWSBucketName($siteID);
        $params[] = Common::getAWSFullURLForProfile();
        $workFlowListArray = $this->CallRawForMultipleTable($spName,$params,false,['UserID','StatusID','AuthorID', 'AssignedID','CategoryID','TagID','IsOverlay']);

        /* For Author Array */


        if($workflowID > 0){
            $currentStatusID = $workFlowListArray[3][0]->StatusID;
        }else{
            $currentStatusID =1;
        }


        $authorArray =  $workFlowListArray[0];

        /*Here used array filter for fetch author record without legal as per permission*/
        $roleLegal = Constants::$RoleLegal;
        $authorWithoutLegalArray = array_filter($authorArray, function ($v) use ($roleLegal) {
            return $v->RoleID != $roleLegal;
        });

        $workflowDetails->AuthorListArray = $authorWithoutLegalArray;
        $workflowDetails->AssignListArray = $authorArray;
        $workflowDetails->Messages = $workFlowListArray[4];
        $workflowDetails->currentStatusID = $currentStatusID;

        /*For get status list array*/
        $statusArray = $workFlowListArray[2];

        /* For Approve and Deny Button */
        $showApproveDenyButton = array_filter($statusArray, function ($v){
            return $v->StatusID == Constants::$WorkFlowStatus_Approve or  $v->StatusID == Constants::$WorkFlowStatus_Denied;
        });

        if($workflowID>0 && !empty($showApproveDenyButton) && ($loggedInUserRoleID == Constants::$RoleITAdmin or  $loggedInUserRoleID == Constants::$RoleMarketingDirector or $loggedInUserRoleID == Constants::$RoleLegal) ){
            $workflowDetails->ShowApproveDenyButton = Constants::$Value_True;
        }else{
            $workflowDetails->ShowApproveDenyButton= Constants::$Value_False;
        }

        /* For CanViewPage or Not */
        $workflowDetails->ViewPage = $workFlowListArray[5][0]->ViewPage;

        /* For Publish Button */
        if($workflowBlogPost){
            if(isset($workFlowListArray[10][0]->CurrentWorkFlowStatus) && $workflowID> 0){
                if($workFlowListArray[10][0]->CurrentWorkFlowStatus==Constants::$WorkFlowStatus_Approve && ($loggedInUserRoleID==Constants::$RoleITAdmin or $loggedInUserRoleID==Constants::$RoleMarketingDirector)){
                    $workflowDetails->ShowPublishButton= Constants::$Value_True;
                }else{
                    $workflowDetails->ShowPublishButton = Constants::$Value_False;
                }
            }else{
                $workflowDetails->ShowPublishButton = Constants::$Value_False;
            }
        }

        if(!$workflowBlogPost){
            if(isset($workFlowListArray[6][0]->CurrentWorkFlowStatus) && $workflowID> 0){
                if($workFlowListArray[6][0]->CurrentWorkFlowStatus==Constants::$WorkFlowStatus_Approve && $loggedInUserRoleID==Constants::$RoleITAdmin){
                    $workflowDetails->ShowPublishButton= Constants::$Value_True;
                }else{
                    $workflowDetails->ShowPublishButton = Constants::$Value_False;
                }
            }else{
                $workflowDetails->ShowPublishButton = Constants::$Value_False;
            }
        }


        /* For If User Status Is "Publish"  the allow SEO filed to edit.*/
        if($workflowBlogPost) {
            if ($workflowID > 0 && isset($workFlowListArray[11][0]->AssignedUserID) && isset($workFlowListArray[10][0]->CurrentWorkFlowStatus)) {
                if ($workFlowListArray[11][0]->AssignedUserID == $loggedInUserID && $workFlowListArray[10][0]->CurrentWorkFlowStatus == Constants::$WorkFlowStatus_Published) {
                    $workflowDetails->CanEditSEOFields = Constants::$Value_True;
                } else {
                    $workflowDetails->CanEditSEOFields = Constants::$Value_False;
                }
            } else {
                $workflowDetails->CanEditSEOFields = Constants::$Value_False;
            }
        }

        if(!$workflowBlogPost) {
            if ($workflowID > 0 && isset($workFlowListArray[7][0]->AssignedUserID) && isset($workFlowListArray[6][0]->CurrentWorkFlowStatus)) {
                if ($workFlowListArray[7][0]->AssignedUserID == $loggedInUserID && $workFlowListArray[6][0]->CurrentWorkFlowStatus == Constants::$WorkFlowStatus_Published) {
                    $workflowDetails->CanEditSEOFields = Constants::$Value_True;
                } else {
                    $workflowDetails->CanEditSEOFields = Constants::$Value_False;
                }
            } else {
                $workflowDetails->CanEditSEOFields = Constants::$Value_False;
            }
        }



        /*Here fetching BaseUrl and PageSection for made CanonicalURL*/
        $workflowDetails->BaseUrl = $workFlowListArray[1][0]->WebsiteBaseURL;
        $workflowDetails->Section = $workflowBlogPost?$workFlowListArray[1][0]->BlogSection:$workFlowListArray[1][0]->PageSection;

        if($workflowBlogPost){

            $categoryArray = $workFlowListArray[6];
            $tagAgentArray = $workFlowListArray[7];

            $tags = $workFlowListArray[8];
            $disabledTagAgent = $workFlowListArray[9][0]->IsDisableAgent;
            $workflowDetails->TagAgentListArray = $tagAgentArray;
            $workflowDetails->Category = $categoryArray;
            $workflowDetails->TagListArray = $tags;
            $workflowDetails->IsDisabledTagAgent = $disabledTagAgent;
        }
        if(!$workflowBlogPost){
            if(isset($workFlowListArray[8][0]))
                $workflowDetails->IsUsedInMenu =  $workFlowListArray[8][0]->cnt;
        }
        $workflowDetails->StatusListArray = $statusArray;
        $workflowDetails->encryptedSiteID = Common::getEncryptedValue(Constants::$QueryStringSiteID.'='.$siteID);
        $workflowDetails->RedirectURL = $workflowRedirectUrl.Common::getEncryptedValue(Constants::$QueryStringSiteID.'='.$siteID);

        if ($workflowID > 0) {
            $workflowDetails->{$workflowDetailsName} = $workFlowListArray[3][0];


            if(isset($workflowDetails->{$workflowDetailsName}->Category)){
                $category = explode(',',$workflowDetails->{$workflowDetailsName}->Category);
                $workflowDetails->{$workflowDetailsName}->Category = Common::setSingleDimArrayValuesToInt($category);
            }

            if(isset($workflowDetails->{$workflowDetailsName}->TagAgent)){
                $TagAgent = explode(',',$workflowDetails->{$workflowDetailsName}->TagAgent);
                $workflowDetails->{$workflowDetailsName}->TagAgent = Common::setSingleDimArrayValuesToInt($TagAgent);
            }

            /* For Tag Start */
            if(isset($workflowDetails->{$workflowDetailsName}->Tag)){
                if(strlen($workflowDetails->{$workflowDetailsName}->Tag) > 0) {
                    $workflowDetails->{$workflowDetailsName}->Tag = explode(',', $workflowDetails->{$workflowDetailsName}->Tag);
                }
                if(strlen($workflowDetails->{$workflowDetailsName}->TagIDs) > 0) {
                    $workflowDetails->{$workflowDetailsName}->TagIDs = explode(',', $workflowDetails->{$workflowDetailsName}->TagIDs);
                }
                $Word = array();
                if(is_array($workflowDetails->{$workflowDetailsName}->Tag)) {
                    foreach ($workflowDetails->{$workflowDetailsName}->Tag as $key => $keyWord) {
                        array_push($Word, array(
                            'TagID' => $workflowDetails->{$workflowDetailsName}->TagIDs[$key],
                            'Tag' => $keyWord
                        ));
                    }
                }
                $workflowDetails->{$workflowDetailsName}->Tag = $Word;
            }
            /* For Tag End */

            /*Bellow code for edit image*/
            if(!empty($workflowDetails->{$workflowDetailsName}->FBImage)){
                $fbImageData = $this->Awsdownloadfile($workflowDetails->{$workflowDetailsName}->FBImage,$siteID);
                $workflowDetails->{$workflowDetailsName}->FBRealImagePath = $fbImageData->signedUrl;
            }else{
                $workflowDetails->{$workflowDetailsName}->FBRealImagePath = '';
            }
            if(!empty($workflowDetails->{$workflowDetailsName}->TwitterImage)){
                $twitterImageData = $this->Awsdownloadfile($workflowDetails->{$workflowDetailsName}->TwitterImage,$siteID);
                $workflowDetails->{$workflowDetailsName}->TwitterRealImagePath = $twitterImageData->signedUrl;
            }else{
                $workflowDetails->{$workflowDetailsName}->TwitterRealImagePath = '';
            }
            if(!empty($workflowDetails->{$workflowDetailsName}->Image)){
                $imageData = $this->Awsdownloadfile($workflowDetails->{$workflowDetailsName}->Image,$siteID);
                $workflowDetails->{$workflowDetailsName}->GoogleRealImagePath = $imageData->signedUrl;
            }else{
                $workflowDetails->{$workflowDetailsName}->GoogleRealImagePath = '';
            }

        }else{
            $workflowEntity->{$getWorkflowID} = $workflowID;
            $workflowEntity->SiteID = $siteID;

            /* Set Default Logged In User to Author and Assignee */
            $workflowEntity->AuthorID = intval($loggedInUserID);
            $workflowEntity->AssignedID = intval($loggedInUserID);

             /*Set Default Status as a Draft*/
            $workflowEntity->StatusID = Constants::$DefaultStatusDraft;

            $workflowDetails->{$workflowDetailsName} = $workflowEntity;

            /*Below code for image upload*/
            $workflowDetails->{$workflowDetailsName}->FBRealImagePath = '';
            $workflowDetails->{$workflowDetailsName}->TwitterRealImagePath = '';
            $workflowDetails->{$workflowDetailsName}->GoogleRealImagePath = '';
            $workflowDetails->{$workflowDetailsName}->ImageName = '';
            $workflowDetails->{$workflowDetailsName}->IsImageRemoved = Constants::$Value_False;
            $workflowDetails->{$workflowDetailsName}->UploadFilesArray = '';
            $workflowDetails->{$workflowDetailsName}->TempFilesArray = '';
            $workflowDetails->{$workflowDetailsName}->RealFeaturedImagePath = '';
        }
        /* Images slider */
        if(isset($workflowDetails->PageDetails->PageID) AND $workflowDetails->PageDetails->PageID > 0 ){
            $result = $this->CallRawForMultipleTable('getpagesliderimages',[$workflowDetails->PageDetails->PageID]);
            if($result[1][0]->ResultStatus){
                $workflowDetails->{$workflowDetailsName}->UploadedFile = $result[0];
            }
        }else{
            $workflowDetails->{$workflowDetailsName}->UploadedFile = array();
        }
        /* Images slider */

        /*File Upload Settings*/
        $workflowDetails->{$workflowDetailsName}->Fileuploadsettings = $this->FileUploadSettings($this->getAwsRequestType(),$siteID,$loggedInUserID);

        $workflowDetails->currentSiteUrl = $this->CallRawForMultipleTable("getSiteUrl",[$siteID]);
        $model->{$workflowModel} = $workflowDetails;
        $response->Data = $model;
        return $response;
    }
    public function saveWorkflowData($workflowModel,$loggedInUserID,$loggedInUserRoleID,$siteID){

        $response = new ServiceResponse();
        $messages = array(
            'required' => trans('messages.PropertyRequired'),
            'min' => trans('messages.PropertyMin'),
            'max' => trans('messages.PropertyMax'),
        );
        $getWorkflowID = $this->getWorkFlowID();

        /* Slug custom validation */
        if($getWorkflowID == Constants::$QueryStringPageID){
            if($workflowModel->SiteID == Constants::$MercerVineSiteID){ $slugRegex = Constants::$MVSlugRegex;
            }else if($workflowModel->SiteID == Constants::$ColoradoSiteID){ $slugRegex = Constants::$COSlugRegex;
            }else if($workflowModel->SiteID == Constants::$WoodBridgeWealthSiteID){ $slugRegex = Constants::$WWSlugRegex;
            }else{ $slugRegex = Constants::$RDSlugRegex; }

            if (!preg_match('@'.$slugRegex.'@', $workflowModel->Slug)) {
                $response->IsSuccess = false;
                $response->Message = trans('messages.InvalidSlug');
                return $response;
            }
        }

        $SPName = $this->saveWorkflowDataSPName();

        $isEditMode = false;
        if($workflowModel->{$getWorkflowID}>0){
            $isEditMode = true;
        }
        $workflowEntity = $this->getWorkflowEntity();
        $validator = Validator::make((array)$workflowModel, $isEditMode ? $workflowEntity::$Edit_rules : $workflowEntity::$Add_rules, $messages);
        $validator->setAttributeNames($workflowEntity::$niceNameArray);
        if ($validator->fails()) {
            $response->Message = Common::getValidationMessagesFormat($validator->messages());
            return $response;
        }

        $workflowModel->MetaDescription = isset($workflowModel->MetaDescription) ? $workflowModel->MetaDescription : "";
        $workflowModel->FBTitle = isset($workflowModel->FBTitle) ? $workflowModel->FBTitle : "";
        $workflowModel->FBDescription = isset($workflowModel->FBDescription) ? $workflowModel->FBDescription : "";
        $workflowModel->FBImage = isset($workflowModel->FBImage) ? $workflowModel->FBImage : "";
        $workflowModel->TwitterCard = isset($workflowModel->TwitterCard) ? $workflowModel->TwitterCard : "";
        $workflowModel->TwitterSite = isset($workflowModel->TwitterSite) ? $workflowModel->TwitterSite : "";
        $workflowModel->TwitterTitle = isset($workflowModel->TwitterTitle) ? $workflowModel->TwitterTitle : "";
        $workflowModel->TwitterDescription = isset($workflowModel->TwitterDescription) ? $workflowModel->TwitterDescription : "";
        $workflowModel->TwitterImage = isset($workflowModel->TwitterImage) ? $workflowModel->TwitterImage : "";
        $workflowModel->Headline = isset($workflowModel->Headline) ? $workflowModel->Headline : "";
        $workflowModel->Image = isset($workflowModel->Image) ? $workflowModel->Image : "";
        $workflowModel->Description = isset($workflowModel->Description) ? $workflowModel->Description : "";
        $workflowModel->ImageHeight = isset($workflowModel->ImageHeight) ? $workflowModel->ImageHeight : "";
        $workflowModel->ImageWidth = isset($workflowModel->ImageWidth) ? $workflowModel->ImageWidth : "";
        $workflowModel->Message = isset($workflowModel->Message) ? $workflowModel->Message : null;
        $workflowModel->FeaturedImage = isset($workflowModel->FeaturedImage) ? $workflowModel->FeaturedImage : "";
        if(isset($workflowModel->Opacity)){
            $workflowModel->Opacity = ($workflowModel->Opacity / 100);
        }
        if($workflowModel->SiteID == Constants::$RiverDaleFundingSiteID){
            $workflowModel->IsShowBrokerPackageCTA = isset($workflowModel->IsShowBrokerPackageCTA) ? $workflowModel->IsShowBrokerPackageCTA : 0;
        }else{
            $workflowModel->IsShowBrokerPackageCTA = 0;
        }
        $param = $this->getSaveWorkFlowSPParameter($workflowModel->{$getWorkflowID},$workflowModel,$loggedInUserID,$siteID,$loggedInUserRoleID);

        $saveWorkflowData = $this->CallRawForMultipleTable($SPName,$param);
        /* Blog post */
        if(!isset($workflowModel->TagAgent) || $workflowModel->TagAgent == null){
            $workflowModel->TagAgent =array();
        }
        if(!isset($workflowModel->OldAgents) || $workflowModel->OldAgents == null){
            $workflowModel->OldAgents =array();
        }

        if(isset($workflowModel->BlogPostID) && !empty($workflowModel->BlogPostID) && $workflowModel->BlogPostID > 0 ){
            CacheHelper::CacheManage($siteID,Constants::$cacheBlogID,Constants::$cacheActionUpdate,$workflowModel->BlogPostID,$workflowModel->Slug);
            if($workflowModel->Slug!=$saveWorkflowData[0][0]->Slug) {
                CacheHelper::CacheManage($siteID, Constants::$cacheBlogID, Constants::$cacheActionUpdate, $workflowModel->BlogPostID, $saveWorkflowData[0][0]->Slug);
            }
            if($siteID==Constants::$MercerVineSiteID) {
                $updateAgent = array_unique(array_merge($workflowModel->TagAgent, $workflowModel->OldAgents));
                foreach ($updateAgent as $agent) {
                    $searchParam = array();
                    $searchValues = Common::SetSearchArray('UserID', $agent, Constants::$Value_True);
                    array_push($searchParam, $searchValues);
                    $AgentDetail = $this->GetEntity(new UserEntity(), $searchParam);
                    CacheHelper::CacheManage($siteID, Constants::$cacheAgentID, Constants::$cacheActionUpdate, $AgentDetail->Slug);
                }
            }
        }else{
            if(isset($saveWorkflowData[1][0]->EntityID) && !empty($saveWorkflowData[1][0]->EntityID) && $saveWorkflowData[1][0]->EntityID > 0 ) {
                CacheHelper::CacheManage($siteID, Constants::$cacheBlogID, Constants::$cacheActionInsert, $saveWorkflowData[1][0]->EntityID,$saveWorkflowData[1][0]->slug);
            }
            if($siteID==Constants::$MercerVineSiteID) {
                if(property_exists($workflowModel,'TagAgent')){
                    $updateAgent = array_unique($workflowModel->TagAgent);
                    foreach ($updateAgent as $agent) {
                        $searchParam = array();
                        $searchValues = Common::SetSearchArray('UserID', $agent, Constants::$Value_True);
                        array_push($searchParam, $searchValues);
                        $AgentDetail = $this->GetEntity(new UserEntity(), $searchParam);
                        CacheHelper::CacheManage($siteID, Constants::$cacheAgentID, Constants::$cacheActionUpdate, $AgentDetail->Slug);
                    }
                }
            }
        }
        /* Pages */
        if(isset($workflowModel->PageID) && !empty($workflowModel->PageID) && $workflowModel->PageID > 0 ){
            CacheHelper::CacheManage($siteID,Constants::$cachePagesID,Constants::$cacheActionUpdate,$workflowModel->PageID,$workflowModel->Slug);
            if(isset($saveWorkflowData[0][0]->Slug)){
                if($workflowModel->Slug != $saveWorkflowData[0][0]->Slug) {
                    CacheHelper::CacheManage($siteID, Constants::$cachePagesID, Constants::$cacheActionUpdate, $workflowModel->PageID, $saveWorkflowData[0][0]->Slug);
                }
            }
        }else{
            if(isset($saveWorkflowData[1][0]->PageID) && !empty($saveWorkflowData[1][0]->PageID) && $saveWorkflowData[1][0]->PageID > 0 ){
                
                CacheHelper::CacheManage($siteID,Constants::$cachePagesID,Constants::$cacheActionInsert,$saveWorkflowData[1][0]->PageID,$saveWorkflowData[1][0]->slug);
            }
        }

        if($saveWorkflowData[0][0]->ResultStatus == Constants::$uniqueStatus){
            $response->Message = $this->getUniqueMessage();
        }else if($saveWorkflowData[0][0]->ResultStatus == Constants::$addSuccessStatus) {
            /* This code use only add/edit page */
            /* Page Slider images upload */
            if(isset($workflowModel->PageID)) {
                if (($workflowModel->PageID > 0)) {
                    $CurrentPageID = $workflowModel->PageID;
                }
                if (($workflowModel->PageID == 0 OR $workflowModel->PageID == '')) {
                    $CurrentPageID = $saveWorkflowData[1][0]->PageID;
                }
            }

            if(isset($CurrentPageID) AND $CurrentPageID > 0 AND isset($workflowModel->ImagesNameModel)) {
                if(is_array($workflowModel->ImagesNameModel)) {
                    $keys = array_flip($workflowModel->ImagesNameModel);
                }else {
                    $keys = $workflowModel->ImagesNameModel;
                }
                usort($workflowModel->ImagesModel, function($a, $b) use($keys) {
                    return $keys[@array_pop(explode("/",$a['FilePath']))] - $keys[@array_pop(explode("/",$b['FilePath']))];
                });

                // Story images Upload
                $uploadImages = $workflowModel->ImagesModel;
                $data = array();
                if(is_array($uploadImages)) {
                    foreach ($uploadImages as $key => $imageData) {
                        if (!is_null($imageData['FileName'])) {
                            $processData = array(
                                'PageID' => $CurrentPageID,
                                'FileName' => $imageData['FileName'],
                                'FilePath' => $imageData['FilePath'],
                                'FileSize' => $imageData['FileSize'],
                                'SiteID' => $siteID,
                                'SortOrder' => $key + 1,
                            );
                            if ($imageData['IsSavedInDB'] != 1)
                                array_push($data, $processData);
                            else
                                $this->CustomUpdateEntity(new PageSliderImagesEntity(), 'ImageID', $imageData['ImageID'], $processData);
                        }
                    }
                    if (count($data))
                        $this->MultipleInsert(new PageSliderImagesEntity(), $data);
                }
            }
            /* Page Slider images upload end*/
            $response->IsSuccess = true;
            $response->Data = $saveWorkflowData;
            $responseURL = $this->getWorkFlowResponseRedirectURL();
            $response->RedirectURL = URL::to('/')."/$responseURL/".Common::getEncryptedValue(Constants::$QueryStringSiteID.'='.$siteID);
            if($workflowModel->ActionType == Constants::$ApproveWorkFlowActionType){
                $response->Message = $this->getApproveWorkFlowMessage();
            }elseif($workflowModel->ActionType == Constants::$DenyWorkFlowActionType){
                $response->Message = $this->getDenyWorkFlowMessage();
            }else if($workflowModel->ActionType == Constants::$PublishWorkFlowActionType){
                $response->Message = $this->getPublishWorkFlowMessage();
            }else{
               $response->Message = $isEditMode ? $this->getUpdateMessage() : $this->getAddMessage();
            }
            if(isset($saveWorkflowData[1][0]->MailtoSend)){
                $emailData = new stdClass();
                $emailData->LoginLink = URL::to('/');
                $emailData->Title = $workflowModel->Title;
                $emailData->CreatedBy = $loggedInUserID;
                $emailData->SiteID = $siteID;
                $data = (array)$emailData;
                $this->getWorkFlowAssignedMail($saveWorkflowData[1][0]->MailtoSend,$data);
            }
        }else{
            $response->Message = trans('messages.ErrorOccurred');
        }
        return $response;
    }

    public function AwsFileDownload($imageData,$siteID){
        $response = new ServiceResponse();
        $response->Data = $this->Awsdownloadfile($imageData->ImageName,$siteID);
        $response->IsSuccess=true;
        return $response;
    }

    public function removeImageFromAmazon($imageData,$siteID){
        $response = new ServiceResponse();
        $model=new stdClass();
        $getWorkflowID = $this->getWorkFlowID();
        $this->Awsdeletefile($imageData->ImageName,$siteID);
        if($imageData->{$getWorkflowID} == 0){
            $this->Awsdeletefile($imageData->ImageName,$siteID);
        }
        $response->Data= $model->RealImagePath='';
        $response->IsSuccess=true;
        return $response;
    }

    /*End Dev_VA*/
}