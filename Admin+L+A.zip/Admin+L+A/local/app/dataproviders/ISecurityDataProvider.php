<?php 
namespace dataproviders;


Interface ISecurityDataProvider {

    /* RB Start */
    public function AuthenticateUser($loginModel);
    public function SendVerificationEmail($userID,$siteID,$createByID);
    /* RB End */

    /* AD Start */
    public function SendResetPasswordEmail($userData);
    public function GetForgotPassword($token);
    public function postResetPasswordEmail($userModel);
    /* AD End */


    /*DN Start */

    /*DN End */

}
