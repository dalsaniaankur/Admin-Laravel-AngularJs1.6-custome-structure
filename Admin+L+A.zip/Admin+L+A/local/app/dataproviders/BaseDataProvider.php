<?php
namespace dataproviders;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Cookie\CookieJar;
use \ViewModels\PageModel;
use Aws\S3\S3Client;
use \stdClass;
use Illuminate\Support\Facades\Config;
use \Infrastructure\Constants;
use \Infrastructure\Common;
use \ViewModels\SearchValueModel;
use \ReflectionClass;
use File;
use \Image;


class BaseDataProvider
{

    public function SaveEntity($item)
    {
        $item->save();
        return $item;
    }

    public function MultipleInsert($item,$dataArray){
        if(!empty($dataArray)) {
            $class = $this->GetReflectionClass($item);
            $tableName = $class->getProperty('table')->getValue($item);
            return DB::table($tableName)->insert($dataArray);
        } else {
            return Constants::$Value_False;
        }
    }

    public function RunQueryStatement($queryString, $queryType,$parameters = array())
    {
        switch ($queryType) {
            case Constants::$QueryType_Select:
                return DB::select($queryString, $parameters);
                break;
            case Constants::$QueryType_Update:
                return DB::update($queryString, $parameters);
                break;
            case Constants::$QueryType_Insert:
                return DB::insert($queryString, $parameters);
                break;
            case Constants::$QueryType_Delete:
                return DB::delete($queryString, $parameters);
                break;
        }
    }

    public function DeleteEntity($item, $primaryKeyValue)
    {
        $class = $this->GetReflectionClass($item);
        $tableName = $class->getProperty('table')->getValue($item);
        $primaryKeyName = $class->getProperty('primaryKey')->getValue($item);
        DB::table($tableName)->where($primaryKeyName, $primaryKeyValue)->delete();
    }

    public function GetReflectionClass($item)
    {
        $ReflectionClass = get_class($item);
        return new ReflectionClass($ReflectionClass);
    }

    public function CustomDeleteEntity($item, $FieldKeyName, $FieldKeyValue)
    {
        $tableName = $this->GetTableNameFromReflectionClass($item);
        DB::table($tableName)->where($FieldKeyName, $FieldKeyValue)->delete();
    }

    public function GetTableNameFromReflectionClass($item)
    {
        $class = $this->GetReflectionClass($item);
        return $class->getProperty('table')->getValue($item);
    }

    public function CustomUpdateEntity($item, $FieldKeyName, $FieldKeyValue, $UpdateValueArray){
        $tableName = $this->GetTableNameFromReflectionClass($item);
        DB::table($tableName)->where($FieldKeyName, $FieldKeyValue)->update($UpdateValueArray);
    }

    public function CustomMultiUpdateEntity($item, $FieldKeyName, $FieldKeyValueArray, $UpdateValueArray)
    {
        $tableName = $this->GetTableNameFromReflectionClass($item);
        DB::table($tableName)->whereIn($FieldKeyName, $FieldKeyValueArray)->update($UpdateValueArray);
    }

    public function CustomMultiUpdateEntityWithMultipleFieldsSearch($item, $searchParams, $UpdateValueArray)
    {
        $tableName = $this->GetTableNameFromReflectionClass($item);
        if (!empty($searchParams) && count($searchParams) > 0) {
            $db = DB::table($tableName);
            foreach ($searchParams as &$val) {
                $FieldKeyValue = $val->Value;
                $FieldKeyName = $val->Name;
                $db = $db->where($FieldKeyName, $FieldKeyValue);
            }

            return $db->update($UpdateValueArray);
        } else {
            return false;
        }

    }

    public function GetEntityForUpdateByPrimaryKey($item, $primaryKeyValue)
    {
        $ReflectionClass = get_class($item);
        return $ReflectionClass::find($primaryKeyValue);
    }

    public function GetEntityForUpdateByFilter($item, $searchParams)
    {
        $ReflectionClass = get_class($item);
        $isfirsttimeset = false;
        if (!empty($searchParams) && count($searchParams) > 0) {
            foreach ($searchParams as &$val) {
                $Value = $val->Value;
                $Name = $val->Name;
                if ($isfirsttimeset)
                    $ReflectionClass = $ReflectionClass->where($Name, $Value);
                else {
                    $ReflectionClass = $ReflectionClass::where($Name, $Value);
                    $isfirsttimeset = true;
                }
            }
        }
        return $ReflectionClass->first();
    }

    public function GetEntity($item, $searchParams, $sortIndex = "", $sortDirection = "", $customWhere = "")
    {
        $selectQuery = $this->GetFilterString($item, $searchParams, $sortIndex, $sortDirection, $customWhere);
        $result = DB::select($selectQuery . " LIMIT 0,1");
        if (!empty($result))
            return DB::select($selectQuery . " LIMIT 0,1")[0];

        return null;

    }

    private function GetFilterString($item, $searchParams, $sortIndex = "", $sortDirection = "", $customWhere = "", $CustomGroup = "")
    {
        return $this->GetFilterStringCommon($item, $searchParams, $sortIndex, $sortDirection, $customWhere, $CustomGroup);
    }

    private function GetFilterStringCommon($item, $searchParams, $sortIndex = "", $sortDirection = "", $customWhere = "", $CustomGroup = "", $IsMultiSort = false, $sortArray = null, $IsForCount = false)
    {
        $class = $this->GetReflectionClass($item);
        $tableName = $class->getProperty('table')->getValue($item);
        $modelPropTypes = $class->getProperty('Model_Types')->getValue($item);
        $select = ($IsForCount ? "SELECT COUNT(*) AS cnt FROM " : "SELECT * FROM ") . $tableName;
        $where = "";

        if (!empty($searchParams) && count($searchParams) > 0) {
            $where .= " WHERE 1=1";

            foreach ($searchParams as $val) {
                $Value = addslashes($val->Value);
                $Name = $val->Name;
                $columnName = "`". $val->Name ."`";
                $CheckForExactMatch = $val->CheckForExactMatch;
                $propertyType = $modelPropTypes[$Name];
                if ($propertyType == 'string') {
                    if (!empty($CheckForExactMatch) && $CheckForExactMatch != 1)
                        $where .= " AND " . $columnName . " LIKE '" . $Value . "%'";
                    else if (!empty($CheckForExactMatch) && $CheckForExactMatch)
                        $where .= " AND " . $columnName . " = '" . $Value . "'";
                    else
                        $where .= " AND " . $columnName . " LIKE '%" . $Value . "%'";
                } else if ($propertyType == 'bool') {
                    $where .= " AND " . $columnName . "=" . $Value;
                } else if ($propertyType == 'int' || $propertyType == 'long') {
                    $where .= " AND " . $columnName . "=" . $Value;
                } else if ($propertyType == 'DateTime') {

                    /*
                    if (searchParam.Count(a => a.Name == val.Name) > 1)
                    {
                        $where .= " AND ((" . $Name . " BETWEEN " . searchParam.First(a => a.Name == val.Name).Value + " AND " + searchParam.Last(a => a.Name == val.Name).Value + ") OR (" + val.Name + " BETWEEN " + searchParam.Last(a => a.Name == val.Name).Value + " AND " + searchParam.First(a => a.Name == val.Name).Value + "))";
                    }
                    else
                    {
                        $where .= " AND " . $Name . "='" . $Value . "'";
                    }

                    */


                }

            }
        }

        //TODO: Check below function is working or not for customwhere.
        //$customWhere = addslashes($customWhere);
        $where .= $customWhere != "" ? empty($where) ? " WHERE (" . $customWhere . ")" : " AND (" . $customWhere . ")" : "";

        if ($CustomGroup)
            $where .= " GROUP BY  " . $CustomGroup;
        if (!$IsMultiSort && $sortIndex != "")
            $where .= " ORDER BY " . $sortIndex . " " . $sortDirection;
        else if ($IsMultiSort && !empty($sortArray) && count($sortArray) > 0) {
            $where .= " ORDER BY ";
            foreach ($sortArray as &$val) {
                $where .= $val->Index . " " . $val->Direction . ",";
            }
            $where = rtrim($where, ',');
        }
        $where = str_replace("1=1 AND", "", $where);
        $where = str_replace("1=1", "", $where);
        return $select . $where;
    }

    public function GetEntityList($item, $searchParams, $sortIndex = "", $sortDirection = "", $customWhere = "", $CustomGroup = "")
    {
        $selectQuery = $this->GetFilterString($item, $searchParams, $sortIndex, $sortDirection, $customWhere, $CustomGroup);
        return DB::select($selectQuery);
    }

    public function GetEntityListWithMultiSort($item, $searchParams, $SortArray, $customWhere = "")
    {
        $selectQuery = $this->GetFilterStringForMultiSort($item, $searchParams, $SortArray, $customWhere);

        return DB::select($selectQuery);
    }

    private function GetFilterStringForMultiSort($item, $searchParams, $sortArray, $customWhere = "", $CustomGroup = "")
    {
        return $this->GetFilterStringCommon($item, $searchParams, "", "", $customWhere, $CustomGroup, true, $sortArray);
    }

    public function GetPageInStoredProcResultSet($item, $pageIndex, $pageSize, $count, $itemsList)
    {
        $pageModel = new PageModel();
        $pageModel->CurrentPage = $pageIndex;
        $pageModel->TotalItems = $count;
        $pageModel->TotalPages = $count / $pageSize;
        $pageModel->ItemsPerPage = $pageSize;

        if (($pageModel->TotalItems % $pageSize) != 0)
            $pageModel->TotalPages = $pageModel->TotalPages + 1;

        $pageModel->Items = $itemsList;
        return $pageModel;
    }

    public function RunQueryStatementWithPagination($selectQuery, $pageIndex, $pageSizeCount, $sortIndex = "", $sortDirection = "")
    {
        $selectQry = explode("FROM", $selectQuery, 2);
        if ($sortIndex != "" && $sortDirection != "")
            $selectQuery .= " ORDER BY " . $sortIndex . " " . $sortDirection;
        $TotalRecords = 0;
        if ($pageSizeCount != Constants::$AllRecords) {
            $selectQueryWithPaging = $selectQuery . " LIMIT " . ($pageIndex - 1) * $pageSizeCount . "," . $pageSizeCount . "";
            $countSelectQuery = str_replace($selectQry[0], "SELECT Count(*) as TotalItems ", $selectQuery);
            $records = DB::select($countSelectQuery);
            if(count($records) > 0)
                $TotalRecords = DB::select($countSelectQuery)[0]->TotalItems;
            else
                $TotalRecords = 0;

        } else {
            $selectQueryWithPaging = $selectQuery;
        }

        $items = DB::select($selectQueryWithPaging);
        if ($pageSizeCount == Constants::$AllRecords)
            $TotalRecords = count($items);
        $pageModel = new PageModel();
        $pageModel->CurrentPage = $pageIndex;
        $pageModel->TotalItems = $TotalRecords;
        $pageModel->ItemsPerPage = $pageSizeCount;
        $pageModel->TotalPages = ceil($pageModel->TotalItems / $pageModel->ItemsPerPage);
        $pageModel->Items = $items;
        return $pageModel;
    }

    public function GetEntityWithPaging($item, $searchParams, $pageIndex, $pageSizeCount, $sortIndex = "", $sortDirection = "", $customWhere = "", $CustomGroup = "")
    {

        $selectQuery = $this->GetFilterString($item, $searchParams, $sortIndex, $sortDirection, $customWhere, $CustomGroup);

        if ($CustomGroup) {
            $countSelectQuery = str_replace("* FROM", "Count(*) as TotalItems  FROM ( select * FROM ", $selectQuery . ") AS Items");
        } else {
            $countSelectQuery = str_replace("*", "Count(*) as TotalItems", $selectQuery);

        }

        $selectQueryWithPaging = $selectQuery . " LIMIT " . ($pageIndex - 1) * $pageSizeCount . "," . $pageSizeCount . "";
        $pageModel = new PageModel();
        $pageModel->CurrentPage = $pageIndex;
        $pageModel->TotalItems = DB::select($countSelectQuery)[0]->TotalItems;//$selectQuery->count();
        $pageModel->ItemsPerPage = $pageSizeCount;
        $pageModel->TotalPages = ceil($pageModel->TotalItems / $pageModel->ItemsPerPage);
        $pageModel->Items = DB::select($selectQueryWithPaging);
        return $pageModel;
    }

    public function GetEntityListWithMultiSortWithPaging($item, $searchParams, $pageIndex, $pageSizeCount, $SortArray, $customWhere = "", $CustomGroup = "")
    {
        $selectQuery = $this->GetFilterStringForMultiSort($item, $searchParams, $SortArray, $customWhere, $CustomGroup);

        $countSelectQuery = str_replace("*", "Count(*) as TotalItems", $selectQuery);
        $queryData = DB::select($countSelectQuery);
        if ($queryData)
            $totalItems = $queryData[0]->TotalItems;
        else
            $totalItems = 0;
        if ($pageSizeCount == Constants::$AllRecords) {
            $pageSizeCount = $totalItems > 0 ? $totalItems : Constants::$DefaultPageSize;
        }
        $selectQueryWithPaging = $selectQuery . " LIMIT " . ($pageIndex - 1) * $pageSizeCount . "," . $pageSizeCount . "";

        $pageModel = new PageModel();
        $pageModel->CurrentPage = $pageIndex;

        $pageModel->TotalItems = $totalItems;
        $pageModel->ItemsPerPage = $pageSizeCount;
        $pageModel->TotalPages = ceil($pageModel->TotalItems / $pageModel->ItemsPerPage);
        $pageModel->Items = DB::select($selectQueryWithPaging);
        return $pageModel;
    }

    public function GetEntityWithPagingDistinctCount($item, $searchParams, $pageIndex, $pageSizeCount, $sortIndex = "", $sortDirection = "", $customWhere = "", $CustomGroup = "")
    {
        $selectQuery = $this->GetFilterString($item, $searchParams, $sortIndex, $sortDirection, $customWhere, $CustomGroup);
        $countSelectQuery = str_replace("*", "COUNT(*) TotalItems FROM (SELECT " . $CustomGroup, $selectQuery) . ') AS a';
        $selectQueryWithPaging = $selectQuery . " LIMIT " . ($pageIndex - 1) * $pageSizeCount . "," . $pageSizeCount . "";

        $pageModel = new PageModel();
        $pageModel->CurrentPage = $pageIndex;
        $pageModel->TotalItems = DB::select($countSelectQuery)[0]->TotalItems;//$selectQuery->count();
        $pageModel->ItemsPerPage = $pageSizeCount;
        $pageModel->TotalPages = ceil($pageModel->TotalItems / $pageModel->ItemsPerPage);
        $pageModel->Items = DB::select($selectQueryWithPaging);

        return $pageModel;
    }

    public function GetEntityListWithDistinctCount($item, $searchParams, $sortIndex = "", $sortDirection = "", $customWhere = "", $CustomGroup = "")
    {
        $selectQuery = $this->GetFilterString($item, $searchParams, $sortIndex, $sortDirection, $customWhere, $CustomGroup);
        $countSelectQuery = str_replace("*", "* FROM (SELECT " . $CustomGroup, $selectQuery) . ') AS a';
        return DB::select($selectQuery);
    }

    public function GetEntityCount($item, $searchParams, $sortIndex = "", $sortDirection = "", $customWhere = "")
    {   $selectQuery = $this->GetFilterStringForCount($item, $searchParams, $sortIndex, $sortDirection, $customWhere);
        $result = DB::select($selectQuery . " LIMIT 0,1");
        return intval($result[0]->cnt);
    }

    private function GetFilterStringForCount($item, $searchParams, $sortIndex = "", $sortDirection = "", $customWhere = "", $CustomGroup = "")
    {
        return $this->GetFilterStringCommon($item, $searchParams, "", "", $customWhere, $CustomGroup, false, null, true);
    }

    public function FindOrNewEntity($entity, $columnValue)
    {
        $resultEntity = $entity::findOrNew($columnValue);
        return $resultEntity;
    }

    public function FirstOrNewEntityByKey($entity, $key, $keyValue)
    {
        $resultEntity = $entity::firstOrNew([$key => $keyValue]);
        return $resultEntity;
    }

    public function FillDataEntity($entity, $data)
    {
        $resultEntity = $entity->fill((array)$data);
        return $resultEntity;
    }

    public function GenerateGameCode($userID)
    {
        $code = $userID . uniqid(md5(microtime()));
        return $code;
    }

    public function CallRawForMultipleTable($procName, $parameters = null, $isExecute = false, $intColumns= null,$ProvideDb=null)
    {
        $syntax = "";

        for ($i = 0; $i < count($parameters); $i++) {
            $syntax .= (!empty($syntax) ? ',' : '') . '?';
        }

        $syntax = 'CALL ' . $procName . '(' . $syntax . ');';
        if($ProvideDb!=''){
            $pdo=DB::connection($ProvideDb)->getPdo();
        }
        else {
            $pdo = DB::connection()->getPdo();
        }

        $pdo->setAttribute(\PDO::ATTR_EMULATE_PREPARES, true);
        $stmt = $pdo->prepare($syntax,[\PDO::ATTR_CURSOR=>\PDO::CURSOR_SCROLL]);

        for ($i = 0; $i < count($parameters); $i++) {
            $stmt->bindValue((1 + $i), $parameters[$i]);
            //$stmt->bindParam((1 + $i), $parameters[$i], \PDO::PARAM_INT);
        }

        $exec = $stmt->execute();
        if (!$exec) return $pdo->errorInfo();
        if ($isExecute) return $exec;

        $results = [];
         do {
            try {
                $results[] = $stmt->fetchAll(\PDO::FETCH_OBJ);
            } catch (\Exception $ex) {

            }
        } while ($stmt->nextRowset());

        // This code is added to update string values to int values
        if(!empty($intColumns) ) {
            for ($i = 0; $i < count($results); $i++) {
                $results[$i]= Common::setSelectedPropertyValueToIntOfList($results[$i], $intColumns);
            }
        }

        return $results;
    }

    /* To get multiple result data set using Stored Procedure */
    public function CallRawForSingleTable($procName, $parameters = null, $isExecute = false, $intColumns= null,$ProvideDb=null)
    {
       $results = $this->CallRawForMultipleTable($procName, $parameters, $isExecute, $intColumns,$ProvideDb);

       if (1 === count($results))
            return $results[0];
        else if(count($results) > 1)
            $results[0] =  $results[0][0];

        return $results;
    }

    public function GetPageRecordsUsingSP($procName,$pageIndex,$pageSize, $parameters = null, $intColumns = null,$ProvideDb=null)
    {
        $items = $this->CallRawForSingleTable($procName, $parameters,false, $intColumns,$ProvideDb);
        $totalItemsCount = 0;
        if (!empty($items) && count($items) > 0) {
            $totalItemsCount = $items[0]->{Constants::$TotalItemsCountColumn};
            if(isset($items[1]->PageIndex))
                $pageIndex = $items[1]->{Constants::$PageIndex};
        }
        $results = new stdClass();
        $results->CurrentPage = $pageIndex;
        $results->ItemsPerPage = $pageSize;
        $results->Items = $items;
        $results->TotalItems = intval($totalItemsCount);
        return $results;
    }

    public function GetPageRecordsUsingSPWithStatus($procName,$pageIndex,$pageSize, $parameters = null)
    {
        $items = $this->CallRawForSingleTable($procName, $parameters);
        $totalItemsCount = 0;
        $isSuccess =0;

        if (!empty($items) && count($items) > 0) {
            if(count($items) > 1) {
                if(!empty($items[1]) && count($items[1]) > 0) {
                    $totalItemsCount = $items[1][0]->{Constants::$TotalItemsCountColumn};
                    if(isset($items[1][0]->PageIndex))
                        $pageIndex = $items[1][0]->{Constants::$PageIndex};
                }
                //$isSuccess = 1;
            }
        }
        $isSuccess = 1;
        $results = new stdClass();
        $results->CurrentPage = $pageIndex;
        $results->ItemsPerPage = $pageSize;
        $results->Items =$items;
        $results->TotalItems = intval($totalItemsCount);
        $results->IsSuccess = $isSuccess;
        return $results;
    }


    /* AWS Section Start */
    public function FileUploadSettings($type='',$siteID = 0,$userid){
        $Model=new stdClass();
        $final_folder = '';

       // $projectidentifier = '';

       // static $bucket;
        //static $accesskey;
        //static $secret;
        //static $url;
        $sucess_action=Config::get('aws.AWSuccessAction');

        /* to upload file as private */
        //$acl=Config::get('aws.AWSAcl_Private');
        /* to upload file as public */

        $acl=Config::get('aws.AWSAcl_Public');

        if($siteID > 0) {
            switch($siteID){
                case Constants::$MercerVineSiteID:
                $final_folder = Config::get('aws.AWSSiteFolder') . '/' . Config::get('aws.AWSMercerVineFolder') . '/';
                break;
                case Constants::$ColoradoSiteID:
                    $final_folder = Config::get('aws.AWSSiteFolder') . '/' . Config::get('aws.AWSColoradoFolder') . '/';
                    break;
                case Constants::$WoodBridgeWealthSiteID:
                    $final_folder = Config::get('aws.AWSSiteFolder') . '/' . Config::get('aws.AWSWoodBridgeWealthFolder') . '/';
                    break;
                case Constants::$RiverDaleFundingSiteID:
                    $final_folder = Config::get('aws.AWSSiteFolder') . '/' . Config::get('aws.AWSRiverDaleFundingFolder') . '/';
                    break;
                //default:
                    //$final_folder = Config::get('aws.AWSRequestType_Profile_Folder');
                    //break;
            }
        }

        $bucket = Common::getAWSBucketName($siteID);
        $accesskey = Common::getAPIKey($siteID);
        $secret = Common::getAWSSecretKey($siteID);
        $url = Common::getAWSUrl($siteID);
        $cacheControlTime =  Config::get('aws.cacheControlTime');

        switch($type){
            case Constants::$AWSRequestType_Profile:
                $final_folder =  Config::get('aws.AWSRequestType_Profile_Folder');
                break;
            case Constants::$AWSRequestType_Video:
                $final_folder .=  Config::get('aws.AWSRequestType_Videos_Folder');
                break;
            case Constants::$AWSRequestType_Development:
                $final_folder .=  Config::get('aws.AWSRequestType_Developments_Folder');
                break;
            case Constants::$AWSRequestType_Listing:
                $final_folder .=  Config::get('aws.AWSRequestType_Listing_Folder');
                break;
            case Constants::$AWSRequestType_Pages:
                $final_folder .=  Config::get('aws.AWSRequestType_Pages_Folder');
                break;
            case Constants::$AWSRequestType_Blogs;
                $final_folder .=  Config::get('aws.AWSRequestType_Blogs_Folder');
                break;
            case Constants::$AWSRequestType_Configuration;
                $final_folder .=  Config::get('aws.AWSRequestType_configurations_Folder');
                break;
            case Constants::$AWSRequestType_Home;
                $final_folder .=  Config::get('aws.AWSRequestType_Home_Folder');
                break;
            case Constants::$AWSRequestType_Loan:
                $final_folder .=  Config::get('aws.AWSRequestType_Loan_Folder');
                break;
            case Constants::$AWSRequestType_LandingPage:
                $final_folder .=  Config::get('aws.AWSRequestType_Landing_Page_Folder');
                break;
            //default:
                //$final_folder = Config::get('aws.AWSRequestType_Profile_Folder');
                //break;
        }

        $policy = json_encode(array(
            'expiration' => date('Y-m-d\TG:i:s\Z', strtotime('+50 hours')),
            'conditions' => array(
                array(
                    'bucket' => $bucket
                ),
                array(
                    'acl' => $acl
                ),
                array(
                    'Cache-Control' => $cacheControlTime
                ),
                array(
                    'starts-with',
                    '$key',
                    ''
                ),
                array(
                    'success_action_status' => $sucess_action
                )
            )
        ));

        $base64Policy = base64_encode($policy);
        $signature = base64_encode(hash_hmac("sha1", $base64Policy, $secret, $raw_output = true));

        $Model->url=$url.$bucket.'/';
        $Model->accesskey=$accesskey;
        $Model->secret=$secret;
        $Model->acl=$acl;
        $Model->success_action=$sucess_action;
        $Model->base64Policy=$base64Policy;
        $Model->signature=$signature;
        $Model->folder=$final_folder;
        $Model->enc_userid=$userid;
        $Model->cacheControlTime=$cacheControlTime;

        return $Model;
    }


    public function FileUploadSettingsForProfileImage($type='',$siteID = 0,$userid){
        $Model=new stdClass();

        $sucess_action=Config::get('aws.AWSuccessAction');
        $acl=Config::get('aws.AWSAcl_Public');

        if($type == Constants::$AWSRequestType_Profile)
            $final_folder = Config::get('aws.AWSRequestType_Profile_Folder');

        $bucket =  Config::get('aws.ProfileAWSBucketName');
        $accesskey =   Config::get('aws.ProfileAPIKey');
        $secret =  Config::get('aws.ProfileAWSSecretKey');
        $url =  Config::get('aws.ProfileAWSUrl');
        $cacheControlTime =  Config::get('aws.cacheControlTime');

        $policy = json_encode(array(
            'expiration' => date('Y-m-d\TG:i:s\Z', strtotime('+50 hours')),
            'conditions' => array(
                array(
                    'bucket' => $bucket
                ),
                array(
                    'acl' => $acl
                ),
                array(
                    'Cache-Control' => $cacheControlTime
                ),
                array(
                    'starts-with',
                    '$key',
                    ''
                ),
                array(
                    'success_action_status' => $sucess_action
                )
            )
        ));

        $base64Policy = base64_encode($policy);
        $signature = base64_encode(hash_hmac("sha1", $base64Policy, $secret, $raw_output = true));

        $Model->url=$url.$bucket.'/';
        $Model->accesskey=$accesskey;
        $Model->secret=$secret;
        $Model->acl=$acl;
        $Model->success_action=$sucess_action;
        $Model->base64Policy=$base64Policy;
        $Model->signature=$signature;
        $Model->folder=$final_folder;
        $Model->enc_userid=$userid;
        $Model->cacheControlTime=$cacheControlTime;

        return $Model;
    }

    public function GenerateFileName($name,$userid)
    {
        $ext=explode('.',$name);
        $t = explode(" ",microtime());
        $milliseconds=substr((string)$t[0],2,3);
        $str = $milliseconds+$userid;
        $hash = substr(md5($str), 0, 8);
        $date = date("d-m-Y h:i:s",time());
        $dateparts = explode(" ",$date);
        $date=explode('-',$dateparts[0]);
        $time=explode(':',$dateparts[1]);
        $name=$hash.'-'.$time[2].$time[1].$time[0].'-'.$date[1].$date[0].$date[2].'.'.$ext[count($ext)-1];
        return $name;
    }
    //TODO: Need to restrict this method call when needed. i.e. data from SP

    public function Awsdownloadfile($key,$siteID='',$isForProfile=''){
        $Model=new stdClass();

        if($isForProfile == true){
            $bucket = Config::get('aws.ProfileAWSBucketName');
            $url = Config::get('aws.ProfileAWSUrl');
        }else{
            $bucket = Common::getAWSBucketName($siteID);
            $url = Common::getAWSUrl($siteID);
        }
        $Model->signedUrl = $url.$bucket.'/'.$key;
        return $Model;
    }


    public function GenerateFolderName($userid)
    {
        $t = explode(" ",microtime());
        $milliseconds=substr((string)$t[0],2,3);
        $str = $milliseconds+$userid;
        $hash = substr(md5($str), 0, 8);
        $date = date("d-m-Y h:i:s",time());
        $dateparts = explode(" ",$date);
        $date=explode('-',$dateparts[0]);
        $time=explode(':',$dateparts[1]);
        return $hash.'-'.$time[2].$time[1].$time[0].'-'.$date[1].$date[0].$date[2];
    }

    public function FileUpload($type='',$userID,$siteID=0,$path,$base64data='',$isForProfile='')
    {
        $Model=new stdClass();

        //static $bucket;
        //static $accesskey;
        //static $secret;
        //static $url;

        $sucess_action=Config::get('aws.AWSuccessAction');
        $acl=Config::get('aws.AWSAcl_Public');


        if($isForProfile== true){
              $bucket = Config::get('aws.ProfileAWSBucketName');
              $accessKey = Config::get('aws.ProfileAPIKey');
              $secret = Config::get('aws.ProfileAWSSecretKey');
        }else {
            $bucket = Common::getAWSBucketName($siteID);
            $accessKey = Common::getAPIKey($siteID);
            $secret = Common::getAWSSecretKey($siteID);
        }

        $client = S3Client::factory(array(
            'key'    => $accessKey,
            'secret' => $secret
        ));

        if($siteID > 0) {
            switch($siteID){
                case Constants::$MercerVineSiteID:
                    $final_folder = Config::get('aws.AWSSiteFolder') . '/' . Config::get('aws.AWSMercerVineFolder') . '/';
                    break;
                case Constants::$ColoradoSiteID:
                    $final_folder = Config::get('aws.AWSSiteFolder') . '/' . Config::get('aws.AWSColoradoFolder') . '/';
                    break;
                case Constants::$WoodBridgeWealthSiteID:
                    $final_folder = Config::get('aws.AWSSiteFolder') . '/' . Config::get('aws.AWSWoodBridgeWealthFolder') . '/';
                    break;
                case Constants::$RiverDaleFundingSiteID:
                    $final_folder = Config::get('aws.AWSSiteFolder') . '/' . Config::get('aws.AWSRiverDaleFundingFolder') . '/';
                    break;
                //default:
                    //$final_folder = Config::get('aws.AWSRequestType_Profile_Folder');
                   // break;
            }
        }else{
            $final_folder = Config::get('aws.AWSRequestType_Profile_Folder');
        }

        switch($type){
            case Constants::$AWSRequestType_Profile:
                $final_folder =  Config::get('aws.AWSRequestType_Profile_Folder');
                break;
            case Constants::$AWSRequestType_Video:
                $final_folder .=  Config::get('aws.AWSRequestType_Videos_Folder');
                break;
            case Constants::$AWSRequestType_Development:
                $final_folder .=  Config::get('aws.AWSRequestType_Developments_Folder');
                break;
            case Constants::$AWSRequestType_Listing:
                $final_folder .=  Config::get('aws.AWSRequestType_Listing_Folder');
                break;
            case Constants::$AWSRequestType_Pages:
                $final_folder .=  Config::get('aws.AWSRequestType_Pages_Folder');
                break;
            case Constants::$AWSRequestType_Loan:
                $final_folder .=  Config::get('aws.AWSRequestType_Loan_Folder');
                break;
            default:
                $final_folder = Config::get('aws.AWSRequestType_Profile_Folder');
                break;
        }

        if(!empty($base64data))
        {
            $fielname = $path;
            $new_filename = $path;
            $fileData = $base64data;
        }
        else {
            $filepath = explode('/', $path);
            $fielname = $filepath[count($filepath) - 1];
            $new_filename = $this->GenerateFileName($fielname, $userID);
            //$fileData = file_get_contents($path);
            /***** comporess ***********/
            $img = Image::make($path);
            $info = getimagesize($path);
            $ext = File::extension($path);
            if($info[0]>1500)
                $width = round($info[0] / 2);
            else
                $width=$info[0];
            //exit;
            $img->resize($width, null, function ($constraint) {
                $constraint->aspectRatio();
            });

            $base64 = (string)$img->encode($ext);
            /***** comporess ***********/

            $fileData = $base64;
        }
        $key = $final_folder . '/' . $new_filename;
        $ext = pathinfo($path, PATHINFO_EXTENSION);
        $head = array_change_key_case(get_headers("http://example.com/file.ext", TRUE));
        $fileSize = $head['content-length'];
        $cacheControlTime =  Config::get('aws.cacheControlTime');
        try {
            $result = $client->putObject(array(
                'Bucket' => $bucket,
                'Key'    => $key,
                'Body'   => $fileData,
                'ACL'    => $acl,
                "CacheControl" => $cacheControlTime,//, must-revalidate",
            ));
            $url=$key;

        } catch (S3Exception $e) {
            echo $e->getMessage() . "\n";
        }
        $fileData = new stdClass();
        $fileData->FilePath=$url;
        $fileData->FileName=$fielname;
        $fileData->FileSize=$fileSize;
        $fileData->extension =$ext;
        return $fileData;
    }



    public function Awsdeletefile($key,$siteID,$isForProfile='')
    {
        $Model=new stdClass();

        if($isForProfile == true){
            $bucket = Config::get('aws.ProfileAWSBucketName');
            $accesskey = Config::get('aws.ProfileAPIKey');
            $secret = Config::get('aws.ProfileAWSSecretKey');
        }else {
            $bucket = Common::getAWSBucketName($siteID);
            $accesskey = Common::getAPIKey($siteID);
            $secret = Common::getAWSSecretKey($siteID);
        }

        $client = S3Client::factory(array(
            'key'    => $accesskey,
            'secret' => $secret
        ));

        $Model->result = $client->deleteObject(array('Bucket' => $bucket,'Key' => $key));
        return $Model;
    }
    /* AWS Section End */

    public function SetEntityAttributes($item,$model,$isExtraAttr=false){
        $ActualFields = array_map(function () { return ''; }, $item->Model_Types);
        if($isExtraAttr) {
            $ExtraFields = array_map(function () { return ''; }, $item->Model_Extras);
            $ActualFields = array_merge($ActualFields,$ExtraFields);
        }
        return array_merge($ActualFields,(array)$model);
    }

    public function getWebSiteBaseURL($siteID){
        $baseURL = DB::table('sites')->where('SiteID', $siteID)->pluck('WebsiteBaseURL');
        return $baseURL;
    }
}