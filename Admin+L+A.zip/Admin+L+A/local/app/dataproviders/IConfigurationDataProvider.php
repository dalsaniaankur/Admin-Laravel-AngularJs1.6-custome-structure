<?php 
namespace dataproviders;

Interface IConfigurationDataProvider{

    /*AD Start*/
    /*AD  End*/

}
