<?php
namespace dataproviders;


Interface IDevelopmentDataProvider{
    /*Start Dev_VA*/
    public function getDevelopmentData($developmentID,$siteID,$loginUserID);
    public function SaveDevelopment($devModel,$loggedInUserID,$siteID);
    /*End Dev_VA*/
    public function getSearchModelForDevelopmentList($SiteID);
    public function getDevelopmentInfoList($developmentData,$loggedInUserID,$siteID);
    public function RemoveImage($fileRemoveData,$siteID);
    public function getDevelopmentVideoList($developmentData,$siteID);
    public function RemoveDevelopmentVideo($videoID,$siteID);
    public function DeleteDevelopmentListing($developmentID,$siteID);
    public function geDevelopmentListing($userData,$siteID);
    public function DeleteDevelopment($developmentID,$siteID);
}