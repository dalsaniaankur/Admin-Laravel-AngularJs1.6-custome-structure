<?php
namespace dataproviders;
use \ViewModels\ServiceResponse;
use \Infrastructure\Constants;
use \stdClass;
use \Crypt;
use \URL;
use \Mail;
use File;
use MenuItemsEntity;
use Infrastructure\CacheHelper;


class NavigationDataProvider extends BaseDataProvider implements INavigationDataProvider {
    /* Dev_AD Region Start */
    public function postNavigationMenuData($menuModel,$loginUserID,$siteID){
        $response = new ServiceResponse();
        $model =  new StdClass();
        $pageStatus = Constants::$PageStatusPublished;
        $menuResult = $this->CallRawForMultipleTable('menudetails',array($menuModel->MenuID,$loginUserID,$siteID,$pageStatus));
        $parentMenu = $menuResult[1];

        $model->Pages = $menuResult[0];
        $model->Tree = $this->buildTree($parentMenu);
        $model->IsFooterMenu = $menuModel->MenuID;
        $model->MenuID = $menuResult[2][0]->MenuID;

        $response->Data = $model;
        $response->IsSuccess=true;

        return $response;
    }

    function buildTree(array $elements, $parentId = 0) {
        $branch = array();

        foreach ($elements as $element) {
            if ($element->ParentMenuItemID == $parentId) {
                $children = $this->buildTree($elements, $element->MenuItemID);
                if ($children) {
                    $element->nodes = $children;
                }
                else
                    $element->nodes = [];
                $branch[] = $element;
            }
        }

        return $branch;
    }

    public function postSaveNavigationMenu($Model,$loginUserID,$siteID){
        $response = new ServiceResponse();
        $model =  new StdClass();
        if(isset($Model->DeletedMenuItemID) AND ($Model->DeletedMenuItemID != NULL)) {
            $this->CallRawForMultipleTable('deletenavigationmenu', [$Model->DeletedMenuItemID]);
        }
        $menuModel = $Model->Tree;
        $Results = $this->flattenTree($menuModel, $Model->MenuID, 1, 0, $siteID, $loginUserID);

        if($Results){
            /* Get menu date */
            $pageStatus = Constants::$PageStatusPublished;
            $menuResult = $this->CallRawForMultipleTable('menudetails',array($Model->SelectedMenuID, $loginUserID, $siteID, $pageStatus));
            $model->Tree = $this->buildTree($menuResult[1]);
            $response->Data = $model;

            $response->IsSuccess = true;
            $response->Message = trans('messages.NavigationMenuAddedSuccess');
            CacheHelper::CacheManage($siteID,Constants::$cacheNavigationID,Constants::$cacheActionUpdate,$Model->SelectedMenuID);
        }else{
            $response->Message = trans('messages.ErrorOccured');
        }
        return $response;
    }

    function flattenTree(array $arr, $MenuID, $index = 1, $parentID = 0, $siteID = 0, $loginUserID = 0)
    {
        $dateTime = date(Constants::$DefaultDateTimeFormat);
        foreach($arr as $key=>$item){
            $menuItemEntity = new MenuItemsEntity();
            if(isset($item['MenuItemID'])){
                $menuItemEntity = $this->GetEntityForUpdateByPrimaryKey($menuItemEntity,$item['MenuItemID']);
            }
            else{
                $menuItemEntity->CreatedDate = $dateTime;
                $menuItemEntity->CreatedByID = $loginUserID;
                $menuItemEntity->MenuID= $MenuID;
                $menuItemEntity->SiteID= $siteID;
                $menuItemEntity->IsOpenNewTab= isset($item['IsOpenNewTab'])? $item['IsOpenNewTab']:'';
                if($item['Type'] == 'Pages'){
                    $menuItemEntity->PageID = $item['PageID'];
                    $menuItemEntity->DevelopmentID =NULL;
                    $menuItemEntity->CustomURL = NULL;
                }else if($item['Type'] == 'Developments'){
                   $menuItemEntity->DevelopmentID = $item['PageID'];
                   $menuItemEntity->PageID = NULL;
                   $menuItemEntity->CustomURL = NULL;
                }else if($item['Type'] == 'Custom'){
                    $menuItemEntity->DevelopmentID = NULL;
                    $menuItemEntity->PageID = NULL;
                    $menuItemEntity->CustomURL = $item['CustomURL'];
                }
            }
            $menuItemEntity->ParentMenuItemID = $parentID;
            $menuItemEntity->ItemName = $item['DisplayName'];
            $menuItemEntity->ItemLevel = $index;
            $menuItemEntity->ItemOrder = $key+1;
            $menuItemEntity->ModifiedDate = $dateTime;
            $menuItemEntity->ModifiedByID = $loginUserID;
            $result= $this->SaveEntity($menuItemEntity);

            if(isset($item['nodes']))
            {
                $this->flattenTree($item['nodes'], $MenuID, $index + 1, $result->MenuItemID, $siteID, $loginUserID);
            }
        }

        return true;
    }

    public function checkKeyExists($id,$output)
    {
        if (array_key_exists($id, $output)) {
            return max(array_keys($output)) + 1;
        } else {
            return $id;
        }
    }
    /* Dev_AD Region End */

}