<?php
namespace dataproviders;
 
use Illuminate\Support\ServiceProvider;
 

class BaseServiceProvider extends ServiceProvider {
	
	
  public function register()
  {
    $app = $this->app;
	$app->bind('dataproviders\IUserDataProvider','dataproviders\UserDataProvider');
    $app->bind('dataproviders\ISecurityDataProvider','dataproviders\SecurityDataProvider');
    $app->bind('dataproviders\IAgentDataProvider','dataproviders\AgentDataProvider');
	$app->bind('dataproviders\IFaqDataProvider','dataproviders\FaqDataProvider');
	$app->bind('dataproviders\IVideoDataProvider','dataproviders\VideoDataProvider');
	$app->bind('dataproviders\IDevelopmentDataProvider','dataproviders\DevelopmentDataProvider');
	$app->bind('dataproviders\IPropertyListingDataProvider','dataproviders\PropertyListingDataProvider');
	$app->bind('dataproviders\ISiteDataProvider','dataproviders\SiteDataProvider');
    $app->bind('dataproviders\IWorkflowDataProvider','dataproviders\PagesDataProvider');
    $app->bind('dataproviders\IWorkflowDataProvider','dataproviders\BlogPostDataProvider');
    $app->bind('dataproviders\INavigationDataProvider','dataproviders\NavigationDataProvider');
    $app->bind('dataproviders\IConfigurationDataProvider','dataproviders\ConfigurationDataProvider');
    $app->bind('dataproviders\IHomeDataProvider','dataproviders\HomeDataProvider');
    $app->bind('dataproviders\ILoanDataProvider','dataproviders\LoanDataProvider');
    $app->bind('dataproviders\ILandingPageDataProvider','dataproviders\LandingPageDataProvider');
  }
 
}