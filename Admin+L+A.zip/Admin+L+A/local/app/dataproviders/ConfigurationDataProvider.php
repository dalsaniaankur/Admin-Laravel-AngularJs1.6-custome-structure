<?php
namespace dataproviders;
use Illuminate\Support\Facades\Validator;
use \ViewModels\ServiceResponse;
use \Infrastructure\Constants;
use \Infrastructure\Common;
use Illuminate\Support\Facades\Config;
use \stdClass;
use \Crypt;
use Illuminate\Support\Facades\URL;
use \Mail;
use File;
use SitesEntity;
use Infrastructure\CacheHelper;

class ConfigurationDataProvider extends BaseDataProvider implements IConfigurationDataProvider {

    /* Dev_AD Region Start */
    public function getConfigurationView($SiteID){
        $response = new ServiceResponse();
        $model = new StdClass();
        $ConfigurationModel = new StdClass();
        $results = $this->CallRawForMultipleTable('configurationdetails',[$SiteID], false ,["IsSSL"]);

        $ConfigurationModel->TimeZonesArray = $results[0];
        $ConfigurationModel->ConfigurationDetails = $results[1][0];

        if(!empty($ConfigurationModel->ConfigurationDetails->PublisherLogoPath)){
            $imageData = $this->Awsdownloadfile($ConfigurationModel->ConfigurationDetails->PublisherLogoPath,$SiteID);
            $ConfigurationModel->ConfigurationDetails->RealImagePath = $imageData->signedUrl;
        }else{
            $ConfigurationModel->ConfigurationDetails->RealImagePath ='';
            $ConfigurationModel->ConfigurationDetails->UploadFilesArray = '';
        }
        $ConfigurationModel->ConfigurationDetails->Fileuploadsettings = $this->FileUploadSettings(Constants::$AWSRequestType_Configuration,$SiteID,'');
        $ConfigurationModel->ConfigurationDetails->encryptedSiteID = Common::getEncryptedValue(Constants::$QueryStringSiteID.'='.$SiteID);
        $model->ConfigurationModel = $ConfigurationModel;
        $response->Data = $model;
        return $response;
    }
    public function postSaveConfiguration($model,$SiteID){

        $response = new ServiceResponse();
        $messages = array(
            'required' => trans('messages.PropertyRequired'),
            'min' => trans('messages.PropertyMin'),
            'max' => trans('messages.PropertyMax')
        );

        /* sites table validation. */
        $validator = Validator::make((array)$model,SitesEntity::$Add_rules,$messages);
        $validator->setAttributeNames(SitesEntity::$niceNameArray);
        if($validator->fails()){
            $response->Message=Common::getValidationMessagesFormat($validator->messages());
            return $response;
        }

        if(!isset($model->GoogleCSEKey)){$model->GoogleCSEKey = '';}
        if(!isset($model->GoogleCSEID)){$model->GoogleCSEID = '';}
        if(!isset($model->ScriptBeforeHead)){$model->ScriptBeforeHead = '';}
        if(!isset($model->ScriptBeforeBody)){$model->ScriptBeforeBody = '';}
        if(!isset($model->FacebookURL)){$model->FacebookURL = '';}
        if(!isset($model->InstagramURL)){$model->InstagramURL = '';}
        if(!isset($model->YoutubeURL)){$model->YoutubeURL = '';}
        if(!isset($model->PinterestURL)){$model->PinterestURL = '';}
        if(!isset($model->LinkedInURL)){$model->LinkedInURL = '';}
        if(!isset($model->GooglePlusURL)){$model->GooglePlusURL = '';}

        if(!isset($model->PublisherLogoPath)){$model->PublisherLogoPath = '';}
        if(!isset($model->PageSection)){$model->PageSection = '';}
        if(!isset($model->BlogSection)){$model->BlogSection = '';}
        if(!isset($model->ContactNo)){$model->ContactNo = '';}
        if(!isset($model->Address)){$model->Address = '';}
        if(!isset($model->houzzURL)){$model->houzzURL = '';}

        if(!isset($model->AlternateContactNo)){$model->AlternateContactNo = '';}
        if(!isset($model->EmailId)){$model->EmailId = '';}

        if(!isset($model->NoOfImagesToShowForListing)){$model->NoOfImagesToShowForListing = '';}
        if(!isset($model->NoOfPropertiesToShowOnExclusiveProperties)){$model->NoOfPropertiesToShowOnExclusiveProperties = '';}

        if(!isset($model->RDNoOfLoanClosedToShow)){$model->RDNoOfLoanClosedToShow = '';}

        $result = $this->CallRawForMultipleTable('saveconfiguration',array( $SiteID,
                                                                            $model->WebsiteBaseURL,
                                                                            $model->PublisherName,
                                                                            $model->PublisherLogoPath,
                                                                            $model->TwitterUsername,
                                                                            $model->FacebookAppID,
                                                                            $model->LinkedInAppID,
                                                                            $model->GoogleCSEKey,
                                                                            $model->GoogleCSEID,
                                                                            $model->Timezone,
                                                                            $model->ScriptBeforeHead,
                                                                            $model->ScriptBeforeBody,
                                                                            $model->FacebookURL,
                                                                            $model->InstagramURL,
                                                                            $model->YoutubeURL,
                                                                            $model->PinterestURL,
                                                                            $model->LinkedInURL,
                                                                            $model->GooglePlusURL,
                                                                            $model->SMTPHost,
                                                                            $model->SMTPUserName,
                                                                            $model->SMTPPassword,
                                                                            $model->SMTPPort,
                                                                            $model->SMTPFromAddress,
                                                                            $model->SMTPFromName,
                                                                            $model->IsSSL,
                                                                            $model->RETSUserName,
                                                                            $model->RETSPassword,
                                                                            $model->PageSection,
                                                                            $model->BlogSection,
                                                                            $model->PublisherLogoWidth,
                                                                            $model->PublisherLogoHeight,
                                                                            $model->GeoAPIKey,
                                                                            $model->NoOfImagesToShowForListing,
                                                                            $model->NoOfPropertiesToShowOnExclusiveProperties,
                                                                            $model->ContactNo,
                                                                            $model->RDNoOfLoanClosedToShow,
                                                                            $model->Address,
                                                                            $model->houzzURL,
                                                                            $model->AlternateContactNo,
                                                                            $model->EmailId,
                                                                            ));
        if($result[0][0]->ResultStatus){
            if(isset($SiteID) && !empty($SiteID) && $SiteID > 0 ){
                CacheHelper::CacheManage($SiteID,Constants::$cacheSiteConfigurationID,Constants::$cacheActionUpdate,$SiteID);
            }
            $response->IsSuccess = true;
            $response->Message = trans('messages.ConfigurationUpdateSuccess');
        }else{
            $response->Message = trans('messages.ErrorOccured');
        }
        return $response;

    }
    public function AwsDownloadFileImages($data){
        $response = new ServiceResponse();
        $response->Data = $this->Awsdownloadfile($data->PublisherLogoPath);
        $response->IsSuccess=true;
        return $response;
    }
    public function DeleteSiteImageAmazon($data){
        $response = new ServiceResponse();
        $Model=new stdClass();
        if($data->SiteID == 0){
            $this->Awsdeletefile($data->PublisherLogoPath,0);
        }
        $response->Data= $Model->RealImagePath='';
        $response->IsSuccess=true;
        return $response;
    }
    /* Dev_AD Region End */

}