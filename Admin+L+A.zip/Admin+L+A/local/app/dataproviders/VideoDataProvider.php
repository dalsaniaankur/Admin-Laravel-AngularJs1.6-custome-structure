<?php
namespace dataproviders;
use Illuminate\Support\Facades\Validator;
use \ViewModels\ServiceResponse;
use \Infrastructure\Constants;
use \Infrastructure\Common;
use \stdClass;
use \Crypt;
use Illuminate\Support\Facades\URL;
use \Mail;
use File;
use VideoEntity;
use Infrastructure\CacheHelper;
class VideoDataProvider extends BaseDataProvider implements IVideoDataProvider {
	
    /* Dev_AD Region Start */
    public function getVideoTypeDetails($videoID,$siteID){
        $response = new ServiceResponse();
        $model = new StdClass();
        $videoModel = new StdClass();
        $addEditVideoResults = $this->CallRawForMultipleTable('videodetails',[$videoID,$siteID]);
        if(isset($addEditVideoResults[3])){
            $videoModel->VideoDetails = $addEditVideoResults[3][0];
            if(!empty($videoModel->VideoDetails->ThumbnailImageURL)){
                $imageData = $this->Awsdownloadfile($videoModel->VideoDetails->ThumbnailImageURL,$siteID);
                $videoModel->VideoDetails->RealImagePath = $imageData->signedUrl;
            }else{
                $videoModel->VideoDetails->RealImagePath ='';
                $videoModel->VideoDetails->UploadFilesArray = '';
            }

        }else{
            $videoModel->VideoDetails = new StdClass();
            $videoModel->VideoDetails->VideoID = Constants::$Value_False;
            $videoModel->VideoDetails->RealImagePath = '';
            $videoModel->VideoDetails->ImageName = '';
            $videoModel->VideoDetails->UploadFilesArray = '';
            $videoModel->VideoDetails->TempFilesArray = '';
        }
        if(isset($addEditVideoResults[4])){
           $videoModel->VideoDetails->TagID = $addEditVideoResults[4];
        }
        $videoModel->VideoDetails->Fileuploadsettings = $this->FileUploadSettings(Constants::$AWSRequestType_Video,$siteID,'');
        $videoModel->VideoDetails->encryptedSiteID = Common::getEncryptedValue(Constants::$QueryStringSiteID.'='.$siteID);
        $videoModel->VideoDetails->DevelopmentArray= $addEditVideoResults[0];
        $videoModel->VideoDetails->VideoCategoryArray= $addEditVideoResults[1];
        $videoModel->VideoDetails->SiteTagsArray= $addEditVideoResults[2];
        $model->VideoModel = $videoModel;
        $videoModel->VideoDetails->SiteID= $siteID;
        $response->Data = $model;
        return $response;
    }
    public function AddVideoData($VideoModel,$loginUserID,$siteID){
        $response = new ServiceResponse();
        $message = array(
            'required' => trans('messages.PropertyRequired'),
            'min' => trans('messages.PropertyMin'),
            'max' => trans('messages.PropertyMax')
        );
        $isEditMode = false;
        if(($VideoModel->VideoID) > 0) {
            $isEditMode = true;
        }
        $validator = Validator::make((array)$VideoModel,VideoEntity::$Add_rules,$message);
        $validator->setAttributeNames(VideoEntity::$niceNameArray);
        if($validator->fails()){
            $response->Message=Common::getValidationMessagesFormat($validator->messages());
            return $response;
        }
        if(!isset($VideoModel->ThumbnailImageURL)){$VideoModel->ThumbnailImageURL = NULL;}
        if(!isset($VideoModel->ShortDescription)){$VideoModel->ShortDescription = NULL;}
        if(!isset($VideoModel->DevelopmentID)){$VideoModel->DevelopmentID = NULL;}
        if(!isset($VideoModel->VideoID)){$VideoModel->VideoID = NULL;}
        $tagCsv = isset($VideoModel->TagID) ? Common::GetCsvFromArrayProperty($VideoModel->TagID,"TagID") : '';
        $results = $this->CallRawForMultipleTable('savevideo',[$VideoModel->Title,$VideoModel->YoutubeURL,$VideoModel->CategoryID,$VideoModel->DevelopmentID,$VideoModel->ShortDescription,$VideoModel->ThumbnailImageURL,$VideoModel->VideoID,$VideoModel->SiteID,$loginUserID,$tagCsv]);
        if($results[0][0]->ResultStatus){
             $response->RedirectUrl= URL::to('/')."/videolist/".Common::getEncryptedValue(Constants::$QueryStringSiteID.'='.$siteID);
            if($isEditMode){
                if(isset($results[1][0]->EntityID) && !empty($results[1][0]->EntityID) && $results[1][0]->EntityID > 0 ){
                    CacheHelper::CacheManage($siteID,Constants::$cacheVideoID,Constants::$cacheActionUpdate,$results[1][0]->EntityID);
                    if(isset($VideoModel->DevelopmentID) && $results[1][0]->EntityID != $VideoModel->DevelopmentID) {
                        CacheHelper::CacheManage($siteID,Constants::$cacheVideoID,Constants::$cacheActionUpdate,$VideoModel->DevelopmentID);
                    }
                }else{
                    CacheHelper::CacheManage($siteID,Constants::$cacheVideoID,Constants::$cacheActionUpdate, isset($VideoModel->DevelopmentID) ? $VideoModel->DevelopmentID : '');
                }
                $response->IsSuccess = true;
                $response->Message =trans('messages.VideoUpdateSuccess');
            }else{
                if(isset($results[1][0]->EntityID) && !empty($results[1][0]->EntityID) && $results[1][0]->EntityID > 0 ){
                    CacheHelper::CacheManage($siteID,Constants::$cacheVideoID,Constants::$cacheActionInsert,$results[1][0]->EntityID);
                }else {
                    CacheHelper::CacheManage($siteID, Constants::$cacheVideoID, Constants::$cacheActionInsert, '');
                }
                $response->IsSuccess = true;
                $response->Message = trans('messages.VideoAddedSuccess');
            }



        }else{
            $response->Message = trans('messages.ErrorOccured');
        }
        return $response;
    }
    public function DeleteVideo($VideoID,$siteID,$developmentID){
        $response = new ServiceResponse();
        $deleteVideoResults = $this->CallRawForMultipleTable('deletevideo',[$VideoID,$siteID]);
        if($deleteVideoResults[0][0]->ResultStatus) {
            if(isset($VideoID) && !empty($VideoID) && $VideoID > 0 ){
                CacheHelper::CacheManage($siteID,Constants::$cacheVideoID,Constants::$cacheActionDelete,$developmentID);
                if(isset($developmentID) && $developmentID > 0 ) {
                    CacheHelper::CacheManage($siteID, Constants::$cacheDevelopmentID, Constants::$cacheActionUpdate, $developmentID);
                }
            }
            $response->IsSuccess=true;
            $response->Message= trans('messages.VideoDeleted');
            $response->RedirectUrl= URL::to('/')."/videolist/".Common::getEncryptedValue(Constants::$QueryStringSiteID.'='.$siteID);
        } else {
            $response->Message= trans('messages.ErrorOccured');
        }
        return $response;
    }
    public function getSearchModelForVideoList($SiteID){
        $response = new ServiceResponse();
        $model = new StdClass();
        $videoModel = new StdClass();
        $videoDetail = $this->CallRawForMultipleTable('videolist',[$SiteID]);

        $videoModel->VideoListArray = $videoDetail[0];
        $model->VideoModel = $videoModel;
        $response->Data = $model;
        return $response;
    }
    public function UpdateSortOrderVideo($OldOrder,$newOrder,$SiteID){
        $response = new ServiceResponse();
        $addFaqResults = $this->CallRawForMultipleTable('sortordervideolist',[$OldOrder,$newOrder,$SiteID]);
        CacheHelper::CacheManage($SiteID,Constants::$cacheVideoID,Constants::$cacheUpdateSortOrder,'');
        $response->IsSuccess=true;
        $response->Message= trans('messages.VideoOrder');
        return $response;
    }
    public function AwsDownloadFileImages($data){
        $response = new ServiceResponse();
        $response->Data = $this->Awsdownloadfile($data->ThumbnailImageURL);
        $response->IsSuccess=true;
        return $response;
    }

    public function DeleteVideoImageAmazon($data,$siteID){
        $response = new ServiceResponse();
        $Model=new stdClass();
        if($data->VideoID == 0){
            $this->Awsdeletefile($data->ThumbnailImageURL,$siteID);
        }
        $response->Data= $Model->RealImagePath='';
        $response->IsSuccess=true;
        return $response;
    }

    /* Dev_AD Region End */

}