<?php
namespace dataproviders;
use Illuminate\Support\Facades\DB;
use Infrastructure\Common;
use \ViewModels\ServiceResponse;
use \Infrastructure\Constants;
use \stdClass;
use \Crypt;
use File;
use LandingPageImageEntity;
use ViewModels\SearchValueModel;


class LandingPageDataProvider extends BaseDataProvider implements ILandingPageDataProvider {

    /* Dev_RB Region Start */
   public function getLandingPageDetails($siteID,$loginUserID){

       $response = new ServiceResponse();
       $model = new StdClass();
       $landingPageModel = new StdClass();

       $PageData = $this->CallRawForMultipleTable('landingpageimages', [$siteID]);

       /* For Page Header Image Start */
       $result = $PageData[0];
       if($result){
           $imageArray =$result;
           foreach($imageArray as $data){
               if($data->ImagePath !='')
                $data->RealImagePath = Common::getAWSUrl($siteID).''.Common::getAWSBucketName($siteID).'/'.$data->ImagePath;
               else
                $data->RealImagePath = $data->ImagePath;
           }
       }
       /* For Page Header Image End */


       /* For Right Bottom Image Start */
       $BottomImageData = $PageData[1];
       if($BottomImageData){
           $imageArray = $BottomImageData;
           foreach($imageArray as $data){
               if($data->ImagePath !='')
                   $data->RealImagePath = Common::getAWSUrl($siteID).''.Common::getAWSBucketName($siteID).'/'.$data->ImagePath;
               else
                   $data->RealImagePath = $data->ImagePath;
           }
       }
       /* For Right Bottom Image End */

       /* For Page Content Start */
       $PageContentData = $PageData[2];
       
       /* For Page Content End */


       $landingPageModel->FileUploadSettings = $this->FileUploadSettings(Constants::$AWSRequestType_LandingPage,$siteID,$loginUserID);

       $landingPageModel->SiteID = $siteID;
       $landingPageModel->PageData = $result;
       $landingPageModel->PageRightBottomImageData = $BottomImageData;
       $landingPageModel->PageContentData = $PageContentData;

       $model->LandingPageModel = $landingPageModel;
       $response->Data = $model;
       return $response;
   }

    public function AwsFileDownload($data){
        $response = new ServiceResponse();
        $response->Data = $this->Awsdownloadfile($data->ImagePath,'',true);
        $response->IsSuccess = true;
        return $response;
    }

    public function DeleteLandingPageImageAmazon($data,$siteID){

        $response = new ServiceResponse();

        if(isset($data->fileObject['ImagePath'])){
            $res = $this->Awsdeletefile($data->fileObject['ImagePath'],$siteID,'');

            if(isset($data->fileObject['ID']) && $res){
                 $result = $this->CallRawForSingleTable('deletelandingpageimages', [$data->fileObject['ID']]);
            }
        }

        $response->Data = '';
        $response->Message = trans('messages.LandingPageImageRemove');
        $response->IsSuccess = true;
        return $response;
    }

    public function SaveLandingPageImage($data,$siteID){
        $response = new ServiceResponse();

        $imageData = $data;
        foreach($imageData as $data){
            $LandingPageImageEntity = $this->GetEntityForUpdateByPrimaryKey(new LandingPageImageEntity(),$data['ID']);
            if($data['LandingType'] == 2){
              $LandingPageImageEntity->LandingpageContent = $data['LandingpageContent'];
            }
            else{
              $LandingPageImageEntity->ImagePath = $data['ImagePath'];
            }
            
            $this->SaveEntity($LandingPageImageEntity);
        }

        $response->Message = trans('messages.LandingPageImage');
        $response->IsSuccess=true;
        $response->Data = '';
        return $response;
    }

    /* Dev_RB Region End */

}