<?php
use \Infrastructure\Constants;
use Infrastructure\Common;
/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

/* RB Region Start */
Route::get('mailstosend',array('uses' => 'CronJobController@getSendMail'));
Route::get('unauthorize', array('uses' => 'SecurityController@getUnauthorized'));
Route::get('/',array('uses' => 'SecurityController@getLogin'));
Route::post('authenticate', array('uses' => 'SecurityController@postAuthenticate'));
Route::get('choosesite',array('before' => 'auth:'.Constants::$RoleChooseSite.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'SecurityController@getChooseSite'));
Route::get('logout', array('uses' => 'SecurityController@getLogout'));
Route::post('verification', array('uses' => 'SecurityController@postSendVerificationEmail'));
Route::post('selectsite', array('before' => 'auth:'.Constants::$RoleChooseSite.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'SecurityController@postSelectSite'));
Route::get('dashboard/{siteid?}', array('before' => 'auth:'.Common::getAllRoleArray().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'SecurityController@getDashboard'));
Route::post('getdashboardbloglist',array('before'=>'auth:'.Common::getAllRoleArray().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses'=>'SecurityController@postBlogPostsList'));
Route::post('getdashboardpagelist',array('before'=>'auth:'.Common::getAllRoleArray().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses'=>'SecurityController@postPagesList'));

Route::get('adduser/{combinesiteuserid?}', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'UserController@getAddUser'));
//Route::post('saveuser', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'UserController@postSaveUser'));
Route::post('saveuser', array('before' => 'auth:'.Constants::$RoleChooseSite.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'UserController@postSaveUser'));

/* For Update user and agent profile */
Route::get('updateprofile', array('before' => 'auth:'.Constants::$RoleChooseSite.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'UserController@getUpdateProfile'));
Route::get('updatemyprofile', array('before' => 'auth:'.Constants::$RoleChooseSite.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'UserController@getUpdateMyProfile'));
Route::get('updateagentProfile', array('before' => 'auth:'.Constants::$RoleChooseSite.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'AgentController@getUpdateAgentProfile'));


Route::post('getprofileimage', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'UserController@getProfileImage'));
Route::post('removeprofileimage', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'UserController@postRemoveProfileImage'));

Route::get('adddevelopment/{siteid?}',array('before' => 'auth:'.Common::getRoleITAdminAndAgent().Constants::$AuthSeparator.Common::getSiteMercerVineColorado(),'uses'=>'DevelopmentController@getAddDevelopmentView'));
Route::post('savedevelopment',array('before' => 'auth:'.Common::getRoleITAdminAndAgent().Constants::$AuthSeparator.Common::getSiteMercerVineColorado(),'uses'=>'DevelopmentController@postSaveDevelopment'));
Route::get('developments/{siteid?}',array('before' => 'auth:'.Common::getRoleITAdminAndAgent().Constants::$AuthSeparator.Common::getSiteMercerVineColorado(),'uses' => 'DevelopmentController@getDevelopmentList'));
Route::post('getdevelopmentlist',array('before' => 'auth:'.Common::getRoleITAdminAndAgent().Constants::$AuthSeparator.Common::getSiteMercerVineColorado(),'uses' => 'DevelopmentController@postDevelopmentList'));
Route::post('deleteimage',array('before' => 'auth:'.Common::getRoleITAdminAndAgent().Constants::$AuthSeparator.Common::getSiteMercerVineColorado(),'uses' => 'DevelopmentController@postDeleteImage')); // Update url to deletedevelopmentimage.
Route::post('deletedevelopment',array('before' => 'auth:'.Common::getRoleITAdminAndAgent().Constants::$AuthSeparator.Common::getSiteMercerVineColorado(),'uses' => 'DevelopmentController@postDeleteDevelopment'));
Route::post('getdevelopmentimage',array('before' => 'auth:'.Common::getRoleITAdminAndAgent().Constants::$AuthSeparator.Common::getSiteMercerVineColorado(),'uses' => 'DevelopmentController@getDevelopmentImage'));
Route::post('removedevelopmenttopimage',array('before' => 'auth:'.Common::getRoleITAdminAndAgent().Constants::$AuthSeparator.Common::getSiteMercerVineColorado(),'uses' => 'DevelopmentController@postRemoveDevelopmentImage'));
Route::post('deletedevelopmentfeacturesfiles',array('before' => 'auth:'.Common::getRoleITAdminAndAgent().Constants::$AuthSeparator.Common::getSiteMercerVineColorado(),'uses' => 'DevelopmentController@PostDeleteDevelopmentFeaturesFiles'));

Route::post('developmentvideo',array('before' => 'auth:'.Common::getRoleITAdminAndAgent().Constants::$AuthSeparator.Common::getSiteMercerVineColorado(),'uses' => 'DevelopmentController@PostDevelopmentVideoList'));
Route::post('removedevelopmentvideo',array('before' => 'auth:'.Common::getRoleITAdminAndAgent().Constants::$AuthSeparator.Common::getSiteMercerVineColorado(),'uses' => 'DevelopmentController@PostRemoveDevelopmentVideo'));

Route::post('getdevelopmentpropertylist',array('before' => 'auth:'.Common::getRoleITAdminAndAgent().Constants::$AuthSeparator.Common::getSiteMercerVineColorado(),'uses' => 'DevelopmentController@PostDevelopmentPropertiesList'));
Route::post('deletedevelopmentlisting',array('before' => 'auth:'.Common::getRoleITAdminAndAgent().Constants::$AuthSeparator.Common::getSiteMercerVineColorado(),'uses' => 'DevelopmentController@PostDeleteDevelopmentListing'));
Route::post('deletepropertyfeacturesfiles',array('before' => 'auth:'.Common::getRoleITAdminMDAgent().Constants::$AuthSeparator.Common::getSiteMercerVineWoodbridgeColorado(),'uses' => 'PropertyListingController@PostDeletePropertyFeaturesFiles'));

Route::post('clearcache', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'SiteController@postClearCache'));

Route::get('headerimg/{siteid?}',array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getSiteColoradoWW(),'uses' => 'LandingPageController@getLandingPageImage'));
Route::post('landingpageimage', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getSiteColoradoWW(),'uses' => 'LandingPageController@getLandingPageUploadedImage'));
Route::post('removelandingpageimage', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getSiteColoradoWW(),'uses' => 'LandingPageController@postRemoveLandingPageImage'));
Route::post('savelandingpageimage', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getSiteColoradoWW(),'uses' => 'LandingPageController@postSaveLandingPageImage'));
/* RB Region End */


/* Ayushi Region Start */
Route::get('addlisting/{combinesitelistingid?}', array('before' => 'auth:'.Common::getRoleITAdminMDAgent().Constants::$AuthSeparator.Common::getSiteMercerVineWoodbridgeColorado(),'uses' => 'PropertyListingController@getAddProperty'));
Route::post('savelisting', array('before' => 'auth:'.Common::getRoleITAdminMDAgent().Constants::$AuthSeparator.Common::getSiteMercerVineWoodbridgeColorado(),'uses' => 'PropertyListingController@postSaveProperty'));
Route::post('searchmls', array('before' => 'auth:'.Common::getRoleITAdminMDAgent().Constants::$AuthSeparator.Common::getSiteMercerVineWoodbridgeColorado(),'uses' => 'PropertyListingController@postRETSCall'));
Route::post('deletepropertyimage',array('before' => 'auth:'.Common::getRoleITAdminMDAgent().Constants::$AuthSeparator.Common::getSiteMercerVineWoodbridgeColorado(),'uses' => 'PropertyListingController@postDeletePropertyImage'));
Route::post('deleteproperty',array('before' => 'auth:'.Common::getRoleITAdminMDAgent().Constants::$AuthSeparator.Common::getSiteMercerVineWoodbridgeColorado(),'uses' => 'PropertyListingController@postDeleteProperty'));
Route::get('deletepropertyimages', array('uses' => 'CronJobController@postDeletePropertyImages'));

/* Ayushi Region End */

/*Start Region Dev_AD*/
Route::get('forgotpassword/{token?}', array($token = null,'uses' => 'SecurityController@getForgotPassword'));
Route::post('sendresetpassword', array('uses' => 'SecurityController@postSendResetPasswordEmail'));
Route::post('postresetpassword', array('uses' => 'SecurityController@postResetPasswordEmail'));

Route::get('addfaq/{combinefaqsiteid?}', array('before' => 'auth:'.Common::getRoleMDITAdminSEO().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'FaqController@getAddFaq'));
Route::post('savefaq', array('before' => 'auth:'.Common::getRoleMDITAdminSEO().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'FaqController@postAddFaq'));
Route::get('faqlist/{siteid?}', array('before' => 'auth:'.Common::getRoleMDITAdminSEO().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'FaqController@getFaqList'));
Route::post('updatesortorderfaq', array('before' => 'auth:'.Common::getRoleMDITAdminSEO().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'FaqController@UpdateSortOrderFaq'));
Route::post('deletefaq', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'FaqController@deleteFaq'));

Route::get('addvideo/{combinefaqsiteid?}', array('before' => 'auth:'.Common::getRoleMDITAdminSEO().Constants::$AuthSeparator.Constants::$MercerVineSiteID,'uses' => 'VideoController@getAddVideo'));
Route::post('savevideo', array('before' => 'auth:'.Common::getRoleMDITAdminSEO().Constants::$AuthSeparator.Constants::$MercerVineSiteID,'uses' => 'VideoController@postAddVideo'));
Route::get('videolist/{siteid?}', array('before' => 'auth:'.Common::getRoleMDITAdminSEO().Constants::$AuthSeparator.Constants::$MercerVineSiteID,'uses' => 'VideoController@getVideoList'));
Route::post('updatesortordervideo', array('before' => 'auth:'.Common::getRoleMDITAdminSEO().Constants::$AuthSeparator.Constants::$MercerVineSiteID,'uses' => 'VideoController@UpdateSortOrderVideo'));
Route::post('deletevideo', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Constants::$MercerVineSiteID,'uses' => 'VideoController@deleteVideo'));

Route::post('removevideoimage', array('before' => 'auth:'.Common::getRoleMDITAdminSEO().Constants::$AuthSeparator.Constants::$MercerVineSiteID,'uses' => 'VideoController@postRemoveVideoImage'));
Route::post('getvideoimage', array('before' => 'auth:'.Common::getRoleMDITAdminSEO().Constants::$AuthSeparator.Constants::$MercerVineSiteID,'uses' => 'VideoController@getVideoImage'));

Route::get('addagent/{combinesiteuserid?}', array('before' => 'auth:'.Common::getRoleITAdminMDAgent().Constants::$AuthSeparator.Common::getSiteMercerVineColorado(),'uses' => 'AgentController@getAddAgent'));
Route::post('saveagent', array('before' => 'auth:'.Constants::$RoleChooseSite.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'AgentController@postAddAgent'));
Route::post('featuredchange', array('before' => 'auth:'.Constants::$RoleChooseSite.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'AgentController@postFeaturedChange'));
Route::post('checkuniquelicense', array('before' => 'auth:'.Constants::$RoleChooseSite.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'AgentController@postCheckUniqueLicense'));
Route::post('checkuniqueemail', array('before' => 'auth:'.Constants::$RoleChooseSite.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'AgentController@postCheckUniqueEmail'));

Route::post('getpropertylistagent',array('uses' => 'AgentController@postPropertyList'));

Route::post('getagentimage', array('before' => 'auth:'.Common::getRoleITAdminMDAgent().Constants::$AuthSeparator.Common::getSiteMercerVineColorado(),'uses' => 'AgentController@getAgentImage'));
Route::post('removeagentimage', array('before' => 'auth:'.Common::getRoleITAdminMDAgent().Constants::$AuthSeparator.Common::getSiteMercerVineColorado(),'uses' => 'AgentController@postRemoveAgentImage'));

Route::get('listing/{siteid?}', array('before' => 'auth:'.Common::getRoleITAdminAndAgent().Constants::$AuthSeparator.Common::getSiteMercerVineColorado(),'uses' => 'PropertyListingController@getPropertyList'));
Route::post('getpropertylist',array('before' => 'auth:'.Common::getRoleITAdminAndAgent().Constants::$AuthSeparator.Common::getSiteMercerVineColorado(),'uses' => 'PropertyListingController@postPropertyList'));

Route::get('category/{combinecategoryidsiteid?}', array('before' => 'auth:'.Common::getRoleITAdminMDAgentBloggerSEO().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'SiteController@getAddCategory'));
Route::post('savecategory', array('before' => 'auth:'.Common::getRoleITAdminMDAgentBloggerSEO().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'SiteController@postSaveCategory'));
Route::post('getcategorylist',array('before' => 'auth:'.Common::getRoleITAdminMDAgentBloggerSEO().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'SiteController@postCategoryList'));
Route::post('deletecategory', array('before' => 'auth:'.Common::getRoleITAdminMDAgentBloggerSEO().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'SiteController@deleteCategory'));

Route::post('gettaglist',array('before' => 'auth:'.Common::getRoleITAdminMDAgentBloggerSEO().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'SiteController@postTagList'));
Route::post('savetag', array('before' => 'auth:'.Common::getRoleITAdminMDAgentBloggerSEO().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'SiteController@postSaveTag'));
Route::post('deletetag', array('before' => 'auth:'.Common::getRoleITAdminMDAgentBloggerSEO().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'SiteController@deleteTag'));

Route::get('navigation/{siteid?}', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'NavigationController@getNavigationView'));
Route::post('getmenudata', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'NavigationController@postNavigationMenuData'));
Route::post('savenavigationmenu', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'NavigationController@postSaveNavigationMenu'));

Route::get('configuration/{siteid?}', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'ConfigurationController@getConfigurationView'));
Route::post('saveconfiguration', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'ConfigurationController@postSaveConfiguration'));

Route::post('getsiteimage', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'ConfigurationController@getSiteImage'));
Route::post('removesiteimage', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'ConfigurationController@postRemoveSiteImage'));

Route::post('javascripterror', function(){
    Log::error('Javascript error:' . json_encode(Input::get()));
});

Route::get('home/{siteid?}', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@getHomeView'));
Route::post('deletesliderimagesfile' ,array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@postDeleteSliderImagesFile'));
Route::post('savehomepage', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@postSaveHomePage'));
Route::post('gethoverimage', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@getHoverImage'));
Route::post('removehoverimage', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@postRemoveHoverImage'));
Route::post('deletehomevideo', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@postDeleteVideo'));
Route::post('homechangesection', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@postHomeChangeSection'));
Route::post('deletestory', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@deleteStory'));
Route::post('updatesortorderstory', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@UpdateSortOrderStory'));
Route::post('savestory', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@postSaveStory'));
Route::post('deletestoryimagesfile' ,array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@postDeleteStoryImagesFile'));
Route::post('getstoryimagese' ,array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@postGetStoryImagesFile'));

Route::post('updatesortorderstylisticinfluences', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'AgentController@UpdateSortOrderStylisticInfluences'));
Route::post('deletestylisticinfluences', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'AgentController@deleteStylisticInfluences'));
Route::post('savestylisticinfluences', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'AgentController@postSaveStylisticInfluences'));
Route::post('removeimagerdhome', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'AgentController@postSaveStylisticInfluences'));

Route::post('rdhomeremoveimage', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@postRemoveHoverImage'));
Route::post('getimagerdhome', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@getHoverImage'));
Route::post('saverdhomepage', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@postSaveRDHomePage'));
Route::post('savecohomepage', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@postSaveCOHomePage'));
Route::post('updatesortorderslider', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@UpdateSortOrderSlider'));
Route::post('deleteslider', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@deleteSlider'));
Route::post('getsliderimage', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@getHoverImage'));
Route::post('removesliderimage', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@postRemoveHoverImage'));
Route::post('saveslider', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@postSaveSlider'));
Route::post('deleteslidercolorado', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@deleteCoSlider'));
Route::post('updatesortorderslidercolorado', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@UpdateSortOrderCoSlider'));
Route::post('saveslidercolorado', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@postSaveCoSlider'));
Route::post('removesliderimagecolorado', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@postRemoveHoverImage'));
Route::post('getimagewwhome', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@getHoverImage'));
Route::post('wwhomeremoveimage', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@postRemoveHoverImage'));
Route::post('savewwhomepage', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@postSaveWWHomePage'));
Route::post('updatesortordersliderww', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@UpdateSortOrderWWSlider'));
Route::post('removesliderimageww', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@postRemoveHoverImage'));
Route::post('savesliderww', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@postSaveWWSlider'));
Route::post('deletesliderww', array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'HomeController@deleteWWSlider'));
/* Stop Region Dev_AD */



/*Start Region Dev_Drashtant*/
Route::get('users/{siteid?}',array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'UserController@getUserList'));
Route::post('getuserlist',array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses' => 'UserController@postUserList'));
Route::get('agents/{siteid?}',array('before' => 'auth:'.Common::getRoleITAdminMDAgent().Constants::$AuthSeparator.Common::getSiteMercerVineColorado(),'uses'=>'AgentController@getAgentList'));
Route::post('getagentlist',array('before' => 'auth:'.Common::getRoleITAdminMD().Constants::$AuthSeparator.Common::getSiteMercerVineColorado(),'uses'=>'AgentController@postAgentList'));

Route::post('enableagent',array('before' => 'auth:'.Common::getRoleITAdminMD().Constants::$AuthSeparator.Common::getSiteMercerVineColorado(),'uses'=>'AgentController@enableAgent'));
Route::post('disableagent',array('before' => 'auth:'.Common::getRoleITAdminMD().Constants::$AuthSeparator.Common::getSiteMercerVineColorado(),'uses'=>'AgentController@disableAgent'));

Route::post('enableuser',array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses'=>'UserController@enableUser'));
Route::post('disableuser',array('before' => 'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses'=>'UserController@disableUser'));

Route::get('pages/{siteid}',array('before'=>'auth:'.Common::getRoleMDITAdminSEOLegal().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses'=>'PageController@getPagesList'));
Route::post('getpageslist',array('before'=>'auth:'.Common::getRoleMDITAdminSEOLegal().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses'=>'PageController@postPagesList'));

Route::post('deletepage',array('before'=>'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses'=>'PageController@deletePage'));

Route::get('blogposts/{siteid?}',array('before'=>'auth:'.Common::getRoleBloggerMDITSEOAgentLegal().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses'=>'BlogPostController@getBlogPostsList'));
Route::post('getblogpostlist',array('before'=>'auth:'.Common::getRoleBloggerMDITSEOAgentLegal().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses'=>'BlogPostController@postBlogPostsList'));
Route::post('deletepost',array('before'=>'auth:'.Common::getRoleITAdminMD().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses'=>'BlogPostController@deleteBlogPost'));
/*Stop Region Dev_Drashtant*/


/*Start Dev_VA*/
Route::get('dirPagination',array('uses' => 'UserController@getPagination'));
Route::post('savetestimonial',array('before'=>'auth:'.Common::getRoleITAdminMDAgent().Constants::$AuthSeparator.Common::getSiteMercerVineColorado(),'uses'=>'AgentController@saveTestimonial'));
Route::post('deletetestimonialsdata',array('before'=>'auth:'.Common::getRoleITAdminMDAgent().Constants::$AuthSeparator.Common::getSiteMercerVineColorado(),'uses'=>'AgentController@deleteTestimonialData'));
Route::post('updatesortordertestimonial',array('before'=>'auth:'.Common::getRoleITAdminMDAgent().Constants::$AuthSeparator.Common::getSiteMercerVineColorado(),'uses'=>'AgentController@postSortOrderTestimonial'));
Route::get('addpage/{combinedid?}',array('before'=>'auth:'.Common::getRoleMDITAdminSEO().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses'=>'PageController@getAddPage'));
Route::get('editpage/{combinedid?}',array('before'=>'auth:'.Common::getRoleMDITAdminSEOLegal().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses'=>'PageController@getAddPage'));
Route::post('savepage',array('before'=>'auth:'.Common::getRoleMDITAdminSEOLegal().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses'=>'PageController@savePage'));
Route::post('deletepagesliderimage',array('before'=>'auth:'.Common::getRoleMDITAdminSEOLegal().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses'=>'PageController@postDeletePageSliderImage'));
Route::post('savepageimage',array('before'=>'auth:'.Common::getRoleMDITAdminSEOLegal().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses'=>'PageController@savePageImage'));
Route::post('removepageimage',array('before'=>'auth:'.Common::getRoleMDITAdminSEOLegal().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses'=>'PageController@removePageImage'));
Route::post('saveblogpostimage',array('before'=>'auth:'.Common::getRoleMDITAdminSEO().Constants::$AuthSeparator.Common::getSiteMercerVineColorado(),'uses'=>'BlogPostController@saveBlogPostImage'));
Route::post('removeblogpostimage',array('before'=>'auth:'.Common::getRoleMDITAdminSEO().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses'=>'BlogPostController@removeBlogPostImage'));

Route::post('denypage',array('before'=>'auth:'.Common::getRoleMDITAdminSEOLegal().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses'=>'PageController@postDenyPage'));
Route::post('approvepage',array('before'=>'auth:'.Common::getRoleMDITAdminLegal().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses'=>'PageController@postApprovePage'));
Route::post('publishpage',array('before'=>'auth:'.Constants::$RoleITAdmin.Constants::$AuthSeparator.Common::getAllSiteArray(),'uses'=>'PageController@postPublishPage'));

Route::get('addblog/{combinedid?}',array('before'=>'auth:'.Common::getRoleBloggerMDITSEOAgent().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses'=>'BlogPostController@getAddBlog'));
Route::get('editblog/{combinedid?}',array('before'=>'auth:'.Common::getRoleBloggerMDITSEOAgentLegal().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses'=>'BlogPostController@getAddBlog'));
Route::post('saveblog',array('before'=>'auth:'.Common::getRoleBloggerMDITSEOAgentLegal().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses'=>'BlogPostController@saveBlogPost'));

Route::post('approveblog',array('before'=>'auth:'.Common::getRoleMDITAdminLegal().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses'=>'BlogPostController@postApproveBlog'));
Route::post('denyblog',array('before'=>'auth:'.Common::getRoleMDITAdminSEOLegal().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses'=>'BlogPostController@postDenyBlog'));
Route::post('publishblog',array('before'=>'auth:'.Common::getRoleITAdminMD().Constants::$AuthSeparator.Common::getAllSiteArray(),'uses'=>'BlogPostController@postPublishBlog'));

/*End Dev_VA*/

/* property image cron */
Route::get('addretsimages', array('uses' => 'CronJobController@propertyImageCron'));
Route::get('addretsimages1', array('uses' => 'CronJobController@propertyImageCron1'));
Route::get('addretsimages2', array('uses' => 'CronJobController@propertyImageCron2'));
/* property image cron */

/******* ref#10314 ************/
Route::get('addmlsproperties', array('uses' => 'CronJobController@addPropertiesFromMLSDb')); //1
Route::get('manageproperties',array('uses'=>'CronJobController@PropertyManagement')); // for property management
Route::get('getactiveproperties',array('uses'=>'CronJobController@addActivePropertiesFromMLSDb')); // for property management
Route::get('remaingactivecron',array('uses'=>'CronJobController@addRemainingActiveProperty')); // for property management

Route::get('addretsfaliedimages',array('uses'=>'CronJobController@propertyFailedImageCron')); // for property management
Route::get('cropmvpropertyfailedimages',array('uses'=>'CronJobController@propertyFailedImagesIntervention')); // for property management

/* Property Images Intervention Cron Job */
Route::get('cropmvpropertyimages', array('uses' => 'CronJobController@propertyImagesIntervention'));
/* Property Images Intervention Cron Job */


/* Start Dev_UP */
Route::get('sitetestimonials/{siteid}',array('before'=>'auth:'.Common::getRoleITAdminMD().Constants::$AuthSeparator.Common::getSiteRiverDaleColoradoWW(),'uses'=>'SiteController@getSiteTestimonialList'));
Route::post('deletesitetestimonialsdata',array('before'=>'auth:'.Common::getRoleITAdminMD().Constants::$AuthSeparator.Common::getSiteRiverDaleColoradoWW(),'uses'=>'SiteController@deleteSiteTestimonialList'));
Route::post('updatesortordersitetestimonial',array('before'=>'auth:'.Common::getRoleITAdminMD().Constants::$AuthSeparator.Common::getSiteRiverDaleColoradoWW(),'uses'=>'SiteController@updateSortOrderSiteTestimonial'));
Route::post('savesitetestimonial',array('before'=>'auth:'.Common::getRoleITAdminMD().Constants::$AuthSeparator.Common::getSiteRiverDaleColoradoWW(),'uses'=>'SiteController@postSaveSiteTestimonial'));

Route::get('loans/{siteid}',array('before'=>'auth:'.Common::getRoleITAdminProcesing().Constants::$AuthSeparator.Common::getSiteRiverdale(),'uses'=>'LoanController@getLoanList'));
Route::get('addloan/{combineLoanSiteid?}',array('before'=>'auth:'.Common::getRoleITAdminProcesing().Constants::$AuthSeparator.Common::getSiteRiverdale(),'uses'=>'LoanController@getAddLoan'));
Route::post('updatesortorderloan',array('before'=>'auth:'.Common::getRoleITAdminProcesing().Constants::$AuthSeparator.Common::getSiteRiverdale(),'uses'=>'LoanController@UpdateSortOrderLoan'));
Route::post('deleteloan',array('before'=>'auth:'.Common::getRoleITAdminProcesing().Constants::$AuthSeparator.Common::getSiteRiverdale(),'uses'=>'LoanController@deleteLoan'));

Route::post('saveloan',array('before'=>'auth:'.Common::getRoleITAdminProcesing().Constants::$AuthSeparator.Common::getSiteRiverdale(),'uses'=>'LoanController@postSaveLoan'));
Route::post('removeloanimage',array('before'=>'auth:'.Common::getRoleITAdminProcesing().Constants::$AuthSeparator.Common::getSiteRiverdale(),'uses'=>'LoanController@RemoveLoanImage'));


/* End Dev_UP */
Route::post('updateclassdata', array('before' => 'auth:'.Common::getRoleITAdminMDAgent().Constants::$AuthSeparator.Common::getSiteMercerVineWoodbridgeColorado(),'uses' => 'PropertyListingController@COGetClassPropertyLookUps'));

/* cron job */
Route::get('cofetchmlsproperty', array('uses' => 'PropertyListingController@addCoAllProperties'));
Route::get('copropertyimage', array('uses' => 'PropertyListingController@getCoImageCron'));
Route::get('copropertyimageintervention', array('uses' => 'PropertyListingController@getCoPropertyImagesInterventionCron'));

Route::get('managecoproperties',array('uses'=>'CronJobController@COPropertyManagement')); // for property management

Route::get('cofailedimagecron',array('uses'=>'CronJobController@coPropertyFailedImageCron'));
Route::get('cofailedinterventioncron',array('uses'=>'CronJobController@coPropertyFailedImagesIntervention'));
/* cron job */
?>