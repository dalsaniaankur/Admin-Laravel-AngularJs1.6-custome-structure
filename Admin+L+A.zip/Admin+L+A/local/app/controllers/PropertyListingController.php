<?php
use dataproviders\IPropertyListingDataProvider;

use \Infrastructure\Common;
use \Infrastructure\Constants;
use \ViewModels\SessionHelper;


class PropertyListingController extends BaseController{

    function __construct(IPropertyListingDataProvider $listingDataProvider){
        parent::__construct();
        $this->DataProvider = $listingDataProvider;
    }
    /* Dev_AYS region Start */
    public function getAddProperty($combineSiteListingID=0){
        $decryptedCombineUserIDSiteID = Common::getDecryptedValue($combineSiteListingID);
        $ListingID =  Common::getParamValue($decryptedCombineUserIDSiteID,Constants::$QueryStringListingID);
        if(SessionHelper::getSelectedSiteID()==Constants::$ColoradoSiteID){ // Colorado
            $serviceResponse =$this->DataProvider->COGetPropertyLookUps($ListingID, SessionHelper::getSelectedSiteID(), Constants::$Agent_Role_ID, Constants::$UserActive, Auth::User()->UserID);
            $serviceResponse->Data->PropertyModel->encryptedSiteID = Common::getEncryptedValue(Constants::$QueryStringSiteID . '=' . SessionHelper::getSelectedSiteID());
            View::share('activeMenuID', 'add-property');
            return View::make('propertylisting.coaddpropertylisting', (array)$serviceResponse->Data);
        }
        else {
            $serviceResponse = $this->DataProvider->GetPropertyLookUps($ListingID, SessionHelper::getSelectedSiteID(), Constants::$Agent_Role_ID, Constants::$UserActive, Auth::User()->UserID);
            $serviceResponse->Data->PropertyModel->encryptedSiteID = Common::getEncryptedValue(Constants::$QueryStringSiteID . '=' . SessionHelper::getSelectedSiteID());
            View::share('activeMenuID', 'add-property');
            return View::make('propertylisting.addpropertylisting', (array)$serviceResponse->Data);
        }
    }

    public function postDeletePropertyImage(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->DeletePropertyImage($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function postSaveProperty(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        unset($serviceRequest->Data->UploadedFileOfPropertyFeatures);
        if(SessionHelper::getSelectedSiteID()!=Constants::$ColoradoSiteID) {
            $serviceResponse = $this->DataProvider->SaveProperty($serviceRequest->Data, SessionHelper::getSelectedSiteID(), Auth::User()->UserID,1);
        }
        else {
            $serviceResponse = $this->DataProvider->CoSaveProperty($serviceRequest->Data, SessionHelper::getSelectedSiteID(), Auth::User()->UserID);
        }
        return $this->GetJsonResponse($serviceResponse);
    }

    public function postRETSCall(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $ClassID=0;
        if(property_exists($serviceRequest->Data,'ClassID')){
            $ClassID=$serviceRequest->Data->ClassID;
        }
        $serviceResponse = $this->DataProvider->ProcessRETSCall($serviceRequest->Data->MLSNo,Auth::User()->UserID,SessionHelper::getSelectedSiteID(),$serviceRequest->Data->fetchImage,$ClassID);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function postDeleteProperty(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->DeleteProperty($serviceRequest->Data,SessionHelper::getSelectedSiteID());
        return $this->GetJsonResponse($serviceResponse);
    }
    /* Dev_AYS region End */

    /* Start Region Dev_AD */
    public function getPropertyList(){
        $SiteID = SessionHelper::getSelectedSiteID();
        if($SiteID==Constants::$MercerVineSiteID) {
            $searchModelResponse = $this->DataProvider->getSearchModelForPropertyList($SiteID);
            $model = new stdClass();
            $model->ListModel = $searchModelResponse->Data;
            $model->ListModel->encryptedSiteID = Common::getEncryptedValue(Constants::$QueryStringSiteID . '=' . $SiteID);
            View::share('activeMenuID', 'propertys');
            return View::make('propertylisting.Properties', (array)$model);
        }
        else {
            $searchModelResponse = $this->DataProvider->getCoSearchModelForPropertyList($SiteID);
            $model = new stdClass();
            $model->ListModel = $searchModelResponse->Data;
            $model->ListModel->encryptedSiteID = Common::getEncryptedValue(Constants::$QueryStringSiteID . '=' . $SiteID);
            View::share('activeMenuID', 'propertys');
            return View::make('propertylisting.coproperties', (array)$model);
        }
    }

    public function postPropertyList(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $loggedInUserID=Auth::user()->UserID;
        $serviceResponse = $this->DataProvider->getPropertyInfoList($serviceRequest->Data,$siteID,$loggedInUserID);
        if (!empty($serviceResponse->Data->Items)){
            foreach ($serviceResponse->Data->Items as $userDetails) {
                if($siteID==Constants::$ColoradoSiteID)
                    $stringListingId=Constants::$CoQueryStringListingID;
                if($siteID==Constants::$MercerVineSiteID)
                    $stringListingId=Constants::$QueryStringListingID;
                $encryptedUserID = Constants::$QueryStringUserID . '=' . $userDetails->AgentID.'&'.Constants::$QueryStringListingID.'='.$userDetails->{$stringListingId} ;
                $userDetails->EncryptedSiteListingID = Common::getEncryptedValue($encryptedUserID);
            }
        }
        return $this->GetJsonResponse($serviceResponse);
    }
      /* End Region Dev_AD */

    /* Dev_RB Region Start */
    public function PostDeletePropertyFeaturesFiles(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->RemovePropertyFeaturesFiles($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    /* Dev_RB Region End */

    /* Dev_KT Region start */
    public  function COGetClassPropertyLookUps() {
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->COGetClassPropertyLookUps($serviceRequest->Data->ClassID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public  function addCoAllProperties() {
        $serviceResponse = $this->DataProvider->addCoAllProperties();
        return $this->GetJsonResponse($serviceResponse);
    }
    public  function getCoImageCron() {
        $serviceResponse = $this->DataProvider->getCoImageCron();
        return $this->GetJsonResponse($serviceResponse);
    }
    public function getCoPropertyImagesInterventionCron(){
        $serviceResponse = $this->DataProvider->getCoPropertyImagesInterventionCron();
        return $this->GetJsonResponse($serviceResponse);
    }
    /* Dev_KT Region end */
}