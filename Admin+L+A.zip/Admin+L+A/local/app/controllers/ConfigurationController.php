<?php
use dataproviders\IConfigurationDataProvider;
use \ViewModels\SessionHelper;


class ConfigurationController extends BaseController {

    /*Dev_AD Region Start*/
	function __construct(IConfigurationDataProvider $configurationDataProvider){
        parent::__construct();
		$this->DataProvider = $configurationDataProvider;
	}

    public function getConfigurationView(){
        $SiteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->getConfigurationView($SiteID);
        View::share('activeMenuID','site-configuration');
        return View::make('configuration.addconfiguration',(array)$serviceResponse->Data);
    }

    public function postSaveConfiguration(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $SiteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->postSaveConfiguration($serviceRequest->Data, $SiteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function getSiteImage(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->AwsDownloadFileImages($serviceRequest->Data);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function postRemoveSiteImage(){
        $serviceRequest=$this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->DeleteSiteImageAmazon($serviceRequest->Data);
        return $this->GetJsonResponse($serviceResponse);
    }
    /*Dev_AD Region End*/
}