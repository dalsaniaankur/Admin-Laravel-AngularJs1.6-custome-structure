<?php
use dataproviders\IVideoDataProvider;
use \Infrastructure\Common;
use \Infrastructure\Constants;
use ViewModels\SessionHelper;
use Illuminate\Support\Facades\Auth;

class VideoController extends BaseController {

    /*Dev_AD Region Start*/
	function __construct(IVideoDataProvider $videoDataProvider){
        parent::__construct();
		$this->DataProvider = $videoDataProvider;
	}
	public function getAddVideo($combineVideoSiteID=0){
        $decryptedCombineVideoIDSiteID = Common::getDecryptedValue($combineVideoSiteID);
        $videoID =  Common::getParamValue($decryptedCombineVideoIDSiteID,Constants::$QueryStringVideoID);
        $siteID =  SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->getVideoTypeDetails($videoID,$siteID);
        View::share('activeMenuID','add-videos');
        return View::make('video.addvideo',(array)$serviceResponse->Data);
	}
    public function postAddVideo(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->AddVideoData($serviceRequest->Data, Auth::User()->UserID,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function deleteVideo(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->DeleteVideo($serviceRequest->Data->VideoID,$siteID,$serviceRequest->Data->DevelopmentID);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function getVideoList(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->getSearchModelForVideoList($siteID);
        $serviceResponse->Data->VideoModel->SiteID = $siteID;

        foreach($serviceResponse->Data->VideoModel->VideoListArray as $videoData){
            $encryptCombineID = Common::getEncryptedValue(Constants::$QueryStringVideoID.'='. $videoData->VideoID.'&'.Constants::$QueryStringSiteID.'='.$siteID);
            $videoData->combineVideoSiteid = $encryptCombineID;
            if($videoData->ThumbnailImageURL != ""){
                $videoData->ThumbnailImageURL = Common::getAWSUrl($siteID)."/".Common::getAWSBucketName($siteID)."/".$videoData->ThumbnailImageURL;
            }
        }


        View::share('activeMenuID','videos-list');
        return View::make('video.videos',(array)$serviceResponse->Data);
    }
    public function UpdateSortOrderVideo(){
        $siteID =  SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->UpdateSortOrderVideo($serviceRequest->Data->OldOrder, $serviceRequest->Data->newOrder,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function postRemoveVideoImage(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest=$this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->DeleteVideoImageAmazon($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function getVideoImage(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->AwsDownloadFileImages($serviceRequest->Data);
        return $this->GetJsonResponse($serviceResponse);
    }
    /*Dev_AD Region End*/

    /* Dev_RB Region Start */
    /* Dev_RB Region End */


	/*Start Region Dev_Vishal*/
	/*Stop Region Dev_Vishal*/

}