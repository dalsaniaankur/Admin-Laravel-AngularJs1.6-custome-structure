<?php
use \dataproviders\ILandingPageDataProvider;
use Infrastructure\Constants;
use Infrastructure\Common;
use Infrastructure\CacheHelper;
use ViewModels\SessionHelper;
use Illuminate\Support\Facades\Input;


class LandingPageController extends BaseController {

    /*Dev_RB Region Start*/
	function __construct(ILandingPageDataProvider $landingPageDataProvider){
        parent::__construct();
		$this->DataProvider = $landingPageDataProvider;
	}

    public function getLandingPageImage($encryptedSiteID){
        $decryptedCombineUserSiteID = Common::getDecryptedValue($encryptedSiteID);
        $siteID =  Common::getParamValue($decryptedCombineUserSiteID,Constants::$QueryStringSiteID);
        $loginUserID = Auth::user()->UserID;
        $serviceResponse = $this->DataProvider->getLandingPageDetails($siteID,$loginUserID);

        View::share('activeMenuID', 'landingpage');
        return View::make('landingpage.landingpageimage',(array)$serviceResponse->Data);
    }

    public function getLandingPageUploadedImage(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->AwsFileDownload($serviceRequest->Data);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function postRemoveLandingPageImage(){
        $SiteID = SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->DeleteLandingPageImageAmazon($serviceRequest->Data,$SiteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function postSaveLandingPageImage(){
        $SiteID = SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $fullArray = array_merge($serviceRequest->Data->PageData,$serviceRequest->Data->PageRightBottomImageData, $serviceRequest->Data->PageContentData);
        $serviceResponse = $this->DataProvider->SaveLandingPageImage($fullArray,$SiteID);
        return $this->GetJsonResponse($serviceResponse);
    }


	/*Dev_RB Region End*/

}