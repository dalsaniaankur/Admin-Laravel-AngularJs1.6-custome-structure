<?php
use dataproviders\IFaqDataProvider;
use \Infrastructure\Common;
use \Infrastructure\Constants;
use ViewModels\SessionHelper;
use Illuminate\Support\Facades\Auth;

class FaqController extends BaseController {

    /*Dev_AD Region Start*/
	function __construct(IFaqDataProvider $faqDataProvider){
        parent::__construct();
		$this->DataProvider = $faqDataProvider;
	}

	public function getAddFaq($combineFaqSiteID=0){
        $decryptedCombineFaqSiteID = Common::getDecryptedValue($combineFaqSiteID);
        $faqID =  Common::getParamValue($decryptedCombineFaqSiteID,Constants::$QueryStringFAQID);
        $siteID =  SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->getFaqTypeDetails($faqID,$siteID);
        View::share('activeMenuID','add-faq');
        return View::make('faq.addfaq',(array)$serviceResponse->Data);
	}
    public function postAddFaq(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->AddFaqData($serviceRequest->Data, Auth::User()->UserID,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function deleteFaq(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->DeleteFaq($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }


    public function getFaqList(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->getSearchModelForFaqList($siteID);
        $serviceResponse->Data->FaqModel->SiteID = $siteID;
        foreach($serviceResponse->Data->FaqModel->FaqListArray as $faqData){
            $encryptCombineID = Common::getEncryptedValue(Constants::$QueryStringFAQID.'='. $faqData->FAQID.'&'.Constants::$QueryStringSiteID.'='.$siteID);
            $faqData->combineFaqSiteid = $encryptCombineID;
        }
        View::share('activeMenuID','faq-list');
        return View::make('faq.faqs',(array)$serviceResponse->Data);
    }
    public function UpdateSortOrderFaq(){
        $SiteID = \ViewModels\SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->UpdateSortOrderFaq($serviceRequest->Data->OldOrder, $serviceRequest->Data->newOrder,$SiteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    /*Dev_AD Region End*/


    /* Dev_RB Region Start */
    /* Dev_RB Region End */


	/*Start Region Dev_Vishal*/

	/*Stop Region Dev_Vishal*/
    /* Dev_DN Region Start */

    /* Dev_DN Region End */

}