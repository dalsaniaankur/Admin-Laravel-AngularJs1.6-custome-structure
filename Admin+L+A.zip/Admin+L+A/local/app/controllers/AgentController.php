<?php
use dataproviders\IAgentDataProvider;
use \Infrastructure\Common;
use \Infrastructure\Constants;
use ViewModels\SessionHelper;
use ViewModels\ServiceResponse;


class AgentController extends BaseController{

    function __construct(IAgentDataProvider $agentDataProvider){
        parent::__construct();
        $this->DataProvider = $agentDataProvider;
    }

    public function getAgentList($siteID){
        $siteID = SessionHelper::getSelectedSiteID();
        $searchModelResponse = $this->DataProvider->getSearchModelForAgentList($siteID);
        $model = new stdClass();
        $model->ListModel = $searchModelResponse->Data;
        return View::make('agent.agents',(array)$model);
    }

    public function postAgentList(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->getAgentInfoList($serviceRequest->Data);
        if (!empty($serviceResponse->Data->Items)){
            foreach ($serviceResponse->Data->Items as $agentDetails) {
                $encryptedUserID = Constants::$QueryStringUserID . '=' . $agentDetails->UserID.'&'.Constants::$QueryStringSiteID.'='.$agentDetails->SiteID;
                $agentDetails->EncryptedUserID = Common::getEncryptedValue($encryptedUserID);
            }
        }
        return $this->GetJsonResponse($serviceResponse);
    }

    public function disableAgent(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $loggedInUserID=Auth::user()->UserID;
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->postDisableAgent($serviceRequest->Data,$loggedInUserID,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function enableAgent(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $loggedInUserID=Auth::user()->UserID;
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->postEnableAgent($serviceRequest->Data,$loggedInUserID,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function postFeaturedChange(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->postFeaturedChange($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }


    /*Dev_AD Region Start*/
    public function getAddAgent($combineUserSiteID=0){
        $decryptedCombineUserIDSiteID = Common::getDecryptedValue($combineUserSiteID);
        $userID =  Common::getParamValue($decryptedCombineUserIDSiteID,Constants::$QueryStringUserID);
        $selectedSiteID = SessionHelper::getSelectedSiteID();
        $roleID = SessionHelper::getSelectedRoleID();
        $userSiteList = SessionHelper::getUserSiteList();
        $serviceResponse = $this->DataProvider->getUserTypeDetails($userID,$selectedSiteID,$roleID,$updateProfile=0,$userSiteList);
        View::share('activeMenuID','add-agent');
        return View::make('agent.addagent',(array)$serviceResponse->Data);
    }
    public function postAddAgent(){
        $response = new ServiceResponse();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $currentRole = SessionHelper::getSelectedRoleID();
        if($currentRole!=Constants::$RoleITAdmin && $currentRole!=Constants::$RoleMarketingDirector){
            if(Auth::User()->UserID != $serviceRequest->Data->UserID){
                $response->IsSuccess = false;
                $response->Message = trans('messages.CannotUpdateOtherUserProfile');
                return $this->GetJsonResponse($response);
            }
        }
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->AddAgentData($serviceRequest->Data,$siteID,Auth::User()->UserID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function getAgentImage(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->AwsAgentFileDownload($serviceRequest->Data);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function postRemoveAgentImage(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->DeleteAgentImageAmazon($serviceRequest->Data);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function postCheckUniqueLicense(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->postCheckUniqueLicense($serviceRequest->Data);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function postCheckUniqueEmail(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->postCheckUniqueEmail($serviceRequest->Data);
        return $this->GetJsonResponse($serviceResponse);
    }

    /*Dev_AD Region End*/

    /*Start Dev_VA*/
    public function saveTestimonial(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $SiteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->saveTestimonialDetails($serviceRequest->Data,Auth::user()->UserID,$SiteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function deleteTestimonialData(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $SiteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->postDeleteTestimonialData($serviceRequest->Data,$SiteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function postSortOrderTestimonial(){
        $serviceRequest=$this->GetObjectFromJsonRequest(Input::json()->all());
        $SiteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->postSortOrderTestimonialData($serviceRequest->Data->oldOrder, $serviceRequest->Data->newOrder,$serviceRequest->Data->AgentID,$SiteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function postPropertyList(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $loggedInUserID=Auth::user()->UserID;
        $propertyListingDataProvider = new \dataproviders\PropertyListingDataProvider();
        $serviceResponse = $propertyListingDataProvider->getPropertyInfoList($serviceRequest->Data,$siteID,$loggedInUserID);
        if (!empty($serviceResponse->Data->Items)){
            foreach ($serviceResponse->Data->Items as $userDetails) {
                if($siteID==Constants::$ColoradoSiteID)
                    $stringListingId=Constants::$CoQueryStringListingID;
                if($siteID==Constants::$MercerVineSiteID)
                    $stringListingId=Constants::$QueryStringListingID;
                $encryptedUserID = Constants::$QueryStringUserID . '=' . $userDetails->AgentID.'&'.Constants::$QueryStringListingID.'='.$userDetails->{$stringListingId} ;
                $userDetails->EncryptedSiteListingID = Common::getEncryptedValue($encryptedUserID);
            }
        }
        return $this->GetJsonResponse($serviceResponse);
    }
    public function UpdateSortOrderStylisticInfluences(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->UpdateSortOrderStylisticInfluences($serviceRequest->Data->OldOrder, $serviceRequest->Data->newOrder,$serviceRequest->Data->UserID,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function deleteStylisticInfluences(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->deleteStylisticInfluences($serviceRequest->Data->StylisticInfluencesID, $serviceRequest->Data->UserID, $siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function postSaveStylisticInfluences(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->postSaveStylisticInfluences($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    /*End Dev_VA*/

    /* Dev_RB Region Start */
    public function getUpdateAgentProfile(){
        $userID = Auth::User()->UserID;
        $siteID = SessionHelper::getSelectedSiteID();
        $roleID = SessionHelper::getSelectedRoleID();
        $userSiteList = SessionHelper::getUserSiteList();
        $serviceResponse = $this->DataProvider->getUserTypeDetails($userID,$siteID,$roleID,$updateProfile=1,$userSiteList);
        return View::make('agent.addagent',(array)$serviceResponse->Data);
    }
    /* Dev_RB Region End */

}