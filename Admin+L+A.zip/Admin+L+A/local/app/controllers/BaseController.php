<?php use ViewModels\ServiceRequest;
use ViewModels\SessionHelper;
use Illuminate\Support\Facades\URL;
use \Infrastructure\Common;
use \Infrastructure\Constants;
use \stdClass;

class BaseController extends Controller {

    public function __construct(){
        if(SessionHelper::getSelectedSiteID()){
            $siteID = SessionHelper::getSelectedSiteID();
            $this->EncreptedSiteID = Common::getEncryptedValue(Constants::$QueryStringSiteID . '=' . $siteID);;
            View::share('encryptedSiteID',$this->EncreptedSiteID);
        }

        $userSiteList = SessionHelper::getUserSiteList();
        $siteID = SessionHelper::getSelectedSiteID();

        if($userSiteList){
            $filteredUserSiteList = array_values(array_filter($userSiteList,function($site) use ($siteID){
                return	$site->SiteID != $siteID;
            }));
            $this->UserSiteList = $filteredUserSiteList;
            View::share('UserSiteList',$this->UserSiteList);
        }

        if($userSiteList){
            $SiteUserSiteList = array_values(array_filter($userSiteList,function($site) use ($siteID){
                return	$site->SiteID == $siteID;
            }));
            if($SiteUserSiteList){
            $this->selectedSiteName = $SiteUserSiteList[0]->SiteName;
            View::share('selectedSiteName',$this->selectedSiteName);
            }
        }

        $this->activeMenuID = '';
        View::share('activeMenuID', $this->activeMenuID);
    }

    public static function CheckRoleSitePermission($roleArray,$siteArray){
        $roleID = SessionHelper::getSelectedRoleID();
        $siteID = SessionHelper::getSelectedSiteID();

        $roles = explode(Constants::$Separator,$roleArray);
        $sites = explode(Constants::$Separator,$siteArray);

        if($roleID && $siteID){
            if(in_array($roleID,$roles)&& in_array($siteID,$sites)){
                return true;
            }
        }else{
            return false;
        }
    }

    public function GetJsonResponse($serviceResponse){
	   //$serviceResponse->Data = json_decode($serviceResponse->Data);
       $jsonResponse = Response::make(json_encode($serviceResponse), 200);
	   $jsonResponse->header('Content-Type', 'application/json');
	   return $jsonResponse;
	}

	 public function GetObjectFromJsonRequest($jsonRequest){
		$serviceRequest= new ServiceRequest();
		$request= (object)$jsonRequest;
        $serviceRequest->Token= (!property_exists($request, 'Token') ? null : $request->Token);
		$isIOSRequest= property_exists($request, 'IOS') && $request->IOS;

		$serviceRequest->Data=$isIOSRequest?(object)$request->Data:(!property_exists($request, 'Data') ? null : is_array($request->Data)? (object)$request->Data : json_decode($request->Data));
		return $serviceRequest;
	 }


}
