<?php
use \dataproviders\IHomeDataProvider;
use \ViewModels\SessionHelper;
use Infrastructure\Constants;
use Infrastructure\CacheHelper;

class HomeController extends BaseController {

    /*Dev_AD Region Start*/
	function __construct(IHomeDataProvider $homeDataProvider){
        parent::__construct();
		$this->DataProvider = $homeDataProvider;
	}

    public function getHomeView(){
        $siteID = SessionHelper::getSelectedSiteID();
        $loginUserID=Auth::user()->UserID;
        View::share('activeMenuID','home-page');
        switch ($siteID) {
            case Constants::$MercerVineSiteID :
                $serviceResponse = $this->DataProvider->getHomeView($siteID,$loginUserID);
               // CacheHelper::CacheManage($siteID,Constants::$cacheHomeID,Constants::$cacheActionInsert,'');
                return View::make('home.home',(array)$serviceResponse->Data);
                break;

            case Constants::$RiverDaleFundingSiteID :
                $serviceResponse = $this->DataProvider->getRD_HomeView($siteID,$loginUserID);
                return View::make('home.rd_home',(array)$serviceResponse->Data);
                CacheHelper::CacheManage($siteID,Constants::$cacheHomeID,Constants::$cacheActionInsert,'');
                break;

            case Constants::$ColoradoSiteID :
                $serviceResponse = $this->DataProvider->getCO_HomeView($siteID,$loginUserID);
                return View::make('home.co_home',(array)$serviceResponse->Data);
                break;

            case Constants::$WoodBridgeWealthSiteID :
                $serviceResponse = $this->DataProvider->getWW_HomeView($siteID,$loginUserID);
                return View::make('home.ww_home',(array)$serviceResponse->Data);
                break;

            default:
                $serviceResponse = $this->DataProvider->getHomeView($siteID,$loginUserID);
                return View::make('home.home',(array)$serviceResponse->Data);
                break;
        }
    }

    public function postDeleteSliderImagesFile(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->postDeleteSliderImagesFile($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function postSaveHomePage(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $loginUserID = Auth::user()->UserID;
        $serviceResponse = $this->DataProvider->postSaveHomePage($serviceRequest->Data,$loginUserID,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function getHoverImage(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->AwsDownloadFileImages($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function postRemoveHoverImage(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest=$this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->DeleteImageAmazon($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function postDeleteVideo(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest=$this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->postDeleteVideoAmazon($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function postHomeChangeSection(){
        $serviceRequest=$this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->postHomeChangeSection($serviceRequest->Data->FirstSectionType,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function deleteStory(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->deleteStory($serviceRequest->Data);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function UpdateSortOrderStory(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->UpdateSortOrderStory($serviceRequest->Data->OldOrder, $serviceRequest->Data->newOrder);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function postSaveStory(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->postSaveStory($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function postDeleteStoryImagesFile(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->postDeleteStoryImagesFile($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function postGetStoryImagesFile(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->postGetStoryImagesFile($serviceRequest->Data);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function postSaveRDHomePage(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = Constants::$RiverDaleFundingSiteID;
        $serviceResponse = $this->DataProvider->postSaveRDHomePage($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function UpdateSortOrderSlider(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->UpdateSortOrderSlider($serviceRequest->Data->OldOrder, $serviceRequest->Data->newOrder);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function deleteSlider(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->deleteSlider($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function postSaveSlider(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->postSaveSlider($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function postSaveCOHomePage(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = Constants::$ColoradoSiteID;
        $serviceResponse = $this->DataProvider->postSaveCOHomePage($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function deleteCoSlider(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->deleteCoSlider($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function UpdateSortOrderCoSlider(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->UpdateSortOrderCoSlider($serviceRequest->Data->OldOrder, $serviceRequest->Data->newOrder);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function postSaveCoSlider(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->postSaveCoSlider($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function postSaveWWHomePage(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->postSaveWWHomePage($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function UpdateSortOrderWWSlider(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->UpdateSortOrderWWSlider($serviceRequest->Data->OldOrder, $serviceRequest->Data->newOrder);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function postSaveWWSlider(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->postSaveWWSlider($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function deleteWWSlider(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->deleteWWSlider($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    /* Dev_AD Region Start */


}