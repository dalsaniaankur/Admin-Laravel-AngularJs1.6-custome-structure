<?php
use \dataproviders\BlogPostDataProvider;
use \Infrastructure\Common;
use \Infrastructure\Constants;
use ViewModels\SessionHelper;
class BlogPostController extends BaseController{

    /*Start Region Dev_Drashtant*/

    public function __construct(){
        parent::__construct();
        $this->DataProvider = new BlogPostDataProvider();
    }
    public function getBlogPostsList(){
        $timezone = SessionHelper::getSelectedTimeZone();
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->getSearchModelForWorkFlow($timezone,$siteID);
        $model = new stdClass();
        $model->ListModel = $serviceResponse->Data;
        View::share('activeMenuID','blog');
        return View::make('blogpost.blogposts',(array)$model);
    }
    public function postBlogPostsList(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $timezone = SessionHelper::getSelectedTimeZone();
        $serviceResponse = $this->DataProvider->postData($serviceRequest->Data,$siteID,$timezone);
        if (!empty($serviceResponse->Data->Items)){
            foreach ($serviceResponse->Data->Items as $blogData) {
                $encryptedBlogPostID = Constants::$QueryStringBlogPostID.'='.$blogData->BlogPostID.'&'.Constants::$QueryStringSiteID.'='.$blogData->SiteID;
                $blogData->encryptedBlogPostID = Common::getEncryptedValue($encryptedBlogPostID);
                $blogData->LoggedInUserRoleID = SessionHelper::getSelectedRoleID();
            }
        }
        return $this->GetJsonResponse($serviceResponse);
    }
    public function deleteBlogPost(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->deleteWorkFlow($serviceRequest->Data);
        return $this->GetJsonResponse($serviceResponse);
    }
    /*End Dev_DN*/

    /*Start Dev_VA*/
    public function getAddBlog($combinedID = 0){
        $decryptedCombinedID = Common::getDecryptedValue($combinedID);
        $blogPostID = Common::getParamValue($decryptedCombinedID,Constants::$QueryStringBlogPostID);
        $siteID = SessionHelper::getSelectedSiteID();
        $loggedInUserID = Auth::user()->UserID;
        $loggedInUserRoleID = SessionHelper::getSelectedRoleID();

        $serviceResponse = $this->DataProvider->getAddWorkflowData($blogPostID,$siteID,$loggedInUserID,$loggedInUserRoleID);
        $serviceResponse->Data->BlogModel->BlogDetails->LoggedInUserRoleID = $loggedInUserRoleID;


        if(empty($serviceResponse->Data->BlogModel->BlogDetails->TwitterCard))
            $serviceResponse->Data->BlogModel->BlogDetails->TwitterCard = Constants::$twitterCardSummery; // Set default TwitterCard

        $serviceResponse->Data->BlogModel->SiteID = $siteID;

       if(isset($serviceResponse->Data->BlogModel->BlogDetails->PostDate))
           $serviceResponse->Data->BlogModel->BlogDetails->PostDate = date(Constants::$DateFormatServerSide,strtotime($serviceResponse->Data->BlogModel->BlogDetails->PostDate));
        View::share('activeMenuID','add-blog');
        return View::make('blogpost.addblogpost',(array)$serviceResponse->Data);
    }
    public function saveBlogPost(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceRequest->Data->ActionType = Constants::$SaveWorkFlowActionType;    //Used for message
        $loggedInUserID = Auth::user()->UserID;
        $loggedInUserRoleID = SessionHelper::getSelectedRoleID();
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->saveWorkflowData($serviceRequest->Data,$loggedInUserID,$loggedInUserRoleID,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function postApproveBlog(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceRequest->Data->ActionType = Constants::$ApproveWorkFlowActionType; //Used for message
        $loggedInUserID = Auth::user()->UserID;
        $loggedInUserRoleID = SessionHelper::getSelectedRoleID();
        $siteID = SessionHelper::getSelectedSiteID();
        if($serviceRequest->Data)
            $serviceRequest->Data->StatusID = Constants::$WorkFlowStatus_Approve;
        $serviceResponse = $this->DataProvider->saveWorkflowData($serviceRequest->Data,$loggedInUserID,$loggedInUserRoleID,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function postDenyBlog(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceRequest->Data->ActionType = Constants::$DenyWorkFlowActionType; //Used for message
        $loggedInUserID = Auth::user()->UserID;
        $loggedInUserRoleID = SessionHelper::getSelectedRoleID();
        $siteID = SessionHelper::getSelectedSiteID();
        if($serviceRequest->Data)
            $serviceRequest->Data->StatusID = Constants::$WorkFlowStatus_Denied;
        $serviceResponse = $this->DataProvider->saveWorkflowData($serviceRequest->Data,$loggedInUserID,$loggedInUserRoleID,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function postPublishBlog(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceRequest->Data->ActionType = Constants::$PublishWorkFlowActionType; //Used for message
        $loggedInUserID = Auth::user()->UserID;
        $loggedInUserRoleID = SessionHelper::getSelectedRoleID();
        $siteID = SessionHelper::getSelectedSiteID();
        if($serviceRequest->Data)
            $serviceRequest->Data->StatusID = Constants::$WorkFlowStatus_Published;
        $serviceResponse = $this->DataProvider->saveWorkflowData($serviceRequest->Data,$loggedInUserID,$loggedInUserRoleID,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function saveBlogPostImage(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->AwsFileDownload($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function removeBlogPostImage(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->removeImageFromAmazon($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    /*End Dev_VA*/
}