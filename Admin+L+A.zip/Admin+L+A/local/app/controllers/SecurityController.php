<?php
use dataproviders\ISecurityDataProvider;
use \ViewModels\SessionHelper;
use ViewModels\ServiceResponse;
use \Infrastructure\Common;
use \Infrastructure\Constants;

class SecurityController extends BaseController  {

	function __construct(ISecurityDataProvider $securityDataProvider){
        parent::__construct();
		$this->securityDataProvider = $securityDataProvider;
	}

    /* RB Region Start */
    public function getUnauthorized(){
        if(!(SessionHelper::getSelectedRoleID()) && Auth::check()) {
            Auth::logout();
            return Redirect::to('/')->with('SessionExpired',trans('messages.SessionExpired'));
        }
        return View::make('errors.unauthorized');
    }

    public function getLogin(){
        $roleID = SessionHelper::getSelectedRoleID();
        if(!Auth::check()){
            if(empty($roleID))
                return View::make('security.login',(array)Session::get('SessionExpired'));
            else {
                return View::make('security.login');
            }
        }
        else{
            if(empty($roleID))
                return Redirect::to('choosesite');
            else
                return Redirect::to('dashboard');
        }
    }
    public function getChooseSite(){
        $serviceResponse = new ServiceResponse();
        $model = $this->getDataForChooseSite(SessionHelper::getUserSiteList());
        $serviceResponse->Data=$model;

        return View::make('security.choosesite',(array)$serviceResponse->Data);
    }

    public function postAuthenticate(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->securityDataProvider->AuthenticateUser($serviceRequest->Data);
        if(isset($serviceResponse->Data->UserDetails)){
            Auth::login($serviceResponse->Data->UserDetails);
        }
        if (!empty($serviceResponse->Data->roleList)) {
            foreach ($serviceResponse->Data->roleList as $key => $siteValue) {
                $EncryptSiteID = Constants::$QueryStringSiteID . '=' . $siteValue->SiteID;
                $siteValue->EncryptSiteID = Common::getEncryptedValue($EncryptSiteID);
            }
        }

        if (!empty($serviceResponse->Data->roleList)) {
            SessionHelper::setUserSiteList($serviceResponse->Data->roleList);
        }

        $userLoginChecked = Auth::User();

        if(!empty($userLoginChecked)) {
            $sessionCheckURL = SessionHelper::getRedirectURL();
            // /chooseSite /users/id
            if(!empty($sessionCheckURL)){

                $link_array = explode('/',$sessionCheckURL);
                $lastPart = urldecode(end($link_array));
                $decryptedValue = Common::getDecryptedValue($lastPart);
                $siteID = Common::getParamValue($decryptedValue, Constants::$QueryStringSiteID);

                if($siteID > 0) {
                    // Check user has this site id
                    $checkRoleSiteIDArray = array_values(array_filter($serviceResponse->Data->roleList,function($site) use ($siteID){
                        return	$site->SiteID == $siteID;
                    }));

                    // If yes then set session selectedRoleID & selectedSiteID
                    if($checkRoleSiteIDArray){
                        SessionHelper::setSelectedRoleID($checkRoleSiteIDArray[0]->RoleID);
                        SessionHelper::setSelectedSiteID($checkRoleSiteIDArray[0]->SiteID);
                        SessionHelper::setSelectedTimeZone($checkRoleSiteIDArray[0]->TimeZone);
                        $serviceResponse->redirectURL = $sessionCheckURL;
                    }

                    // If no then redirect to chooseSite
                    if(!$checkRoleSiteIDArray){
                        $serviceResponse->redirectURL = URL::to('/') . '/choosesite';
                    }
                }
                else{
                    // redirect to chooseSite
                    $serviceResponse->redirectURL = URL::to('/') . '/choosesite';
                }

            }else{
                if($serviceResponse->Data->redirectToChooseSite == Constants::$Value_True){
                    $serviceResponse->redirectURL = URL::to('/') . '/choosesite';
                }else{
                    SessionHelper::setSelectedRoleID($serviceResponse->Data->roleList[0]->RoleID);
                    SessionHelper::setSelectedSiteID($serviceResponse->Data->roleList[0]->SiteID);
                    SessionHelper::setSelectedTimeZone($serviceResponse->Data->roleList[0]->TimeZone);
                    $serviceResponse->redirectURL = URL::to('/') . '/dashboard/'.$serviceResponse->Data->roleList[0]->EncryptSiteID;
                }
            }
        }

        //print_r($serviceResponse); exit;

        return $this->GetJsonResponse($serviceResponse);
    }

    public function postSendVerificationEmail(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $createdByID = isset(Auth::User()->UserID)?Auth::User()->UserID:'';
        $serviceResponse = $this->securityDataProvider->SendVerificationEmail($serviceRequest->Data,$siteID,$createdByID);
        return $this->GetJsonResponse($serviceResponse);
    }
    
    public function getLogout(){
        Auth::logout();
        SessionHelper::SessionFlush();
        return Redirect::to('/');
    }

    public function getForgotPassword($token = null){
        if(!Auth::check()){
           if($token) {
                $serviceResponse = $this->securityDataProvider->GetForgotPassword($token);
                if (!$serviceResponse->IsSuccess) {
                     return View::make('errors.linkexpired');
                }else{
                     return View::make('security.forgotpassword',(array)$serviceResponse->Data);
                }
           }else {
            return View::make('security.sendforgotpassword');
        }
        }else{
            return  Redirect::to('dashboard');
        }
    }

    public function postSelectSite(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = new ServiceResponse();
        if($serviceRequest){
            $siteID = $serviceRequest->Data;

            $userSiteList = SessionHelper::getUserSiteList();
            $selectedSite = array_values(array_filter($userSiteList,function($site) use ($siteID){
                return	$site->SiteID == $siteID;
            }));

            if($selectedSite){
                SessionHelper::setSelectedRoleID($selectedSite[0]->RoleID);
                SessionHelper::setSelectedSiteID($selectedSite[0]->SiteID);
                SessionHelper::setSelectedTimeZone($selectedSite[0]->TimeZone);

                $serviceResponse->Data = $selectedSite[0]->EncryptSiteID;
                $serviceResponse->IsSuccess = true;
            }
            return $this->GetJsonResponse($serviceResponse);
        }
    }

    /* Rb Region End*/

    /* Dev_AD Region Start */
    public function getDashboard(){
        $SiteID = SessionHelper::getSelectedSiteID();
        $searchModelResponse = $this->securityDataProvider->getSearchModelForBlogList();
        $model = new stdClass();
        $model->BlogListModel = $searchModelResponse->Data->BlogModel;
        $model->PageListModel = $searchModelResponse->Data->PageModel;
        View::share('activeMenuID','dashboard');
        return View::make('dashboard.dashboard',(array)$model);
    }
    /* Blog list */
    public function postBlogPostsList(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $loggedInUserID=Auth::user()->UserID;
        $SiteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->securityDataProvider->getBlogInfoList($serviceRequest->Data,$loggedInUserID,$SiteID);
        if (!empty($serviceResponse->Data->Items)){
            foreach ($serviceResponse->Data->Items as $blogData) {
                $encryptedBlogPostID = Constants::$QueryStringBlogPostID.'='.$blogData->BlogPostID.'&'.Constants::$QueryStringSiteID.'='.$blogData->SiteID;
                $blogData->encryptedBlogPostID = Common::getEncryptedValue($encryptedBlogPostID);
                $blogData->LoggedInUserRoleID = SessionHelper::getSelectedRoleID();
            }
        }
        return $this->GetJsonResponse($serviceResponse);
    }

    /* Page list */
    public function postPagesList(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $loggedInUserID=Auth::user()->UserID;
        $SiteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->securityDataProvider->getPageInfoList($serviceRequest->Data,$loggedInUserID,$SiteID);
        if (!empty($serviceResponse->Data->Items)){
            foreach ($serviceResponse->Data->Items as $pageData) {
                $encryptedPageID = Constants::$QueryStringPageID.'='.$pageData->PageID.'&'.Constants::$QueryStringSiteID.'='.$pageData->SiteID;
                $pageData->encryptedPageID = Common::getEncryptedValue($encryptedPageID);
                $pageData->LoggedInUserID = SessionHelper::getSelectedRoleID();
            }
        }
        return $this->GetJsonResponse($serviceResponse);
    }

    public function postSendResetPasswordEmail(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->securityDataProvider->SendResetPasswordEmail($serviceRequest->Data);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function postResetPasswordEmail(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->securityDataProvider->postResetPasswordEmail($serviceRequest->Data);
        return $this->GetJsonResponse($serviceResponse);
    }

    /**
     * @return StdClass
     */
    public function getDataForChooseSite($userRoles)
    {
        $model = new StdClass();
        $ChooseSiteModel = new StdClass();
        $ChooseSiteModel->UserSiteList = $userRoles;
        $model->ChooseSiteModel = $ChooseSiteModel;
        return $model;
    }


    /* Dev_AD Region End */


    /* Dev_DN Region Start */


    /* Dev_DN Region End */

    

}