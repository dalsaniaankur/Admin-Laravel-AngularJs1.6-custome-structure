<?php
use dataproviders\ISiteDataProvider;
use \Infrastructure\Common;
use \Infrastructure\Constants;
use Illuminate\Support\Facades\Auth;
use \ViewModels\SessionHelper;

class SiteController extends BaseController {

    /*Dev_AD Region Start*/

	function __construct(ISiteDataProvider $siteDataProvider){
        parent::__construct();
		$this->DataProvider = $siteDataProvider;
	}
	public function getAddCategory($combineCategoryIDSiteID=0){
        $serviceResponse = $this->DataProvider->getCategoryDetails();
        View::share('activeMenuID','category');
        return View::make('category.categories',(array)$serviceResponse->Data);
	}
    public function postSaveCategory(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->SaveCategory($serviceRequest->Data, Auth::User()->UserID, $siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function postCategoryList(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $searchSiteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->getCategoryList($serviceRequest->Data,$searchSiteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function deleteCategory(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->DeleteCategory($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }


    /* Tag Related code */
    public function postTagList(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $searchSiteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->getTagList($serviceRequest->Data,$searchSiteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function postSaveTag(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->SaveTag($serviceRequest->Data, Auth::User()->UserID, $siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function deleteTag(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->DeleteTag($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }

    /*Dev_AD Region End*/




    /*Dev_UP Region Start*/
    public function getSiteTestimonialList(){
        
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->getSearchModelForSiteTestimonialList($siteID);
        $serviceResponse->Data->SiteTestimonialModel->SiteID = $siteID;

       
        foreach($serviceResponse->Data->SiteTestimonialModel->SiteTestimonialListArray as $siteTestimonialData){//echo '<pre>';print_r($siteTestimonialData);exit;
            $encryptCombineID = Common::getEncryptedValue(Constants::$QueryStringTestimonialID.'='. $siteTestimonialData->TestimonialID.'&'.Constants::$QueryStringSiteID.'='.$siteID);
            $siteTestimonialData->combineSiteTestimonialSiteid = $encryptCombineID;

        }
        View::share('activeMenuID','site-testimonials');
        return View::make('sitetestimonial.sitetestimonials',(array)$serviceResponse->Data);
    
    }

    public function deleteSiteTestimonialList(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->DeleteSiteTestimonialList($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function updateSortOrderSiteTestimonial(){

        $SiteID = \ViewModels\SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->UpdateSortOrderSiteTestimonialList($serviceRequest->Data->OldOrder, $serviceRequest->Data->newOrder,$SiteID);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function postSaveSiteTestimonial(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->SaveSiteTestimonialList($serviceRequest->Data,Auth::User()->UserID,$siteID);
       
        return $this->GetJsonResponse($serviceResponse);
    }
    /*Dev_UP Region End*/

    /* RB Start */
    public function postClearCache(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->ClearCache($serviceRequest->Data);
        return $this->GetJsonResponse($serviceResponse);
    }
    /* RB End */
}