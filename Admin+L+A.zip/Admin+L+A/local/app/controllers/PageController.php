<?php
use \dataproviders\PageDataProvider;
use \Infrastructure\Common;
use \Infrastructure\Constants;
use ViewModels\SessionHelper;

class PageController extends BaseController{
    public function __construct(){
        parent::__construct();
        $this->DataProvider = new PageDataProvider();
    }

  /*Start Region Dev_Drashtant*/
    public function getPagesList(){
        $timezone = SessionHelper::getSelectedTimeZone();
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->getSearchModelForWorkFlow($timezone,$siteID);
        $model = new stdClass();
        $model->ListModel = $serviceResponse->Data;
        View::share('activeMenuID','pages');

        View::share('currentSiteUrl',$serviceResponse->Data->currentSiteUrl[0][0]->WebsiteBaseURL);
        return View::make('page.pages',(array)$model);
    }
    public function postPagesList(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $timezone = SessionHelper::getSelectedTimeZone();
        $serviceResponse = $this->DataProvider->postData($serviceRequest->Data,$siteID,$timezone);
        if (!empty($serviceResponse->Data->Items)){
            foreach ($serviceResponse->Data->Items as $pageData) {
                $encryptedPageID = Constants::$QueryStringPageID.'='.$pageData->PageID.'&'.Constants::$QueryStringSiteID.'='.$pageData->SiteID;
                $pageData->encryptedPageID = Common::getEncryptedValue($encryptedPageID);
                $pageData->LoggedInUserID = SessionHelper::getSelectedRoleID();
            }
        }
        return $this->GetJsonResponse($serviceResponse);
    }
    public function deletePage(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->deleteWorkFlow($serviceRequest->Data);
        return $this->GetJsonResponse($serviceResponse);
    }
    /*Stop Region Dev_Drashtant*/

    /*Start Dev_VA*/
    public function getAddPage($combinedID = 0){
        $decryptedCombinedID = Common::getDecryptedValue($combinedID);
        $pageID = Common::getParamValue($decryptedCombinedID,Constants::$QueryStringPageID);
        $siteID = SessionHelper::getSelectedSiteID();
        $loggedInUserID = Auth::user()->UserID;
        $loggedInUserRoleID = SessionHelper::getSelectedRoleID();
        $serviceResponse = $this->DataProvider->getAddWorkflowData($pageID,$siteID,$loggedInUserID,$loggedInUserRoleID); //$updateProfile = 0,

        if(empty($serviceResponse->Data->PageModel->PageDetails->TwitterCard))
            $serviceResponse->Data->PageModel->PageDetails->TwitterCard = Constants::$twitterCardSummery; // Set default TwitterCard

        $serviceResponse->Data->PageModel->PageDetails->LoggedInUserRoleID = $loggedInUserRoleID;
        if(!isset($serviceResponse->Data->PageModel->PageDetails->previousTopImagePath)) {
            $serviceResponse->Data->PageModel->PageDetails->previousTopImagePath ='';
        }
        if(!isset($serviceResponse->Data->PageModel->PageDetails->previousBottomRightImagePath)) {
            $serviceResponse->Data->PageModel->PageDetails->previousBottomRightImagePath ='';
        }
        if($serviceResponse->Data->PageModel->PageDetails->SiteID == Constants::$RiverDaleFundingSiteID){
            if(!isset($serviceResponse->Data->PageModel->PageDetails->IsShowBrokerPackageCTA)) {
                $serviceResponse->Data->PageModel->PageDetails->IsShowBrokerPackageCTA = Constants::$DefaultShowBrokerPackageCTA;
            }
        }
        
        View::share('currentSiteUrl',$serviceResponse->Data->PageModel->currentSiteUrl[0][0]->WebsiteBaseURL);
        View::share('activeMenuID','add-page');
        return View::make('page.addPage',(array)$serviceResponse->Data);
    }

    public function savePage(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceRequest->Data->ActionType = Constants::$SaveWorkFlowActionType;
        $loggedInUserID = Auth::user()->UserID;
        $loggedInUserRoleID = SessionHelper::getSelectedRoleID();
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->saveWorkflowData($serviceRequest->Data,$loggedInUserID,$loggedInUserRoleID,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function postApprovePage(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceRequest->Data->ActionType = Constants::$ApproveWorkFlowActionType; // if not need then remove this.
        $loggedInUserID = Auth::user()->UserID;
        $loggedInUserRoleID = SessionHelper::getSelectedRoleID();
        $siteID = SessionHelper::getSelectedSiteID();
        if($serviceRequest->Data)
            $serviceRequest->Data->StatusID = Constants::$WorkFlowStatus_Approve;
        $serviceResponse = $this->DataProvider->saveWorkflowData($serviceRequest->Data,$loggedInUserID,$loggedInUserRoleID,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function postDenyPage(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceRequest->Data->ActionType = Constants::$DenyWorkFlowActionType; // If not required then remove this.
        $loggedInUserID = Auth::user()->UserID;
        $loggedInUserRoleID = SessionHelper::getSelectedRoleID();
        $siteID = SessionHelper::getSelectedSiteID();
        if($serviceRequest->Data)
            $serviceRequest->Data->StatusID = Constants::$WorkFlowStatus_Denied;
        $serviceResponse = $this->DataProvider->saveWorkflowData($serviceRequest->Data,$loggedInUserID,$loggedInUserRoleID,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function postPublishPage(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceRequest->Data->ActionType = Constants::$PublishWorkFlowActionType; // no longer need then pls remove this.
        $loggedInUserID = Auth::user()->UserID;
        $loggedInUserRoleID = SessionHelper::getSelectedRoleID();
        $siteID = SessionHelper::getSelectedSiteID();
        if($serviceRequest->Data)
            $serviceRequest->Data->StatusID = Constants::$WorkFlowStatus_Published;
        $serviceResponse = $this->DataProvider->saveWorkflowData($serviceRequest->Data,$loggedInUserID,$loggedInUserRoleID,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function savePageImage(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->AwsFileDownload($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function removePageImage(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->removeImageFromAmazon($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    /*End Dev_VA*/

    public function postDeletePageSliderImage(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->postDeletePageSliderImage($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }


}