<?php
use \dataproviders\INavigationDataProvider;
use \ViewModels\SessionHelper;
use Illuminate\Support\Facades\Auth;


class NavigationController extends BaseController {

    /*Dev_AD Region Start*/
	function __construct(INavigationDataProvider $navigationDataProvider){
        parent::__construct();
		$this->DataProvider = $navigationDataProvider;
	}

	public function getNavigationView(){
        View::share('activeMenuID','menu-items');
        return View::make('navigation.navigation');
	}
    public function postNavigationMenuData(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $loggedInUserID = Auth::User()->UserID;
        $serviceResponse = $this->DataProvider->postNavigationMenuData($serviceRequest->Data, $loggedInUserID, $siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function postSaveNavigationMenu(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $loggedInUserID = Auth::User()->UserID;
        $serviceResponse = $this->DataProvider->postSaveNavigationMenu($serviceRequest->Data, $loggedInUserID, $siteID);
        return $this->GetJsonResponse($serviceResponse);
    }

    /*Dev_AD Region End*/
}