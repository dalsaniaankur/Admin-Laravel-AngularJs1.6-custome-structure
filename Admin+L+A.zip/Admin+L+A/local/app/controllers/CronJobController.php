<?php use \Infrastructure\Common;
use \Infrastructure\Constants;

class CronJobController extends BaseController{
    /* Dev_RB Region Start */

    public function getSendMail() {
        $maxFailedAttempts = 0;
        try {

            if (Common::SetIsCronJobRunning($maxFailedAttempts)) {
                try {
                    Common::MailsToSend($maxFailedAttempts);
                }
                catch (Exception $e) {
                    Log::info(' Mails To Send :'.date('Y-m-d H:i:s'));
                    Log::error($e);
                }
                Common::UnsetIsCronJobRunning($maxFailedAttempts);
            }
        }
        catch (Exception $e) {
            Log::info(' Mails To Send :'.date('Y-m-d H:i:s'));
            Log::error($e);
            Common::UnsetIsCronJobRunning($maxFailedAttempts);
        }
    }
    public function propertyImageCron(){
        $propertyDataProvider = new \dataproviders\PropertyListingDataProvider();
        $serviceResponse = $propertyDataProvider->getImageCron(0,Constants::$imagecronjobflagfield);
        return $this->GetJsonResponse($serviceResponse);
    }


    public function propertyImagesIntervention(){
        $propertyDataProvider = new \dataproviders\PropertyListingDataProvider();
        $serviceResponse = $propertyDataProvider->getPropertyImagesInterventionCron();
        return $this->GetJsonResponse($serviceResponse);
    }

    public function addPropertiesFromMLSDb(){
        $propertyDataProvider = new \dataproviders\PropertyListingDataProvider();
        $serviceResponse = $propertyDataProvider->addPropertiesFromMLSDb();
        return $this->GetJsonResponse($serviceResponse);
    }

    public function PropertyManagement(){
        $propertyDataProvider = new \dataproviders\PropertyListingDataProvider();
        $serviceResponse = $propertyDataProvider->PropertyManagement();
        return $this->GetJsonResponse($serviceResponse);
    }

    public function addActivePropertiesFromMLSDb(){
        $propertyDataProvider = new \dataproviders\PropertyListingDataProvider();
        $serviceResponse = $propertyDataProvider->addActivePropertiesFromMLSDb();
        return $this->GetJsonResponse($serviceResponse);
    }
    public function addRemainingActiveProperty(){
        $propertyDataProvider = new \dataproviders\PropertyListingDataProvider();
        $serviceResponse = $propertyDataProvider->addRemainingActiveProperty();
        return $this->GetJsonResponse($serviceResponse);
    }

    /* Dev_RB Region End */


    /* Dev_UP Region Start */
    public function propertyFailedImageCron(){
        $propertyDataProvider = new \dataproviders\PropertyListingDataProvider();
        $serviceResponse = $propertyDataProvider->getFailedImageCron();
        return $this->GetJsonResponse($serviceResponse);
    }

    public function propertyFailedImagesIntervention(){
        $propertyDataProvider = new \dataproviders\PropertyListingDataProvider();
        $serviceResponse = $propertyDataProvider->getFailedPropertyImagesInterventionCron();
        return $this->GetJsonResponse($serviceResponse);
    }
    /* Dev_UP Region End */


    public function postDeletePropertyImages(){
        $propertyDataProvider = new \dataproviders\PropertyListingDataProvider();
        $serviceResponse = $propertyDataProvider->DeletePropertyImages();
        return $this->GetJsonResponse($serviceResponse);
    }

    /* Dev_UP Region Start */
    public function COPropertyManagement(){
        $propertyDataProvider = new \dataproviders\PropertyListingDataProvider();
        $serviceResponse = $propertyDataProvider->COPropertyManagement();
        return $this->GetJsonResponse($serviceResponse);
    }
    /* Dev_UP Region End */

    /* Dev_UP Region Start */
    public function coPropertyFailedImageCron(){
        $propertyDataProvider = new \dataproviders\PropertyListingDataProvider();
        $serviceResponse = $propertyDataProvider->CoGetFailedImageCron();
        return $this->GetJsonResponse($serviceResponse);
    }

    public function coPropertyFailedImagesIntervention(){
        $propertyDataProvider = new \dataproviders\PropertyListingDataProvider();
        $serviceResponse = $propertyDataProvider->CoGetFailedPropertyImagesInterventionCron();
        return $this->GetJsonResponse($serviceResponse);
    }
    /* Dev_UP Region End */
}