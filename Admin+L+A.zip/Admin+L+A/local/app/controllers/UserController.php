<?php
use dataproviders\IUserDataProvider;
use \Infrastructure\Common;
use \Infrastructure\Constants;
use \ViewModels\SessionHelper;
use ViewModels\ServiceResponse;
use Illuminate\Support\Facades\Auth;

class UserController extends BaseController {

	function __construct(IUserDataProvider $userDataProvider){
        parent::__construct();
		$this->DataProvider = $userDataProvider;
	}

    /* Dev_RB Region Start */
	public function getAddUser($combineSiteUserID  = 0){
        $decryptedCombineUserSiteID = Common::getDecryptedValue($combineSiteUserID);
        $userID =  Common::getParamValue($decryptedCombineUserSiteID,Constants::$QueryStringUserID);
        $siteID = SessionHelper::getSelectedSiteID();
        $roleID = SessionHelper::getSelectedRoleID();
        $userSiteList = SessionHelper::getUserSiteList();
        $serviceResponse = $this->DataProvider->getUserDetail($userID,$siteID,$roleID,$updateProfile=0,$userSiteList);
       if($serviceResponse->Data){
           $serviceResponse->Data->UserModel->encryptedSiteID = Common::getEncryptedValue(Constants::$QueryStringSiteID.'='.$siteID);
       }
        View::share('activeMenuID', 'addusers');
        return View::make('user.adduser',(array)$serviceResponse->Data);
	}
    public function getUpdateProfile(){
        $roleID = SessionHelper::getSelectedRoleID();
        $redirectToAgentPage = Constants::$Value_False;
        $agentRoleID = Constants::$RoleAgent;
        if($roleID == $agentRoleID)
            $redirectToAgentPage = Constants::$Value_True;
        else if($roleID==Constants::$Value_False || $roleID=='') {
            $siteList = SessionHelper::getUserSiteList();
            $isUserArray = array_values(array_filter($siteList, function ($userSite) use ($agentRoleID) {
                return $userSite->RoleID != $agentRoleID;
            }));
            if(empty($isUserArray))
                $redirectToAgentPage = Constants::$Value_True;
        }
      if($redirectToAgentPage){
          return Redirect::to('updateagentProfile/');
      }else{
          return Redirect::to('updatemyprofile');
      }

    }
    public function getUpdateMyProfile(){
        $userID = Auth::User()->UserID;
        $siteID = SessionHelper::getSelectedSiteID();
        $roleID = SessionHelper::getSelectedRoleID();
        $userSiteList = SessionHelper::getUserSiteList();
        $serviceResponse = $this->DataProvider->getUserDetail($userID,$siteID,$roleID,$updateProfile=1,$userSiteList);
        return View::make('user.adduser',(array)$serviceResponse->Data);
    }


    public function postSaveUser(){
        $response = new ServiceResponse();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $currentRole = SessionHelper::getSelectedRoleID();
        if($currentRole!=Constants::$RoleITAdmin){
            if(Auth::User()->UserID != $serviceRequest->Data->UserID){
                $response->IsSuccess = false;
                $response->Message = trans('messages.CannotUpdateOtherUserProfile');
                return $this->GetJsonResponse($response);
            }
        }
        $siteID =  SessionHelper::getSelectedSiteID();
        $createdByID = Auth::User()->UserID;
        $serviceResponse = $this->DataProvider->SaveUser($serviceRequest->Data,$createdByID,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function getProfileImage(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->AwsFileDownload($serviceRequest->Data);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function postRemoveProfileImage(){
        $SiteID = SessionHelper::getSelectedSiteID();
        $serviceRequest=$this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->DeleteProfileImageAmazon($serviceRequest->Data,$SiteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    /* Dev_RB Region End */


	/*Start Region Dev_Vishal*/
	public function getUserList($SiteID){
        $SiteID = SessionHelper::getSelectedSiteID();
        $searchModelResponse = $this->DataProvider->getSearchModelForUserList($SiteID);
        $model = new stdClass();
        $model->ListModel = $searchModelResponse->Data;
        $model->ListModel->encryptedSiteID = Common::getEncryptedValue(Constants::$QueryStringSiteID.'='.$SiteID);
        View::share('activeMenuID', 'users');
		return View::make('user.users',(array)$model);
	}

	//For Get Pagination HTML File
	public function getPagination(){
		return View::make('dirPagination');
	}

    public function disableUser(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $loggedInUserID=Auth::user()->UserID;
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->postDisableUser($serviceRequest->Data,$loggedInUserID,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function enableUser(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $loggedInUserID=Auth::user()->UserID;
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->postEnableUser($serviceRequest->Data,$loggedInUserID,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }

	public function postUserList(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $loggedInUserID=Auth::user()->UserID;
        $serviceResponse = $this->DataProvider->getUserInfoList($serviceRequest->Data,$loggedInUserID);

        if (!empty($serviceResponse->Data->Items)){
            foreach ($serviceResponse->Data->Items as $userDetails) {
                $encryptedUserID = Constants::$QueryStringUserID . '=' . $userDetails->UserID.'&'.Constants::$QueryStringSiteID.'='.$userDetails->SiteID ;
                $userDetails->EncryptedSiteUserID = Common::getEncryptedValue($encryptedUserID);
            }
        }
        return $this->GetJsonResponse($serviceResponse);

	}
	/*Stop Region Dev_Vishal*/
}