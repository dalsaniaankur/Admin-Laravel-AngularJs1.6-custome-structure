<?php
use dataproviders\ILoanDataProvider;
use \Infrastructure\Common;
use \Infrastructure\Constants;
use ViewModels\SessionHelper;
use Illuminate\Support\Facades\Auth;

class LoanController extends BaseController {

    /*Dev_UP Region Start*/
    function __construct(ILoanDataProvider $loanDataProvider){
        parent::__construct();
        $this->DataProvider = $loanDataProvider;
    }

    public function getLoanList(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->getSearchModelForLoanList($siteID);
        $serviceResponse->Data->LoanModel->SiteID = $siteID;
        foreach($serviceResponse->Data->LoanModel->LoanListArray as $loanData){//echo '<pre>';print_r($loanData);exit;
            $encryptCombineID = Common::getEncryptedValue(Constants::$QueryStringLoanID.'='. $loanData->LoanID.'&'.Constants::$QueryStringSiteID.'='.$siteID);
            $loanData->combineLoanSiteid = $encryptCombineID;

        }
        View::share('activeMenuID','loan-list');
        return View::make('loan.loans',(array)$serviceResponse->Data);
    }
    public function deleteLoan(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->DeleteLoan($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function UpdateSortOrderLoan(){

        $SiteID = \ViewModels\SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->UpdateSortOrderLoan($serviceRequest->Data->OldOrder, $serviceRequest->Data->newOrder,$SiteID);
        return $this->GetJsonResponse($serviceResponse);
    }

    /* Dev_UP Region End */

    public function getAddLoan($combineSiteLoanID=0){
        $decryptedCombineLoanIDSiteID = Common::getDecryptedValue($combineSiteLoanID);
        $LoanID = Common::getParamValue($decryptedCombineLoanIDSiteID,Constants::$QueryStringLoanID);
        $siteID = SessionHelper::getSelectedSiteID();
        $loginUserID =  Auth::User()->UserID;
        $serviceResponse = $this->DataProvider->getLoanData($LoanID,$siteID,$loginUserID);
        if(isset($serviceResponse->Data->LoanModel))
            $serviceResponse->Data->LoanModel->encryptedSiteID = Common::getEncryptedValue(Constants::$QueryStringSiteID.'='.$siteID);
        if(isset($serviceResponse->Data->LoanModel->DateFunded))
            $serviceResponse->Data->LoanModel->DateFunded = date(Constants::$DateFormatServerSide,strtotime($serviceResponse->Data->LoanModel->DateFunded));

        $serviceResponse->Data->LoanModel->LoggedInUserRoleID = SessionHelper::getSelectedRoleID();
        View::share('activeMenuID','add-loan');
        return View::make('loan.addloan',(array)$serviceResponse->Data);
    }

    public function postSaveLoan(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->SaveLoan($serviceRequest->Data,Auth::User()->UserID,$siteID);
        /*if(!empty($serviceResponse->Data->LoanID)){
            $encryptedID = Constants::$QueryStringLoanID . '=' .$serviceResponse->Data->LoanID.'&'.Constants::$QueryStringSiteID.'='.$siteID;
            $serviceResponse->Data->encryptedLoanSiteID = Common::getEncryptedValue($encryptedID);
        }*/
        return $this->GetJsonResponse($serviceResponse);
    }

    public function RemoveLoanImage(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->RemoveImage($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
}