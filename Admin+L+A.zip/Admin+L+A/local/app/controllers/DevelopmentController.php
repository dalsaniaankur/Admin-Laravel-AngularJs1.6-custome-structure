<?php
use dataproviders\IDevelopmentDataProvider;
use \Infrastructure\Common;
use \Infrastructure\Constants;
use ViewModels\SessionHelper;

class DevelopmentController extends BaseController{
    /*Start Dev_VA*/
    function __construct(IDevelopmentDataProvider $developmentDataProvider){
        parent::__construct();
        $this->DataProvider = $developmentDataProvider;
    }
    public function getAddDevelopmentView($combineDevelopmentSiteID = 0){
        $decryptedCombineDevelopmentSiteID = Common::getDecryptedValue($combineDevelopmentSiteID);
        $developmentID = Common::getParamValue($decryptedCombineDevelopmentSiteID,Constants::$QueryStringDevelopmentID);
        $siteID = SessionHelper::getSelectedSiteID();
        $loginUserID =  Auth::User()->UserID;
        $serviceResponse = $this->DataProvider->getDevelopmentData($developmentID,$siteID,$loginUserID);
        if($serviceResponse->Data->DevelopmentModel->DevDetails){
            $serviceResponse->Data->DevelopmentModel->DevDetails->encryptedSiteID = Common::getEncryptedValue(Constants::$QueryStringSiteID.'='.$siteID);
        }
        $serviceResponse->Data->DevelopmentModel->DevDetails->LoggedInUserRoleID = SessionHelper::getSelectedRoleID();
        View::share('activeMenuID','adddevelopment');
        return View::make('development.addDevelopment',(array)$serviceResponse->Data);
    }

    public function postSaveDevelopment(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->SaveDevelopment($serviceRequest->Data,Auth::User()->UserID,$siteID);
        if(!empty($serviceResponse->Data->DevelopmentID)){
            $encryptedID = Constants::$QueryStringDevelopmentID . '=' .$serviceResponse->Data->DevelopmentID.'&'.Constants::$QueryStringSiteID.'='.$siteID;
            $serviceResponse->Data->encryptedDevlopmentSiteID = Common::getEncryptedValue($encryptedID);
        }
        return $this->GetJsonResponse($serviceResponse);
    }
    /*End Dev_VA*/

    /* Dev_RB Region Start */
    public function getDevelopmentList($SiteID){
        /*if(!empty($SiteID)){
            $decryptSiteID = Common::getDecryptedValue($SiteID);
            $SiteID = Common::getParamValue($decryptSiteID,Constants::$QueryStringSiteID);
        }*/
        $SiteID = SessionHelper::getSelectedSiteID();
        $searchModelResponse = $this->DataProvider->getSearchModelForDevelopmentList($SiteID);
        $model = new stdClass();
        $model->ListModel = $searchModelResponse->Data;
        $model->ListModel->encryptedSiteID = Common::getEncryptedValue(Constants::$QueryStringSiteID.'='.$SiteID);
        View::share('activeMenuID','developments');
        return View::make('development.developments',(array)$model);
    }

    public function postDevelopmentList(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $loggedInUserID=Auth::user()->UserID;
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->getDevelopmentInfoList($serviceRequest->Data,$loggedInUserID,$siteID);
        if (!empty($serviceResponse->Data->Items)){
            foreach ($serviceResponse->Data->Items as $developmentDetails) {
                $encryptedID = Constants::$QueryStringDevelopmentID . '=' . $developmentDetails->DevelopmentID.'&'.Constants::$QueryStringSiteID.'='.$developmentDetails->SiteID ;
                $developmentDetails->EncryptedSiteDevelopmentID = Common::getEncryptedValue($encryptedID);
            }
        }
        return $this->GetJsonResponse($serviceResponse);
    }

    public function postDeleteImage(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->RemoveImage($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }


    public function PostDevelopmentVideoList(){
        $SiteID = \ViewModels\SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->getDevelopmentVideoList($serviceRequest->Data,$SiteID);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function PostRemoveDevelopmentVideo(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->RemoveDevelopmentVideo($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function PostDevelopmentPropertiesList(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->geDevelopmentListing($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function PostDeleteDevelopmentListing(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->DeleteDevelopmentListing($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }

    public function postDeleteDevelopment(){
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceResponse = $this->DataProvider->DeleteDevelopment($serviceRequest->Data,$siteID);
        if($serviceResponse){
            $serviceResponse->Data = Common::getEncryptedValue(Constants::$QueryStringSiteID.'='.$siteID);
        }
        return $this->GetJsonResponse($serviceResponse);
    }
    /* Dev_RB Region End */

    /* Dev_AD Region End */
    public function getDevelopmentImage(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->AwsDownloadFileImages($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function postRemoveDevelopmentImage(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->DeleteDevelopmentImageAmazon($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    public function PostDeleteDevelopmentFeaturesFiles(){
        $siteID = SessionHelper::getSelectedSiteID();
        $serviceRequest = $this->GetObjectFromJsonRequest(Input::json()->all());
        $serviceResponse = $this->DataProvider->RemoveDevelopmentFeaturesFiles($serviceRequest->Data,$siteID);
        return $this->GetJsonResponse($serviceResponse);
    }
    /* Dev_AD Region End */
}



