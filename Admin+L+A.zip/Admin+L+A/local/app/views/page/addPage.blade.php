<?php
use Infrastructure\Constants;
use ViewModels\SessionHelper;
$minify = new \CeesVanEgmond\Minify\Facades\Minify;
$FBImageType = Constants::$FBImageType;
$TwitterImageType = Constants::$TwitterImageType;
$GoogleImageType = Constants::$GoogleImageType;
$ImageMaxSize = Constants::$ImageMaxSize;
?>

@extends('layouts.sitemaster')
@section('Title')
    <?php if($PageModel->PageDetails->PageID > 0 && $PageModel->ViewPage==0 && $PageModel->CanEditSEOFields==0) { print 'View Page'; }else if($PageModel->PageDetails->PageID > 0 && ($PageModel->ViewPage==1 or $PageModel->CanEditSEOFields==1)){ print 'Edit Page';} else {print 'Add Page';} ?>
@stop
@section('css')
    <link href="<?php echo asset('/assets/css/dropzone/dropzone.css');?>" defer rel="stylesheet" type='text/css'>
@stop
@section('content')
<main id="main" role="main" xmlns="http://www.w3.org/1999/html" data-ng-controller="PageController">
    <?php echo Form::hidden('PageModel',htmlspecialchars(json_encode($PageModel), ENT_QUOTES, 'UTF-8'),$attributes = array('id'=>'PageModel'));?>
<form name="PageForm" id="PageForm" role="form" novalidate ng-submit="checkSave(PageForm)">
    <div class="page-content" >
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo URL::to('/dashboard/'.$encryptedSiteID) ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <a href="<?php echo URL::to('/pages/'.$encryptedSiteID) ?>">Pages</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                   <span><?php if($PageModel->PageDetails->PageID > 0 && $PageModel->ViewPage==0 && $PageModel->CanEditSEOFields==0) { print 'View Page'; }else if($PageModel->PageDetails->PageID > 0 && ($PageModel->ViewPage==1 or $PageModel->CanEditSEOFields==1)){ print 'Edit Page';} else {print 'Add Page';} ?></span>
                </li>
            </ul>
            <div class="page-toolbar">
                <div class="btn-group pull-right" ng-cloak>
                    <?php if( SessionHelper::getSelectedSiteID() == Constants::$MercerVineSiteID){?><input name="submit" type="submit" value="Copy To Clipboard" class="btn yellow-mint save-button btn-submit btn-sm"  ng-disabled="requestCounter != responseCounter || !UploadComplete" ngclipboard data-clipboard-text="<?php echo $currentSiteUrl;?>/previewpage/@{{ PageModel.PageDetails.Slug }}" title="Copy to clipboard"/> <?php }?>
                    <input name="submit" type="submit" value="Save" class="btn blue save-button btn-submit btn-sm" ng-hide="PageModel.ViewPage==0 && PageModel.CanEditSEOFields==0" data-ng-click="Save()" ng-disabled="requestCounter != responseCounter || !UploadComplete"/>
                    <input  name="submit" type="submit"  value="Approve" class="btn green-meadow save-button btn-submit btn-sm"   data-ng-click="Approve()" ng-hide="PageModel.ShowApproveDenyButton == 0 || PageModel.ViewPage==0 || PageModel.currentStatusID == <?php echo Constants::$WorkFlowStatus_Approve;?> || PageModel.currentStatusID == <?php echo Constants::$WorkFlowStatus_Published;?>" ng-disabled="requestCounter != responseCounter || !UploadComplete">
                    <input  name="submit" type="submit" value="Deny" class="btn red-sunglo save-button btn-submit btn-sm" data-ng-click="Deny()" ng-hide="PageModel.ShowApproveDenyButton == 0 || PageModel.ViewPage==0 || PageModel.currentStatusID == <?php echo Constants::$WorkFlowStatus_Denied;?> ||  PageModel.currentStatusID == <?php echo Constants::$WorkFlowStatus_Published;?>" ng-disabled="requestCounter != responseCounter || !UploadComplete">
                    <input name="submit" type="submit" value="Publish" class="btn yellow-mint save-button btn-submit btn-sm" data-ng-click="Publish()" ng-hide="PageModel.ShowPublishButton==0 || PageModel.currentStatusID == <?php echo Constants::$WorkFlowStatus_Published;?>" ng-disabled="requestCounter != responseCounter || !UploadComplete"/>
                    <input id="delete" name="delete" type="button" value="Delete" class="btn btn-danger btn-submit  btn-sm btn-outline" data-ng-click="DeletePage()" ng-show="PageModel.PageDetails.PageID > 0 && PageModel.PageDetails.LoggedInUserRoleID== <?php echo Constants::$RoleITAdmin;?>" ng-disabled="requestCounter != responseCounter || !UploadComplete">
                </div>
            </div>
        </div>

        <h3 class="page-title">
            <?php if($PageModel->PageDetails->PageID > 0 && $PageModel->ViewPage==0 && $PageModel->CanEditSEOFields==0) { print 'View Page'; }else if($PageModel->PageDetails->PageID > 0 && ($PageModel->ViewPage==1 or $PageModel->CanEditSEOFields==1)){ print 'Edit Page';} else {print 'Add Page';} ?>
        </h3>
        <div class="row">
            <div class="col-md-12">
                 <div class="portlet box blue-hoki" ng-cloak>
                         <div class="portlet-title" collapse>
                             <div class="caption">
                                 <i class=""></i>Details</div>
                             <div class="tools">
                                 <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                             </div>
                             </div>
                                <div class="portlet-body">
                                        <div class="row">
                                            <div class="form-body" ng-cloak>
                                                <!-- For Slider image upload section start -->
                                                <?php if($PageModel->PageDetails->SiteID == Constants::$RiverDaleFundingSiteID){?>
                                                <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12 visible-sm visible-xs">
                                                    <div class="col-md-12 no-padding">
                                                        <label for="Slider image" class="control-label">Top image</label>
                                                    </div>
                                                    <div class="fileinput fileinput-new" ng-clock>
                                                        <div  class="fileinput-new thumbnail image-box">
                                                            <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                            <img id="actualImage" alt="" ng-src="@{{ PageModel.PageDetails.RealTopImagePath ? PageModel.PageDetails.RealTopImagePath : PageModel.PageDetails.NoImagePath }}" ng-clock>
                                                        </div>
                                                        <div>
                                                            <form></form>
                                                            <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo Constants::$PageTopImageType;?>" name="FormTopImage" role="form" novalidate>
                                                                <input type="hidden" id="key" name="key" value="">
                                                                <input type="hidden" name="AWSAccessKeyId"  ng-value="PageModel.PageDetails.Fileuploadsettings.accesskey">
                                                                <input type="hidden" name="acl"  ng-value="PageModel.PageDetails.Fileuploadsettings.acl">
                                                                <input type="hidden" name="success_action_status"  ng-value="PageModel.PageDetails.Fileuploadsettings.success_action">
                                                                <input type="hidden" name="policy"  ng-value="PageModel.PageDetails.Fileuploadsettings.base64Policy">
                                                                <input type="hidden" name="signature"  ng-value="PageModel.PageDetails.Fileuploadsettings.signature">
                                                                <input type="hidden" name="Cache-Control" ng-value="PageModel.PageDetails.Fileuploadsettings.cacheControlTime">
                                                                <span  class="btn default btn-file" ><input type="file" name="file" ng-model="PageModel.PageDetails.RealTopImagePath" id="file" title="Choose Image" required> Choose Image</span>
                                                                <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage(<?php echo "'".Constants::$PageTopImageType."'"; ?>)" ng-hide="(PageModel.PageDetails.RealTopImagePath == '' || PageModel.PageDetails.RealTopImagePath == null)"> Remove </a>
                                                                <span></span>
                                                            </form>
                                                        </div>
                                                        <span>&nbsp;</span>
                                                        <div class="progress progress-striped display-none background">
                                                            <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="info-alert" ng-if="(AllowedTopFixHeight > 0 ) && (AllowedTopFixWidth > 0 )"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedTopFixWidth }}x@{{ AllowedTopFixHeight }}px</lable></div>
                                                        <div ng-class="{ 'has-error' : (PageForm.$submitted) && FormTopImage.file.$error}" class="has-error">
                                                            <div class="help-block" ng-messages="FormTopImage.file.$error" ng-if="PageForm.$submitted">
                                                                <div ng-show="FormTopImage.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Top images'))}}</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php }?>
                                                <!-- For Slider image upload section end -->
                                                    <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                        <div class="col-md-12  no-padding">
                                                        <div class="form-group col-md-6 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (PageForm.$submitted) && PageForm.Title.$invalid}">
                                                            <label for="Title" class="control-label">Title</label>
                                                            <input class="form-control"  type="text" name="Title"  maxlength="200" data-ng-model="PageModel.PageDetails.Title" data-ng-class="{'has-submitted' : PageForm.$submitted }" ng-disabled="PageModel.ViewPage==0" required />
                                                                <span class="error-text-color" ng-show="PageForm.$submitted">
                                                                    <span ng-show="PageForm.Title.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Title'))}}</span>
                                                                </span>
                                                        </div>
                                                        </div>
                                                         <div class="col-md-12  no-padding">
                                                            <div class="form-group col-md-6 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (PageForm.$submitted) && PageForm.Slug.$invalid}">
                                                                <label for="Slug" class="control-label">Slug</label>
                                                                <input class="form-control"  type="text" name="Slug"  maxlength="200" data-ng-model="PageModel.PageDetails.Slug" data-ng-class="{'has-submitted' : PageForm.$submitted }" is-edit=PageModel.PageDetails.PageID  slug="PageModel.PageDetails.Title"  allowed-slash="1" ng-disabled="PageModel.ViewPage==0" pattern="<?php
                                                                        if($PageModel->PageDetails->SiteID == Constants::$MercerVineSiteID){echo Constants::$MVSlugRegex;
                                                                        }else if($PageModel->PageDetails->SiteID == Constants::$ColoradoSiteID){echo Constants::$COSlugRegex;
                                                                        }else if($PageModel->PageDetails->SiteID == Constants::$WoodBridgeWealthSiteID){echo Constants::$WWSlugRegex;
                                                                        }else{ echo Constants::$RDSlugRegex; }
                                                                 ?>"
                                                                required  />
                                                                <span class="error-text-color" ng-show="PageForm.$submitted">
                                                                    <span ng-show="PageForm.Slug.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Slug'))}}</span>
                                                                    <span ng-show="PageForm.Slug.$error.pattern">{{ trans('messages.InvalidSlug')}}</span>
                                                                </span>
                                                                <span class="font13px help-block info-alert">
                                                                    <span class="info-alert-color"><span class="bold">Note:</span>
                                                                        <?php
                                                                            if($PageModel->PageDetails->SiteID == Constants::$MercerVineSiteID){ echo trans('messages.NoteForMVSlug');
                                                                            }else if($PageModel->PageDetails->SiteID == Constants::$ColoradoSiteID){echo trans('messages.NoteForCOSlug');
                                                                            }else if($PageModel->PageDetails->SiteID == Constants::$WoodBridgeWealthSiteID){echo trans('messages.NoteForWWSlug');
                                                                            }else{ echo trans('messages.NoteForRDSlug');}
                                                                        ?>
                                                                    </span>
                                                                </span>
                                                            </div>

                                                             <div class="form-group col-md-6 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (PageForm.$submitted) && PageForm.Author.$invalid}">
                                                                 <label for="Author" class="control-label">Author</label>
                                                                 <select class="form-control" name="Author" ng-model="PageModel.PageDetails.AuthorID" ng-options="At.UserID as At.Name for At in PageModel.AuthorListArray" data-ng-class="{'has-submitted' : PageForm.$submitted }" required ng-disabled="PageModel.ViewPage==0"></select>
                                                                <span class="error-text-color" ng-show="PageForm.$submitted">
                                                                    <span ng-show="PageForm.Author.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Author'))}}</span>
                                                                </span>
                                                             </div>

                                                            <div class="form-group col-md-12 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (PageForm.$submitted) && PageForm.Content.$invalid}">
                                                                <label for="Content" class="control-label">Content</label>
                                                                <textarea name="Content" data-ng-model="PageModel.PageDetails.Content" ck-editor data-ng-class="{'has-submitted' : PageForm.$submitted }" required  ng-disabled="PageModel.ViewPage==0"></textarea>
                                                                <span class="error-text-color" ng-show="PageForm.$submitted">
                                                                    <span ng-show="PageForm.Content.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Content'))}}</span>
                                                                </span>
                                                            </div>
                                                             <?php if($PageModel->PageDetails->SiteID == Constants::$RiverDaleFundingSiteID){?>
                                                             <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                 <label class="control-label margin-right-10">eBook Download Form: </label>
                                                                 <label class="margin-right-10"><input type="radio" id="IsShowBrokerPackageCTA" ng-model="PageModel.PageDetails.IsShowBrokerPackageCTA" name="IsShowBrokerPackageCTA" value="0"/>  Commercial Real Estate Loan</label>
                                                                 <label><input type="radio" id="IsShowBrokerPackageCTA" ng-model="PageModel.PageDetails.IsShowBrokerPackageCTA" name="IsShowBrokerPackageCTA"  value="1"/> Broker Package</label>
                                                            </div>
                                                             <?php }?>
                                                        </div>
                                                    </div>
                                                <!-- For Slider image upload section start -->
                                                    <?php if($PageModel->PageDetails->SiteID == Constants::$RiverDaleFundingSiteID || $PageModel->PageDetails->SiteID == Constants::$ColoradoSiteID || $PageModel->PageDetails->SiteID == Constants::$WoodBridgeWealthSiteID){?>
                                                        <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12 image-field-right">
                                                            <div class="col-md-12 no-padding">
                                                                <label for="Slider image" class="control-label">Top image</label>
                                                            </div>
                                                            <div class="fileinput fileinput-new" ng-clock>
                                                                <div  class="fileinput-new thumbnail image-box">
                                                                    <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                    <img id="actualImage" alt="" ng-src="@{{ PageModel.PageDetails.RealTopImagePath ? PageModel.PageDetails.RealTopImagePath : PageModel.PageDetails.NoImagePath }}" ng-clock>
                                                                </div>
                                                                <div>
                                                                    <form></form>
                                                                    <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo Constants::$PageTopImageType;?>" name="FormTopImage" role="form" novalidate>
                                                                        <input type="hidden" id="key" name="key" value="">
                                                                        <input type="hidden" name="AWSAccessKeyId"  ng-value="PageModel.PageDetails.Fileuploadsettings.accesskey">
                                                                        <input type="hidden" name="acl"  ng-value="PageModel.PageDetails.Fileuploadsettings.acl">
                                                                        <input type="hidden" name="success_action_status"  ng-value="PageModel.PageDetails.Fileuploadsettings.success_action">
                                                                        <input type="hidden" name="policy"  ng-value="PageModel.PageDetails.Fileuploadsettings.base64Policy">
                                                                        <input type="hidden" name="signature"  ng-value="PageModel.PageDetails.Fileuploadsettings.signature">
                                                                        <input type="hidden" name="Cache-Control" ng-value="PageModel.PageDetails.Fileuploadsettings.cacheControlTime">
                                                                        <span  class="btn default btn-file" ><input type="file" name="file" ng-model="PageModel.PageDetails.RealTopImagePath" id="file" title="Choose Image" <?php if($PageModel->PageDetails->SiteID == Constants::$RiverDaleFundingSiteID) echo "required";?>> Choose Image</span>
                                                                        <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage(<?php echo "'".Constants::$PageTopImageType."'"; ?>)" ng-hide="(PageModel.PageDetails.RealTopImagePath == '' || PageModel.PageDetails.RealTopImagePath == null)"> Remove </a>
                                                                        <span></span>
                                                                    </form>
                                                                </div>
                                                                <span>&nbsp;</span>
                                                                <div class="progress progress-striped display-none background">
                                                                    <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                    </div>
                                                                </div>
                                                                <div class="info-alert" ng-if="(AllowedTopFixHeight > 0 ) && (AllowedTopFixWidth > 0 )"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedTopFixWidth }}x@{{ AllowedTopFixHeight }}px</lable></div>
                                                                <div ng-class="{ 'has-error' : (PageForm.$submitted) && FormTopImage.file.$error}" class="has-error">
                                                                    <div class="help-block" ng-messages="FormTopImage.file.$error" ng-if="PageForm.$submitted">
                                                                        <div ng-show="FormTopImage.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Top images'))}}</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php }?>

                                                    <?php  if($PageModel->PageDetails->SiteID == Constants::$WoodBridgeWealthSiteID){?>
                                                        <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12 image-field-right">
                                                            <div class="col-md-12 no-padding">
                                                                <label for="Slider image" class="control-label">Bottom Right Image</label>
                                                            </div>
                                                            <div class="fileinput fileinput-new" ng-clock>
                                                                <div  class="fileinput-new thumbnail image-box">
                                                                    <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                    <img id="actualImage" alt="" ng-src="@{{ PageModel.PageDetails.RealBottomRightImagePath ? PageModel.PageDetails.RealBottomRightImagePath : PageModel.PageDetails.NoImagePath }}" ng-clock>
                                                                </div>
                                                                <div>
                                                                    <form></form>
                                                                    <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo Constants::$PageBottomRightImageType;?>" name="FormBottomImage" role="form" novalidate>
                                                                        <input type="hidden" id="key" name="key" value="">
                                                                        <input type="hidden" name="AWSAccessKeyId"  ng-value="PageModel.PageDetails.Fileuploadsettings.accesskey">
                                                                        <input type="hidden" name="acl"  ng-value="PageModel.PageDetails.Fileuploadsettings.acl">
                                                                        <input type="hidden" name="success_action_status"  ng-value="PageModel.PageDetails.Fileuploadsettings.success_action">
                                                                        <input type="hidden" name="policy"  ng-value="PageModel.PageDetails.Fileuploadsettings.base64Policy">
                                                                        <input type="hidden" name="signature"  ng-value="PageModel.PageDetails.Fileuploadsettings.signature">
                                                                        <input type="hidden" name="Cache-Control" ng-value="PageModel.PageDetails.Fileuploadsettings.cacheControlTime">
                                                                        <span  class="btn default btn-file" ><input type="file" name="file" ng-model="PageModel.PageDetails.RealBottomRightImagePath" id="file" title="Choose Image" > Choose Image</span>
                                                                        <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage(<?php echo "'".Constants::$PageBottomRightImageType."'"; ?>)" ng-hide="(PageModel.PageDetails.RealBottomRightImagePath == '' || PageModel.PageDetails.RealBottomRightImagePath == null)"> Remove </a>
                                                                        <span></span>
                                                                    </form>
                                                                </div>
                                                                <span>&nbsp;</span>
                                                                <div class="progress progress-striped display-none background">
                                                                    <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                    </div>
                                                                </div>
                                                                <div class="info-alert" ng-if="(AllowedBottomRightFixHeight > 0 ) && (AllowedBottomRightFixWidth > 0 )"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedBottomRightFixWidth }}x@{{ AllowedBottomRightFixHeight }}px</lable></div>
                                                                <div ng-class="{ 'has-error' : (PageForm.$submitted) && FormBottomImage.file.$error}" class="has-error">
                                                                    <div class="help-block" ng-messages="FormBottomImage.file.$error" ng-if="PageForm.$submitted">
                                                                        <div ng-show="FormBottomImage.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Top images'))}}</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php }?>
                                                <!-- For Slider image upload section end -->
                                            </div>
                                        </div>
                                </div>
                 </div>
                 <div class="portlet box blue-hoki" ng-cloak>
                        <div class="portlet-title" collapse="true">
                            <div class="caption">
                                <i class=""></i>SEO</div>
                           <div class="tools">
                                <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                            </div>
                        </div>
                        <div class="portlet-body ">
                            <div class="row">
                                <div class="form-body" ng-cloak>
                                     <div class="col-md-12 no-padding">
                                         <div class="col-md-12 no-padding">
                                            <div class="col-md-9  no-padding">
                                            <div class="form-group col-md-6 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (PageForm.$submitted) && PageForm.BrowserTitle.$invalid}">
                                                <label for="BrowserTitle" class="control-label">Browser Title</label>
                                                <input class="form-control"  type="text" name="BrowserTitle"  maxlength="200" data-ng-model="PageModel.PageDetails.BrowserTitle" data-ng-class="{'has-submitted' : PageForm.$submitted }"  ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"  required/>
                                                    <span class="error-text-color" ng-show="PageForm.$submitted">
                                                        <span ng-show="PageForm.BrowserTitle.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Browser Title'))}}</span>
                                                    </span>
                                            </div>
                                            <div class="form-group col-md-6 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (PageForm.$submitted) && PageForm.CanonicalURL.$invalid}">
                                                <label class="control-label">Canonical URL</label>
                                                <input class="form-control"  type="text" name="CanonicalURL" ng-model="PageModel.PageDetails.CanonicalURL" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>" maxlength="200"  ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0" required/>
                                                <span class="error-text-color" ng-show="PageForm.$submitted">
                                                        <span ng-show="PageForm.CanonicalURL.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'CanonicalURL'))}}</span>
                                                        <span ng-show="PageForm.CanonicalURL.$error.pattern">{{ trans('messages.InvalidCanonicalUrl') }}</span>
                                                </span>
                                            </div>

                                            <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                <label for="MetaDescription" class="control-label">Meta-Description</label>
                                                <textarea rows="6" class="form-control" name="MetaDescription" data-ng-model="PageModel.PageDetails.MetaDescription" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"></textarea>
                                            </div>

                                            </div>
                                             <div class="form-group col-md-12 col-sm-12 col-xs-12 no-padding margin-top-15"><hr class="hr-section margin-top-15"></div>

                                            <div class="col-md-12 no-padding ">
                                                <div class="form-group col-md-12 col-sm-12 col-xs-12 rich-margin">
                                                    <h3 class="page-title font-size19px">Facebook</h3>
                                                </div>
                                            <div class="form-group col-md-8 col-lg-9 col-sm-12 col-xs-12  no-padding">
                                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                    <label for="FBTitle" class="control-label">Facebook Title</label>
                                                    <input class="form-control" type="text" name="FBTitle"  maxlength="200" data-ng-model="PageModel.PageDetails.FBTitle" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0" />
                                                </div>
                                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                <label for="FBDescription" class="control-label">Facebook-Description</label>
                                                <textarea rows="6" class="form-control" name="FBDescription" data-ng-model="PageModel.PageDetails.FBDescription" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"></textarea>
                                            </div>
                                            </div>
                                            <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12">
                                                <label for="FBImage" class="control-label">Facebook Image</label>
                                            </div>
                                            <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12 margin-top1pr">
                                                <div class="fileinput fileinput-new">
                                                    <div class="fileinput-new thumbnail image-box">
                                                        <img src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                        <img id="actualImage" alt="" src="@{{PageModel.PageDetails.FBRealImagePath ? PageModel.PageDetails.FBRealImagePath : PageModel.PageDetails.NoImagePath}}">
                                                    </div>
                                                    <div>
                                                        <form></form>
                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo $FBImageType;?>">
                                                            <input type="hidden" id="key" name="key" value="">
                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="PageModel.PageDetails.Fileuploadsettings.accesskey">
                                                            <input type="hidden" name="acl"  ng-value="PageModel.PageDetails.Fileuploadsettings.acl">
                                                            <input type="hidden" name="success_action_status"  ng-value="PageModel.PageDetails.Fileuploadsettings.success_action">
                                                            <input type="hidden" name="policy"  ng-value="PageModel.PageDetails.Fileuploadsettings.base64Policy">
                                                            <input type="hidden" name="signature"  ng-value="PageModel.PageDetails.Fileuploadsettings.signature">
                                                            <input type="hidden" name="Cache-Control" ng-value="PageModel.PageDetails.Fileuploadsettings.cacheControlTime">
                                                            <span class="btn default btn-file" ><input type="file" name="file" id="file" title="Choose Image" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"> Choose Image </span>
                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage(<?php echo "'".$FBImageType."'"; ?>)" data-ng-hide="PageModel.PageDetails.FBRealImagePath =='' || (PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0)">Remove</a>
                                                            <span></span>
                                                        </form>
                                                    </div>
                                                    <span>&nbsp;</span>
                                                    <div class="progress progress-striped display-none">
                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        </div>
                                            <div class="form-group col-md-12 col-sm-12 col-xs-12 no-padding"><hr class="hr-section"></div>
                                         <div class="col-md-12 no-padding">
                                            <div class="form-group col-md-12 col-sm-12 col-xs-12 rich-margin">
                                                 <h3 class="page-title font-size19px">Twitter</h3>
                                             </div>
                                             <div class="form-group col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                            <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                <label for="TwitterCard" class="control-label">Twitter Card</label>
                                                <input class="form-control" type="text" name="TwitterCard"  maxlength="50" data-ng-model="PageModel.PageDetails.TwitterCard" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"/>
                                            </div>
                                            <div class="form-group col-md-6 col-sm-12 col-xs-12">
                                                <label for="TwitterSite" class="control-label">Twitter Site</label>
                                                <input class="form-control"  type="text" name="TwitterSite"  maxlength="200" data-ng-model="PageModel.PageDetails.TwitterSite" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"/>
                                            </div>
                                            <div class="form-group col-md-6 col-sm-12 col-xs-12">
                                                <label for="TwitterTitle" class="control-label">Twitter Title</label>
                                                <input class="form-control"  type="text" name="TwitterTitle"  maxlength="200" data-ng-model="PageModel.PageDetails.TwitterTitle" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"/>
                                            </div>
                                            <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                <label for="TwitterDescription" class="control-label">Twitter-Description</label>
                                                <textarea rows="6" class="form-control" name="TwitterDescription" data-ng-model="PageModel.PageDetails.TwitterDescription" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"></textarea>
                                            </div>

                                         </div>
                                             <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12">
                                                 <label for="TwitterImage" class="control-label">Twitter Image</label>
                                             </div>
                                         <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12 margin-top1pr">
                                                <div class="fileinput fileinput-new">
                                                    <div class="fileinput-new thumbnail image-box">
                                                        <img src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                        <img id="actualImage" alt="" src="@{{PageModel.PageDetails.TwitterRealImagePath ? PageModel.PageDetails.TwitterRealImagePath : PageModel.PageDetails.NoImagePath}}">
                                                    </div>
                                                    <div>
                                                        <form></form>
                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo $TwitterImageType;?>">
                                                            <input type="hidden" id="key" name="key" value="">
                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="PageModel.PageDetails.Fileuploadsettings.accesskey">
                                                            <input type="hidden" name="acl"  ng-value="PageModel.PageDetails.Fileuploadsettings.acl">
                                                            <input type="hidden" name="success_action_status"  ng-value="PageModel.PageDetails.Fileuploadsettings.success_action">
                                                            <input type="hidden" name="policy"  ng-value="PageModel.PageDetails.Fileuploadsettings.base64Policy">
                                                            <input type="hidden" name="signature"  ng-value="PageModel.PageDetails.Fileuploadsettings.signature">
                                                            <input type="hidden" name="Cache-Control" ng-value="PageModel.PageDetails.Fileuploadsettings.cacheControlTime">
                                                            <span class="btn default btn-file"><input type="file" name="file" id="file" title="Choose Image" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"> Choose Image </span>
                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage(<?php echo "'".$TwitterImageType."'"; ?>)" data-ng-hide="PageModel.PageDetails.TwitterRealImagePath=='' || (PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0) ">Remove</a>
                                                            <span></span>
                                                        </form>
                                                    </div>
                                                    <span>&nbsp;</span>
                                                    <div class="progress progress-striped display-none">
                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                         </div>
                                         <div class="form-group col-md-12 col-sm-12 col-xs-12 no-padding"><hr class="hr-section"></div>
                                         <div class="form-group col-md-12 col-sm-12 col-xs-12 rich-margin">
                                             <h3 class="page-title font-size19px">Rich Snippets</h3>
                                         </div>

                                         <div class="col-md-12  no-padding">
                                            <div class="col-md-12  no-padding">
                                                <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                        <label for="Headline" class="control-label">Headline</label>
                                                        <input class="form-control"  type="text" name="Headline"  maxlength="200" data-ng-model="PageModel.PageDetails.Headline" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"/>
                                                    </div>
                                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                    <label for="TwitterDescription" class="control-label">Description</label>
                                                    <textarea rows="6" class="form-control" name="Description" data-ng-model="PageModel.PageDetails.Description" ng-disabled="PageModel.ViewPage==0 && PageModel.CanEditSEOFields==0"></textarea>
                                                </div>
                                                </div>
                                                <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12">
                                                    <label for="TwitterImage" class="control-label">Image Upload</label>
                                                </div>
                                                <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12 margin-top1pr">
                                                <div class="fileinput fileinput-new">
                                                    <div class="fileinput-new thumbnail image-box">
                                                        <img src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                        <img id="actualImage" alt="" src="@{{PageModel.PageDetails.GoogleRealImagePath ? PageModel.PageDetails.GoogleRealImagePath : PageModel.PageDetails.NoImagePath}}">
                                                    </div>
                                                    <div>
                                                        <form></form>
                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo $GoogleImageType;?>">
                                                            <input type="hidden" id="key" name="key" value="">
                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="PageModel.PageDetails.Fileuploadsettings.accesskey">
                                                            <input type="hidden" name="acl"  ng-value="PageModel.PageDetails.Fileuploadsettings.acl">
                                                            <input type="hidden" name="success_action_status"  ng-value="PageModel.PageDetails.Fileuploadsettings.success_action">
                                                            <input type="hidden" name="policy"  ng-value="PageModel.PageDetails.Fileuploadsettings.base64Policy">
                                                            <input type="hidden" name="signature"  ng-value="PageModel.PageDetails.Fileuploadsettings.signature">
                                                            <input type="hidden" name="Cache-Control" ng-value="PageModel.PageDetails.Fileuploadsettings.cacheControlTime">
                                                            <span class="btn default btn-file" ><input type="file" name="file" id="file" title="Choose Image" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"> Choose Image </span>
                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage(<?php echo "'".$GoogleImageType."'"; ?>)" data-ng-hide="PageModel.PageDetails.GoogleRealImagePath == '' || (PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0)">Remove</a>
                                                            <span></span>
                                                        </form>
                                                    </div>
                                                    <span>&nbsp;</span>
                                                    <div class="progress progress-striped display-none">
                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                       </div>
                 </div>
                 <div class="portlet box blue-hoki" ng-cloak>
                        <div class="portlet-title" collapse>
                            <div class="caption">
                                <i class=""></i>Assign for approval</div>
                            <div class="tools">
                                <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                            </div>
                        </div>
                        <div class="portlet-body">
                            <div class="row">
                                <div class="form-body" ng-cloak>
                                    <div class="col-md-12  no-padding">
                                        <div class="form-group col-md-9 col-sm-12 col-xs-12 no-padding">
                                            <div class="form-group col-md-6 col-sm-12 col-xs-12">
                                                <label for="Assign" class="control-label">Assign To</label>
                                                <select class="form-control" name="AssignTo" ng-model="PageModel.PageDetails.AssignedID" ng-options="As.UserID as As.Name for As in PageModel.AssignListArray" data-ng-class="{'has-submitted' : PageForm.$submitted }" required ng-disabled="PageModel.ViewPage==0"></select>
                                                    <span class="error-text-color" ng-show="PageForm.$submitted">
                                                        <span ng-show="PageForm.AssignTo.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Assign To'))}}</span>
                                                    </span>
                                            </div>
                                            <div class="form-group col-md-6 col-sm-12 col-xs-12">
                                                <label for="Status" class="control-label">Status</label>
                                                <select class="form-control" name="Status" ng-model="PageModel.PageDetails.StatusID" ng-options="St.StatusID as St.Status for St in PageModel.StatusListArray" ng-disabled="PageModel.ViewPage==0"></select>
                                            </div>
                                        </div>
                                        <div class="col-md-12  no-padding">
                                            <div class="form-group col-md-9 col-sm-12 col-xs-12">
                                                <label for="TwitterDescription" class="control-label">Message</label>
                                                <textarea rows="6" id="deny-message" class="form-control" name="Message" data-ng-model="PageModel.PageDetails.Message" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <!-- For File Upload Start -->

                <div class="portlet box blue-hoki" ng-cloak>
                    <div class="portlet-title" collapse>
                        <div class="caption">
                            <i class=""></i>SLIDER IMAGES</div>
                        <div class="tools">
                            <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                        </div>
                    </div>
                    <div class="portlet-body">
                        <div class="row">
                            <div class="col-md-12 no-padding">
                                <div class="form-body" >
                                    <div class="col-md-12 no-padding">
                                       <div class="form-group col-md-12"> <!-- ng-class="{ 'has-error' : (PageForm.$submitted) && PageForm.HeaderText.$invalid}">-->
                                            <label for="Header text" class="control-label">Header text</label>
                                            <input class="form-control" type="text" name="HeaderText" ng-model="PageModel.PageDetails.HeaderText"  maxlength="255"  />
                                           <!-- <div  class="help-block" ng-messages="PageForm.HeaderText.$error" ng-if="PageForm.$submitted">
                                                <div ng-show="PageForm.HeaderText.$error.required  && PageForm.HeaderText.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Header text'))}}</div>
                                            </div>-->
                                        </div>
                                        <div class="form-group col-md-12">
                                            <input type="checkbox" name="IsOverlay" class="margin-right-5" id="IsOverlay" ng-false-value="0" ng-true-value="1" ng-model="PageModel.PageDetails.IsOverlay">
                                            <label for="IsOverlay">Add Overlay?</label>
                                        </div>
                                        <div class="form-group col-md-2" ng-class="{ 'has-error' : (PageForm.$submitted) && PageForm.Opacity.$invalid}" ng-show="PageModel.PageDetails.IsOverlay == 1">
                                            <label for="Opacity" class="control-label">Opacity (1-100)</label>
                                            <input class="form-control" type="text" name="Opacity" ng-model="PageModel.PageDetails.Opacity" ng-class="{ 'has-submitted' : HomeForm.$submitted }"  ng-required="PageModel.PageDetails.IsOverlay == 1" maxlength="3" intype="digit" pattern="<?php echo \Infrastructure\Constants::$OpacityRegex;?>"/>
                                            <div  class="help-block" ng-messages="PageForm.Opacity.$error" ng-if="PageForm.$submitted">
                                                <div ng-show="PageForm.Opacity.$error.required  && PageForm.Opacity.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Opacity'))}}</div>
                                                <div ng-show="PageForm.Opacity.$error.pattern">{{ trans('messages.InvalidOpacity')}}</div>
                                            </div>
                                        </div>
                                        <?php if($PageModel->PageDetails->SiteID == Constants::$MercerVineSiteID){ ?>
                                        <div class="col-md-12 margin-bottom-10">
                                            <span class="font13px help-block info-alert"><span><span class="bold">Note:</span> {{ trans('messages.PageSliderImagesDimension')}}</span></span>
                                        </div>
                                        <?php } ?>
                                        <div class="clearboth"></div>
                                        <div class="form-group col-md-12 dropZoneOuter">
                                            <form></form>
                                            <form action="" class="dropzone" drop-zone="" id="file-dropzone"  ng-aws-settings-model="PageModel.PageDetails.Fileuploadsettings" success-callback="PushFilesToUploadArray" remove-file="RemoveFile" upload-file="PageModel.PageDetails.ImagesModel" file-name="PageModel.PageDetails.ImagesNameModel" ext-type="PageModel.PageDetails.ImageExtensionType" max-files="PageModel.maxFiles" request-counter="PageModel.requestCounter" response-counter="PageModel.responseCounter"  upload-complete="UploadComplete" uploaded-file="PageModel.PageDetails.UploadedFile" file-size-exceeds="{{ trans('messages.NoMoreImages')}}" invalid-file-format="{{trans('messages.InvalidImageTypeFormat')}}" allow-sortable="PageModel.IsAllowSortable" sortable-callback="updateSortOrderSlider">
                                                <div class="dz-preview dz-file-preview margin-10p sortable" id="template">
                                                    <div class="dz-details">
                                                        <div class="dz-filename"><span data-dz-name></span></div>
                                                        <div class="dz-size" data-dz-size></div>
                                                        <div><span class="dz-remove"></span></div><img data-dz-thumbnail />
                                                    </div>
                                                    <br/>
                                                    <div  class="progress progress-striped active" id="totalprogressbar"  role="progressbar" aria-valuemin='0' aria-valuemax='100' aria-valuenow='0'> <div class="progress-bar progress-bar-success bar width-none" data-dz-uploadprogress></div> </div>
                                                    <div class="dz-success-mark"><span>✔</span></div>
                                                    <div class="dz-error-mark"><span>✘</span></div>
                                                    <div class="file-error-message"><strong class="error text-danger" data-dz-errormessage></strong></div>

                                                    <div class="col-md-12 col-md-push-1 no-padding" >
                                                        <div class="sortable-handle vertical-align btn btn-gray col-md-4 no-padding col-sm-4 col-xs-4 drag-drop-icon">
                                                            <center><span class="draggable-icon-arrow"><i class="fa fa-bars draggable-icon dropzone-draggable-button"></i>
                                                                             <i class="fa fa-arrows-alt draggable-icon dropzone-draggable-button"></i></span></center>
                                                        </div>
                                                        <div class=" col-md-3 no-padding col-md-push-2">
                                                            <button data-dz-remove="" class="btn btn-danger delete cancel dropzone-delete-button"><i class="glyphicon glyphicon-trash"></i></button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clearboth"></div>
                <!-- For File Upload End -->
                    <?php if($PageModel->PageDetails->PageID > 0) {?>
                        <div class="col-md-12 no-padding margin-bottom-10" ng-show="PageModel.PageDetails.PageID > 0">
                            <span class="font13px help-block info-alert display-none" >
                                    <span><span class="bold">Note:</span> {{ trans('messages.NoteForImageInProgressEdit')}}</span>
                            </span>
                        </div>
                    <?php } ?>
                    <?php if($PageModel->PageDetails->PageID == 0) {?>
                        <div class="col-md-12 no-padding margin-bottom-10" ng-show="PageModel.PageDetails.PageID == 0">
                            <span class="font13px help-block info-alert display-none" >
                                    <span><span class="bold">Note:</span> {{ trans('messages.NoteForImageInProgressAdd')}}</span>
                            </span>
                        </div>
                    <?php } ?>
                 <div class="col-md-12 no-padding" ng-cloak>
                         <div class="form-actions  col-md-12 col-sm-12 col-xs-12 no-padding">
                             <input name="submit" type="submit" value="Save" class="btn blue save-button btn-submit" ng-hide="PageModel.ViewPage==0 && PageModel.CanEditSEOFields==0" data-ng-click="Save()" ng-disabled="requestCounter != responseCounter || !UploadComplete"/>
                             <input name="submit" type="submit" value="Approve" class="btn green-meadow save-button btn-submit" data-ng-click="Approve()" ng-hide="PageModel.ShowApproveDenyButton == 0 || PageModel.ViewPage==0 || PageModel.currentStatusID == <?php echo Constants::$WorkFlowStatus_Approve;?>  || PageModel.currentStatusID == <?php echo Constants::$WorkFlowStatus_Published;?>" ng-disabled="requestCounter != responseCounter || !UploadComplete"/>
                             <input name="submit" type="submit" value="Deny" class="btn red-sunglo save-button btn-submit" data-ng-click="Deny()" ng-hide="PageModel.ShowApproveDenyButton == 0 || PageModel.ViewPage==0 || PageModel.currentStatusID == <?php echo Constants::$WorkFlowStatus_Denied;?> || PageModel.currentStatusID == <?php echo Constants::$WorkFlowStatus_Published;?>" ng-disabled="requestCounter != responseCounter || !UploadComplete"/>
                             <input name="submit" type="submit" value="Publish" class="btn yellow-mint save-button btn-submit" data-ng-click="Publish()" ng-hide="PageModel.ShowPublishButton==0 || PageModel.currentStatusID == <?php echo Constants::$WorkFlowStatus_Published;?>" ng-disabled="requestCounter != responseCounter || !UploadComplete"/>
                             <button type="button" id="cancel" name="cancel" class="btn default" data-ng-click="Cancel()" ng-disabled="requestCounter != responseCounter || !UploadComplete">Cancel</button>
                         </div>
                     </div>
                 <div class="clearboth"></div>
                 <div class="portlet box blue-hoki margin-top-25" ng-show="PageModel.PageDetails.PageID >0 && PageModel.Messages.length >0" ng-cloak>
                        <div class="portlet-title" collapse>
                            <div class="caption">
                                <i class=""></i>Message History</div>
                            <div class="tools">
                                <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                            </div>
                        </div>
                        <div class="portlet-body">
                            <div class="row">
                                <div class="form-body" ng-cloak>
                                    <div class="col-md-12  no-padding">
                                        <div class="col-md-12 col-sm-6" ng-show="PageModel.PageDetails.PageID >0 && PageModel.Messages.length >0">
                                            <div class="portlet light bordered msg-history">

                                                <div class="portlet-body" id="chats">
                                                    <div class="scroller history-scroll"  data-always-visible="1" data-rail-visible1="1">
                                                        <ul class="chats" data-ng-repeat="data in PageModel.Messages">
                                                            <li ng-class="{'out': data.ClassIn==1,'in':data.ClassIn==0}">
                                                                <img class="avatar" alt="" src="@{{data.ImageURL ? data.ImageURL : PageModel.PageDetails.NoProfileImagePath}}"/>
                                                                <div class="message">
                                                                    <span class="arrow"> </span>
                                                                    <a href="" class="name">@{{data.Name}}</a>
                                                                    <span class="datetime"> at @{{ data.CreatedDate }} </span>
                                                                    <span class="body">@{{data.Message}}</span>
                                                                </div>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                        </div>

                 </div>

                 </div>
            </div>
        </div>
    </div>
</form>
</main>
@stop
@section('script')
   {{ $minify::javascript(array('/assets/js/viewjs/pages/addpage.js',
                             //'/assets/js/ckeditor/ckeditor.js',
                             '/assets/js/library/jquery.fileupload/jquery.ui.widget.js',
                             '/assets/js/library/jquery.fileupload/jquery.fileupload.js',
                             '/assets/js/library/binaryajax.js',
                             '/assets/js/library/exif.js',
                             '/assets/js/library/bootstrap-fileinput.js',
                             '/assets/js/sitejs/canvasResize.js'))->withFullUrl()}}
   <script src="{{asset('/assets/js/ckeditor/ckeditor.js')}}" defer></script>

   {{ $minify::javascript(array('/assets/js/sitejs/dropzone.js'))->withFullUrl()}}
   {{ $minify::javascript(array('/assets/js/sitejs/jquery-ui-1.9.2.custom.min.js',
                                  '/assets/js/sitejs/jquery.ui.touch-punch.min.js'))->withFullUrl()}}

   <script>
       window.ImageFileAllowedMessage ="{{ trans('messages.ImageFileAllowedMessage')}}";
       window.ConfirmUploadMessage ="{{ trans('messages.ConfirmUploadMessage')}}";
       window.FBMaxFileSizeErrorMessage = "{{trans('messages.FBImageErrorMessage')}}";
       window.TwitterMaxFileSizeErrorMessage = "{{trans('messages.TwitterImageErrorMessage')}}";
       window.GoogleMaxFileSizeErrorMessage = "{{trans('messages.GoogleImageErrorMessage')}}";
       window.DefaultUploadPhotoHeight='<?php echo Constants::$DefaultUploadProfileHeight;?>';
       window.DefaultUploadPhotoWidth='<?php echo Constants::$DefaultUploadProfileWidth;?>';
       window.ImageSize = '<?php echo $ImageMaxSize; ?>';
       window.NoImagePath = '<?php echo asset('/assets/images/Samplephoto.png') ?>';
       window.NoProfileImagePath = '<?php echo asset('/assets/images/no-user.png') ?>';
       window.FBImageType = '<?php echo $FBImageType; ?>';
       window.TwitterImageType = '<?php echo $TwitterImageType; ?>';
       window.GoogleImageType = '<?php echo $GoogleImageType; ?>';
       window.PageTopImageType = '<?php echo Constants::$PageTopImageType; ?>';
       window.RiverDaleFundingSiteID = '<?php echo Constants::$RiverDaleFundingSiteID; ?>';
       window.ColoradoSiteID = '<?php echo Constants::$ColoradoSiteID; ?>';
       window.MessageRequired = "{{ trans('messages.MessageRequired')}}";
       window.PageBottomRightImageType = '<?php echo Constants::$PageBottomRightImageType; ?>';
       window.WoodBridgeWealthSiteID = '<?php echo Constants::$WoodBridgeWealthSiteID; ?>';
   </script>
@stop