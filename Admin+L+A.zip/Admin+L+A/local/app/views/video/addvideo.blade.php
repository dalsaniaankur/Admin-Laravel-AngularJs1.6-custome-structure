<?php
    use Infrastructure\Constants;
    use Infrastructure\Common;
    use BaseController as BA;
    $minify = new \CeesVanEgmond\Minify\Facades\Minify;
?>
@extends('layouts.sitemaster')
@section('Title')
    <?php if($VideoModel->VideoDetails->VideoID == 0){ print 'Add Videos';}else{ print 'Edit Videos';}?>
@stop
@section('css')
    {{ $minify::stylesheet(array('/assets/css/tagsinput/ng-tags-input.min.css'))->withFullUrl()}}
@stop
@section('content')
<main id="main" role="main" ng-controller = "VideoController">
<form name="VideoForm" id="VideoForm" role="form" novalidate ng-submit="checkSave(VideoForm)">
<?php echo Form::hidden('VideoModel', json_encode($VideoModel),$attributes = array('id'=>'VideoModel')); ?>
    <div class="page-content" >
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo URL::to('/dashboard/'.$encryptedSiteID) ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <a href="<?php echo URL::to('/videolist/'.$encryptedSiteID) ?>">Videos</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span><?php if($VideoModel->VideoDetails->VideoID == 0){ print 'Add Video';}else{ print 'Edit Video';}?></span>
                </li>
            </ul>

            <div class="page-toolbar">
                <div class="btn-group pull-right"  ng-cloak>
                    <input id="btn-submit" name="submit" type="submit" value="Save" class="btn blue save-button btn-sm" data-ng-click="AddVideo()"  ng-disabled="DisableButtons || (responseCounter != requestCounter)">
                    <?php if(($VideoModel->VideoDetails->VideoID > 0) AND (BA::CheckRoleSitePermission(Constants::$RoleITAdmin,Constants::$MercerVineSiteID))){ ?>
                    <input id="delete" name="delete" type="button" value="Delete" class="btn btn-danger btn-sm btn-outline" data-ng-click="deleteVideo(VideoModel)">
                    <?php } ?>
                </div>
            </div>

        </div>
        <h3 class="page-title"> <?php if($VideoModel->VideoDetails->VideoID == 0){ print 'Add Video';}else{ print 'Edit Video';}?></h3>
        <div class="row">
            <div class="col-md-12">

                    <div class="form-body" ng-cloak>
                        <div class="portlet box blue-hoki" ng-cloak>
                            <div class="portlet-title" collapse>
                                <div class="caption">
                                    <i class=""></i>Details</div>
                                <div class="tools">
                                    <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                </div>
                            </div>
                            <div class="portlet-body">
                                <div class="row">
                                    <div class="col-md-12 no-padding">
                                        <div class="form-body" ng-cloak>
                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12 visible-sm visible-xs">
                                                <div class="fileinput fileinput-new">
                                                    <div  class="fileinput-new thumbnail image-box">
                                                        <img class="display-none loadingImage"  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage">
                                                        <img id="actualImage" alt="" src="@{{VideoModel.RealImagePath ? VideoModel.RealImagePath : VideoModel.NoImagePath}}">
                                                    </div>
                                                    <div>
                                                        <form></form>
                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" class="direct-upload">
                                                            <input type="hidden" id="key" name="key" value="">
                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="VideoModel.Fileuploadsettings.accesskey">
                                                            <input type="hidden" name="acl"  ng-value="VideoModel.Fileuploadsettings.acl">
                                                            <input type="hidden" name="success_action_status"  ng-value="VideoModel.Fileuploadsettings.success_action">
                                                            <input type="hidden" name="policy"  ng-value="VideoModel.Fileuploadsettings.base64Policy">
                                                            <input type="hidden" name="signature"  ng-value="VideoModel.Fileuploadsettings.signature">
                                                            <input type="hidden" name="Cache-Control" ng-value="VideoModel.Fileuploadsettings.cacheControlTime">
                                                            <span  class="btn default btn-file" ><input type="file" name="file" id="file" title="Choose Image"> Choose Image</span>
                                                            <a  class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage()" ng-hide="VideoModel.RealImagePath ==''"> Remove </a>
                                                            <span></span>
                                                        </form>
                                                    </div>
                                                    <span>&nbsp;</span>
                                                    <div class="progress progress-striped display-none">
                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                        </div>
                                                    </div>
                                                    <div class="info-alert" ng-if="(AllowedFixWidth > 0 ) && (AllowedFixHeight > 0 )"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedFixWidth }}x@{{ AllowedFixHeight }}px</lable></div>
                                                </div>
                                            </div>
                                            <div class="clearboth"></div>
                                            <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                    <div class="form-group col-md-6" ng-class="{ 'has-error' : (VideoForm.$submitted) && VideoForm.Title.$invalid}">
                                                        <label for="Question" class="control-label">Title</label>
                                                        <input class="form-control"  type="text" name="Title" ng-model="VideoModel.Title" ng-class="{ 'has-submitted' : VideoForm.$submitted }" maxlength="100" required />
                                                        <div  class="help-block" ng-messages="VideoForm.Title.$error" ng-if="VideoForm.$submitted">
                                                            <div  ng-show="VideoForm.Title.$error.required  && VideoForm.Title.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Title'))}}</div>
                                                        </div>
                                                    </div>

                                                    <div class="form-group col-md-6" ng-class="{ 'has-error' : (VideoForm.$submitted) && VideoForm.YoutubeURL.$invalid}">
                                                        <label for="Question" class="control-label">Youtube Link</label>
                                                        <input class="form-control"  type="text" name="YoutubeURL" ng-model="VideoModel.YoutubeURL" pattern="<?php echo \Infrastructure\Constants::$YoutubeRegex; ?>" ng-class="{ 'has-submitted' : VideoForm.$submitted }" required />
                                                        <div  class="help-block" ng-messages="VideoForm.YoutubeURL.$error" ng-if="VideoForm.$submitted">
                                                            <div  ng-show="VideoForm.YoutubeURL.$error.required  && VideoForm.YoutubeURL.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Youtube URL'))}}</div>
                                                            <div  ng-show="VideoForm.YoutubeURL.$error.pattern ">{{ trans('messages.InvalidYoutubeLink')}}</div>
                                                        </div>
                                                    </div>

                                                    <div class="form-group col-md-6">
                                                        <label for="Development" class="control-label">Development</label>
                                                        <select class="form-control" id="DevelopmentID" name="Name" ng-model="VideoModel.DevelopmentID" ng-options="Developments.DevelopmentID as Developments.Name for Developments in VideoModel.DevelopmentArray">
                                                            <option value="">-- select --</option>
                                                        </select>
                                                    </div>

                                                    <div class="form-group col-md-6" ng-class="{ 'has-error' : (VideoForm.$submitted) && VideoForm.Category.$invalid}">
                                                        <label for="Category" class="control-label">Category</label>
                                                        <select class="form-control" id="CategoryID" name="Category" ng-model="VideoModel.CategoryID" ng-options="Video.CategoryID as Video.Category for Video in VideoModel.VideoCategoryArray" ng-class="{ 'has-submitted' : VideoForm.$submitted }" required>
                                                            <option value="">-- select --</option>
                                                        </select>
                                                        <div class="help-block" ng-messages="VideoForm.CategoryID.$error" ng-if="VideoForm.$submitted">
                                                            <div  ng-show="VideoForm.Category.$error.required && VideoForm.Category.$invalid">{{ trans('messages.PropertyRequired',array('attribute'=>'Category Type'))}}</div>
                                                        </div>
                                                    </div>

                                                    <div class="form-group col-md-12" ng-class="{ 'has-error' : (VideoForm.$submitted) && ShowTagsError}">
                                                        <label for="Tags" class="control-label">Tags</label>
                                                        <tags-input ng-model="VideoModel.TagID" display-property="Tag" replace-spaces-with-dashes="false" add-from-autocomplete-only="true" class="ngTagsInput" >
                                                            <auto-complete source="loadSiteTags($query)"  min-length="0" load-on-focus="true" load-on-empty="false" template="my-custom-template"></auto-complete>
                                                        </tags-input>

                                                        <div class="help-block"  ng-if="ShowTagsError">
                                                            <div ng-show="ShowTagsError">{{ trans('messages.InvalidTag')}}</div>
                                                        </div>

                                                        <script type="text/ng-template" id="my-custom-template">
                                                            <span ng-bind-html="$highlight($getDisplayText())"></span>
                                                        </script>
                                                    </div>

                                                    <div class="form-group col-md-12">
                                                        <label for="Short Description" class="control-label">Short Description</label>
                                                        <textarea class="form-control" rows="5" name="ShortDescription" ng-model="VideoModel.ShortDescription"></textarea>
                                                    </div>

                                                </div>
                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12 hidden-sm hidden-xs">
                                                <div class="fileinput fileinput-new">
                                                    <div  class="fileinput-new thumbnail image-box">
                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                        <img id="actualImage" alt="" src="@{{VideoModel.RealImagePath ? VideoModel.RealImagePath : VideoModel.NoImagePath}}">
                                                    </div>
                                                    <div>
                                                        <form></form>
                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" class="direct-upload">
                                                            <input type="hidden" id="key" name="key" value="">
                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="VideoModel.Fileuploadsettings.accesskey">
                                                            <input type="hidden" name="acl"  ng-value="VideoModel.Fileuploadsettings.acl">
                                                            <input type="hidden" name="success_action_status"  ng-value="VideoModel.Fileuploadsettings.success_action">
                                                            <input type="hidden" name="policy"  ng-value="VideoModel.Fileuploadsettings.base64Policy">
                                                            <input type="hidden" name="signature"  ng-value="VideoModel.Fileuploadsettings.signature">
                                                            <input type="hidden" name="Cache-Control" ng-value="VideoModel.Fileuploadsettings.cacheControlTime">
                                                            <span  class="btn default btn-file" ><input type="file" name="file" id="file" class="file" title="Choose Image"> Choose Image</span>
                                                            <a  class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage()" ng-hide="VideoModel.RealImagePath ==''"> Remove </a>
                                                            <span></span>
                                                        </form>
                                                    </div>
                                                    <span>&nbsp;</span>
                                                    <div class="progress progress-striped display-none">
                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                        </div>
                                                    </div>
                                                    <div class="info-alert" ng-if="(AllowedFixWidth > 0 ) && (AllowedFixHeight > 0 )"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedFixWidth }}x@{{ AllowedFixHeight }}px</lable></div>
                                                </div>
                                            </div>
                                            <div class="clearboth"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 no-padding">
                            <input id="btn-submit" name="submit" type="submit" value="Save" class="btn blue save-button" data-ng-click="AddVideo()"  ng-disabled="DisableButtons || (responseCounter != requestCounter)">
                            <button type="button" id="cancel" class="btn default" data-ng-click="Cancel()" ng-disabled="DisableButtons || (responseCounter != requestCounter)">Cancel</button>
                        </div>
                    </div>

            </div>
        </div>
    </div>
</form>
</main>

@stop

@section('script')

    {{ $minify::javascript(array('/assets/js/viewjs/video/addvideo.js',
                                 '/assets/js/library/jquery.fileupload/jquery.ui.widget.js',
                                 '/assets/js/library/jquery.fileupload/jquery.fileupload.js',
                                 '/assets/js/library/binaryajax.js',
                                 '/assets/js/library/exif.js',
                                 '/assets/js/library/bootstrap-fileinput.js',
                                 '/assets/js/sitejs/canvasResize.js'))->withFullUrl()}}
    <script>
        window.ImageFileAllowedMessage ="{{ trans('messages.ImageFileAllowedMessage')}}";
        window.ConfirmUploadMessage ="{{ trans('messages.ConfirmUploadMessage')}}";
        window.DefaultUploadPhotoHeight='<?php echo Constants::$DefaultUploadProfileHeight;?>';
        window.DefaultUploadPhotoWidth='<?php echo Constants::$DefaultUploadProfileWidth?>';
        window.NoImagePath = '<?php echo asset('/assets/images/Samplephoto.png') ?>';
    </script>

@stop