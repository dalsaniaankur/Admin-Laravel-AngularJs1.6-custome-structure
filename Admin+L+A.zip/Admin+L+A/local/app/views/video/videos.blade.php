<?php
use Infrastructure\Constants;
use Infrastructure\Common;
use BaseController as BA;
$minify = new \CeesVanEgmond\Minify\Facades\Minify;
?>
@extends('layouts.sitemaster')
@section('Title','Videos')
@stop
@section('css')
@stop
@section('content')
    <?php echo Form::hidden('VideoModel', json_encode($VideoModel), $attributes = array('id' => 'VideoModel')); ?>
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content" data-ng-controller = "VideoListController">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo URL::to('/dashboard/'.$encryptedSiteID) ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Videos</span>
                </li>
            </ul>
            <div class="page-toolbar">
                <div class="btn-group pull-right">
                    <a href="<?php echo URL::to('/addvideo/'.$encryptedSiteID); ?>" class="btn btn-primary btn-sm btn-outline"> Add A Video </a>
                </div>
            </div>

        </div>
        <h3 class="page-title">Videos</h3>
        <div class="row">
            <div class="col-md-12">
                <div data-ng-if="VideoListArray.length > 0" class="table-scrollable sortable" ng-cloak>
                    <div>
                    <table class="table table-striped table-bordered table-hover" sortable-list="VideoListArray" sortable-callback="updateSortOrder">
                        <thead class="site-footer">
                        <tr>
                            <th class="vertical-align" data-ng-if="VideoListArray.length > 1" ng-clock><span class="anchor_color"></span></th>
                            <th class="vertical-align video-dp-width"><span class="anchor_color ">Video</span></th>
                            <th class="vertical-align"><span class="anchor_color">Title</span></th>
                            <th class="vertical-align"><span class="anchor_color">Category</span></th>
                            <th class="vertical-align">Action</th>
                        </tr>
                        </thead>
                        <tbody class="drag-video-list">
                        <tr ng-repeat="item in VideoListArray" class="sortable-row" role="row">
                            <td class="sortable-handle vertical-align" data-ng-if="VideoListArray.length > 1">
                                <span class="draggable-icon-arrow">
                                    <i class="fa fa-bars draggable-icon"></i>
                                    <i class="fa fa-arrows-alt draggable-icon"></i>
                                </span>
                            </td>
                            <td class="vertical-align"><img src="@{{item.ThumbnailImageURL ? item.ThumbnailImageURL : VideoModel.NoImagePath}}" class="video-thumb-img" width="70px" height="70px"></td>
                            <td class="vertical-align"><div class="video-ellipsis"><a href="<?php echo URL::to('/')."/addvideo/"?>@{{item.combineVideoSiteid}}" title="Edit Video" ng-model="EditVideo">@{{item.Title}}</a></div></td>
                            <td class="vertical-align">@{{item.Category}}</td>
                            <td class="faq-action-part vertical-align">
                                <div>
                                    <a href="<?php echo URL::to('/')."/addvideo/"?>@{{item.combineVideoSiteid}}" title="Edit Video" ng-model="EditVideo"><i class="fa fa-pencil text-default" ></i></a>
                                    &nbsp;
                                    <?php if(BA::CheckRoleSitePermission(Constants::$RoleITAdmin,Constants::$MercerVineSiteID)) {?>
                                    <a ng-model="deleteVideo" ng-click="deleteVideo(item)" title="Delete Video" ng-model="DeleteVideo"><i class="fa fa-trash-o text-danger"></i></a>
                                    <?php } ?>
                                </div>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                    </div>
                </div>
                <div class="form-group col-md-12 display-none"  align="center" id="nodata">
                    <b>Sorry, no videos found</b>
                </div>
            </div>
        </div>
    </div>
@stop
@section('script')
       {{ $minify::javascript(array('/assets/js/sitejs/jquery-ui-1.9.2.custom.min.js',
                                   '/assets/js/viewjs/video/videos.js',
                                   '/assets/js/sitejs/jquery.ui.touch-punch.min.js'))->withFullUrl()}}
       <script>
           window.NoImagePath = '<?php echo asset('/assets/images/Samplephoto.png') ?>';
       </script>
@stop
