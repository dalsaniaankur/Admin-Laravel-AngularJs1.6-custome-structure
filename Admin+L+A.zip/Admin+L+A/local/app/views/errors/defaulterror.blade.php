<?php
    use Infrastructure\Constants;
    use Infrastructure\Common;
?>
@extends(Auth::User() ? $siteID = \ViewModels\SessionHelper::getSelectedSiteID() ? 'layouts.sitemaster':'layouts.choosesitemaster' : 'layouts.loginmaster');
@section('Title', $HeaderMessage)
@stop
@section('content')

     <main id="main" role="main">
         <div class="page-content">
             <div class="row">
                 <div class="col-md-12">
                     <?php if(Auth::User()){?>
                        <br/><br/><br/><br/><br/><br/><br/>
                     <?php } ?>
                     <div class="box-header with-border">
                         <h3 class="box-title" align="center"><?php echo $HeaderMessage ?></h3>
                     </div>
                     <div class="box-body">
                         <div class="social-auth-links text-center">
                             <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                 <div class="error-container">
                                     <h1>Oops!</h1>
                                     <h2><?php echo $ErrorCodeWithMessage;?></h2>
                                     <div class="error-details">
                                         <?php echo $ErrorMessage ;?>
                                     </div>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>

         </div>
     </main>


@stop
        <!-- show error section start -->
@section('footer_error')
    <div class="container-fluid">
        <a id="btn_show_error" href="javascript:void(0);" class="footer-error-link" data-toggle="collapse" data-target="#error_section">[+]</a>
        <div id="error_section" class="collapse out footer-error-section">
            <?php
            try{
                if(isset($ExceptionMessage) && !empty($ExceptionMessage) && ($ExceptionMessage != '')){
                    $errorHeader = 'exception' . Common::GetBetween('exception', 'Stack trace', $ExceptionMessage) . 'Stack trace:';
                    $stackTrace = str_replace($errorHeader, '', $ExceptionMessage);
                    echo str_replace('Stack trace:', '<br>Stack trace:', $errorHeader);
                    echo str_replace('#', '<br>#', $stackTrace);
                }else if(isset($FooterErrorMessage) && !empty($FooterErrorMessage) && ($FooterErrorMessage != '')){
                    echo $FooterErrorMessage;
                }else{
                    echo Constants::$DefaultErrorFooterMessage;
                }
            }catch (\ErrorException $ex){
                print $ex;
            }
            ?>
        </div>
    </div>
    @stop
            <!-- show error section end -->

@section('script')
 <script type="text/javascript">
 $(document).ready(function () {
	 $("#main").show();
	});
</script>
<!-- error section script start -->
 <script>
     $('#btn_show_error').attr('title','Show error');
     $('#error_section').on('show.bs.collapse', function (){
         $('#btn_show_error').html('[-]');
         $("html, body").animate({ scrollTop: $(document).height() }, 1000);
         $('#btn_show_error').attr('title','Hide error');
     });
     $('#error_section').on('hidden.bs.collapse', function (){
         $('#btn_show_error').html('[+]');
         $('#btn_show_error').attr('title','Show error');
     });
 </script>
<!-- error section script stop -->
@stop