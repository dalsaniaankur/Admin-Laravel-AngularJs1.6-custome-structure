@extends(Auth::User() ? $siteID = \ViewModels\SessionHelper::getSelectedSiteID() ? 'layouts.sitemaster':'layouts.choosesitemaster' : 'layouts.loginmaster');
@section('Title', ' Unauthorized ')
@section('content')

     <main id="main" role="main">
         <div class="page-content">
             <div class="row">
                 <div class="col-md-12">
                     <div class="box-header with-border">
                         <h3 class="box-title" align="center">Authorization Error</h3>
                     </div>
                     <div class="box-body">
                         <div class="social-auth-links text-center">
                             <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                 <div class="error-container">
                                     <h1>Oops!</h1>
                                     <h2> Authorization Error</h2>
                                     <div class="error-details">
                                         Sorry, You are trying to access a web page without proper authorization.
                                     </div>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>

         </div>
     </main>

@stop  
@section('script')
<script type="text/javascript">
	$(document).ready(function () {
		$("#main").show();
	});
</script>
@stop