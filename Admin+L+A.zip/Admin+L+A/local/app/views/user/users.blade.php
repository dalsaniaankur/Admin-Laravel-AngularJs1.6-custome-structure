<?php
$minify = new \CeesVanEgmond\Minify\Facades\Minify;
?>
@extends('layouts.sitemaster')
@section('Title','Users')
@stop
@section('css')
@stop
@section('content')
<?php
    echo Form::hidden('ListModel', json_encode($ListModel), $attributes = array('id' => 'ListModel'));
?>
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content" data-ng-controller = "UserListController">
        <!-- BEGIN PAGE HEADER-->
        <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo URL::to('/dashboard/'.$encryptedSiteID) ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Users</span>
                </li>
            </ul>
            <div class="page-toolbar">
                <div class="btn-group pull-right">
                    <a ng-click="RedirectToAdd()" class="btn btn-primary btn-sm btn-outline"> Add User </a>
                </div>
            </div>
        </div>
        <!-- END PAGE BAR -->
        <!-- BEGIN PAGE TITLE-->
        <h3 class="page-title"> Users
            <!--<small>dashboard & statistics</small>-->
        </h3>
        <!-- END PAGE TITLE-->
        <!-- END PAGE HEADER-->
        <!-- BEGIN Form Design-->
        <div class="row">
            <div class="col-md-12">
                <!-- BEGIN SAMPLE FORM PORTLET-->
                <form>
                    <div class="form-body" ng-cloak>
                       <div class="form-group col-md-2">
                                <label for="Last Name" class="control-label">Last Name</label>
                                <input type="text" class="form-control" data-ng-model="ListModel.frontSearchModel.LastName" id="LastName" name="LastName">
                            </div>
                            <div class="form-group col-md-3">
                                <label for="Email" class="control-label">Email</label>
                                <input type="text" class="form-control" data-ng-model="ListModel.frontSearchModel.Email" id="Email" name="Email">
                            </div>
                            <div class="form-group col-md-2">
                                <label for="Status" class="control-label">Status</label>
                                <select class="form-control" id="Status" name="Status" data-ng-model="ListModel.frontSearchModel.StatusID">
                                    <option ng-repeat="data in ListModel.StatusLookup" value="@{{data.StatusID}}">@{{data.Status}}</option>
                                </select>
                            </div>
                            <div class="form-group col-md-3">
                                <label for="Role" class="control-label">Role</label>
                                <select class="form-control" id="Role" name="Role" data-ng-model="ListModel.frontSearchModel.RoleID">
                                    <option ng-repeat="data in ListModel.rolesLookup" value="@{{data.RoleID}}">@{{data.Role}}</option>
                                </select>
                            </div>
                            <div class="form-group col-md-2">
                                <div class="search-label-hidden"><label class="control-label">&nbsp;</label></div>
                                <button data-ng-click="SearchUserRecords()" class="btn blue btn-search">Search</button>
                            </div>
                    </div>
                </form>
                <div data-ng-if="UserList.length > 0" class="table-responsive col-md-12" ng-cloak>
                    <table class="table dataTable table-striped table-bordered table-hover">
                        <thead class="site-footer">
                        <tr>
                            <th class="sorting" data-ng-click="ListPager.sortColumn('NAME')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'NAME' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'NAME' && !ListPager.reverse)}">
                                User
                            </th>
                            <th class="sorting" data-ng-click="ListPager.sortColumn('Email')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'Email' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'Email' && !ListPager.reverse)}">
                               Email
                            </th>
                            <th class="sorting" data-ng-click="ListPager.sortColumn('ModifiedDate')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'ModifiedDate' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'ModifiedDate' && !ListPager.reverse)}">
                                Last Updated
                            </th>
                            <th class="sorting" data-ng-click="ListPager.sortColumn('ModifiedByID')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'ModifiedByID' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'ModifiedByID' && !ListPager.reverse)}">
                                Last Updated By
                            </th>
                            <th class="sorting" data-ng-click="ListPager.sortColumn('Role')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'Role' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'Role' && !ListPager.reverse)}">
                                Role
                            </th>
                            <th class="sorting" data-ng-click="ListPager.sortColumn('Status')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'Status' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'Status' && !ListPager.reverse)}">
                                Status
                            </th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody dir-paginate="data in UserList | itemsPerPage:ListPager.pageSize" total-items="ListPager.totalRecords" current-page="ListPager.currentPage" pagination-id="UserID">
                        <tr>
                            <td><a ng-click="EditUser(data)" title="Edit User" >@{{data.Name}}</a></td>
                            <td>@{{data.Email}}</td>
                            <td>@{{data.ModifiedDate}}</td>
                            <td>@{{data.ModifiedBy}}</td>
                            <td>@{{data.Role}}</td>
                            <td>@{{data.Status}}</td>
                            <td>
                                <div>
                                    <a ng-click="EditUser(data)" title="Edit User" ><i class="fa fa-pencil text-default" ></i></a>
                                    &nbsp;
                                    <a ng-click="DisableUser(data)" ng-hide="@{{data.HideDisableButton}}==1"  title="Disable User"><i class="fa fa-ban text-danger"></i></a>
                                    <a ng-click="EnableUser(data)"  ng-hide="@{{data.HideEnableButton}}==1" title="Enable User"><i class="fa fa-circle-o font-green-jungle"></i></a>
                                </div>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
                    <div class="col-md-12" data-ng-if="UserList.length > 0">
                        <dir-pagination-controls boundary-links="true"  on-page-change="ListPager.pageChanged(newPageNumber)" pagination-id="UserID">
                        </dir-pagination-controls>
                    </div>

                    <div class="form-group col-md-12 display-none"  align="center" id="nodata">
                        <b>{{ trans('messages.NoUserRecordFound') }}</b>
                    </div>

            </div>

        </div>
        <!-- END DASHBOARD STATS 1-->
    </div>
    <!-- END CONTENT BODY -->
@stop

@section('script')
       <script>
           window.DisabledConfirmation ="{{ trans('messages.ConfirmDialogMessageForDisabled')}}";
           window.EnabledConfirmation ="{{ trans('messages.ConfirmDialogMessageForEnabled')}}";
        </script>
       {{ $minify::javascript(array('/assets/js/viewjs/user/users.js'))->withFullUrl()}}
@stop
