<?php use Infrastructure\Constants;
$userSiteList = \ViewModels\SessionHelper::getUserSiteList();
$minify = new \CeesVanEgmond\Minify\Facades\Minify;
?>
@extends('layouts.sitemaster')
@section('Title')
    <?php if($UserModel->UserDetails->UserID == 0){ print 'Add User';}else if($UserModel->UserDetails->IsUpdateProfile==0 && $UserModel->UserDetails->UserID> 0){ print 'Edit User';}else{print 'Update Profile';}?>
@stop
@section('css')
@stop
@section('content')
    <main id="main" role="main" ng-controller = "UserController">
        <form name="AddUserForm" id="AddUserForm" role="form" novalidate ng-submit="checkSave(AddUserForm)">
        <?php echo Form::hidden('UserModel',htmlspecialchars(json_encode($UserModel), ENT_QUOTES, 'UTF-8'),$attributes = array('id'=>'UserModel'));?>
        <div class="page-content"   ng-cloak>
            <div class="page-bar">
                <ul class="page-breadcrumb">
                    <li>
                        <?php if(isset($encryptedSiteID)){ ?>
                            <a href="<?php echo URL::to('/dashboard/'.$encryptedSiteID) ?>">Home</a>
                        <?php }else {?>
                            <a href="<?php echo URL::to('/choosesite') ?>">Home</a>
                        <?php }?>
                        <i class="fa fa-circle"></i>
                    </li>
                    <?php if($UserModel->UserDetails->IsUpdateProfile==0){ ?>
                    <li>
                        <a href="<?php echo URL::to('/users/'.$encryptedSiteID) ?>">Users</a>
                        <i class="fa fa-circle"></i>
                    </li>
                    <?php } ?>
                    <li>
                        <span><?php if($UserModel->UserDetails->UserID == 0){ print 'Add User';}else if($UserModel->UserDetails->IsUpdateProfile==0 && $UserModel->UserDetails->UserID> 0){ print 'Edit User';}else{print 'Update Profile';}?></span>
                    </li>
                </ul>
                <div class="page-toolbar">
                    <div class="btn-group pull-right">
                        <input id="btn-submit" name="submit" type="submit" value="Save" class="btn blue save-button btn-sm" data-ng-click="Save()" ng-disabled="DisableButtons">
                    </div>
                </div>
           </div>
            <h3 class="page-title"> <?php if($UserModel->UserDetails->UserID == 0){ print 'Add User';}else if($UserModel->UserDetails->IsUpdateProfile==0 && $UserModel->UserDetails->UserID> 0){ print 'Edit User';}else{print 'Update Profile';}?></h3>
            <div class="row">
                <div class="col-md-12">
                    
                        <div class="form-body" ng-cloak>
                        <div class="portlet box blue-hoki" ng-cloak>
                            <div class="portlet-title" collapse>
                                <div class="caption">
                                    <i class=""></i>Details</div>
                                <div class="tools">
                                    <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                </div>
                            </div>
                            <div class="portlet-body">
                                <div class="row">
                                    <div class="col-md-12 no-padding">
                                        <div class="form-body" ng-cloak>
                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12 visible-sm visible-xs">
                                                <div class="fileinput fileinput-new">
                                                    <div  class="fileinput-new thumbnail image-box">
                                                        <img class="display-none loadingImage" src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" >
                                                        <img id="actualImage" alt="" src="@{{UserModel.RealImagePath ? UserModel.RealImagePath : UserModel.NoImagePath}}">
                                                    </div>
                                                    <div>
                                                        <form></form>
                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload">
                                                            <input type="hidden" id="key" name="key" value="">
                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="UserModel.Fileuploadsettings.accesskey">
                                                            <input type="hidden" name="acl"  ng-value="UserModel.Fileuploadsettings.acl">
                                                            <input type="hidden" name="success_action_status"  ng-value="UserModel.Fileuploadsettings.success_action">
                                                            <input type="hidden" name="policy"  ng-value="UserModel.Fileuploadsettings.base64Policy">
                                                            <input type="hidden" name="signature"  ng-value="UserModel.Fileuploadsettings.signature">
                                                            <input type="hidden" name="Cache-Control" ng-value="UserModel.Fileuploadsettings.cacheControlTime">
                                                            <span  class="btn default btn-file" ><input type="file" name="file" class="file"  id="file" title="Choose Image"> Choose Image</span>
                                                            <a  class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage()" ng-hide="UserModel.RealImagePath ==''"> Remove </a>
                                                            <span></span>
                                                        </form>
                                                    </div>
                                                    <span>&nbsp;</span>
                                                    <div class="progress progress-striped display-none">
                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                    <div class="form-group col-md-6"  ng-class="{ 'has-error' : (AddUserForm.$submitted) && AddUserForm.FirstName.$invalid}">
                                                        <label for="FirstName" class="control-label">First Name</label>
                                                        <input class="form-control"  type="text"  maxlength="50" name="FirstName" ng-model="UserModel.FirstName" ng-class="{ 'has-submitted' : AddUserForm.$submitted}" required />
                                                        <span class="error-text-color" ng-show="AddUserForm.$submitted">
                                                                <span ng-show="AddUserForm.FirstName.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'First Name'))}}</span>
                                                         </span>
                                                    </div>

                                                    <div class="form-group col-md-6"  ng-class="{'has-error' : (AddUserForm.$submitted) && AddUserForm.LastName.$invalid}">
                                                        <label for="FirstName" class="control-label">Last Name</label>
                                                        <input class="form-control"  type="text" maxlength="50" name="LastName" ng-model="UserModel.LastName" ng-class="{ 'has-submitted' : AddUserForm.$submitted}" required />
                                                       <span class="error-text-color" ng-show="AddUserForm.$submitted">
                                                                <span ng-show="AddUserForm.LastName.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Last Name'))}}</span>
                                                         </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                    <div class="form-group col-md-6" ng-class="{ 'has-error' : (AddUserForm.$submitted) && AddUserForm.Email.$invalid}">
                                                        <label class="control-label">Email</label>
                                                        <input class="form-control" type="email" maxlength="50"   name="Email"  ng-model="UserModel.Email" pattern="<?php echo \Infrastructure\Constants::$emailRegex?>" ng-class="{ 'has-submitted' : AddUserForm.$submitted}" required />
                                                        <span class="error-text-color" ng-show="AddUserForm.$submitted">
                                                                <span ng-show="AddUserForm.Email.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Email'))}}</span>
                                                                <span ng-show="AddUserForm.Email.$error.pattern">{{ trans('messages.InvalidEmail')}}</span>
                                                         </span>
                                                    </div>

                                                    <div class="form-group col-md-6" ng-if="UserModel.UserID > 0">
                                                        <label class="control-label">Account Verified?</label><br/>
                                                        <p class="form-control-static" ng-if="UserModel.IsVerified==<?php echo Constants::$IsVerified_True?>">Yes</p>
                                                        <p class="form-control-static" ng-if="UserModel.IsVerified==<?php echo Constants::$IsVerified_False?>">No</p>
                                                    </div>

                                                    <div class="col-md-12 col-sm-12 col-xs-12 no-padding" ng-if="UserModel.UserID > 0">
                                                        <div class="form-group col-md-6 col-sm-12 col-xs-12" ng-class="{ 'has-error' : AddUserForm.Password.$invalid }">
                                                            <label class="control-label">Password</label>
                                                            <input type="password" class="form-control" ng-pattern=<?php echo \Infrastructure\Constants::$passwordRegex;?>  id="Password" name="Password"   maxlength="50" data-ng-model="UserModel.Password" ng-required/>
                                                            <span class="error-text-color" ng-show="AddUserForm.Password !=''">
                                                                <span  ng-show="AddUserForm.$dirty && AddUserForm.Password.$invalid && UserModel.Password !=''">{{ trans('messages.PasswordRegex')}}</span>
                                                            </span>
                                                        </div>

                                                        <div class="form-group col-md-6 col-sm-12 col-xs-12" ng-if="UserModel.UserID > 0" ng-class="{ 'has-error' : AddUserForm.ConfirmPassword.$error.pwmatch}">
                                                            <label class="control-label">Confirm Password</label>
                                                            <input type="password" class="form-control" id="ConfirmPassword" name="ConfirmPassword"   data-ng-model="UserModel.ConfirmPassword" maxlength="50" ng-required pw-check="Password"/>
                                                            <div class="msg-block error-text-color" ng-show="AddUserForm.$error">
                                                                <span class="msg-error" ng-show="AddUserForm.ConfirmPassword.$error.pwmatch">{{trans('messages.PasswordDoesNotMatch')}}</span>
                                                            </div>
                                                        </div>

                                                    </div>

                                                </div>
                                            </div>
                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12 hidden-sm hidden-xs">
                                                <div class="fileinput fileinput-new">
                                                    <div  class="fileinput-new thumbnail image-box">
                                                        <img class="display-none loadingImage" src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" >
                                                        <img id="actualImage" alt="" src="@{{UserModel.RealImagePath ? UserModel.RealImagePath : UserModel.NoImagePath}}">
                                                    </div>
                                                    <div>
                                                        <form></form>
                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload">
                                                            <input type="hidden" id="key" name="key" value="">
                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="UserModel.Fileuploadsettings.accesskey">
                                                            <input type="hidden" name="acl"  ng-value="UserModel.Fileuploadsettings.acl">
                                                            <input type="hidden" name="success_action_status"  ng-value="UserModel.Fileuploadsettings.success_action">
                                                            <input type="hidden" name="policy"  ng-value="UserModel.Fileuploadsettings.base64Policy">
                                                            <input type="hidden" name="signature"  ng-value="UserModel.Fileuploadsettings.signature">
                                                            <input type="hidden" name="Cache-Control" ng-value="UserModel.Fileuploadsettings.cacheControlTime">
                                                            <span  class="btn default btn-file" ><input type="file" name="file" class="file" id="file" title="Choose Image"> Choose Image</span>
                                                            <a  class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage()" ng-hide="UserModel.RealImagePath ==''"> Remove </a>
                                                            <span></span>
                                                        </form>
                                                    </div>
                                                    <span>&nbsp;</span>
                                                    <div class="progress progress-striped display-none">
                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                <div class="col-md-12"><h3 class="page-title">Site-specific Permissions</h3></div>

                                                <div class="col-md-3 col-sm-3">
                                                    <h4>{{Constants::$siteMercerVine}}</h4>
                                                    <div ng-repeat="data in RoleMVCOArray">
                                                        <label class="radio-inline padding-bottom7px">
                                                            <input  type="radio" id="mvRadio" ng-model="UserModel.MVRole" name="mv"  value="@{{data.RoleID}}" ng-disabled="UserModel.MVUserRole !=<?php echo Constants::$RoleITAdmin;?> ||  UserModel.NoAccessMV==1 "/> @{{data.Role}}
                                                        </label>
                                                    </div>
                                                    <div ng-if="UserModel.UserID>0" >
                                                        <label class="checkbox inline padding-left12px">
                                                            <input  type="checkbox" id="NoAccessMV" ng-model="UserModel.NoAccessMV" name="NoAccessMV"  ng-true-value="1" ng-false-value="0" ng-disabled="UserModel.MVUserRole !=<?php echo Constants::$RoleITAdmin;?> || UserModel.IsVerified==<?php echo Constants::$IsVerified_False?> || !UserModel.MVRole"/> Disabled
                                                        </label>
                                                    </div>
                                                </div>

                                                <div class="col-md-3 col-sm-3">
                                                    <h4>{{Constants::$siteColorado}}</h4>
                                                    <div ng-repeat="data in RoleMVCOArray">
                                                        <label class="radio-inline padding-bottom7px">
                                                            <input  type="radio" id="mvRadio" ng-model="UserModel.CORole" name="co"  value="@{{data.RoleID}}" ng-disabled="UserModel.COUserRole !=<?php echo Constants::$RoleITAdmin;?> || UserModel.NoAccessCO==1 "/> @{{data.Role}}
                                                        </label>
                                                    </div>
                                                    <div ng-if="UserModel.UserID>0" >
                                                        <label class="checkbox inline padding-left12px">
                                                            <input  type="checkbox" id="NoAccessCO" ng-model="UserModel.NoAccessCO" name="NoAccessCO" ng-true-value="1" ng-false-value="0" ng-disabled="UserModel.COUserRole !=<?php echo Constants::$RoleITAdmin;?> || UserModel.IsVerified==<?php echo Constants::$IsVerified_False?> || !UserModel.CORole"/> Disabled
                                                        </label>
                                                    </div>
                                                </div>

                                                <div class="col-md-3 col-sm-3">
                                                    <h4>{{Constants::$siteWoodBridgeWealth}}</h4>
                                                    <div ng-repeat="data in RoleRDWWArray">
                                                        <label class="radio-inline padding-bottom7px">
                                                            <input  type="radio" id="mvRadio" ng-model="UserModel.WWRole" name="ww"  value="@{{data.RoleID}}" ng-disabled="UserModel.WWUserRole !=<?php echo Constants::$RoleITAdmin;?> || UserModel.NoAccessWW==1 "/> @{{data.Role}}
                                                        </label>
                                                    </div>
                                                    <div ng-if="UserModel.UserID>0" >
                                                        <label class="checkbox inline padding-left12px">
                                                            <input  type="checkbox" id="NoAccessWW" ng-model="UserModel.NoAccessWW" name="NoAccessWW"  ng-true-value="1" ng-false-value="0" ng-disabled="UserModel.WWUserRole !=<?php echo Constants::$RoleITAdmin;?> || UserModel.IsVerified==<?php echo Constants::$IsVerified_False?> || !UserModel.WWRole"/> Disabled
                                                        </label>
                                                    </div>
                                                </div>

                                                <div class="col-md-3 col-sm-3">
                                                    <h4>{{Constants::$siteRiverDaleFunding}}</h4>
                                                    <div ng-repeat="data in RoleRDWWArray">
                                                        <label class="radio-inline padding-bottom7px">
                                                            <input  type="radio" id="mvRadio" ng-model="UserModel.RDRole" name="rd"  value="@{{data.RoleID}}" ng-disabled="UserModel.RDUserRole !=<?php echo Constants::$RoleITAdmin;?> || UserModel.NoAccessRD==1"/> @{{data.Role}}
                                                        </label>
                                                    </div>
                                                    <div ng-if="UserModel.UserID>0" >
                                                        <label class="checkbox inline padding-left12px">
                                                            <input  type="checkbox" id="NoAccessRD" ng-model="UserModel.NoAccessRD" name="NoAccessRD"  ng-true-value="1" ng-false-value="0" ng-disabled="UserModel.RDUserRole !=<?php echo Constants::$RoleITAdmin;?> || UserModel.IsVerified==<?php echo Constants::$IsVerified_False?> || !UserModel.RDRole"/> Disabled
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="clearboth"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 no-padding">
                            <input id="btn-submit" name="submit" type="submit" value="Save" class="btn blue save-button" data-ng-click="Save()" ng-disabled="DisableButtons">
                            <button type="button" id="cancel" class="btn default" data-ng-click="Cancel(data)" ng-disabled="DisableButtons">Cancel</button>
                        </div>
                        </div>
                    
                </div>
            </div>
        </div>
        </form>
    </main>
@stop

@section('script')
    {{ $minify::javascript(array('/assets/js/viewjs/user/adduser.js',
                            '/assets/js/library/jquery.fileupload/jquery.ui.widget.js',
                            '/assets/js/library/jquery.fileupload/jquery.fileupload.js',
                            '/assets/js/library/binaryajax.js',
                            '/assets/js/library/exif.js',
                            '/assets/js/library/bootstrap-fileinput.js',
                            '/assets/js/sitejs/canvasResize.js'))->withFullUrl()}}
    <script>
        window.ImageFileAllowedMessage ="{{ trans('messages.ImageFileAllowedMessage')}}";
        window.ConfirmUploadMessage ="{{ trans('messages.ConfirmUploadMessage')}}";
        var roleNoAccess="<?php echo Constants::$RoleNoAccess;?>";
        window.selectRole="{{ trans('messages.SelectRole')}}";
        window.DefaultUploadPhotoHeight='<?php echo Constants::$DefaultUploadProfileHeight;?>';
        window.DefaultUploadPhotoWidth='<?php echo Constants::$DefaultUploadProfileWidth?>';
        window.NoImagePath = '<?php echo asset('/assets/images/no-user.png') ?>';
    </script>
@stop
