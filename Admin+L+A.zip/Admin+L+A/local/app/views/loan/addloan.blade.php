<?php
$minify = new \CeesVanEgmond\Minify\Facades\Minify;
use \Infrastructure\Constants;
?>
@extends('layouts.sitemaster')
@section('Title')
    <?php if ($LoanModel->LoanID > 0) {
        print 'Edit Loan Closed';
    } else {
        print 'Add Loan Closed';
    } ?>
@stop
@section('css')
    <link href="<?php echo asset('/assets/css/dropzone/dropzone.css');?>" defer rel="stylesheet" type='text/css'>
@stop
@section('content')
    <main id="main" role="main" data-ng-controller="LoanController">

        <form name="LoanForm" id="LoanForm" role="form" novalidate ng-submit="checkSave(LoanForm)" >
            <?php echo Form::hidden('LoanModel', htmlspecialchars(json_encode($LoanModel), ENT_QUOTES, 'UTF-8'), $attributes = array('id' => 'LoanModel')); ?>
            <!-- BEGIN CONTENT BODY -->
            <div class="page-content">
                <!-- BEGIN PAGE HEADER-->
                <!-- BEGIN PAGE BAR -->
                <div class="page-bar">
                    <ul class="page-breadcrumb">
                        <li>
                            <a href="<?php echo URL::to('/dashboard/' . $encryptedSiteID) ?>">Home</a>
                            <i class="fa fa-circle"></i>
                        </li>
                        <li>
                            <a href="<?php echo URL::to('/loans/' . $encryptedSiteID) ?>">Loans</a>
                            <i class="fa fa-circle"></i>
                        </li>
                        <li>
                        <span><?php if ($LoanModel->LoanID > 0) {
                                print 'Edit Loan Closed';
                            } else {
                                print 'Add Loan Closed';
                            } ?></span>
                        </li>
                    </ul>

                    <div class="page-toolbar">
                        <div class="btn-group pull-right" ng-cloak>
                            
                            <input id="submit" name="submit" type="submit" value="Save" class="btn blue save-button btn-submit btn-sm" id="btn-submit" data-ng-click="SaveLoan()" ng-disabled="!UploadComplete || (responseCounter != requestCounter) || DisableButtons">
                            <input id="delete" name="delete" type="button" value="Delete" class="btn btn-danger btn-submit  btn-sm btn-outline" data-ng-click="DeleteLoan()" ng-show="LoanModel.LoanID > 0 && LoanModel.LoggedInUserRoleID== <?php echo Constants::$RoleITAdmin;?>" ng-disabled="requestCounter != responseCounter || !UploadComplete">
                        </div>
                    </div>
                </div>
                <h3 class="page-title">
                    <?php if ($LoanModel->LoanID > 0) {
                        print 'Edit Loan Closed';
                    } else {
                        print 'Add Loan Closed';
                    } ?></h3>
                <div class="portlet-body">
                    <!-- END PAGE BAR -->
                    <!-- END PAGE HEADER-->
                    <!-- BEGIN Form Design-->
                    <div class="row">
                        <div class="col-md-12 ">

                            <div class="form-body" ng-cloak>

                                <div class="col-md-12 no-padding">
                                    <div class="tab-content">

                                        <div class="tab-pane active" id="tab_1_1">
                                            <div class="portlet box blue-hoki" ng-cloakcloak>
                                                <div class="portlet-title" collapse>
                                                    <div class="caption">
                                                        <i class=""></i>Details</div>
                                                    <div class="tools">
                                                        <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                                    </div>
                                                </div>
                                                <div class="portlet-body">
                                                    <div class="row">
                                                        <div class="col-md-12 no-padding">
                                                            <div class="form-body" >
                                                                <div class="col-md-12 no-padding">

                                                                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 no-padding">
                                                                        <div class="col-md-6 col-lg-6 col-xs-12 no-padding">
                                                                            <div class="form-group col-md-12" ng-class="{ 'has-error' : (LoanForm.$submitted) && LoanForm.Title.$invalid}">
                                                                                <label for="Title" class="control-label">Title</label>
                                                                                <input class="form-control" type="text" name="Title" maxlength="100"
                                                                                       data-ng-class="{'has-submitted' : LoanForm.$submitted }" data-ng-model="LoanModel.Title" required/>
                                                                                <span class="error-text-color" ng-show="LoanForm.$submitted">
                                                                                            <span ng-show="LoanForm.Title.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Title'))}}</span>
                                                                                </span>
                                                                            </div>
                                                                            <div class="clearboth"></div>
                                                                            <div class="form-group col-md-12" ng-class="{ 'has-error' : (LoanForm.$submitted) && LoanForm.LoanAmount.$invalid}">
                                                                                <label for="LoanAmount" class="control-label">Loan Amount</label>
                                                                                <input class="form-control" type="text" name="LoanAmount"
                                                                                       data-ng-class="{'has-submitted' : LoanForm.$submitted }" data-ng-model="LoanModel.LoanAmount" intype="positiveNumeric" ng-pattern="<?php echo \Infrastructure\Constants::$PropertyPriceRegex; ?>" required/>
                                                                                <span class="error-text-color" ng-show="LoanForm.$submitted">
                                                                                            <span ng-show="LoanForm.LoanAmount.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Loan Amount'))}}</span>
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-6 col-lg-6 col-xs-12">
                                                                            <label for="Purpose" class="control-label">Purpose</label>
                                                                            <textarea class="form-control" name="Purpose" data-ng-model="LoanModel.Purpose" rows="4" cols="100"></textarea>
                                                                        </div>
                                                                        <div class="col-md-12 col-lg-12 col-xs-12 no-padding">
                                                                            <div class="form-group col-md-6">
                                                                                <label for="PropertyType" class="control-label">Property Type</label>
                                                                                <input class="form-control" type="text" name="PropertyType" data-ng-model="LoanModel.PropertyType" />
                                                                            </div>
                                                                            <div class="form-group col-md-6">
                                                                                <label for="DateFunded" class="control-label">Date Funded</label>
                                                                                <div class="input-group date col-md-6">
                                                                                    <input class="form-control" type="text" name="DateFunded" datepicker  id="PostDate"
                                                                                            data-ng-model="LoanModel.DateFunded" />
                                                                                    <span class="input-group-addon" id="PostDateIcon">
                                                                                        <span class="glyphicon glyphicon-calendar"></span>
                                                                                    </span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="clearboth"></div>
                                            <div class="portlet box blue-hoki" ng-cloak>
                                                <div class="portlet-title" collapse>
                                                    <div class="caption">
                                                        <i class=""></i>IMAGES</div>
                                                    <div class="tools">
                                                        <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                                    </div>
                                                </div>

                                                <div class="portlet-body">
                                                    <div class="row">
                                                        <div class="col-md-12 no-padding">
                                                            <div class="form-body" >
                                                                <div class="col-md-12 no-padding">
                                                                    <div class="form-group col-md-12 dropZoneOuter drop-property">
                                                                        <form></form>
                                                                        <!-- For File Upload Start -->
                                                                        <div class="form-group col-md-12 dropZoneOuter no-padding">
                                                                            <form></form>
                                                                            <form action="" class="dropzone" drop-zone="" id="file-dropzone"
                                                                                  on-file="OnFileAdded"
                                                                                  ng-aws-settings-model="LoanModel.FileUploadSettings"
                                                                                  success-callback="PushFilesToUploadArray"
                                                                                  remove-file="RemoveFile"
                                                                                  upload-file="LoanModel.UploadFilesArray"
                                                                                  ext-type="LoanModel.ImageExtensionType"
                                                                                  max-files="LoanModel.maxFiles"
                                                                                  request-counter="LoanModel.requestCounter"
                                                                                  response-counter="LoanModel.responseCounter"
                                                                                  enabled-button="LoanModel.EnableSubmitButton"
                                                                                  upload-complete="UploadComplete"
                                                                                  uploaded-file="LoanModel.UploadedFileArray"
                                                                                  file-size-exceeds="{{ trans('messages.LoanNoMoreImages')}}"
                                                                                  invalid-file-format="{{trans('messages.InvalidImageTypeFormat')}}"
                                                                                  radio-select-value="LoanModel.IsDefaultImage"
                                                                                  on-file-load="OnDefaultFileLoad"
                                                                                  allow-order="LoanModel.IsAllowStoreOrder"
                                                                                  file-name="LoanModel.ImagesNameModel">

                                                                                <div class="dz-preview dz-file-preview margin-10p"
                                                                                     id="template">
                                                                                    <div class="dz-details">
                                                                                        <div class="dz-filename"><span data-dz-name></span>
                                                                                        </div>
                                                                                        <div class="dz-size" data-dz-size></div>
                                                                                        <div><span class="dz-remove"></span></div>
                                                                                        <img data-dz-thumbnail/>
                                                                                    </div>
                                                                                    <br/>
                                                                                    <div class="progress progress-striped active"
                                                                                         id="totalprogressbar" role="progressbar"
                                                                                         aria-valuemin='0' aria-valuemax='100'
                                                                                         aria-valuenow='0'>
                                                                                        <div class="progress-bar progress-bar-success bar width-none"
                                                                                             data-dz-uploadprogress></div>
                                                                                    </div>
                                                                                    <div class="dz-success-mark"><span>✔</span></div>
                                                                                    <div class="dz-error-mark"><span>✘</span></div>
                                                                                    <div class="file-error-message"><strong
                                                                                                class="error text-danger"
                                                                                                data-dz-errormessage></strong></div>
                                                                                    <button data-dz-remove
                                                                                            class="btn btn-danger delete cancel btn-xs margin-left12pr">
                                                                                        <i class="glyphicon glyphicon-trash padding-top-bottom"></i>
                                                                                        <span>Delete &nbsp;</span></button>
                                                                                    <div class="margin-top4p">

                                                                                        <label class="radio-inline">
                                                                                            <input type="radio" name="IsDefaultImage"
                                                                                                   class="IsDefaultImage"
                                                                                                   data-ng-model="LoanModel.IsDefaultImage"
                                                                                                   ng-bind="LoanModel.IsDefaultImage"
                                                                                                   value=""> Is Default
                                                                                        </label>
                                                                                    </div>
                                                                                </div>
                                                                            </form>
                                                                        </div>
                                                                        <!-- For File Upload End -->
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 no-padding">
                                                <input id="submit" name="submit" type="submit" value="Save" class="btn blue save-button btn-submit" id="btn-submit" data-ng-click="SaveLoan()"
                                                       ng-disabled="!UploadComplete || (responseCounter != requestCounter) || DisableButtons">
                                                <button type="button" id="cancel" class="btn default" ng-disabled="!UploadComplete || (responseCounter != requestCounter) || DisableButtons"
                                                        data-ng-click="Cancel()">Cancel</button>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <!-- END DASHBOARD STATS 1-->
                </div>
            </div>
            <!-- END CONTENT BODY -->
        </form>
    </main>
@stop
@section('script')

    {{$minify::javascript(array('/assets/js/viewjs/loan/addloan.js'))->withFullUrl()}}
    <script src="{{asset('/assets/js/sitejs/dropzone.js')}}" defer></script>
    <script src="{{asset('/assets/js/ckeditor/ckeditor.js')}}" defer></script>

    {{ $minify::javascript(array('/assets/js/sitejs/jquery-ui-1.9.2.custom.min.js',
                                '/assets/js/library/jquery.fileupload/jquery.ui.widget.js',
                                   '/assets/js/sitejs/jquery.ui.touch-punch.min.js'))->withFullUrl()}}
    <script type="text/javascript">
        window.NoImagePath = '<?php echo asset('/assets/images/Samplephoto.png') ?>';
        window.LoanImage = "{{ trans('messages.LoanImage')}}";
        window.DefaultLoanImage = "{{ trans('messages.DefaultLoanImage')}}";
        $( "#PostDateIcon" ).click(function() {
            $( "#PostDate" ).focus();
        });
    </script>
@stop