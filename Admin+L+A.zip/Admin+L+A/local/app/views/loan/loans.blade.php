<?php
use Infrastructure\Constants;
use Infrastructure\Common;
use BaseController as BA;
$minify = new \CeesVanEgmond\Minify\Facades\Minify;
?>
@extends('layouts.sitemaster')
@section('Title','Loans')
@stop
@section('css')

@stop
@section('content')
<?php echo Form::hidden('LoanModel', json_encode($LoanModel), $attributes = array('id' => 'LoanModel')); ?>
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content" data-ng-controller = "LoanListController">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo URL::to('/dashboard/'.$encryptedSiteID) ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Loans Closed</span>
                </li>
            </ul>
            <div class="page-toolbar">
                <div class="btn-group pull-right">
                    <a href="<?php echo URL::to('/addloan/'.$encryptedSiteID); ?>" class="btn btn-primary btn-sm btn-outline"> Add Loan Closed</a>
                </div>
            </div>
        </div>
        <h3 class="page-title">Loans Closed</h3>
        <div class="row">
            <div class="col-md-12">
                <div data-ng-if="LoanListArray.length > 0" class="table-scrollable sortable" ng-cloak>
                    <div>
                    <table class="table table-striped table-bordered table-hover" sortable-list="LoanListArray" sortable-callback="updateSortOrder">
                        <thead class="site-footer">
                        <tr role="row">
                            <th data-ng-if="LoanListArray.length > 1"><span class="anchor_color vertical-align"></span></th>
                            <th class="vertical-align"><span class="anchor_color">Image</span></th>
                            <th class="vertical-align"><span class="anchor_color">Title</span></th>
                            <th class="vertical-align"><span class="anchor_color">Property type</span></th>
                            <th class="vertical-align"><span class="anchor_color">Loan Amount</span></th>
                            <th class="vertical-align"><span class="anchor_color">Date Funded</span></th>
                            <th class="vertical-align">Action</th>
                        </tr>
                        </thead>
                        <tbody class="drag-loan-list">
                        <tr ng-repeat="item in LoanListArray" class="sortable-row" role="row">
                            <td class="sortable-handle vertical-align" data-ng-if="LoanListArray.length > 1">
                                <span class="draggable-icon-arrow">
                                    <i class="fa fa-bars draggable-icon"></i>
                                    <i class="fa fa-arrows-alt draggable-icon"></i>
                                </span>
                            </td>
                            <td class="vertical-align"><img src="@{{item.FilePath ? item.FilePath : ListModel.NoImagePath}}" class="dev-thumb-img"></td>
                            <!-- <td class="vertical-align">@{{item.Title}}</td> -->


                            <td class="vertical-align"><a ng-click="EditLoan(item)" title="Edit Loan Closed" >@{{item.Title}}</a></td>


                            <td class="vertical-align">@{{item.PropertyType}}</td>
                            <td class="vertical-align text-right ">@{{item.LoanAmount | currency}}</td>
                            <td class="vertical-align">@{{item.DateFunded}}</td>
                            <td class="loan-action-part vertical-align">
                                <div>
                                    <a href="<?php echo URL::to('/')."/addloan/"?>@{{item.combineLoanSiteid}}" title="Edit Loan" ng-model="EditLoan"><i class="fa fa-pencil text-default" ></i></a>
                                    &nbsp;
                                    <?php if(BA::CheckRoleSitePermission(Common::getRoleITAdminProcesing(),Common::getSiteRiverdale())) {?>
                                    <a ng-model="deleteLoan" ng-click="deleteLoan(item)" title="Delete Loan" ng-model="DeleteLoan"><i class="fa fa-trash-o text-danger"></i></a>
                                    <?php } ?>
                                </div>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                    </div>
                </div>
                <div class="form-group col-md-12 display-none" align="center" id="nodata">
                    <b>Sorry, no Loans found</b>
                </div>
            </div>
        </div>
    </div>
@stop
@section('script')
       {{ $minify::javascript(array('/assets/js/sitejs/jquery-ui-1.9.2.custom.min.js', '/assets/js/viewjs/loan/loans.js', '/assets/js/sitejs/jquery.ui.touch-punch.min.js'))->withFullUrl()}}
@stop
