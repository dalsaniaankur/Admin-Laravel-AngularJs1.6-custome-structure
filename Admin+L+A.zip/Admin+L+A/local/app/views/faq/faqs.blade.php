<?php
use Infrastructure\Constants;
use Infrastructure\Common;
use BaseController as BA;
$minify = new \CeesVanEgmond\Minify\Facades\Minify;
$siteID = \ViewModels\SessionHelper::getSelectedSiteID();
?>
@extends('layouts.sitemaster')
@section('Title','FAQs')
@stop
@section('css')

@stop
@section('content')
<?php echo Form::hidden('FaqModel', json_encode($FaqModel), $attributes = array('id' => 'FaqModel')); ?>
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content" data-ng-controller = "FaqListController">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo URL::to('/dashboard/'.$encryptedSiteID) ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>FAQs</span>
                </li>
            </ul>
            <div class="page-toolbar">
                <div class="btn-group pull-right">
                    <a href="<?php echo URL::to('/addfaq/'.$encryptedSiteID); ?>" class="btn btn-primary btn-sm btn-outline"> Add A Question </a>
                </div>
            </div>
        </div>
        <h3 class="page-title">FAQs</h3>
        <div class="row">
            <div class="col-md-12">
                <div data-ng-if="FaqListArray.length > 0" class="table-scrollable sortable" ng-cloak>
                    <div>
                    <table class="table table-striped table-bordered table-hover" sortable-list="FaqListArray" sortable-callback="updateSortOrder">
                        <thead class="site-footer">
                        <tr role="row">
                            <th data-ng-if="FaqListArray.length > 1"><span class="anchor_color vertical-align"></span></th>
                            <th class="vertical-align"><span class="anchor_color">Questions</span></th>
                            <?php if($siteID==Constants::$WoodBridgeWealthSiteID){?>
                            <th class="vertical-align"><span class="anchor_color">Type</span></th>
                            <?php }?>
                            <th class="vertical-align"><span class="anchor_color">Last Updated</span></th>
                            <th class="vertical-align"><span class="anchor_color">Last Updated By</span></th>
                            <th class="vertical-align">Action</th>
                        </tr>
                        </thead>
                        <tbody class="drag-faq-list">
                        <tr ng-repeat="item in FaqListArray" class="sortable-row" role="row">
                            <td class="sortable-handle vertical-align" data-ng-if="FaqListArray.length > 1">
                                <span class="draggable-icon-arrow">
                                    <i class="fa fa-bars draggable-icon"></i>
                                    <i class="fa fa-arrows-alt draggable-icon"></i>
                                </span>
                            </td>
                            <td class="vertical-align"><div class="faq-ellipsis"><a href="<?php echo URL::to('/')."/addfaq/"?>@{{item.combineFaqSiteid}}" title="Edit FAQ" ng-model="EditFaq">@{{item.Question}}</a></div></td>
                            <?php if($siteID==Constants::$WoodBridgeWealthSiteID){?>
                            <td class="vertical-align">@{{item.Type}}</td>
                            <?php }?>
                            <td class="vertical-align">@{{item.ModifiedDate}}</td>
                            <td class="vertical-align">@{{item.LastUpdatedBy}}</td>
                            <td class="faq-action-part vertical-align">
                                <div>
                                    <a href="<?php echo URL::to('/')."/addfaq/"?>@{{item.combineFaqSiteid}}" title="Edit FAQ" ng-model="EditFaq"><i class="fa fa-pencil text-default" ></i></a>
                                    &nbsp;
                                    <?php if(BA::CheckRoleSitePermission(Constants::$RoleITAdmin,Common::getAllSiteArray())) {?>
                                    <a ng-model="deleteFaq" ng-click="deleteFaq(item)" title="Delete FAQ" ng-model="DeleteFaq"><i class="fa fa-trash-o text-danger"></i></a>
                                    <?php } ?>
                                </div>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                    </div>
                </div>
                <div class="form-group col-md-12 display-none" align="center" id="nodata">
                    <b>Sorry, no FAQs found</b>
                </div>
            </div>
        </div>
    </div>
@stop
@section('script')
       {{ $minify::javascript(array('/assets/js/sitejs/jquery-ui-1.9.2.custom.min.js', '/assets/js/viewjs/faq/faqs.js', '/assets/js/sitejs/jquery.ui.touch-punch.min.js'))->withFullUrl()}}
@stop
