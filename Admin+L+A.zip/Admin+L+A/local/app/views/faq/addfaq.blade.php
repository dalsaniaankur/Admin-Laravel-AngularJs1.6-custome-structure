<?php
    use Infrastructure\Constants;
    use Infrastructure\Common;
    use BaseController as BA;
    use ViewModels\SessionHelper;
    $minify = new \CeesVanEgmond\Minify\Facades\Minify;
?>
@extends('layouts.sitemaster')
@section('Title')
    <?php isset($FaqModel->FAQDetails->FAQID) ? print 'Edit FAQ' : print 'Add FAQ';?>
@stop
@section('css')

@stop
@section('content')
<main id="main" role="main" ng-controller = "FaqController">
    <form name="FaqForm" id="FaqForm" role="form" novalidate ng-submit="checkSave(FaqForm)">
<?php echo Form::hidden('FaqModel', json_encode($FaqModel),$attributes = array('id'=>'FaqModel')); ?>
    <input type="hidden" ng-model="FaqModel.SiteID">
    <div class="page-content" >
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo URL::to('/dashboard/'.$encryptedSiteID) ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <a href="<?php echo URL::to('/faqlist/'.$encryptedSiteID) ?>">FAQs</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span><?php isset($FaqModel->FAQDetails->FAQID) ? print 'Edit FAQ' : print 'Add FAQ';?></span>
                </li>
            </ul>
            
            <div class="page-toolbar">
                <div class="btn-group pull-right">
                    <input id="submit" name="submit" type="submit" value="Save" class="btn blue save-button btn-sm" data-ng-click="AddFaq()" ng-disabled="DisableButtons">
                    <?php if((isset($FaqModel->FAQDetails->FAQID)) AND ((BA::CheckRoleSitePermission(Constants::$RoleITAdmin,Common::getAllSiteArray())))){ ?>
                    <input id="delete" name="delete" type="button" value="Delete" class="btn btn-danger btn-sm btn-outline" data-ng-click="deleteFaq(FaqModel)">
                    <?php  } ?>
                </div>
            </div>
            
        </div>
        <h3 class="page-title"> <?php isset($FaqModel->FAQDetails->FAQID) ? print 'Edit FAQ' : print 'Add FAQ';?></h3>
        
            <div class="col-md-12 no-padding">
                    <div class="portlet box blue-hoki" ng-cloak>
                        <div class="portlet-title" collapse>
                            <div class="caption">
                                <i class=""></i>Details</div>
                            <div class="tools">
                                <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                            </div>
                        </div>
                        <div class="portlet-body">
                            <div class="row">
                                <div class="col-md-12">
                                        <div class="form-body" ng-cloak>

                                            <div class="form-group col-md-9 no-padding" ng-class="{ 'has-error' : (FaqForm.$submitted) && FaqForm.Question.$invalid}">
                                                <label for="Question" class="control-label">Question</label>
                                                <input class="form-control"  type="text" name="Question" ng-model="FaqModel.Question" ng-class="{ 'has-submitted' : FaqForm.$submitted }" required />
                                                <div  class="help-block" ng-messages="FaqForm.Question.$error" ng-if="FaqForm.$submitted">
                                                    <div  ng-show="FaqForm.Question.$error.required  && FaqForm.Question.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Question'))}}</div>
                                                </div>
                                            </div>

                                            <div class="form-group col-md-9 no-padding" ng-class="{ 'has-error' : (FaqForm.$submitted) && FaqForm.Answer.$invalid}">
                                                <label for="Answer" class="control-label">Answer</label>
                                                <textarea class="form-control" rows="10" name="Answer" ck-editor ng-model="FaqModel.Answer" ng-class="{ 'has-submitted' : FaqForm.$submitted }" required ></textarea>
                                                <div  class="help-block" ng-messages="FaqForm.Answer.$error" ng-if="FaqForm.$submitted">
                                                    <div  ng-show="FaqForm.Answer.$error.required && FaqForm.Answer.$invalid">{{ trans('messages.PropertyRequired',array('attribute'=>'Answer'))}}</div>
                                                </div>
                                            </div>

                                            <?php if($FaqModel->IsFAQTypeEnabled){ ?>
                                            <div class="form-group col-md-9 no-padding" ng-class="{ 'has-error' : (FaqForm.$submitted) && FaqForm.Type.$invalid}">
                                                <label for="TypeID" class="control-label">Select Type</label>
                                                <select class="form-control" id="TypeID" name="Type" ng-model="FaqModel.TypeID" ng-options="Types.TypeID as Types.Type for Types in TypeArray" ng-class="{ 'has-submitted' : FaqForm.$submitted }" required>
                                                    <option value="">Please Select option</option>
                                                </select>
                                                <div class="help-block" ng-messages="FaqForm.TypeID.$error" ng-if="FaqForm.$submitted">
                                                    <div  ng-show="FaqForm.Type.$error.required && FaqForm.Type.$invalid">{{ trans('messages.PropertyRequired',array('attribute'=>'Type'))}}</div>
                                                </div>
                                            </div>
                                            <?php } ?>

                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
            <div class="clearboth"></div>
            <div class="col-md-12 no-padding">
                    <div class="form-actions  col-md-12 col-sm-12 col-xs-12 no-padding">
                        <input id="submit" name="submit" type="submit" value="Save" class="btn blue save-button" data-ng-click="AddFaq()" ng-disabled="DisableButtons">
                        <button type="button" id="cancel" class="btn default" data-ng-click="Cancel()" ng-disabled="DisableButtons">Cancel</button>
                    </div>
            </div>
            <div class="clearboth"></div>
        
    </div>
    </form>
</main>
@stop

@section('script')
    {{ $minify::javascript(array('/assets/js/viewjs/faq/addfaq.js',/*'/assets/js/ckeditor/ckeditor.js'*/))->withFullUrl()}}
    <script src="{{asset('/assets/js/ckeditor/ckeditor.js')}}" defer></script>
@stop