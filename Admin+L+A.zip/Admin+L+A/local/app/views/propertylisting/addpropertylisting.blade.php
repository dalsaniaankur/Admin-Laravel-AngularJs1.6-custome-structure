<?php $minify = new \CeesVanEgmond\Minify\Facades\Minify;
use Infrastructure\Constants;
use Infrastructure\Common;
use ViewModels\SessionHelper;
$siteID = SessionHelper::getSelectedSiteID();
?>
@extends('layouts.sitemaster')
@section('Title')
    <?php print  ($PropertyModel->ListingModel->ListingID > 0) ? 'Edit Listing' :  'Add Listing';?>
@stop
@section('css')
    {{ $minify::stylesheet(array('/assets/css/tagsinput/ng-tags-input.min.css'))->withFullUrl()}}
    <link href="<?php echo asset('/assets/css/dropzone/dropzone.css');?>" defer rel="stylesheet" type='text/css'>
@stop
@section('content')
    <main id="main" role="main" xmlns="http://www.w3.org/1999/html" ng-controller = "PropertyController">
        <form name="PropertyForm" id="PropertyForm" role="form" novalidate ng-submit="checkSave(PropertyForm)">
        <?php echo Form::hidden('PropertyModel', json_encode($PropertyModel),$attributes = array('id'=>'PropertyModel')); ?>
        <div class="page-content"    ng-cloak>
            <div class="page-bar">
                <ul class="page-breadcrumb">
                    <li>
                        <a href="<?php echo URL::to('/dashboard/'.$encryptedSiteID) ?>">Home</a>
                        <i class="fa fa-circle"></i>
                    </li>
                    <li>
                        <a href="<?php echo URL::to('/listing/'.$encryptedSiteID) ?>">Listings</a>
                        <i class="fa fa-circle"></i>
                    </li>
                    <li>
                        <span><?php print ($PropertyModel->ListingModel->ListingID > 0) ?  'Edit Listing' :  'Add Listing';?></span>
                    </li>
                </ul>
                <div class="page-toolbar">
                    <div class="btn-group pull-right">
                        <input id="submit" name="submit" type="submit" value="Save" class="btn blue save-button btn-sm" data-ng-click="AddListing()" ng-disabled="!UploadComplete || !UploadCompleteOFPF">
                        <input id="delete" name="delete" type="button" value="Delete" class="btn btn-danger btn-sm btn-outline" data-ng-click="DeleteProperty()" ng-show="PropertyModel.ListingModel.ListingID > 0 && (PropertyModel.ListingModel.MLSNo=='' || PropertyModel.ListingModel.MLSNo==null)">
                    </div>
                </div>
            </div>
            <h3 class="page-title"> <?php print ($PropertyModel->ListingModel->ListingID > 0) ?  'Edit Listing' :  'Add Listing';?></h3>
                <div class="row">
                        <div class="col-md-12 ">
                            
                                <div class="form-body">
                                    <div class="clearboth"></div>
                                    <div class="portlet box blue-hoki" ng-cloak>
                                        <div class="portlet-title" collapse>
                                            <div class="caption">
                                                <i class=""></i>PROPERTY DETAILS<?php print ($PropertyModel->ListingModel->ListingID > 0) ?  ': '.$PropertyModel->ListingModel->Street : '' ;?></div>
                                            <div class="tools">
                                                <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                            </div>
                                        </div>
                                        <div class="portlet-body">
                                            <div class="row">
                                                <div class="col-md-12 no-padding">
                                                    <div class="form-body" >
                                                        <div class="col-md-12 no-padding">
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <div class="form-group col-md-7 no-padding col-sm-6 col-xs-12">
                                                                        <div class="col-lg-6 col-md-5 col-sm-12 col-xs-12"  ng-class="{ 'has-error' : ( ((retsFlag == true || PropertyForm.$submitted) && (PropertyForm.MLSNo.$error.minlength)) || ((retsFlag == true && (PropertyModel.ListingModel.MLSNo =='' || PropertyModel.ListingModel.MLSNo == null) )) )}">
                                                                            <label for="MLSNo" class="control-label">MLS#</label>
                                                                            <input class="form-control" ng-model="PropertyModel.ListingModel.MLSNo" ng-disabled="PropertyModel.ListingModel.ListingID > 0"  type="text" name="MLSNo"  maxlength="20" intype="alphaNumeric" ng-minlength="8"/>
                                                                            <span class="error-text-color" ng-show="((retsFlag == true || PropertyForm.$submitted) && (PropertyForm.MLSNo.$error.minlength))">
                                                                                <span ng-show="PropertyForm.MLSNo.$error.minlength"><?php echo trans('messages.PropertyMinValue'); ?></span>
                                                                            </span>
                                                                            <span class="error-text-color" ng-show="( retsFlag == true && (!PropertyForm.MLSNo.$error.minlength) )">
                                                                                <span ng-show="( retsFlag == true && (PropertyModel.ListingModel.MLSNo =='' || PropertyModel.ListingModel.MLSNo == null) )">{{ trans('messages.PropertyRequired',array('attribute'=>'MLS#'))}}</span>
                                                                            </span>
                                                                        </div>
                                                                        <div class="col-lg-4 col-md-5 col-sm-9 col-xs-9 margin-top-25 no-padding-desktop"  ng-hide="PropertyModel.ListingModel.ListingID > 0">
                                                                            <input type="checkbox" name="fetchImage" class="ng-pristine ng-untouched ng-valid margin-right-5" id="fetchImage" ng-false-value="0" ng-true-value="1" ng-model="PropertyModel.ListingModel.fetchImage" ng-init="PropertyModel.ListingModel.fetchImage=1">
                                                                            <label for="fetchImage">Fetch Images from MLS?</label>
                                                                        </div>
                                                                        <div class="col-md-1 col-sm-3 col-xs-3 margin-top-25 text-right" ng-hide="PropertyModel.ListingModel.ListingID > 0">
                                                                            <button type="button" name="search" class="btn green" data-ng-click="SearchMls(false)"> Go </button>
                                                                        </div>

                                                                    </div>
                                                                    <div class="form-group col-md-5 col-sm-6  col-xs-12">
                                                                        <label for="Agent Name" class="control-label">Agent Name</label>
                                                                        <span ng-if="PropertyModel.ListingModel.AgentID!==null && PropertyModel.ListingModel.AgentID!=='0'">
                                                                            <span ng-if="PropertyModel.ListingModel.IsDisabledUser==1">
                                                                                <span tooltip data-toggle="tooltip" data-placement="bottom" title="Disabled Agent">
                                                                                        <i class="fa fa-info-circle font-size-18px margin-top-10"></i>
                                                                                </span>
                                                                            </span>
                                                                        </span>
                                                                        <select class="form-control" ng-model="PropertyModel.ListingModel.AgentID"
                                                                                ng-options="agent.UserID as agent.AgentName for agent in PropertyModel.Agents"
                                                                                id="Agent_Name" name="Agent Name" ><option value="">-- select --</option></select>
                                                                        <span>@{{$scope.PropertyModel.Agents.length}}</span>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12 no-padding">
                                                                <div class="form-group col-md-2" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.Price.$invalid}">
                                                                    <label for="Price" class="control-label">Price</label>
                                                                    <div class="input-group">
                                                                        <span class="input-group-addon">$</span>
                                                                        <input class="form-control" ng-model="PropertyModel.ListingModel.Price" type="text" name="Price" ng-class="{ 'has-submitted' : PropertyForm.$submitted }" intype="positiveNumeric" ng-pattern="<?php echo \Infrastructure\Constants::$PropertyPriceRegex; ?>" required/>
                                                                    </div>
                                <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                    <span ng-show="PropertyForm.Price.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Price'))}}</span>
                                    <span ng-show="PropertyForm.Price.$error.pattern">{{ trans('messages.InvalidPrice')}}</span>
                                </span>
                                                                </div>
                                                                <div class="form-group col-md-2" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.Lot_Size.$invalid}">
                                                                    <label for="Lot Size" class="control-label">Lot Size (In Acre)</label>
                                                                    <input class="form-control" ng-model="PropertyModel.ListingModel.LotSize" type="text" name="Lot_Size" ng-class="{ 'has-submitted' : PropertyForm.$submitted }" required  intype="positiveNumeric" ng-pattern="<?php echo \Infrastructure\Constants::$lotSizeRegex; ?>"/>
                                <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                    <span ng-show="PropertyForm.Lot_Size.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Lot Size'))}}</span>
                                    <span ng-show="PropertyForm.Lot_Size.$error.pattern">{{ trans('messages.InvalidLotSize')}}</span>
                                </span>
                                                                </div>
                                                                <div class="form-group col-md-2" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.Sq_Ft.$invalid}">
                                                                    <label for="Sq Ft" class="control-label">Square Feet</label>
                                                                    <input class="form-control" ng-model="PropertyModel.ListingModel.SquareFeet" type="text" name="Sq_Ft" ng-class="{ 'has-submitted' : PropertyForm.$submitted }" required  intype="positiveNumeric" ng-pattern="<?php echo \Infrastructure\Constants::$squareFeetRegex; ?>"/>
                                <span  class="error-text-color"  ng-show="PropertyForm.$submitted">
                                    <span  ng-show="PropertyForm.Sq_Ft.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Square Feet'))}}</span>
                                    <span ng-show="PropertyForm.Sq_Ft.$error.pattern">{{ trans('messages.InvalidFeetSquare')}}</span>
                                </span>
                                                                </div>

                                                                <div class="form-group col-md-2" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.Beds.$invalid}">
                                                                    <label for="Beds" class="control-label">Beds</label>
                                                                    <input class="form-control" ng-model="PropertyModel.ListingModel.NoOfBeds" type="text" name="Beds" ng-class="{ 'has-submitted' : PropertyForm.$submitted }" required  maxlength="3" intype="digit"/>
                                <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                    <span  ng-show="PropertyForm.Beds.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Beds'))}}</span>
                                </span>
                                                                </div>
                                                                <div class="form-group col-md-2" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.Full_Baths.$invalid}">
                                                                    <label for="Full Baths" class="control-label">Full Baths</label>
                                                                    <input class="form-control" ng-model="PropertyModel.ListingModel.NoOfFullBaths" type="text" name="Full_Baths" ng-class="{ 'has-submitted' : PropertyForm.$submitted }" required  maxlength="3" intype="digit"/>
                                <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                    <span  ng-show="PropertyForm.Full_Baths.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Full Bath'))}}</span>
                                </span>
                                                                </div>
                                                                <div class="form-group col-md-2" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.Half_Baths.$invalid}">
                                                                    <label for="HalfBaths" class="control-label">Half Baths</label>
                                                                    <input class="form-control" ng-model="PropertyModel.ListingModel.NoOfHalfBaths" type="text" name="Half_Baths" ng-class="{ 'has-submitted' : PropertyForm.$submitted }" required  maxlength="3" intype="digit"/>
                                <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                    <span  ng-show="PropertyForm.Half_Baths.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Half Bath'))}}</span>
                                </span>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-2" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.Stories.$invalid}">
                                                                <label for="Stories" class="control-label">Stories</label>
                                                                <input class="form-control" ng-model="PropertyModel.ListingModel.NoOfStories" type="text" name="Stories" ng-class="{ 'has-submitted' : PropertyForm.$submitted }" required  maxlength="3" intype="digit"/>
                            <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                <span  ng-show="PropertyForm.Stories.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Story'))}}</span>
                            </span>
                                                            </div>
                                                            <div class="form-group col-md-2" ng-class="{ 'has-error' : (PropertyForm.$submitted) && (PropertyForm.Year_Built.$invalid || PropertyForm.Year_Built.$error.invalidYear)}">
                                                                <label for="Year Built" class="control-label">Year Built</label>
                                                                <input class="form-control" ng-model="PropertyModel.ListingModel.BuiltYear" future-year-not-allowed type="text" name="Year_Built" ng-class="{ 'has-submitted' : PropertyForm.$submitted }"  maxlength="4" minlength="4" intype="digit"/>
                                                            <span class="error-text-color" ng-show="PropertyForm.$submitted" >
                                                                <span ng-show="PropertyForm.Year_Built.$error.minlength">{{ trans('messages.InvalidYear')}}</span>
                                                                <span class="msg-error" ng-show="PropertyForm.Year_Built.$error.invalidYear">{{trans('messages.FutureYear')}}</span>
                                                            </span>
                                                            </div>
                                                            <div class="form-group col-md-3" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.Property_Type.$invalid}">
                                                                <label for="Property Type" class="control-label">Property Type</label>
                                                                <select class="form-control" ng-model="PropertyModel.ListingModel.TypeID" ng-options="type.TypeID as type.Type for type in PropertyModel.PropertyTypes" id="Property_Type" name="Property_Type"  ng-class="{ 'has-submitted' : PropertyForm.$submitted }" required><option value="">-- select --</option></select>
                            <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                <span  ng-show="PropertyForm.Property_Type.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Property Type'))}}</span>
                            </span>
                                                            </div>
                                                            <div class="form-group col-md-3">
                                                                <label for="Property Subtype" class="control-label">Property Subtype</label>
                                                                <select class="form-control" ng-model="PropertyModel.ListingModel.SubTypeID" ng-options="type.SubTypeID as type.SubType for type in PropertyModel.PropertySubTypes" id="Property_Subtype" name="Property_Subtype"><option value="">-- select --</option></select>
                                                                <div class="form-group" ng-if="PropertyModel.ListingModel.SubTypeID ==<?php echo Constants::$PropertyOtherSubTypeID ?>" style="margin-bottom: 0;">
                                                                    <label for="Property Subtype" class="control-label">Other Subtype</label>
                                                                    <input class="form-control" ng-model="PropertyModel.ListingModel.OtherPropertySubtype" type="text" name="OtherSubType"/>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-2" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.Status.$invalid}">
                                                                <label for="Status" class="control-label">Status</label>
                                                                <select class="form-control" ng-model="PropertyModel.ListingModel.StatusID" ng-options="status.StatusID as status.Status for status in PropertyModel.PropertyStatuses" id="Status" name="Status"  ng-class="{ 'has-submitted' : PropertyForm.$submitted }" required><option value="">-- select --</option></select>
                            <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                <span  ng-show="PropertyForm.Status.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Status'))}}</span>
                            </span>
                                                            </div>

                                                            <div class="form-group col-md-12">
                                                                <label for="Street" class="control-label">One-line Description</label>
                                                                <input class="form-control" ng-model="PropertyModel.ListingModel.OneLineDescription" type="text" name="OneLineDescription"/>
                                                            </div>

                                                            <div class="form-group col-md-12">
                                                                <label for="Description" class="control-label">Description/Remarks</label>
                                                                <textarea class="form-control" ng-model="PropertyModel.ListingModel.Description" rows="6" name="Description"></textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>



                                            </div>


                                        </div>

                                    </div>



                                    <div class="clearboth"></div>
                                    <div class="portlet box blue-hoki" ng-cloak>
                                        <div class="portlet-title" collapse>
                                            <div class="caption">
                                                <i class=""></i>LOCATION DETAILS</div>
                                            <div class="tools">
                                                <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                            </div>
                                        </div>
                                        <div class="portlet-body">
                                            <div class="row">
                                                <div class="col-md-12 no-padding">
                                                    <div class="form-body" >
                                                        <div class="col-md-12 no-padding">
                                                            <div class="form-group col-md-3" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.Street.$invalid}">
                                                                <label for="Street" class="control-label">Street</label>
                                                                <input class="form-control" ng-model="PropertyModel.ListingModel.Street" type="text" name="Street" ng-class="{ 'has-submitted' : PropertyForm.$submitted }" required maxlength="100"/>
                                        <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                            <span  ng-show="PropertyForm.Street.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Street'))}}</span>
                                        </span>
                                                            </div>
                                                            <div class="form-group col-md-3" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.City.$invalid}">
                                                                <label for="City" class="control-label">City</label>
                                                                <input class="form-control" ng-model="PropertyModel.ListingModel.City" type="text" name="City" ng-class="{ 'has-submitted' : PropertyForm.$submitted }" required maxlength="100"/>
                                        <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                            <span  ng-show="PropertyForm.City.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'City'))}}</span>
                                        </span>
                                                            </div>
                                                            <div class="form-group col-md-2" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.Zip.$invalid}">
                                                                <label for="Zip" class="control-label">Zip</label>
                                                                <input class="form-control" ng-model="PropertyModel.ListingModel.ZipCode" type="text" name="Zip" ng-class="{ 'has-submitted' : PropertyForm.$submitted }" ng-pattern="<?php echo Constants::$zipRegex; ?>" intype="digit" required maxlength="5"/>
                                        <span class="error-text-color" ng-show="PropertyForm.$submitted && PropertyForm.Zip.$invalid">
                                            <span  ng-show="PropertyForm.Zip.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Zip'))}}</span>
                                            <span ng-show="PropertyForm.Zip.$error.pattern">{{ trans('messages.InvalidZipCode')}}</span>
                                        </span>
                                                            </div>
                                                            <div class="form-group col-md-3">
                                                                <label for="Area" class="control-label">Area</label>
                                                                <select class="form-control" ng-model="PropertyModel.ListingModel.AreaID" ng-options="area.AreaID as area.Area for area in PropertyModel.Areas" id="Area" name="Area"  ng-class="{ 'has-submitted' : PropertyForm.$submitted }" >
                                                                <option value="">-- select --</option></select>
                                                            </div>
                                                            <div class="col-md-12 no-padding">
                                                                <div class="form-group col-md-3" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.State.$invalid}">
                                                                    <label for="State" class="control-label">State</label>
                                                                    <select class="form-control" ng-model="PropertyModel.ListingModel.StateID"
                                                                            ng-options="state.StateID as state.StateName for state in PropertyModel.States" id="State" name="State"
                                                                            ng-class="{ 'has-submitted' : PropertyForm.$submitted }" required><option value="">-- select --</option></select>
                                            <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                                <span  ng-show="PropertyForm.State.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'State'))}}</span>
                                            </span>
                                                                </div>

                                                                <div class="form-group col-md-3" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.County.$invalid}">
                                                                    <label for="County" class="control-label">County</label>
                                                                    <input class="form-control" ng-model="PropertyModel.ListingModel.County" type="text" name="County" ng-class="{ 'has-submitted' : PropertyForm.$submitted }" required maxlength="100"/>
                                        <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                            <span  ng-show="PropertyForm.County.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'County'))}}</span>
                                        </span>
                                                                </div>
                                                                <?php if(SessionHelper::getSelectedSiteID() !=  Common::getSiteColorado()){?>
                                                                <div class="form-group col-md-5">
                                                                    <label for="Development" class="control-label">Development</label>
                                                                    <select class="form-control" ng-model="PropertyModel.ListingModel.DevelopmentID" ng-options="development.DevelopmentID as development.Name for development in PropertyModel.Developments" id="Development" name="Development" ><option value="">-- select --</option></select>
                                                                </div>
                                                                <?php }?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="clearboth"></div>
                                    <div class="portlet box blue-hoki" ng-cloak>
                                        <div class="portlet-title" collapse>
                                            <div class="caption">
                                                <i class=""></i>SCHOOLS</div>
                                            <div class="tools">
                                                <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                            </div>
                                        </div>
                                        <div class="portlet-body">
                                            <div class="row">
                                                <div class="col-md-12 no-padding">
                                                    <div class="form-body" >
                                                        <div class="col-md-12 no-padding">
                                                            <div class="form-group col-md-4">
                                                                <label for="Elementary" class="control-label">Elementary</label>
                                                                <input class="form-control" ng-model="PropertyModel.ListingModel.ElementarySchool" type="text" name="Elementary" maxlength="100"/>
                                                            </div>
                                                            <div class="form-group col-md-4">
                                                                <label for="Junior High" class="control-label">Junior High</label>
                                                                <input class="form-control" ng-model="PropertyModel.ListingModel.JuniorHighSchool" type="text" name="Junior High" maxlength="100"/>
                                                            </div>
                                                            <div class="form-group col-md-4">
                                                                <label for="Senior High" class="control-label">Senior High</label>
                                                                <input class="form-control" ng-model="PropertyModel.ListingModel.SeniorHighSchool" type="text" name="Senior High" maxlength="100"/>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="clearboth"></div>
                                    <div class="portlet box blue-hoki" ng-cloak>
                                        <div class="portlet-title" collapse>
                                            <div class="caption">
                                                <i class=""></i>EXTERIOR</div>
                                            <div class="tools">
                                                <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                            </div>
                                        </div>
                                        <div class="portlet-body">
                                            <div class="row">
                                                <div class="col-md-12 no-padding">
                                                    <div class="form-body" >
                                                        <div class="col-md-12 no-padding">
                                                            <div class="form-group col-md-3">
                                                                <label for="Security" class="control-label">Security</label>
                                                                <select class="form-control" multiple ng-model="PropertyModel.ListingModel.SecurityTypes"
                                                                        ng-options="security.SecurityTypeID as security.SecurityType for security in PropertyModel.SecurityTypes"
                                                                        id="Security" name="Security" clear-other select-val="PropertyModel.ListingModel.SecurityTypes"
                                                                        other-val="<?php echo Constants::$PropertyOtherSecurityTypeID; ?>"
                                                                        other="PropertyModel.ListingModel.OtherSecurityType"></select>
                                                                <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.SecurityTypes.indexOf('<?php echo Constants::$PropertyOtherSecurityTypeID; ?>') > -1">
                                                                    <label for="Style" class="control-label">Other Security</label>
                                                                    <input class="form-control" ng-model="PropertyModel.ListingModel.OtherSecurityType" type="text" name="OtherSecurityType" maxlength="100"/>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-3">
                                                                <label for="Pool" class="control-label">Pool</label>
                                                                <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Pools"
                                                                        ng-options="pool.PoolTypeID as pool.PoolType for pool in PropertyModel.PoolTypes" id="Pool" name="Pool"
                                                                        clear-other select-val="PropertyModel.ListingModel.Pools"
                                                                        other-val="<?php echo Constants::$PropertyOtherPoolID; ?>"
                                                                        other="PropertyModel.ListingModel.OtherPoolType"></select>
                                                                <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.Pools.indexOf('<?php echo Constants::$PropertyOtherPoolID; ?>') > -1">
                                                                    <label for="Style" class="control-label">Other Pool</label>
                                                                    <input class="form-control" ng-model="PropertyModel.ListingModel.OtherPoolType" type="text" name="OtherPool" maxlength="100"/>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-3">
                                                                <label for="Spa" class="control-label">Spa</label>
                                                                <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Spas"
                                                                        ng-options="spa.SpaTypeID as spa.SpaType for spa in PropertyModel.SpaTypes" id="Spa" name="Spa"
                                                                        clear-other select-val="PropertyModel.ListingModel.Spas"
                                                                        other-val="<?php echo Constants::$PropertyOtherSpaID; ?>"
                                                                        other="PropertyModel.ListingModel.OtherSpa"></select>
                                                                <div class="form-group  margin-top-10" ng-if="PropertyModel.ListingModel.Spas.indexOf('<?php echo Constants::$PropertyOtherSpaID; ?>') > -1">
                                                                    <label for="Style" class="control-label">Other Spa</label>
                                                                    <input class="form-control" ng-model="PropertyModel.ListingModel.OtherSpa" type="text" name="OtherSpa" maxlength="100"/>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-3">
                                                                <label for="View" class="control-label">View</label>
                                                                <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Views"
                                                                        ng-options="view.ViewID as view.View for view in PropertyModel.Views" id="View" name="View"
                                                                        clear-other select-val="PropertyModel.ListingModel.Views"
                                                                        other-val="<?php echo Constants::$PropertyOtherViewID; ?>"
                                                                        other="PropertyModel.ListingModel.OtherView"></select>
                                                                <div class="form-group  margin-top-10" ng-if="PropertyModel.ListingModel.Views.indexOf('<?php echo Constants::$PropertyOtherViewID; ?>') > -1">
                                                                    <label for="Style" class="control-label">Other View</label>
                                                                    <input class="form-control" ng-model="PropertyModel.ListingModel.OtherView" type="text" name="OtherView" maxlength="100"/>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12 no-padding">
                                                                <div class="form-group col-md-3">
                                                                    <label for="Style" class="control-label">Style</label>
                                                                    <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Styles"
                                                                            ng-options="style.StyleID as style.Style for style in PropertyModel.Styles" id="Style" name="Style"
                                                                            clear-other select-val="PropertyModel.ListingModel.Styles"
                                                                            other-val="<?php echo Constants::$PropertyOtherStyleID; ?>"
                                                                            other="PropertyModel.ListingModel.OtherStyle"></select>
                                                                    <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.Styles.indexOf('<?php echo Constants::$PropertyOtherStyleID; ?>') > -1">
                                                                        <label for="Style" class="control-label">Other Style</label>
                                                                        <input class="form-control" ng-model="PropertyModel.ListingModel.OtherStyle" type="text" name="OtherStyle" maxlength="100"/>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-md-3">
                                                                    <label for="Waterfront" class="control-label">Waterfront</label>
                                                                    <select class="form-control" multiple ng-model="PropertyModel.ListingModel.WaterFronts" ng-options="waterfront.WaterfrontID as waterfront.Waterfront for waterfront in PropertyModel.WaterFronts" id="Waterfront" name="Waterfront"></select>
                                                                </div>
                                                                <div class="form-group col-md-3">
                                                                    <label for="Roofing" class="control-label">Roofing</label>
                                                                    <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Roofings"
                                                                            ng-options="roofing.RoofingID as roofing.Roofing for roofing in PropertyModel.Roofings" id="Roofing" name="Roofing"
                                                                            clear-other select-val="PropertyModel.ListingModel.Roofings"
                                                                            other-val="<?php echo Constants::$PropertyOtherRoofingID; ?>"
                                                                            other="PropertyModel.ListingModel.OtherRoofing"></select>
                                                                    <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.Roofings.indexOf('<?php echo Constants::$PropertyOtherRoofingID; ?>') > -1">
                                                                        <label for="Style" class="control-label">Other Roofing</label>
                                                                        <input class="form-control" ng-model="PropertyModel.ListingModel.OtherRoofing" type="text" name="OtherRoofing" maxlength="100"/>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-md-3">
                                                                    <label for="Sewer" class="control-label">Sewer</label>
                                                                    <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Sewers"
                                                                            ng-options="sewer.SewerID as sewer.Sewer for sewer in PropertyModel.Sewers" id="Sewer" name="Sewer"
                                                                            clear-other select-val="PropertyModel.ListingModel.Sewers"
                                                                            other-val="<?php echo Constants::$PropertyOtherSewerID; ?>"
                                                                            other="PropertyModel.ListingModel.OtherSewer"></select>
                                                                    <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.Sewers.indexOf('<?php echo Constants::$PropertyOtherSewerID; ?>') > -1">
                                                                        <label for="Style" class="control-label">Other Sewer</label>
                                                                        <input class="form-control" ng-model="PropertyModel.ListingModel.OtherSewer" type="text" name="OtherSewer" maxlength="100"/>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="clearboth"></div>
                                    <div class="portlet box blue-hoki" ng-cloak>
                                        <div class="portlet-title" collapse>
                                            <div class="caption">
                                                <i class=""></i>INTERIOR</div>
                                            <div class="tools">
                                                <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                            </div>
                                        </div>
                                        <div class="portlet-body">
                                            <div class="row">
                                                <div class="col-md-12 no-padding">
                                                    <div class="form-body" >
                                                        <div class="col-md-12 no-padding">
                                                            <div class="col-md-12 no-padding">
                                                                <div class="form-group col-md-3">
                                                                    <label for="Equipment" class="control-label">Equipment</label>
                                                                    <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Equipments"
                                                                            ng-options="equipment.EquipmentID as equipment.Equipment for equipment in PropertyModel.Equipments" id="Equipment" name="Equipment"
                                                                            clear-other select-val="PropertyModel.ListingModel.Equipments"
                                                                            other-val="<?php echo Constants::$PropertyOtherEquipmentID; ?>"
                                                                            other="PropertyModel.ListingModel.OtherEquipment"></select>
                                                                    <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.Equipments.indexOf('<?php echo Constants::$PropertyOtherEquipmentID; ?>') > -1">
                                                                        <label for="Style" class="control-label">Other Equipment</label>
                                                                        <input class="form-control" ng-model="PropertyModel.ListingModel.OtherEquipment" type="text" name="OtherEquipment" maxlength="100"/>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-md-3">
                                                                    <label for="Flooring" class="control-label">Flooring</label>
                                                                    <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Floorings"
                                                                            ng-options="flooring.FlooringID as flooring.Flooring for flooring in PropertyModel.Floorings" id="Flooring" name="Flooring"
                                                                            clear-other select-val="PropertyModel.ListingModel.Floorings"
                                                                            other-val="<?php echo Constants::$PropertyOtherFlooringID; ?>"
                                                                            other="PropertyModel.ListingModel.OtherFlooring"><option>Select Flooring</option></select>
                                                                    <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.Floorings.indexOf('<?php echo Constants::$PropertyOtherFlooringID; ?>') > -1">
                                                                        <label for="Style" class="control-label">Other Flooring</label>
                                                                        <input class="form-control" ng-model="PropertyModel.ListingModel.OtherFlooring" type="text" name="OtherFlooring" maxlength="100"/>
                                                                    </div>
                                                                </div>

                                                                <div class="form-group col-md-3">
                                                                    <label for="Heating" class="control-label">Heating</label>
                                                                    <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Heatings"
                                                                            ng-options="heating.HeatingID as heating.Heating for heating in PropertyModel.Heatings" id="Heating" name="Heating"
                                                                            clear-other select-val="PropertyModel.ListingModel.Heatings"
                                                                            other-val="<?php echo Constants::$PropertyOtherHeatingID; ?>"
                                                                            other="PropertyModel.ListingModel.OtherHeating"><option>Select Heating</option></select>
                                                                    <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.Heatings.indexOf('<?php echo Constants::$PropertyOtherHeatingID; ?>') > -1">
                                                                        <label for="Style" class="control-label">Other Heating</label>
                                                                        <input class="form-control" ng-model="PropertyModel.ListingModel.OtherHeating" type="text" name="OtherHeating" maxlength="100"/>
                                                                    </div>
                                                                </div>

                                                                <div class="form-group col-md-3">
                                                                    <label for="Air Conditioning" class="control-label">Air Conditioning</label>
                                                                    <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Airconditionings"
                                                                            ng-options="airconditioning.AirConditioningID as airconditioning.AirConditioning for airconditioning in PropertyModel.Airconditionings" id="Air_Conditioning" name="Air Conditioning"
                                                                            clear-other select-val="PropertyModel.ListingModel.Airconditionings"
                                                                            other-val="<?php echo Constants::$PropertyOtherAirConditioningID; ?>"
                                                                            other="PropertyModel.ListingModel.OtherAirConditioning"><option>Select Air Conditioning</option></select>
                                                                    <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.Airconditionings.indexOf('<?php echo Constants::$PropertyOtherAirConditioningID; ?>') > -1">
                                                                        <label for="Style" class="control-label">Other Air Conditioning</label>
                                                                        <input class="form-control" ng-model="PropertyModel.ListingModel.OtherAirConditioning" type="text" name="OtherAirConditioning" maxlength="100"/>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-3">
                                                                <label for="Rooms" class="control-label">Rooms</label>
                                                                <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Rooms"
                                                                        ng-options="room.RoomID as room.Room for room in PropertyModel.Rooms" id="Rooms" name="Rooms"
                                                                        clear-other select-val="PropertyModel.ListingModel.Rooms"
                                                                        other-val="<?php echo Constants::$PropertyOtherRoomID; ?>"
                                                                        other="PropertyModel.ListingModel.OtherRoom"><option>Select Rooms</option></select>
                                                                <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.Rooms.indexOf('<?php echo Constants::$PropertyOtherRoomID; ?>') > -1">
                                                                    <label for="Style" class="control-label">Other Room</label>
                                                                    <input class="form-control" ng-model="PropertyModel.ListingModel.OtherRoom" type="text" name="OtherRoom" maxlength="100"/>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-3">
                                                                <label for="Fireplaces" class="control-label">Fireplaces</label>
                                                                <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Fireplaces"
                                                                        ng-options="frireplace.FireplaceID as frireplace.Fireplace for frireplace in PropertyModel.Fireplaces" id="Fireplaces" name="Fireplaces"
                                                                        clear-other select-val="PropertyModel.ListingModel.Fireplaces"
                                                                        other-val="<?php echo Constants::$PropertyOtherFireplaceID; ?>"
                                                                        other="PropertyModel.ListingModel.OtherFireplace"><option>Select Fireplaces</option></select>
                                                                <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.Fireplaces.indexOf('<?php echo Constants::$PropertyOtherFireplaceID; ?>') > -1">
                                                                    <label for="Style" class="control-label">Other Fireplace</label>
                                                                    <input class="form-control" ng-model="PropertyModel.ListingModel.OtherFireplace" type="text" name="OtherFireplace" maxlength="100"/>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-3">
                                                                <label for="Laundry" class="control-label">Laundry</label>
                                                                <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Laundries"
                                                                        ng-options="laundry.LaundryID as laundry.Laundry for laundry in PropertyModel.Laundries" id="Laundry" name="Laundry"
                                                                        clear-other select-val="PropertyModel.ListingModel.Laundries"
                                                                        other-val="<?php echo Constants::$PropertyOtherLaundryID; ?>"
                                                                        other="PropertyModel.ListingModel.OtherLaundry"><option>Select Laundry</option></select>
                                                                <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.Laundries.indexOf('<?php echo Constants::$PropertyOtherLaundryID; ?>') > -1">
                                                                    <label for="Style" class="control-label">Other Laundry</label>
                                                                    <input class="form-control" ng-model="PropertyModel.ListingModel.OtherLaundry" type="text" name="OtherLaundry" maxlength="100"/>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="clearboth"></div>
                                    <div class="portlet box blue-hoki" ng-cloak>
                                        <div class="portlet-title" collapse>
                                            <div class="caption">
                                                <i class=""></i>ADDITIONAL PROPERTY DETAILS</div>
                                            <div class="tools">
                                                <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                            </div>
                                        </div>
                                        <div class="portlet-body">
                                            <div class="row">
                                                <div class="col-md-12 no-padding">
                                                    <div class="form-body" >
                                                        <div class="col-md-12 no-padding">
                                                            <div class="form-group col-md-3">
                                                                <label for="Parking" class="control-label">Parking</label>
                                                                <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Parkings"
                                                                        ng-options="parking.ParkingID as parking.Parking for parking in PropertyModel.Parkings" id="Parking" name="Parking"
                                                                        clear-other select-val="PropertyModel.ListingModel.Parkings"
                                                                        other-val="<?php echo Constants::$PropertyOtherParkingID; ?>"
                                                                        other="PropertyModel.ListingModel.OtherParking"><option>Select Parking</option></select>
                                                                <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.Parkings.indexOf('<?php echo Constants::$PropertyOtherParkingID; ?>') > -1">
                                                                    <label for="Style" class="control-label">Other Parking</label>
                                                                    <input class="form-control" ng-model="PropertyModel.ListingModel.OtherParking" type="text" name="OtherParking" maxlength="100"/>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-3">
                                                                <label for="Disability Access" class="control-label">Disability Access</label>
                                                                <select class="form-control" multiple ng-model="PropertyModel.ListingModel.DisabilityAccesses"
                                                                        ng-options="disability.DisabilityAccessID as disability.DisabilityAccess for disability in PropertyModel.DisabilityAccesses"
                                                                        id="Disability_Access" name="Disability Access"><option>Select Disability Access</option></select>
                                                            </div>
                                                            <div class="form-group col-md-3">
                                                                <label for="Tennis/Courts" class="control-label">Tennis/Courts</label>
                                                                <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Courts"
                                                                        ng-options="court.CourtID as court.Court for court in PropertyModel.Courts" id="Tennis/Courts" name="Tennis/Courts"
                                                                        clear-other select-val="PropertyModel.ListingModel.Courts"
                                                                        other-val="<?php echo Constants::$PropertyOtherCourtID; ?>"
                                                                        other="PropertyModel.ListingModel.OtherCourt"><option>Select Tennis/Courts</option></select>
                                                                <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.Courts.indexOf('<?php echo Constants::$PropertyOtherCourtID; ?>') > -1">
                                                                    <label for="Style" class="control-label">Other Tennis/Courts</label>
                                                                    <input class="form-control" ng-model="PropertyModel.ListingModel.OtherCourt" type="text" name="OtherCourt" maxlength="100"/>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-3">
                                                                <label for="Amenities" class="control-label">Amenities</label>
                                                                <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Amenities"
                                                                        ng-options="amenity.AmenityID as amenity.Amenity for amenity in PropertyModel.Amenities" id="Amenities" name="Amenities"
                                                                        clear-other select-val="PropertyModel.ListingModel.Amenities"
                                                                        other-val="<?php echo Constants::$PropertyOtherAmenityID; ?>"
                                                                        other="PropertyModel.ListingModel.OtherAmenity"><option>Select Amenities</option></select>
                                                                <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.Amenities.indexOf('<?php echo Constants::$PropertyOtherAmenityID; ?>') > -1">
                                                                    <label for="Style" class="control-label">Other Amenities</label>
                                                                    <input class="form-control" ng-model="PropertyModel.ListingModel.OtherAmenity" type="text" name="OtherAmenity" maxlength="100"/>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12 no-padding">
                                                                <div class="form-group col-md-3" ng-class="{ 'has-error' : (PropertyForm.$submitted) && ShowKeywordsError}">
                                                                    <label for="Keywords" class="control-label">Keywords</label>
                                                                    <tags-input  ng-model="PropertyModel.ListingModel.Keywords" display-property="Keyword" replace-spaces-with-dashes="false" add-from-autocomplete-only="true"  class="ngTagsInput" ng-class="{ 'has-submitted' : PropertyForm.$submitted }">
                                                                        <auto-complete source="loadKeywords($query)"  min-length="0" load-on-focus="true" load-on-empty="false" template="my-custom-template"></auto-complete>
                                                                    </tags-input>
                                                                    <script type="text/ng-template" id="my-custom-template">
                                                                        <span ng-bind-html="$highlight($getDisplayText())"></span>
                                                                    </script>
                                                                    <span class="error-text-color" ng-if="ShowKeywordsError">
                                                                        <span  ng-show="ShowKeywordsError">{{ trans('messages.InvalidKeyword')}}</span>
                                                                    </span>
                                                                    <!--<select class="form-control" multiple id="Keywords" name="Keywords"><option>Select Keywords</option></select>-->
                                                                </div>
                                                                <div class="col-md-3  margin-top-25">
                                                                    <input type="checkbox" ng-model="PropertyModel.ListingModel.HasGuestHouse"
                                                                           ng-true-value="1" ng-false-value="0" id="Has_guest_house">
                                                                    <label> Has guest house</label>
                                                                </div>
                                                                <div class="col-md-3  margin-top-25">
                                                                    <input type="checkbox" ng-model="PropertyModel.ListingModel.HasHorseProperty"
                                                                           ng-true-value="1" ng-false-value="0" id="horse_property">
                                                                    <label> Horse Property</label>
                                                                </div>
                                                                <div class="col-md-3  margin-top-25">
                                                                    <label class="control-label"> Is Hidden?</label>
                                                                    <!--<div class="ng-scope">-->
                                                                    <label class="ng-binding"><input  type="radio" id="IsHidden" ng-model="PropertyModel.ListingModel.IsHidden" name="IsHidden"  value="1"/> Yes</label>
                                                                    <label class="ng-binding"><input  type="radio" id="IsHidden" ng-model="PropertyModel.ListingModel.IsHidden" name="IsHidden"  value="0"/> No</label>
                                                                    <!-- </div> -->
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- For File Upload Start -->
                                    <div class="clearboth"></div>
                                    <div class="portlet box blue-hoki" ng-cloak>
                                        <div class="portlet-title" collapse>
                                            <div class="caption">
                                                <i class=""></i>IMAGES</div>
                                            <div class="tools">
                                                <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                            </div>
                                        </div>
                                        <div class="portlet-body">
                                            <div class="row">
                                                <div class="col-md-12 no-padding">
                                                    <div class="form-body" >
                                                        <div class="col-md-12 no-padding">
                                                            <div class="form-group col-md-12 dropZoneOuter">
                                                                <div class="col-md-12 no-padding" ng-if="PropertyModel.IsShowUploadNote == 1">
                                                                    <span class="font13px help-block info-alert" >
                                                                            <span><span class="bold">Note:</span> {{ trans('messages.PropertyImageQueue')}}</span>
                                                                    </span>
                                                                </div>
                                                                <div class="col-md-12 no-padding margin-bottom-10" >
                                                                    <?php if(($siteID == Constants::$MercerVineSiteID) || ($siteID == Constants::$ColoradoSiteID)) ?>
                                                                    <span class="font13px help-block info-alert" >
                                                                            <span><span class="bold">Note:</span> {{ trans('messages.PropertyImagesDimension')}}</span>
                                                                    </span>
                                                                    <?php ?>
                                                                </div>

                                                                <div class="clearboth"></div><form></form>
                                                                <form action=""  class="dropzone" drop-zone="" id="file-dropzone"  ng-aws-settings-model="PropertyModel.FileUploadSettings" success-callback="PushFilesToUploadArray" remove-file="RemoveFile" upload-file="PropertyModel.ListingModel.ImagesModel" file-name="PropertyModel.ListingModel.ImagesNameModel" ext-type="PropertyModel.ImageExtensionType" max-files="PropertyModel.maxFiles" request-counter="PropertyModel.requestCounter" response-counter="PropertyModel.responseCounter"  upload-complete="UploadComplete" uploaded-file="PropertyModel.ListingModel.UploadedFile" file-size-exceeds="{{ trans('messages.NoMoreImages')}}" invalid-file-format="{{trans('messages.InvalidImageTypeFormat')}}" allow-sortable="PropertyModel.IsAllowSortable" sortable-callback="updateSortOrder" url-upload-file="PropertyModel.ListingModel.RestsImageURL">
                                                                    <div class="dz-preview dz-file-preview margin-10p sortable" id="template">
                                                                        <div class="dz-details">
                                                                            <div class="dz-filename"><span data-dz-name></span></div>
                                                                            <div class="dz-size" data-dz-size></div>
                                                                            <div><span class="dz-remove"></span></div><img data-dz-thumbnail />
                                                                        </div>
                                                                        <br/>
                                                                        <div  class="progress progress-striped active" id="totalprogressbar"  role="progressbar" aria-valuemin='0' aria-valuemax='100' aria-valuenow='0'> <div class="progress-bar progress-bar-success bar width-none" data-dz-uploadprogress></div> </div>
                                                                        <div class="dz-success-mark"><span>✔</span></div>
                                                                        <div class="dz-error-mark"><span>✘</span></div>
                                                                        <div class="file-error-message"><strong class="error text-danger" data-dz-errormessage></strong></div>

                                                                        <div class="col-md-12 col-md-push-1 no-padding" >
                                                                            <div class="sortable-handle vertical-align btn btn-gray col-md-4 no-padding col-sm-4 col-xs-4 drag-drop-icon">
                                                                                <center><span class="draggable-icon-arrow"><i class="fa fa-bars draggable-icon dropzone-draggable-button"></i>
                                                                             <i class="fa fa-arrows-alt draggable-icon dropzone-draggable-button"></i></span></center>
                                                                            </div>
                                                                            <div class=" col-md-3 no-padding col-md-push-2">
                                                                                <button data-dz-remove="" class="btn btn-danger delete cancel dropzone-delete-button"><i class="glyphicon glyphicon-trash"></i></button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- For File Upload End -->
                                    <div class="clearboth"></div>
                                    <div class="portlet box blue-hoki" ng-cloak>
                                        <div class="portlet-title" collapse>
                                            <div class="caption">
                                                <i class=""></i>PROPERTY FEATURES</div>
                                            <div class="tools">
                                                <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                            </div>
                                        </div>
                                        <div class="portlet-body">
                                            <div class="row">
                                                <div class="col-md-12 no-padding">
                                                    <div class="form-body" >
                                                        <div class="col-md-12 no-padding">
                                                            <div class="form-group col-md-12 dropZoneOuter drop-property">
															<div class="col-md-12 no-padding margin-bottom-10" >
                                                                    <?php if(($siteID == Constants::$MercerVineSiteID) || ($siteID == Constants::$ColoradoSiteID)) ?>
                                                                    <span class="font13px help-block info-alert" >
                                                                            <span><span class="bold">Note:</span> {{ trans('messages.PropertyFeatureImagesDimension')}}</span>
                                                                    </span>
                                                                    <?php ?>
                                                                </div>
                                                                   <div class="clearboth"></div><form></form>
                                                                <form action="" class="dropzone" drop-zone-with-extra-fields="" id="file-dropzone"
                                                                      ng-aws-settings-model="PropertyModel.FileUploadSettings" success-callback="PushFilesToUploadArrayOfPropertyFeatures" remove-file="RemovePropertyFeaturesFiles"
                                                                      upload-file="PropertyModel.ListingModel.ImagesModelOfPropertyFeatures"  ext-type="PropertyModel.ImageExtensionTypeOfPropertyFeatures"
                                                                      max-files="PropertyModel.maxFilesOfPropertyFeatures" request-counter="PropertyModel.requestCounterOfPropertyFeatures" response-counter="PropertyModel.responseCounterOfPropertyFeatures"
                                                                      upload-complete="UploadCompleteOfPropertyFeatures" uploaded-file="PropertyModel.ListingModel.UploadedFileOfPropertyFeatures" file-size-exceeds="{{ trans('messages.NoMorePropertyFeaturesImages')}}"
                                                                      invalid-file-format="{{trans('messages.InvalidImageTypeFormat')}}"  error-array="ErrorArray"
                                                                      allow-order="PropertyModel.IsAllowStoreOrder"  file-order-name="PropertyModel.ListingModel.PropertyImagesNameModel">

                                                                    <div class="dz-preview dz-file-preview margin-10p width-97pr property-features" id="template">
                                                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding-0">
                                                                            <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
                                                                                <div class="dz-details">
                                                                                    <div class="dz-filename"><span data-dz-name></span></div>
                                                                                    <div class="dz-size" data-dz-size></div>
                                                                                    <div><span class="dz-remove"></span></div>
                                                                                    <img class="img-thumbnail opacity-none" data-dz-thumbnail/><br/>

                                                                                </div><br/>
                                                                                <div class="progress progress-striped active width-65pr" id="totalprogressbar"  role="progressbar" aria-valuemin='0' aria-valuemax='100' aria-valuenow='0'> <div class="progress-bar progress-bar-success bar width-none" data-dz-uploadprogress></div> </div>
                                                                                <div class="file-error-message"><strong class="error text-danger" data-dz-errormessage></strong></div>

                                                                            </div>
                                                                            <div class="col-lg-4 col-md-3 col-sm-3 col-xs-12">
                                                                                <div  id="PropertyFeaturesTitle" class="padding-10pr">
                                                                                    <label for="Title" class="control-label">Title</label>
                                                                                    <input  class="form-control" id="PFTitle"  onblur="checkValidation(this)" />
                                                                                    <span class="validationMessage positionInherit display-none">{{ trans('messages.PropertyRequired',array('attribute'=>'Title'))}}</span>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-lg-4 col-md-3 col-sm-3 col-xs-12">
                                                                                <div  id="PropertyFeaturesDescriptions" class="padding-10pr">
                                                                                    <label for="Descriptions" class="control-label">Description</label>
                                                                                    <textarea class="form-control" id="PFDescription" rows="3"  onblur="checkValidation(this)"></textarea>
                                                                                    <span class="validationMessage positionInherit display-none">{{ trans('messages.PropertyRequired',array('attribute'=>'Descriptions'))}}</span>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12 padding-0">
                                                                                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-12 padding-35pr"><button data-dz-remove class="btn btn-danger delete cancel btn-xs margin-bottom-15">
                                                                                        <i class="glyphicon glyphicon-trash padding-top-bottom"></i> <span>Delete &nbsp;</span></button></div>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                </form>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-actions  col-md-12">
                                        <input id="submit" name="submit" type="submit" value="Save" class="btn blue save-button" data-ng-click="AddListing()" ng-disabled="!UploadComplete || !UploadCompleteOFPF">
                                        <input id="cancel" name="cancel" type="button" value="Cancel" class="btn grey" data-ng-click="Cancel()" ng-disabled="!UploadComplete || !UploadCompleteOFPF">
                                    </div>

                                </div>
                            
                        </div>
                    </div>
        </div>
        </form>
    </main>
@stop

@section('script')
    {{ $minify::javascript(array('/assets/js/viewjs/property/addpropertylisting.js','/assets/js/sitejs/dropzone.js'))->withFullUrl()}}
    {{ $minify::javascript(array('/assets/js/sitejs/jquery-ui-1.9.2.custom.min.js',
                                   '/assets/js/sitejs/jquery.ui.touch-punch.min.js'))->withFullUrl()}}
    {{ $minify::javascript(array('/assets/js/sitejs/exif.js','/assets/js/sitejs/binaryajax.js'))->withFullUrl()}}
    {{ $minify::javascript(array('/assets/js/sitejs/canvasResize.js'))->withFullUrl()}}
    <script>
        window.PropertyOtherSubTypeID = '<?php echo Constants::$PropertyOtherSubTypeID ?>';
    </script>
@stop