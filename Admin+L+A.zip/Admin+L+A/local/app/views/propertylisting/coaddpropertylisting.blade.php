<?php
/**
 * Created by PhpStorm.
 * User: kajal
 * Date: 22-Oct-16
 * Time: 11:46 AM
 */
$minify = new \CeesVanEgmond\Minify\Facades\Minify;
use Infrastructure\Constants;
use Infrastructure\Common;
use ViewModels\SessionHelper;
?>
@extends('layouts.sitemaster')
@section('Title')
    <?php print  ($PropertyModel->ListingModel->CoListingID > 0) ? 'Edit Listing' :  'Add Listing';?>
@stop
@section('css')
    {{ $minify::stylesheet(array('/assets/css/tagsinput/ng-tags-input.min.css'))->withFullUrl()}}
    <link href="<?php echo asset('/assets/css/dropzone/dropzone.css');?>" defer rel="stylesheet" type='text/css'>
@stop
@section('content')
    <main id="main" role="main" xmlns="http://www.w3.org/1999/html" ng-controller = "PropertyController">
        <form name="PropertyForm" id="PropertyForm" role="form" novalidate ng-submit="checkSave(PropertyForm)">
            <?php echo Form::hidden('PropertyModel', json_encode($PropertyModel),$attributes = array('id'=>'PropertyModel')); ?>
            <div class="page-content"    ng-cloak>
                <div class="page-bar">
                    <ul class="page-breadcrumb">
                        <li>
                            <a href="<?php echo URL::to('/dashboard/'.$encryptedSiteID) ?>">Home</a>
                            <i class="fa fa-circle"></i>
                        </li>
                        <li>
                            <a href="<?php echo URL::to('/listing/'.$encryptedSiteID) ?>">Listings</a>
                            <i class="fa fa-circle"></i>
                        </li>
                        <li>
                            <span><?php print ($PropertyModel->ListingModel->CoListingID > 0) ?  'Edit Listing' :  'Add Listing';?></span>
                        </li>
                    </ul>
                    <div class="page-toolbar">
                        <div class="btn-group pull-right">
                            <input id="submit" name="submit" type="submit" value="Save" class="btn blue save-button btn-sm" data-ng-click="AddListing()" ng-disabled="!UploadComplete">
                            <input id="delete" name="delete" type="button" value="Delete" class="btn btn-danger btn-sm btn-outline" data-ng-click="DeleteProperty()" ng-show="PropertyModel.ListingModel.CoListingID > 0 && (PropertyModel.ListingModel.MLSNo=='' || PropertyModel.ListingModel.MLSNo==null)" ng-disabled="!UploadComplete">
                        </div>
                    </div>
                </div>
                <h3 class="page-title"> <?php print ($PropertyModel->ListingModel->CoListingID > 0) ?  'Edit Listing' :  'Add Listing';?></h3>
                <div class="row">
                    <div class="col-md-12 ">
                        <div class="form-body">
                            <div class="clearboth"></div>
                            <div class="portlet box blue-hoki" ng-cloak>
                                <div class="portlet-title" collapse>
                                    <div class="caption">
                                        <i class=""></i>PROPERTY DETAILS<?php print ($PropertyModel->ListingModel->CoListingID > 0) ?  ': '.$PropertyModel->ListingModel->Street : '' ;?></div>
                                    <div class="tools">
                                        <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                    </div>
                                </div>
                                <div class="portlet-body">
                                    <div class="form-body" >
                                        <div class="row">
                                            <div class="col-md-12 no-padding">
                                                <div class="row">
                                                    <div class="col-md-12 form-group">
                                                        <div class="col-lg-3 col-md-6 col-xs-12">
                                                            <label for="PropertyClass" class="control-label">Class</label>
                                                            <select class="form-control" ng-model="PropertyModel.ListingModel.ClassID"
                                                                    ng-options="Classes.ClassID as Classes.Class for Classes in PropertyModel.Classes"
                                                                    id="PropertyClass" name="PropertyClass" ng-change="GetClassFields()" ng-disabled="PropertyModel.ListingModel.CoListingID > 0" ></select>
                                                        </div>
                                                        <div class="col-lg-3 col-md-6 col-xs-12">
                                                            <label for="MLSNo" class="control-label">MLS#</label>
                                                            <input class="form-control" ng-model="PropertyModel.ListingModel.MLSNo" ng-disabled="PropertyModel.ListingModel.CoListingID > 0"  type="text" name="MLSNo"  maxlength="20" ng-minlength="5"  intype="alphaNumeric"/>
                                                            <span class="error-text-color" ng-show="((retsFlag == true || PropertyForm.$submitted) && (PropertyForm.MLSNo.$error.minlength))">
                                                                <span ng-show="PropertyForm.MLSNo.$error.minlength"><?php echo trans('messages.PropertyCoMLSMinValue'); ?></span>
                                                            </span>
                                                            <span class="error-text-color" ng-show="( retsFlag == true && (!PropertyForm.MLSNo.$error.minlength) )">
                                                                  <span ng-show="( retsFlag == true && (PropertyModel.ListingModel.MLSNo =='' || PropertyModel.ListingModel.MLSNo == null) )">{{ trans('messages.PropertyRequired',array('attribute'=>'MLS#'))}}</span>
                                                            </span>
                                                        </div>
                                                        <div class="col-lg-2 col-md-3 col-sm-9 col-xs-9 margin-top-25 padding-medium">
                                                            <div ng-hide="PropertyModel.ListingModel.CoListingID > 0">
                                                                <input type="checkbox" name="fetchImage" class="ng-pristine ng-untouched ng-valid margin-right-5" id="fetchImage" ng-false-value="0" ng-true-value="1" ng-model="PropertyModel.ListingModel.fetchImage" ng-init="PropertyModel.ListingModel.fetchImage=1">
                                                                <label for="fetchImage">Fetch MLS Images?</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-1 col-md-3 col-sm-3 col-xs-3 margin-top-25 text-right co-mls-go-button" >
                                                            <div ng-hide="PropertyModel.ListingModel.CoListingID > 0">
                                                                <button type="button" name="search" class="btn green" data-ng-click="SearchMls(false)"> Go </button>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-3 col-md-6 col-xs-12">
                                                            <label for="Agents" class="control-label">Agent</label>
                                                            <select class="form-control" ng-model="PropertyModel.ListingModel.AgentID"
                                                                    ng-options="Agents.UserID as Agents.AgentName for Agents in PropertyModel.Agents"
                                                                    id="Agents" name="Agents"><option value="">-- select --</option></select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 form-group">
                                                        <div class="col-md-3 col-xs-12" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.Price.$invalid}">
                                                            <label for="Price" class="control-label" >Price</label>
                                                            <div class="input-group">
                                                                <span class="input-group-addon">$</span>
                                                                <input type="text" name="Price" ng-model="PropertyModel.ListingModel.Price" class="form-control" intype="positiveNumeric" ng-pattern="<?php echo \Infrastructure\Constants::$PropertyPriceRegex; ?>" required maxlength="21">
                                                            </div>
                                                            <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                                                <span ng-show="PropertyForm.Price.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Price'))}}</span>
                                                                <span ng-show="PropertyForm.Price.$error.pattern">{{ trans('messages.InvalidPrice')}}</span>
                                                            </span>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.Status.$invalid}">
                                                            <label for="Status" class="control-label">Status</label>
                                                            <select class="form-control" ng-model="PropertyModel.ListingModel.StatusID"
                                                                    ng-options="Status.StatusID as Status.Status for Status in PropertyModel.Status"
                                                                    id="Status" name="Status" required><option value="">-- select --</option></select>
                                                            <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                                                <span  ng-show="PropertyForm.Status.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Status'))}}</span>
                                                            </span>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12" ng-if="PropertyModel.Type != ''" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.Type.$invalid}">
                                                            <label for="Type" class="control-label">Type</label>
                                                            <select class="form-control" ng-model="PropertyModel.ListingModel.TypeID"
                                                                    ng-options="Type.TypeID as Type.Type for Type in PropertyModel.Type"
                                                                    id="Type" name="Type" required><option value="">-- select --</option></select>
                                                            <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                                                <span  ng-show="PropertyForm.Type.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Type'))}}</span>
                                                            </span>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.memberAssociations.$invalid}">
                                                            <label for="memberAssociations" class="control-label">Member Association</label>
                                                            <select class="form-control" ng-model="PropertyModel.ListingModel.MemberAssociationID"
                                                                    ng-options="memberAssociations.MemberAssociationID as memberAssociations.MemberAssociation for memberAssociations in PropertyModel.memberAssociations"
                                                                    id="memberAssociations" name="memberAssociations" required><option value="">-- select --</option></select>
                                                            <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                                                <span  ng-show="PropertyForm.memberAssociations.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Member Association'))}}</span>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 form-group">
                                                        <div class="col-md-2 col-xs-12" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.NoOf3by4Baths.$invalid}" ng-if="PropertyModel.ListingModel.ClassID!=3 && PropertyModel.ListingModel.ClassID!=4 && PropertyModel.ListingModel.ClassID!=6 && PropertyModel.ListingModel.ClassID!=5"> <!-- remove ng-if if allow to all class -->
                                                            <label for="NoOf3by4Baths" class="control-label">Baths - 3/4</label>
                                                            <input type="text" class="form-control" name="NoOf3by4Baths"  ng-model="PropertyModel.ListingModel.NoOf3by4Baths" required  maxlength="3" intype="digit">
                                                            <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                                                <span  ng-show="PropertyForm.NoOf3by4Baths.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Bath 3/4'))}}</span>
                                                            </span>
                                                        </div>
                                                        <div class="col-md-2 col-xs-12" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.NoOfFullBaths.$invalid}" ng-if="PropertyModel.ListingModel.ClassID!=3 && PropertyModel.ListingModel.ClassID!=4 && PropertyModel.ListingModel.ClassID!=6 && PropertyModel.ListingModel.ClassID!=5"><!-- remove ng-if if allow to all class -->
                                                            <label for="NoOfFullBaths" class="control-label">Baths - Full</label>
                                                            <input type="text" class="form-control" name="NoOfFullBaths"  ng-model="PropertyModel.ListingModel.NoOfFullBaths" required  maxlength="3" intype="digit">
                                                            <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                                                <span  ng-show="PropertyForm.NoOfFullBaths.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Full Bath'))}}</span>
                                                            </span>
                                                        </div>
                                                        <div class="col-md-2 col-xs-12" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.NoOfHalfBaths.$invalid}" ng-if="PropertyModel.ListingModel.ClassID!=3 && PropertyModel.ListingModel.ClassID!=4 && PropertyModel.ListingModel.ClassID!=6 && PropertyModel.ListingModel.ClassID!=5"><!-- remove ng-if if allow to all class -->
                                                            <label for="NoOfHalfBaths" class="control-label">Baths - Half</label>
                                                            <input type="text" class="form-control" name="NoOfHalfBaths"  ng-model="PropertyModel.ListingModel.NoOfHalfBaths" required  maxlength="3" intype="digit">
                                                            <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                                                <span  ng-show="PropertyForm.NoOfHalfBaths.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Half Bath'))}}</span>
                                                            </span>
                                                        </div>
                                                        <div class="col-md-2 col-xs-12" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.NoOfBeds.$invalid}" ng-if="PropertyModel.ListingModel.ClassID!=3 && PropertyModel.ListingModel.ClassID!=4 && PropertyModel.ListingModel.ClassID!=6 && PropertyModel.ListingModel.ClassID!=5"><!-- remove ng-if if allow to all class -->
                                                            <label for="NoOfBeds" class="control-label">Bedrooms</label>
                                                            <input type="text" class="form-control" name="NoOfBeds"  ng-model="PropertyModel.ListingModel.NoOfBeds" required  maxlength="3" intype="digit">
                                                            <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                                                <span  ng-show="PropertyForm.NoOfBeds.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Beds'))}}</span>
                                                            </span>
                                                        </div>
                                                        <div class="col-md-2 col-xs-12" ng-class="{ 'has-error' : (PropertyForm.$submitted) && (PropertyForm.YearBuilt.$invalid || PropertyForm.YearBuilt.$error.invalidYear)}" ng-if="PropertyModel.ListingModel.ClassID!=5 && PropertyModel.ListingModel.ClassID!=6">
                                                            <label for="YearBuilt" class="control-label">Year Built</label>
                                                            <input type="text" class="form-control" name="YearBuilt" id="year-built" future-year-not-allowed ng-model="PropertyModel.ListingModel.YearBuilt" maxlength="4" intype="digit" minlength="4">
                                                            <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                                                <span ng-show="PropertyForm.YearBuilt.$error.minlength">{{ trans('messages.InvalidYear')}}</span>
                                                                <span class="msg-error" ng-show="PropertyForm.YearBuilt.$error.invalidYear">{{trans('messages.FutureYear')}}</span>
                                                            </span>
                                                        </div>
                                                        <div class="col-md-2 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID!=5 && PropertyModel.ListingModel.ClassID!=3 && PropertyModel.ListingModel.ClassID!=6">
                                                            <label for="TotalSqFt" class="control-label">Total Sqft</label>
                                                            <input type="text" class="form-control" name="TotalSqFt"  ng-model="PropertyModel.ListingModel.TotalSqFt" intype="positiveNumeric" maxlength="16">
                                                        </div>
                                                        <div ng-if="PropertyModel.ListingModel.ClassID!=5 && PropertyModel.ListingModel.ClassID!=3 && PropertyModel.ListingModel.ClassID!=6 && PropertyModel.ListingModel.ClassID!=4" class="clearboth"></div>
                                                        <div class="col-md-2 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID!=2">
                                                            <label for="NbrOfAcres" class="control-label">Nbr Of Acres</label>
                                                            <input type="text" class="form-control" name="NbrOfAcres"  ng-model="PropertyModel.ListingModel.NbrOfAcres" intype="positiveNumeric" maxlength="16">
                                                        </div>
                                                        <div class="col-md-2 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID!=2">
                                                            <label for="LotSqFt" class="control-label">Lot SqFt</label>
                                                            <input type="text" class="form-control" name="LotSqFt"  ng-model="PropertyModel.ListingModel.LotSqFt" intype="positiveNumeric" maxlength="21">
                                                        </div>
                                                        <div class="col-md-2 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID!=4 && PropertyModel.ListingModel.ClassID!=7">
                                                            <label for="Auction" class="control-label">Auction</label>
                                                            <select ng-model="PropertyModel.ListingModel.Auction" class="form-control">
                                                                <option value="">-- select --</option>
                                                                <option value="1">Yes</option>
                                                                <option value="2">No</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-2 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID!=5 && PropertyModel.ListingModel.ClassID!=6" ng-class="{ 'has-error' : (PropertyForm.$submitted) && (PropertyForm.YearRemodeled.$invalid || PropertyForm.YearRemodeled.$error.invalidRemodeledYear)}">
                                                            <label for="YearRemodeled" class="control-label">Year Remodeled</label>
                                                            <input type="text" class="form-control" name="YearRemodeled"  ng-model="PropertyModel.ListingModel.YearRemodeled" remodeled-year="year-built" maxlength="4" minlength="4" >
                                                            <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                                                <span ng-show="PropertyForm.YearRemodeled.$error.minlength">{{ trans('messages.InvalidYear')}}</span>
                                                                <span class="msg-error" ng-show="PropertyForm.YearRemodeled.$error.invalidRemodeledYear">{{trans('messages.InvalidYearRemodeled')}}</span>
                                                            </span>
                                                        </div>

                                                        <div class="col-md-4 col-xs-12" ng-if="PropertyModel.SubType != ''" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.SubType.$invalid}">
                                                            <label for="SubType" class="control-label">Sub Type</label>
                                                            <select class="form-control" ng-model="PropertyModel.ListingModel.SubTypeID"
                                                                    ng-options="SubType.SubTypeID as SubType.SubType for SubType in PropertyModel.SubType"
                                                                    id="SubType" name="SubType"><option value="">-- select --</option></select>
                                                        </div>
                                                        <div class="clearboth"></div>
                                                        <div class="col-md-3  margin-top-25">
                                                            <label class="control-label"> Is Hidden?</label>
                                                            <label class="ng-binding"><input  type="radio" id="IsHidden" ng-model="PropertyModel.ListingModel.IsHidden" name="IsHidden"  value="1"/> Yes</label>
                                                            <label class="ng-binding"><input  type="radio" id="IsHidden" ng-model="PropertyModel.ListingModel.IsHidden" name="IsHidden"  value="0"/> No</label>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 form-group"  ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.Legal.$invalid}">
                                                        <div class="form-group col-md-12">
                                                            <label for="Legal" class="control-label">Legal</label>
                                                            <input class="form-control" type="text" maxlength="1000" name="Legal" ng-model="PropertyModel.ListingModel.Legal" required>
                                                            <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                                                <span  ng-show="PropertyForm.Legal.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Legal'))}}</span>
                                                            </span>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-12 form-group" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.OneLineDescription.$invalid}">
                                                        <div class="form-group col-md-12">
                                                            <label for="OneLineDescription" class="control-label">One Line Description</label>
                                                            <input class="form-control" type="text" maxlength="1000" name="OneLineDescription" ng-model="PropertyModel.ListingModel.OneLineDescription">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 form-group">
                                                        <div class="form-group col-md-12">
                                                            <label for="PublicRemark" class="control-label">Public Remark / Description</label>
                                                            <textarea class="form-control" ng-model="PropertyModel.ListingModel.PublicRemark" rows="6" name="PublicRemark"></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 form-group display-none">
                                                        <div class="form-group col-md-12">
                                                            <label for="Description" class="control-label">Description/Remarks</label>
                                                            <textarea class="form-control" ng-model="PropertyModel.ListingModel.Description" rows="6" name="Description"></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="portlet box blue-hoki" ng-cloak>
                                <div class="portlet-title" collapse>
                                    <div class="caption">
                                        <i class=""></i>LOCATION DETAILS</div>
                                    <div class="tools">
                                        <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                    </div>
                                </div>
                                <div class="portlet-body">
                                    <div class="form-body" >
                                        <div class="row">
                                            <div class="col-md-12 no-padding">
                                                <div class="row">
                                                    <div class="col-md-12 form-group">
                                                        <div class="col-md-3 col-xs-12" >
                                                            <label for="StreetNo" class="control-label">Street #</label>
                                                            <input type="text" class="form-control" name="StreetNo"  ng-model="PropertyModel.ListingModel.StreetNo" intype="digit" maxlength="10">
                                                        </div>
                                                        <div class="col-md-3 col-xs-12" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.Street.$invalid}">
                                                            <label for="Street" class="control-label">Street</label>
                                                            <input type="text" class="form-control" name="Street"  ng-model="PropertyModel.ListingModel.Street" required maxlength="30">
                                                            <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                                                <span  ng-show="PropertyForm.Street.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Street'))}}</span>
                                                            </span>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.City.$invalid}">
                                                            <label for="City" class="control-label">City</label>
                                                            <input type="text" class="form-control" name="City"  ng-model="PropertyModel.ListingModel.City" required maxlength="100">
                                                            <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                                                <span  ng-show="PropertyForm.City.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'City'))}}</span>
                                                            </span>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.County.$invalid}">
                                                            <label for="County" class="control-label">County</label>
                                                            <input type="text" class="form-control" name="County"  ng-model="PropertyModel.ListingModel.County" required maxlength="100 ">
                                                            <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                                                <span  ng-show="PropertyForm.County.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'County'))}}</span>
                                                            </span>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.ZipCode.$invalid}">
                                                            <label for="ZipCode" class="control-label">ZipCode</label>
                                                            <input type="text" class="form-control" name="ZipCode"  ng-model="PropertyModel.ListingModel.ZipCode" ng-pattern="<?php echo Constants::$zipRegex; ?>" intype="digit" required maxlength="5">
                                                            <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                                                <span  ng-show="PropertyForm.ZipCode.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'ZipCode'))}}</span>
                                                                <span ng-show="PropertyForm.ZipCode.$error.pattern">{{ trans('messages.InvalidCoZipCode')}}</span>
                                                            </span>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12">
                                                            <label for="Address2ORUnit" class="control-label">Address 2/Unit #</label>
                                                            <input type="text" class="form-control" name="Address2ORUnit"  ng-model="PropertyModel.ListingModel.Address2ORUnit">
                                                        </div>
                                                        <div class="col-md-3 col-xs-12" >
                                                            <label for="StreetDirectionPfx" class="control-label">Street Direction Pfx</label>
                                                            <select class="form-control" ng-model="PropertyModel.ListingModel.StreetDirectionPfxID"
                                                                    ng-options="StreetDirectionPfx.StreetDirectionPfxID as StreetDirectionPfx.StreetDirectionPfx for StreetDirectionPfx in PropertyModel.StreetDirectionPfx"
                                                                    id="Areas" name="StreetDirectionPfx"><option value="">-- select --</option></select>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12">
                                                            <label for="StreetSuffix" class="control-label">Street Suffix</label>
                                                            <select class="form-control" ng-model="PropertyModel.ListingModel.StreetSuffixID"
                                                                    ng-options="StreetSuffix.StreetSuffixID as StreetSuffix.StreetSuffix for StreetSuffix in PropertyModel.StreetSuffixes"
                                                                    id="StreetSuffix" name="StreetSuffix"><option value="">-- select --</option></select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 form-group">
                                                        <div class="col-md-3 col-xs-12" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.MajorArea.$invalid}">
                                                            <label for="MajorArea" class="control-label">Major Area</label>
                                                            <select class="form-control" ng-model="PropertyModel.ListingModel.MajorAreaID"
                                                                    ng-options="MajorAreas.MajorAreaID as MajorAreas.MajorArea for MajorAreas in PropertyModel.MajorAreas"
                                                                    id="MajorArea" name="MajorArea" required=""><option value="">-- select --</option></select>
                                                            <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                                                <span  ng-show="PropertyForm.MajorArea.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Major Area'))}}</span>
                                                            </span>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.Areas.$invalid}">
                                                            <label for="Areas" class="control-label">Area</label>
                                                            <select class="form-control" ng-model="PropertyModel.ListingModel.AreaID"
                                                                    ng-options="Areas.AreaID as Areas.Area for Areas in PropertyModel.Areas"
                                                                    id="Areas" name="Areas" required><option value="">-- select --</option></select>
                                                            <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                                                <span  ng-show="PropertyForm.Areas.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Area'))}}</span>
                                                            </span>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12" ng-class="{ 'has-error' : (PropertyForm.$submitted) && PropertyForm.States.$invalid}">
                                                            <label for="States" class="control-label">States</label>
                                                            <select class="form-control" ng-model="PropertyModel.ListingModel.StateID"
                                                                    ng-options="State.StateID as State.State for State in PropertyModel.State"
                                                                    id="States" name="States" required><option value="">-- select --</option></select>
                                                            <span class="error-text-color" ng-show="PropertyForm.$submitted">
                                                                <span  ng-show="PropertyForm.States.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'State'))}}</span>
                                                            </span>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12">
                                                            <label for="SubLoc" class="control-label">Sub Location</label>
                                                            <select class="form-control" ng-model="PropertyModel.ListingModel.SubLocID"
                                                                    ng-options="SubLoc.SubLocID as SubLoc.SubLoc for SubLoc in PropertyModel.SubLocs"
                                                                    id="SubLoc" name="SubLoc"><option value="">-- select --</option></select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 form-group">
                                                        <div class="col-md-3 col-xs-12" ng-if="PropertyModel.LocationAmenity != ''">
                                                            <label for="LocationAmenity" class="control-label">Location Amenity</label>
                                                            <select class="form-control" ng-model="PropertyModel.ListingModel.LocationAmenity" multiple
                                                                    ng-options="LocationAmenity.LocationAmenityID as LocationAmenity.LocationAmenity for LocationAmenity in PropertyModel.LocationAmenity"
                                                                    id="LocationAmenity" name="LocationAmenity"></select>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12" ng-if="PropertyModel.Accesses != ''">
                                                            <label for="Access" class="control-label">Accesse</label>
                                                            <select class="form-control" ng-model="PropertyModel.ListingModel.Accesses" multiple
                                                                    ng-options="Accesses.AccessID as Accesses.Access for Accesses in PropertyModel.Accesses"
                                                                    id="Access" name="Access"></select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="portlet box blue-hoki" ng-cloak>
                                <div class="portlet-title" collapse>
                                    <div class="caption">
                                        <i class=""></i>INTERIOR FEATURES</div>
                                    <div class="tools">
                                        <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                    </div>
                                </div>
                                <div class="portlet-body">
                                    <div class="form-body" >
                                        <div class="row">
                                            <div class="col-md-12 no-padding">
                                                <div class="row">
                                                    <div class="col-md-12 form-group">
                                                        <div class="col-md-4 col-lg-3 col-xs-12" >
                                                            <label for="NoOfStories" class="control-label">No. Of Stories</label>
                                                            <input class="form-control" type="text" name="NoOfStories" ng-model="PropertyModel.ListingModel.NoOfStories" maxlength="8" intype="positiveNumeric">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1 || PropertyModel.ListingModel.ClassID==2 || PropertyModel.ListingModel.ClassID==7">
                                                            <label for="UnfinishedSqFt" class="control-label">Unfinished SqFt</label>
                                                            <input class="form-control" type="text" name="UnfinishedSqFt" ng-model="PropertyModel.ListingModel.UnfinishedSqFt" intype="alphaNumeric" maxlength="21">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1 || PropertyModel.ListingModel.ClassID==2">
                                                            <label for="Bedroom1RoomLevel" class="control-label">Bedroom 1 Room Level</label>
                                                            <input class="form-control" type="text" name="Bedroom1RoomLevel" ng-model="PropertyModel.ListingModel.Bedroom1RoomLevel" maxlength="25">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1 || PropertyModel.ListingModel.ClassID==2">
                                                            <label for="Bedroom2RoomLevel" class="control-label">Bedroom 2 Room Level</label>
                                                            <input class="form-control" type="text" name="Bedroom2RoomLevel" ng-model="PropertyModel.ListingModel.Bedroom2RoomLevel" maxlength="25">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1 || PropertyModel.ListingModel.ClassID==2">
                                                            <label for="Bedroom3RoomLevel" class="control-label">Bedroom 3 Room Level</label>
                                                            <input class="form-control" type="text" name="Bedroom3RoomLevel" ng-model="PropertyModel.ListingModel.Bedroom3RoomLevel" maxlength="25">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1">
                                                            <label for="Bedroom4PlusRoomLevel" class="control-label">Bedroom 4+ Room Level</label>
                                                            <input class="form-control" type="text" name="Bedroom4PlusRoomLevel" ng-model="PropertyModel.ListingModel.Bedroom4PlusRoomLevel" maxlength="25">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1">
                                                            <label for="Bedroom4PlusRoomRemarks" class="control-label">Bedroom 4+ Room Remarks</label>
                                                            <input class="form-control" type="text" name="Bedroom4PlusRoomRemarks" ng-model="PropertyModel.ListingModel.Bedroom4PlusRoomRemarks" maxlength="25">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1" >
                                                            <label for="FamilyRoomRoomLevel" class="control-label">Family Room: Room Level</label>
                                                            <input class="form-control" type="text" name="FamilyRoomRoomLevel" ng-model="PropertyModel.ListingModel.FamilyRoomRoomLevel" maxlength="25">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1 || PropertyModel.ListingModel.ClassID==2">
                                                            <label for="FullBathRoomLevel" class="control-label">Full Bath: Room Level</label>
                                                            <input class="form-control" type="text" name="FullBathRoomLevel" ng-model="PropertyModel.ListingModel.FullBathRoomLevel" maxlength="25">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1">
                                                            <label for="LaundryOrUtilityRoomRoomLevel" class="control-label">Laundry/Utility Room: Room Level</label>
                                                            <input class="form-control" type="text" name="LaundryOrUtilityRoomRoomLevel" ng-model="PropertyModel.ListingModel.LaundryOrUtilityRoomRoomLevel" maxlength="25">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1 || PropertyModel.ListingModel.ClassID==2" >
                                                            <label for="LivingRoomRoomLevel" class="control-label">Living Room: Room Level</label>
                                                            <input class="form-control" type="text" name="LivingRoomRoomLevel" ng-model="PropertyModel.ListingModel.LivingRoomRoomLevel" maxlength="25">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1 || PropertyModel.ListingModel.ClassID==2">
                                                            <label for="Bedroom1Width" class="control-label">Bedroom 1 Width</label>
                                                            <input class="form-control" type="text" name="Bedroom1Width" ng-model="PropertyModel.ListingModel.Bedroom1Width" maxlength="25">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1 || PropertyModel.ListingModel.ClassID==2">
                                                            <label for="DiningRoomLength" class="control-label">Dining Room Length</label>
                                                            <input class="form-control" type="text" name="DiningRoomLength" ng-model="PropertyModel.ListingModel.DiningRoomLength" maxlength="25">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1 || PropertyModel.ListingModel.ClassID==2">
                                                            <label for="DiningRoomWidth" class="control-label">Dining Room Width</label>
                                                            <input class="form-control" type="text" name="DiningRoomWidth" ng-model="PropertyModel.ListingModel.DiningRoomWidth" maxlength="25">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3  col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1 || PropertyModel.ListingModel.ClassID==2">
                                                            <label for="DiningRoomNoofRooms" class="control-label">Dining Room: Number of Rooms</label>
                                                            <input class="form-control" type="text" name="DiningRoomNoofRooms" ng-model="PropertyModel.ListingModel.DiningRoomNoofRooms" maxlength="25">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1 || PropertyModel.ListingModel.ClassID==2">
                                                            <label for="DiningRoomRoomLevel" class="control-label">Dining Room: Room Level</label>
                                                            <input class="form-control" type="text" name="DiningRoomRoomLevel" ng-model="PropertyModel.ListingModel.DiningRoomRoomLevel" maxlength="25">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1 || PropertyModel.ListingModel.ClassID==2">
                                                            <label for="KitchenLength" class="control-label">Kitchen Length</label>
                                                            <input class="form-control" type="text" name="KitchenLength" ng-model="PropertyModel.ListingModel.KitchenLength" maxlength="25">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1 || PropertyModel.ListingModel.ClassID==2">
                                                            <label for="KitchenWidth" class="control-label">Kitchen Width</label>
                                                            <input class="form-control" type="text" name="KitchenWidth" ng-model="PropertyModel.ListingModel.KitchenWidth" maxlength="25">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1 || PropertyModel.ListingModel.ClassID==2">
                                                            <label for="KitchenNoofRooms" class="control-label">Kitchen: Number of Rooms</label>
                                                            <input class="form-control" type="text" name="KitchenNoofRooms" ng-model="PropertyModel.ListingModel.KitchenNoofRooms" maxlength="25">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1 || PropertyModel.ListingModel.ClassID==2">
                                                            <label for="KitchenRoomLevel" class="control-label">Kitchen: Room Level</label>
                                                            <input class="form-control" type="text" name="KitchenRoomLevel" ng-model="PropertyModel.ListingModel.KitchenRoomLevel" maxlength="10">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1 || PropertyModel.ListingModel.ClassID==2">
                                                            <label for="LivingRoomNoofRooms" class="control-label">Living Room: Number of Rooms</label>
                                                            <input class="form-control" type="text" name="LivingRoomNoofRooms" ng-model="PropertyModel.ListingModel.LivingRoomNoofRooms" maxlength="25">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1 || PropertyModel.ListingModel.ClassID==2">
                                                            <label for="LivingRoomWidth" class="control-label">Living Room Width</label>
                                                            <input class="form-control" type="text" name="LivingRoomWidth" ng-model="PropertyModel.ListingModel.LivingRoomWidth" maxlength="25">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3  col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1 || PropertyModel.ListingModel.ClassID==2">
                                                            <label for="LivingRoomLength" class="control-label">Living Room Length</label>
                                                            <input class="form-control" type="text" name="LivingRoomLength" ng-model="PropertyModel.ListingModel.LivingRoomLength" maxlength="25">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3  col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1">
                                                            <label for="FireplaceNoofFireplaces" class="control-label">Fireplace: Number of Fireplaces</label>
                                                            <input class="form-control" type="text" name="FireplaceNoofFireplaces" ng-model="PropertyModel.ListingModel.FireplaceNoofFireplaces" maxlength="25">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1 || PropertyModel.ListingModel.ClassID==2 || PropertyModel.ListingModel.ClassID==7">
                                                            <label for="HeatedSqFt" class="control-label">Heated SqFt</label>
                                                            <input class="form-control" type="text" name="HeatedSqFt" ng-model="PropertyModel.ListingModel.HeatedSqFt" intype="positiveNumeric" maxlength="21">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1 || PropertyModel.ListingModel.ClassID==2 || PropertyModel.ListingModel.ClassID==7">
                                                            <label for="HeatedSqFtAbvGrnd" class="control-label">Heated SqFt (Above Ground)</label>
                                                            <input class="form-control" type="text" name="HeatedSqFtAbvGrnd" ng-model="PropertyModel.ListingModel.HeatedSqFtAbvGrnd" intype="positiveNumeric"  maxlength="21">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1 || PropertyModel.ListingModel.ClassID==2 || PropertyModel.ListingModel.ClassID==7">
                                                            <label for="HeatedSqFtBlwGrnd" class="control-label">Heated SqFt (Below Ground)</label>
                                                            <input class="form-control" type="text" name="HeatedSqFtBlwGrnd" ng-model="PropertyModel.ListingModel.HeatedSqFtBlwGrnd" intype="positiveNumeric"  maxlength="21">
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" ng-if="PropertyModel.Furnishes != ''">
                                                            <label for="Furnish" class="control-label">Furnished</label>
                                                            <select class="form-control" ng-model="PropertyModel.ListingModel.FurnishID"
                                                                    ng-options="Furnishes.FurnishID as Furnishes.Furnish for Furnishes in PropertyModel.Furnishes"
                                                                    id="Furnish" name="Furnish"><option value="">-- select --</option></select>
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" ng-if="PropertyModel.Coolings != ''">
                                                            <label for="Coolings" class="control-label">Cooling</label>
                                                            <select class="form-control" ng-model="PropertyModel.ListingModel.CoolingID"
                                                                    ng-options="Coolings.CoolingID as Coolings.Cooling for Coolings in PropertyModel.Coolings"
                                                                    id="Coolings" name="Coolings"><option value="">-- select --</option></select>
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" >
                                                            <label for="IndoorAirPlus" class="control-label">Indoor Air Plus</label>
                                                            <select ng-model="PropertyModel.ListingModel.IndoorAirPlus" class="form-control" name="IndoorAirPlus">
                                                                <option value="">-- select --</option>
                                                                <option value="1">Yes</option>
                                                                <option value="2">No</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==7">
                                                            <label for="MaxNumberOccupants" class="control-label">Max Number Occupants</label>
                                                            <input class="form-control" type="text" name="MaxNumberOccupants" ng-model="PropertyModel.ListingModel.MaxNumberOccupants" maxlength="3" intype="digit">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 form-group">
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.Laundry!=''">
                                                            <label for="Laundry" class="control-label">Laundry</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Laundry"
                                                                    ng-options="Laundry.LaundryID as Laundry.Laundry for Laundry in PropertyModel.Laundry"
                                                                    id="Laundry" name="Laundry"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.FirePlaces!=''">
                                                            <label for="FirePlace" class="control-label">FirePlace</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.FirePlaces"
                                                                    ng-options="FirePlaces.FireplaceID as FirePlaces.Fireplace for FirePlaces in PropertyModel.FirePlaces"
                                                                    id="FirePlace" name="FirePlace"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.MainLevel!=''">
                                                            <label for="MainLevel" class="control-label">Main Level</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.MainLevel"
                                                                    ng-options="MainLevel.MainLevelID as MainLevel.MainLevel for MainLevel in PropertyModel.MainLevel"
                                                                    id="MainLevel" name="MainLevel"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.LowerLevel!=''">
                                                            <label for="LowerLevel" class="control-label">Lower Level</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.LowerLevel"
                                                                    ng-options="LowerLevel.LowerLevelID as LowerLevel.LowerLevel for LowerLevel in PropertyModel.LowerLevel"
                                                                    id="LowerLevel" name="LowerLevel"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.OtherCooling!=''">
                                                            <label for="OtherCooling" class="control-label">Other Cooling</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.OtherCooling"
                                                                    ng-options="OtherCooling.OtherCoolingID as OtherCooling.OtherCooling for OtherCooling in PropertyModel.OtherCooling"
                                                                    id="OtherCooling" name="OtherCooling"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.IndoorAirQuality!=''">
                                                            <label for="IndoorAirQuality" class="control-label">Indoor Air Quality</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.IndoorAirQuality"
                                                                    ng-options="IndoorAirQuality.IndoorAirQualityID as IndoorAirQuality.IndoorAirQuality for IndoorAirQuality in PropertyModel.IndoorAirQuality"
                                                                    id="IndoorAirQuality" name="IndoorAirQuality"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.UpperLevel!=''">
                                                            <label for="UpperLevel" class="control-label">Upper Level</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.UpperLevel"
                                                                    ng-options="UpperLevel.UpperLevelID as UpperLevel.UpperLevel for UpperLevel in PropertyModel.UpperLevel"
                                                                    id="UpperLevel" name="UpperLevel"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.HeatingAndCoolings!=''">
                                                            <label for="HeatingAndCoolings" class="control-label">Heating/Coolings</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.HeatingAndCoolings"
                                                                    ng-options="HeatingAndCoolings.HeatingAndCoolingID as HeatingAndCoolings.HeatingAndCooling for HeatingAndCoolings in PropertyModel.HeatingAndCoolings"
                                                                    id="HeatingAndCoolings" name="HeatingAndCoolings" clear-other select-val="PropertyModel.ListingModel.HeatingAndCoolings"
                                                                    other-val="GetUpdateValue('HeatingAndCoolings','HeatingAndCoolingID','HeatingAndCooling')"
                                                                    other="PropertyModel.ListingModel.OtherHeatingAndCooling"
                                                                    ></select>
                                                            <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.HeatingAndCoolings.indexOf(GetUpdateValue('HeatingAndCoolings','HeatingAndCoolingID','HeatingAndCooling')) > -1">
                                                                <label for="OtherHeatingAndCooling" class="control-label">Other Heating/Coolings</label>
                                                                <input class="form-control" ng-model="PropertyModel.ListingModel.OtherHeatingAndCooling" type="text" name="OtherHeatingAndCooling" maxlength="100"/>
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.Heatings!=''">
                                                            <label for="Heatings" class="control-label">Heating</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Heatings"
                                                                    ng-options="Heatings.HeatingID as Heatings.Heating for Heatings in PropertyModel.Heatings"
                                                                    id="Heatings" name="Heatings" clear-other select-val="PropertyModel.ListingModel.Heatings"
                                                                    other-val="GetUpdateValue('Heatings','HeatingID','Heating')"
                                                                    other="PropertyModel.ListingModel.OtherHeating"
                                                                    ></select>
                                                            <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.Heatings.indexOf(GetUpdateValue('Heatings','HeatingID','Heating')) > -1">
                                                                <label for="OtherHeating" class="control-label">Other Heating</label>
                                                                <input class="form-control" ng-model="PropertyModel.ListingModel.OtherHeating" type="text" name="OtherHeating" maxlength="100"/>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="portlet box blue-hoki" ng-cloak>
                                <div class="portlet-title" collapse>
                                    <div class="caption">
                                        <i class=""></i>ADDITIONAL FEATURES</div>
                                    <div class="tools">
                                        <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                    </div>
                                </div>
                                <div class="portlet-body">
                                    <div class="form-body" >
                                        <div class="row">
                                            <div class="col-md-12 no-padding">
                                                <div class="row">
                                                    <div class="col-md-12 form-group">
                                                        <div class="col-md-3 col-xs-12">
                                                            <label for="ADU" class="control-label">ADU</label>
                                                            <select ng-model="PropertyModel.ListingModel.ADU" class="form-control" name="ADU">
                                                                <option value="">-- select --</option>
                                                                <option value="1">Yes</option>
                                                                <option value="2">No</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12">
                                                            <label for="ListNumberMain" class="control-label">List Number Main</label>
                                                            <input type="text" class="form-control" name="ListNumberMain"  ng-model="PropertyModel.ListingModel.ListNumberMain" maxlength="6" intype="digit">
                                                        </div>
                                                        <div class="col-md-3 col-xs-12">
                                                            <label for="Zoning" class="control-label">Zoning</label>
                                                            <input type="text" class="form-control" name="Zoning"  ng-model="PropertyModel.ListingModel.Zoning" maxlength="100">
                                                        </div>
                                                        <div class="col-md-3 col-xs-12">
                                                            <label for="SpecialAssessments" class="control-label">Special Assessments</label>
                                                            <input type="text" class="form-control" name="SpecialAssessments"  ng-model="PropertyModel.ListingModel.SpecialAssessments" maxlength="100">
                                                        </div>
                                                        <div class="col-md-3 col-xs-12">
                                                            <label for="Condominiumized" class="control-label">Condominiumized</label>
                                                            <select ng-model="PropertyModel.ListingModel.Condominiumized" class="form-control" name="Condominiumized">
                                                                <option value="">-- select --</option>
                                                                <option value="1">Yes</option>
                                                                <option value="2">No</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12" >
                                                            <label for="FAR" class="control-label">FAR</label>
                                                            <select ng-model="PropertyModel.ListingModel.FAR" class="form-control" name="FAR">
                                                                <option value="">-- select --</option>
                                                                <option value="1">Yes</option>
                                                                <option value="2">No</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12" >
                                                            <label for="Pets" class="control-label">Pets</label>
                                                            <select ng-model="PropertyModel.ListingModel.Pets" class="form-control" name="Pets">
                                                                <option value="">-- select --</option>
                                                                <option value="1">Yes</option>
                                                                <option value="2">No</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12">
                                                            <label for="Inventory" class="control-label">Inventory</label>
                                                            <select ng-model="PropertyModel.ListingModel.Inventory" class="form-control" name="Inventory">
                                                                <option value="">-- select --</option>
                                                                <option value="1">Yes</option>
                                                                <option value="2">No</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12">
                                                            <label for="PUD" class="control-label">PUD</label>
                                                            <select ng-model="PropertyModel.ListingModel.PUD" class="form-control" name="PUD">
                                                                <option value="">-- select --</option>
                                                                <option value="1">Yes</option>
                                                                <option value="2">No</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12">
                                                            <label for="UnderConstruction" class="control-label">Under Construction</label>
                                                            <select ng-model="PropertyModel.ListingModel.UnderConstruction" class="form-control" name="UnderConstruction">
                                                                <option value="">-- select --</option>
                                                                <option value="1">Yes</option>
                                                                <option value="2">No</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12">
                                                            <label for="VacationTrading" class="control-label">Vacation Trading</label>
                                                            <input type="text" class="form-control" name="VacationTrading"  ng-model="PropertyModel.ListingModel.VacationTrading" maxlength="50">
                                                        </div>
                                                        <div class="col-md-3 col-xs-12">
                                                            <label for="BusinessName" class="control-label">Business Name</label>
                                                            <input type="text" class="form-control" name="BusinessName"  ng-model="PropertyModel.ListingModel.BusinessName" maxlength="100">
                                                        </div>
                                                        <div class="col-md-3 col-xs-12" ng-if="PropertyModel.RentalTerms != ''">
                                                            <label for="RentalTerm" class="control-label">Rental Term</label>
                                                            <select class="form-control" ng-model="PropertyModel.ListingModel.RentalTermID"
                                                                    ng-options="RentalTerm.RentalTermID as RentalTerm.RentalTerm for RentalTerm in PropertyModel.RentalTerms"
                                                                    id="RentalTerm" name="RentalTerm"><option value="">-- select --</option></select>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12" ng-if="PropertyModel.OwnershipInterest != ''">
                                                            <label for="OwnershipInterest" class="control-label">Ownership Interest</label>
                                                            <select class="form-control" ng-model="PropertyModel.ListingModel.OwnershipInterestID"
                                                                    ng-options="OwnershipInterest.OwnershipInterestID as OwnershipInterest.OwnershipInterest for OwnershipInterest in PropertyModel.OwnershipInterest"
                                                                    id="OwnershipInterest" name="OwnershipInterest"><option value="">-- select --</option></select>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12" ng-if="PropertyModel.SeasonalInterest !=''">
                                                            <label for="SeasonalInterest" class="control-label">Seasonal Interest</label>
                                                            <select class="form-control" ng-model="PropertyModel.ListingModel.SeasonalInterestID"
                                                                    ng-options="SeasonalInterest.SeasonalInterestID as SeasonalInterest.SeasonalInterest for SeasonalInterest in PropertyModel.SeasonalInterest"
                                                                    id="SeasonalInterest" name="SeasonalInterest"><option value="">-- select --</option></select>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12" ng-if="PropertyModel.ApprovalFeatures != ''" >
                                                            <label for="ApprovalFeatures" class="control-label">Approval Feature</label>
                                                            <select class="form-control" ng-model="PropertyModel.ListingModel.ApprovalFeatureID"
                                                                    ng-options="ApprovalFeatures.ApprovalFeatureID as ApprovalFeatures.ApprovalFeature for ApprovalFeatures in PropertyModel.ApprovalFeatures"
                                                                    id="ApprovalFeatures" name="ApprovalFeatures"><option value="">-- select --</option></select>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12" ng-if="PropertyModel.BuildingSqFt != ''" >
                                                            <label for="BuildingSqFt" class="control-label">Building SqFt</label>
                                                            <select class="form-control" ng-model="PropertyModel.ListingModel.BuildingSqFtID"
                                                                    ng-options="BuildingSqFt.BuildingSqFtID as BuildingSqFt.BuildingSqFt for BuildingSqFt in PropertyModel.BuildingSqFt"
                                                                    id="BuildingSqFt" name="BuildingSqFt"><option value="">-- select --</option></select>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12">
                                                            <label for="EnergyStarRated" class="control-label">Energy Star Rated</label>
                                                            <select ng-model="PropertyModel.ListingModel.EnergyStarRated" class="form-control">
                                                                <option value="">-- select --</option>
                                                                <option value="1">Yes</option>
                                                                <option value="2">No</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.PreFabricatedHome!=''">
                                                            <label for="PreFabricatedHomeID" class="control-label">Pre-Fabricated Home</label>
                                                            <select class="form-control" ng-model="PropertyModel.ListingModel.PreFabricatedHomeID"
                                                                    ng-options="PreFabricatedHome.PreFabricatedHomeID as PreFabricatedHome.PreFabricatedHome for PreFabricatedHome in PropertyModel.PreFabricatedHome"
                                                                    id="PreFabricatedHomeID" name="PreFabricatedHomeID" clear-other select-val="PropertyModel.ListingModel.PreFabricatedHome"
                                                                    other-val="GetUpdateValue('PreFabricatedHome','PreFabricatedHomeID','PreFabricatedHome')"
                                                                    other="PropertyModel.ListingModel.OtherPreFabricatedHome"
                                                                    ><option value="">-- select --</option></select>
                                                            <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.PreFabricatedHome.indexOf(GetUpdateValue('PreFabricatedHome','PreFabricatedHomeID','PreFabricatedHome')) > -1">
                                                                <label for="OtherPreFabricatedHome" class="control-label">Other Pre-Fabricated Home</label>
                                                                <input class="form-control" ng-model="PropertyModel.ListingModel.OtherPreFabricatedHome" type="text" name="OtherPreFabricatedHome" maxlength="100"/>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 form-group additional-data" >
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.Conditions!=''">
                                                            <label for="Conditions" class="control-label">Condition</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Conditions"
                                                                    ng-options="Conditions.ConditionID as Conditions.Condition for Conditions in PropertyModel.Conditions"
                                                                    id="Conditions" name="Conditions"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.Electrics!=''">
                                                            <label for="Electrics" class="control-label">Electric</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Electrics"
                                                                    ng-options="Electrics.ElectricID as Electrics.Electric for Electrics in PropertyModel.Electrics"
                                                                    id="Electrics" name="Electrics"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.EnergyEfficiency!=''">
                                                            <label for="EnergyEfficiency" class="control-label">Energy Efficiency</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.EnergyEfficiency"
                                                                    ng-options="EnergyEfficiency.EnergyEfficiencyID as EnergyEfficiency.EnergyEfficiency for EnergyEfficiency in PropertyModel.EnergyEfficiency"
                                                                    id="EnergyEfficiency" name="EnergyEfficiency"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.Exclusions!=''">
                                                            <label for="Exclusions" class="control-label">Exclusions</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Exclusions"
                                                                    ng-options="Exclusions.ExclusionID as Exclusions.Exclusion for Exclusions in PropertyModel.Exclusions"
                                                                    id="Exclusions" name="Exclusions"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.Extras!=''">
                                                            <label for="Extras" class="control-label">Extra</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Extras"
                                                                    ng-options="Extras.ExtraID as Extras.Extra for Extras in PropertyModel.Extras"
                                                                    id="Extras" name="Extras"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.Gases!=''">
                                                            <label for="Gases" class="control-label">Gas</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Gases"
                                                                    ng-options="Gases.GasID as Gases.Gas for Gases in PropertyModel.Gases"
                                                                    id="Gases" name="Gases"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.Inclusion!=''">
                                                            <label for="Inclusion" class="control-label">Inclusion</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Inclusion"
                                                                    ng-options="Inclusion.InclusionID as Inclusion.Inclusion for Inclusion in PropertyModel.Inclusion"
                                                                    id="Inclusion" name="Inclusion"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.Inclusion!=''">
                                                            <label for="Possessions" class="control-label">Possessions</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Possessions"
                                                                    ng-options="Possessions.PossessionID as Possessions.Possession for Possessions in PropertyModel.Possessions"
                                                                    id="Possessions" name="Possessions"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.WaterRight!=''">
                                                            <label for="WaterRight" class="control-label">Water Right</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.WaterRight"
                                                                    ng-options="WaterRight.WaterRightID as WaterRight.WaterRight for WaterRight in PropertyModel.WaterRight"
                                                                    id="WaterRight" name="WaterRight"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.Amenities!=''">
                                                            <label for="Amenities" class="control-label">Amenities</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Amenities"
                                                                    ng-options="Amenities.AmenityID as Amenities.Amenity for Amenities in PropertyModel.Amenities"
                                                                    id="Amenities" name="Amenities"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.GreenFeatures!=''">
                                                            <label for="GreenFeatures" class="control-label">Green Features</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.GreenFeatures"
                                                                    ng-options="GreenFeatures.GreenFeatureID as GreenFeatures.GreenFeature for GreenFeatures in PropertyModel.GreenFeatures"
                                                                    id="GreenFeatures" name="GreenFeatures"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.HoaAmenities!=''">
                                                            <label for="HoaAmenities" class="control-label">HOA Amenities</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.HoaAmenities"
                                                                    ng-options="HoaAmenities.HOAAmenityID as HoaAmenities.HOAAmenity for HoaAmenities in PropertyModel.HoaAmenities"
                                                                    id="HoaAmenities" name="HoaAmenities"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.MineralRights!=''">
                                                            <label for="MineralRights" class="control-label">Mineral Right</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.MineralRights"
                                                                    ng-options="MineralRights.MineralRightID as MineralRights.MineralRight for MineralRights in PropertyModel.MineralRights"
                                                                    id="MineralRights" name="MineralRights"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.LeedCertified!=''">
                                                            <label for="LeedCertified" class="control-label">Leed Certified</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.LeedCertified"
                                                                    ng-options="LeedCertified.LeedCertifiedID as LeedCertified.LeedCertified for LeedCertified in PropertyModel.LeedCertified"
                                                                    id="LeedCertified" name="LeedCertified"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.LeedForHome!=''">
                                                            <label for="LeedForHome" class="control-label">Leed For Home</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.LeedForHome"
                                                                    ng-options="LeedForHome.LeedforHomeID as LeedForHome.LeedforHome for LeedForHome in PropertyModel.LeedForHome"
                                                                    id="LeedForHome" name="LeedForHome"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.PossibleUse!=''">
                                                            <label for="PossibleUse" class="control-label">Possible Use</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.PossibleUse"
                                                                    ng-options="PossibleUse.PossibleUseID as PossibleUse.PossibleUse for PossibleUse in PropertyModel.PossibleUse"
                                                                    id="PossibleUse" name="PossibleUse"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.SustainableMaterial!=''">
                                                            <label for="SustainableMaterial" class="control-label">Sustainable Material</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.SustainableMaterial"
                                                                    ng-options="SustainableMaterial.SustainableMaterialID as SustainableMaterial.SustainableMaterial for SustainableMaterial in PropertyModel.SustainableMaterial"
                                                                    id="SustainableMaterial" name="SustainableMaterial"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.WaterEfficiency!=''">
                                                            <label for="WaterEfficiency" class="control-label">Water Efficiency</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.WaterEfficiency"
                                                                    ng-options="WaterEfficiency.WaterEfficiencyID as WaterEfficiency.WaterEfficiency for WaterEfficiency in PropertyModel.WaterEfficiency"
                                                                    id="WaterEfficiency" name="WaterEfficiency"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.ShowingInstructions!=''">
                                                            <label for="ShowingInstructions" class="control-label">Showing Instruction</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.ShowingInstructions"
                                                                    ng-options="ShowingInstructions.ShowingInstructionID as ShowingInstructions.ShowingInstruction for ShowingInstructions in PropertyModel.ShowingInstructions"
                                                                    id="ShowingInstructions" name="ShowingInstructions"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.Sanitation!=''">
                                                            <label for="Sanitation" class="control-label">Sanitation</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Sanitation"
                                                                    ng-options="Sanitation.SanitationID as Sanitation.Sanitation for Sanitation in PropertyModel.Sanitation"
                                                                    id="Sanitation" name="Sanitation" clear-other select-val="PropertyModel.ListingModel.Sanitation"
                                                                    other-val="GetUpdateValue('Sanitation','SanitationID','Sanitation')"
                                                                    other="PropertyModel.ListingModel.OtherSanitation"
                                                                    ></select>
                                                            <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.Sanitation.indexOf(GetUpdateValue('Sanitation','SanitationID','Sanitation')) > -1">
                                                                <label for="OtherSanitation" class="control-label">Other Sanitation</label>
                                                                <input class="form-control" ng-model="PropertyModel.ListingModel.OtherSanitation" type="text" name="OtherSanitation" maxlength="100"/>
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.SubStructures!=''">
                                                            <label for="SubStructures" class="control-label">SubStructures</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.SubStructures"
                                                                    ng-options="SubStructures.SubstructureID as SubStructures.Substructure for SubStructures in PropertyModel.SubStructures"
                                                                    id="SubStructures" name="SubStructures" clear-other select-val="PropertyModel.ListingModel.SubStructures"
                                                                    other-val="GetUpdateValue('SubStructures','SubstructureID','Substructure')"
                                                                    other="PropertyModel.ListingModel.OtherSubStructure"
                                                                    ></select>
                                                            <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.SubStructures.indexOf(GetUpdateValue('SubStructures','SubstructureID','Substructure')) > -1">
                                                                <label for="OtherSubStructure" class="control-label">Other SubStructure</label>
                                                                <input class="form-control" ng-model="PropertyModel.ListingModel.OtherSubStructure" type="text" name="OtherSubStructure" maxlength="100"/>
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.TermsOffered!=''">
                                                            <label for="TermsOffered" class="control-label">Terms Offered</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.TermsOffered"
                                                                    ng-options="TermsOffered.TermsOfferedID as TermsOffered.TermsOffered for TermsOffered in PropertyModel.TermsOffered"
                                                                    id="TermsOffered" name="TermsOffered" clear-other select-val="PropertyModel.ListingModel.TermsOffered"
                                                                    other-val="GetUpdateValue('TermsOffered','TermsOfferedID','TermsOffered')"
                                                                    other="PropertyModel.ListingModel.OtherTermsOffered"
                                                                    ></select>
                                                            <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.TermsOffered.indexOf(GetUpdateValue('TermsOffered','TermsOfferedID','TermsOffered')) > -1">
                                                                <label for="OtherTermsOffered" class="control-label">Other Terms Offered</label>
                                                                <input class="form-control" ng-model="PropertyModel.ListingModel.OtherTermsOffered" type="text" name="OtherTermsOffered" maxlength="100"/>
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.Construction!=''">
                                                            <label for="Construction" class="control-label">Construction</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Construction"
                                                                    ng-options="Construction.ConstructionID as Construction.Construction for Construction in PropertyModel.Construction"
                                                                    id="Construction" name="Construction" clear-other select-val="PropertyModel.ListingModel.Construction"
                                                                    other-val="GetUpdateValue( 'Construction','ConstructionID','Construction' )"
                                                                    other="PropertyModel.ListingModel.OtherConstruction"
                                                                    ></select>
                                                            <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.Construction.indexOf(GetUpdateValue( 'Construction','ConstructionID','Construction' )) > -1">
                                                                <label for="OtherConstruction" class="control-label">Other Construction</label>
                                                                <input class="form-control" ng-model="PropertyModel.ListingModel.OtherConstruction" type="text" name="OtherConstruction" maxlength="100"/>
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.Water!=''">
                                                            <label for="Water" class="control-label">Water</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Water"
                                                                    ng-options="water.WaterID as water.Water for water in PropertyModel.Water"
                                                                    id="Water" name="Water" clear-other select-val="PropertyModel.ListingModel.Water"
                                                                    other-val="GetUpdateValue( 'Water','WaterID','Water' )"
                                                                    other="PropertyModel.ListingModel.OtherWater"
                                                                    ></select>
                                                           <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.Water.indexOf(GetUpdateValue( 'Water','WaterID','Water' )) > -1">
                                                                <label for="OtherWater" class="control-label">Other Water</label>
                                                                <input class="form-control" ng-model="PropertyModel.ListingModel.OtherWater" type="text" name="OtherWater" maxlength="100"/>
                                                            </div>
                                                            <!-- other-val="<?php //$keyWater = array_search('Other',array_column( array_map(function($o){return (array)$o;},$PropertyModel->Water) , 'Water'));  if($keyWater!='' && $keyWater>=0) { $keyWater=$PropertyModel->Water[$keyWater]->WaterID; } echo $keyWater; ?>"
                                                                    other="PropertyModel.ListingModel.OtherWater"
                                                                    ></select>
                                                            <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.Water.indexOf('<?php //echo $keyWater; ?>') > -1">
                                                                <label for="OtherWater" class="control-label">Other Water</label>
                                                                <input class="form-control" ng-model="PropertyModel.ListingModel.OtherWater" type="text" name="OtherWater" maxlength="100"/>
                                                            </div> -->
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.Deeds!=''">
                                                            <label for="Deeds" class="control-label">Deeds</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Deeds"
                                                                    ng-options="Deeds.DeedID as Deeds.Deed for Deeds in PropertyModel.Deeds"
                                                                    id="Deeds" name="Deeds" clear-other select-val="PropertyModel.ListingModel.Deeds"
                                                                    other-val="GetUpdateValue('Deeds','DeedID','Deed')"
                                                                    other="PropertyModel.ListingModel.OtherDeed"
                                                                    ></select>
                                                            <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.Deeds.indexOf(GetUpdateValue('Deeds','DeedID','Deed')) > -1">
                                                                <label for="OtherDeed" class="control-label">Other Deed</label>
                                                                <input class="form-control" ng-model="PropertyModel.ListingModel.OtherDeed" type="text" name="OtherDeed" maxlength="100"/>
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.CurrentUses!=''">
                                                            <label for="CurrentUses" class="control-label">Current Use</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.CurrentUses"
                                                                    ng-options="CurrentUses.CurrentUseID as CurrentUses.CurrentUse for CurrentUses in PropertyModel.CurrentUses"
                                                                    id="CurrentUses" name="CurrentUses" clear-other select-val="PropertyModel.ListingModel.CurrentUses"
                                                                    other-val="GetUpdateValue('CurrentUses','CurrentUseID','CurrentUse')"
                                                                    other="PropertyModel.ListingModel.OtherCurrentUses"
                                                                    ></select>
                                                            <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.CurrentUses.indexOf(GetUpdateValue('CurrentUses','CurrentUseID','CurrentUse')) > -1">
                                                                <label for="OtherCurrentUses" class="control-label">Other Current Use</label>
                                                                <input class="form-control" ng-model="PropertyModel.ListingModel.OtherCurrentUses" type="text" name="OtherCurrentUses" maxlength="100"/>
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.Disclousures != ''">
                                                            <label for="Disclousures" class="control-label">Disclosure</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Disclousures"
                                                                    ng-options="Disclousures.DisclosureID as Disclousures.Disclosure for Disclousures in PropertyModel.Disclousures"
                                                                    id="Disclousures" name="Disclousures" clear-other select-val="PropertyModel.ListingModel.Disclousures"
                                                                    other-val="GetUpdateValue('Disclousures','DisclosureID','Disclosure')"
                                                                    other="PropertyModel.ListingModel.OtherDisclosure"
                                                                    ></select>
                                                            <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.Disclousures.indexOf(GetUpdateValue('Disclousures','DisclosureID','Disclosure')) > -1">
                                                                <label for="OtherDisclosure" class="control-label">Other Disclosure</label>
                                                                <input class="form-control" ng-model="PropertyModel.ListingModel.OtherDisclosure" type="text" name="OtherDisclosure" maxlength="100"/>
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.HowSold != ''">
                                                            <label for="HowSold" class="control-label">How Sold</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.HowSold"
                                                                    ng-options="HowSold.HowSoldID as HowSold.HowSold for HowSold in PropertyModel.HowSold"
                                                                    id="HowSold" name="HowSold" clear-other select-val="PropertyModel.ListingModel.HowSold"
                                                                    other-val="GetUpdateValue('HowSold','HowSoldID','HowSold')"
                                                                    other="PropertyModel.ListingModel.OtherHowSold"
                                                                    ></select>
                                                            <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.HowSold.indexOf(GetUpdateValue('HowSold','HowSoldID','HowSold')) > -1">
                                                                <label for="OtherHowSold" class="control-label">Other How sold</label>
                                                                <input class="form-control" ng-model="PropertyModel.ListingModel.OtherHowSold" type="text" name="OtherHowSold" maxlength="100"/>
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.Style!=''">
                                                            <label for="Style" class="control-label">Style</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Style"
                                                                    ng-options="Style.StyleID as Style.Style for Style in PropertyModel.Style"
                                                                    id="Style" name="Style" clear-other select-val="PropertyModel.ListingModel.Style"
                                                                    other-val="GetUpdateValue('Style','StyleID','Style')"
                                                                    other="PropertyModel.ListingModel.OtherStyle"
                                                                    ></select>
                                                            <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.Style.indexOf(GetUpdateValue('Style','StyleID','Style')) > -1">
                                                                <label for="OtherStyle" class="control-label">Other Style</label>
                                                                <input class="form-control" ng-model="PropertyModel.ListingModel.OtherStyle" type="text" name="OtherStyle" maxlength="100"/>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="portlet box blue-hoki" ng-cloak>
                                <div class="portlet-title" collapse>
                                    <div class="caption">
                                        <i class=""></i>EXTERIOR FEATURES</div>
                                    <div class="tools">
                                        <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                    </div>
                                </div>
                                <div class="portlet-body">
                                    <div class="form-body" >
                                        <div class="row">
                                            <div class="col-md-12 no-padding">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="col-md-3 col-xs-12" ng-if="PropertyModel.Unit != ''">
                                                            <label for="Unit" class="control-label">Unit</label>
                                                            <select class="form-control" ng-model="PropertyModel.ListingModel.UnitID"
                                                                    ng-options="Unit.UnitID as Unit.Unit for Unit in PropertyModel.Unit"
                                                                    id="Unit" name="Unit"><option value="">-- select --</option></select>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID!=3 && PropertyModel.ListingModel.ClassID!=4 && PropertyModel.ListingModel.ClassID!=5 && PropertyModel.ListingModel.ClassID!=6">
                                                            <label for="GarageSqFt" class="control-label">Garage SqFt</label>
                                                            <input class="form-control" ng-model="PropertyModel.ListingModel.GarageSqFt" type="text" name="GarageSqFt" maxlength="16" intype="positiveNumeric"/>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==3 || PropertyModel.ListingModel.ClassID==4">
                                                            <label for="UnitSqFt" class="control-label">Unit SqFt</label>
                                                            <input class="form-control" ng-model="PropertyModel.ListingModel.UnitSqFt" type="text" name="UnitSqFt" maxlength="21" intype="positiveNumeric"/>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1 || PropertyModel.ListingModel.ClassID==2">
                                                            <label for="WorkShopNoofRooms" class="control-label">Work Shop No. of Rooms</label>
                                                            <input class="form-control" ng-model="PropertyModel.ListingModel.WorkShopNoofRooms" type="text" name="WorkShopNoofRooms" maxlength="10"/>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12" ng-if="PropertyModel.ListingModel.ClassID==1 || PropertyModel.ListingModel.ClassID==2">
                                                            <label for="WorkShopRoomLevel" class="control-label">Work Shop Room Level</label>
                                                            <input class="form-control" ng-model="PropertyModel.ListingModel.WorkShopRoomLevel" type="text" name="WorkShopRoomLevel"  maxlength="10"/>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12" >
                                                            <label for="Crops" class="control-label">Crops</label>
                                                            <select ng-model="PropertyModel.ListingModel.Crops" class="form-control" name="Crops">
                                                                <option value="">-- select --</option>
                                                                <option value="1">Yes</option>
                                                                <option value="2">No</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12" ng-if="PropertyModel.UnitSqFtRange != ''" >
                                                            <label for="UnitSqFtRange" class="control-label">Unit SqFt Range</label>
                                                            <select class="form-control" ng-model="PropertyModel.ListingModel.UnitSqFtRangeID"
                                                                    ng-options="UnitSqFtRange.UnitSqFtRangeID as UnitSqFtRange.UnitSqFtRange for UnitSqFtRange in PropertyModel.UnitSqFtRange"
                                                                    id="UnitSqFtRange" name="UnitSqFtRange"><option value="">-- select --</option></select>
                                                        </div>
                                                        <div class="col-md-3 col-xs-12" ng-if="PropertyModel.LotSize != ''">
                                                            <label for="LotSize" class="control-label">Lot Size</label>
                                                            <select class="form-control" ng-model="PropertyModel.ListingModel.LotSizeID"
                                                                    ng-options="LotSize.LotSizeID as LotSize.LotSize for LotSize in PropertyModel.LotSize"
                                                                    id="LotSize" name="LotSize"><option value="">-- select --</option></select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.Parking!=''">
                                                            <label for="Parking" class="control-label">Parking</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Parking"
                                                                    ng-options="Parking.ParkingID as Parking.Parking for Parking in PropertyModel.Parking"
                                                                    id="Parking" name="Parking"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.UnitFace != ''">
                                                            <label for="UnitFace" class="control-label">Unit Faces</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.UnitFace"
                                                                    ng-options="UnitFace.UnitFaceID as UnitFace.UnitFace for UnitFace in PropertyModel.UnitFace"
                                                                    id="UnitFace" name="UnitFace"
                                                                    ></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.Garages != ''">
                                                            <label for="Garage" class="control-label">Garage</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Garages"
                                                                    ng-options="Garages.GarageID as Garages.Garage for Garages in PropertyModel.Garages"
                                                                    id="Garage" name="Garage"></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.Carports != ''">
                                                            <label for="Carports" class="control-label">Carport</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Carports"
                                                                    ng-options="Carports.CarportID as Carports.Carport for Carports in PropertyModel.Carports"
                                                                    id="Carports" name="Carports"></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.LotImprovements != ''">
                                                            <label for="LotImprovements" class="control-label">Lot Improvements</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.LotImprovements"
                                                                    ng-options="LotImprovements.LotImprovementID as LotImprovements.LotImprovement for LotImprovements in PropertyModel.LotImprovements"
                                                                    id="LotImprovements" name="LotImprovements"></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.LotDescription != ''">
                                                            <label for="LotDescription" class="control-label">Lot Description</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.LotDescription"
                                                                    ng-options="LotDescription.LotDescriptionID as LotDescription.LotDescription for LotDescription in PropertyModel.LotDescription"
                                                                    id="LotDescription" name="LotDescription"></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.ParkingArea != ''">
                                                            <label for="ParkingArea" class="control-label">Parking Area</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.ParkingArea"
                                                                    ng-options="ParkingArea.ParkingAreaID as ParkingArea.ParkingArea for ParkingArea in PropertyModel.ParkingArea"
                                                                    id="ParkingArea" name="ParkingArea"></select>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.ConstructExterior != ''">
                                                            <label for="ConstructExterior" class="control-label">Construct/Exterior</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.ConstructExterior"
                                                                    ng-options="ConstructExterior.ConstructExteriorID as ConstructExterior.ConstructExterior for ConstructExterior in PropertyModel.ConstructExterior"
                                                                    id="ConstructExterior" name="ConstructExterior" other-val="GetUpdateValue('ConstructExterior','ConstructExteriorID','ConstructExterior')"
                                                                    other="PropertyModel.ListingModel.OtherConstructExterior"
                                                                    ></select>
                                                            <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.ConstructExterior.indexOf(GetUpdateValue('ConstructExterior','ConstructExteriorID','ConstructExterior')) > -1">
                                                                <label for="OtherConstructExterior" class="control-label">Construct/Exterior</label>
                                                                <input class="form-control" ng-model="PropertyModel.ListingModel.OtherConstructExterior" type="text" name="OtherConstructExterior" maxlength="100"/>
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.Roofs != ''">
                                                            <label for="Roofs" class="control-label">Roofs</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Roofs"
                                                                    ng-options="Roofs.RoofID as Roofs.Roof for Roofs in PropertyModel.Roofs"
                                                                    id="Roofs" name="Roofs"
                                                                    other-val="GetUpdateValue('Roofs','RoofID','Roof')"
                                                                    other="PropertyModel.ListingModel.OtherRoof"
                                                                    ></select>
                                                            <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.Roofs.indexOf(GetUpdateValue('Roofs','RoofID','Roof')) > -1">
                                                                <label for="OtherRoof" class="control-label">Other Roof</label>
                                                                <input class="form-control" ng-model="PropertyModel.ListingModel.OtherRoof" type="text" name="OtherRoof" maxlength="100"/>
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-md-3" ng-if="PropertyModel.Exteriors != ''">
                                                            <label for="Exteriors" class="control-label">Exterior</label>
                                                            <select class="form-control" multiple ng-model="PropertyModel.ListingModel.Exteriors"
                                                                    ng-options="Exterior.ExteriorID as Exterior.Exterior for Exterior in PropertyModel.Exteriors"
                                                                    id="Exteriors" name="Exteriors"
                                                                    other-val="GetUpdateValue('Exteriors','ExteriorID','Exterior')"
                                                                    other="PropertyModel.ListingModel.OtherExterior"
                                                                    ></select>
                                                            <div class="form-group margin-top-10" ng-if="PropertyModel.ListingModel.Exteriors.indexOf(GetUpdateValue('Exteriors','ExteriorID','Exterior')) > -1">
                                                                <label for="OtherExterior" class="control-label">Other Exterior</label>
                                                                <input class="form-control" ng-model="PropertyModel.ListingModel.OtherExterior" type="text" name="OtherExterior" maxlength="100"/>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="clearboth"></div>
                            <div class="portlet box blue-hoki" ng-cloak>
                                <div class="portlet-title" collapse>
                                    <div class="caption">
                                        <i class=""></i>IMAGES</div>
                                    <div class="tools">
                                        <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                    </div>
                                </div>
                                <div class="portlet-body">
                                    <div class="row">
                                        <div class="col-md-12 no-padding">
                                            <div class="form-body" >
                                                <div class="col-md-12 no-padding">
                                                    <div class="form-group col-md-12 dropZoneOuter">
                                                        <div class="col-md-12 no-padding margin-bottom-10" ng-if="PropertyModel.IsShowUploadNote == 1">
                                                                    <span class="font13px help-block info-alert" >
                                                                            <span><span class="bold">Note:</span> {{ trans('messages.PropertyImageQueue')}}</span>
                                                                    </span>
                                                        </div>
                                                        <div class="col-md-12 no-padding margin-bottom-10" >
                                                            <span class="font13px help-block info-alert" >
                                                                            <span><span class="bold">Note:</span> {{ trans('messages.PropertyImagesDimension')}}</span>
                                                            </span>
                                                        </div>
                                                        <div class="clearboth"></div><form></form>
                                                        <form action=""  class="dropzone" drop-zone="" id="file-dropzone"  ng-aws-settings-model="PropertyModel.FileUploadSettings" success-callback="PushFilesToUploadArray" remove-file="RemoveFile" upload-file="PropertyModel.ListingModel.ImagesModel" file-name="PropertyModel.ListingModel.ImagesNameModel" ext-type="PropertyModel.ImageExtensionType" max-files="PropertyModel.maxFiles" request-counter="PropertyModel.requestCounter" response-counter="PropertyModel.responseCounter"  upload-complete="UploadComplete" uploaded-file="PropertyModel.ListingModel.UploadedFile" file-size-exceeds="{{ trans('messages.NoMoreImages')}}" invalid-file-format="{{trans('messages.InvalidImageTypeFormat')}}" allow-sortable="PropertyModel.IsAllowSortable" sortable-callback="updateSortOrder" url-upload-file="PropertyModel.ListingModel.RestsImageURL">
                                                            <div class="dz-preview dz-file-preview margin-10p sortable" id="template">
                                                                <div class="dz-details">
                                                                    <div class="dz-filename"><span data-dz-name></span></div>
                                                                    <div class="dz-size" data-dz-size></div>
                                                                    <div><span class="dz-remove"></span></div><img data-dz-thumbnail />
                                                                </div>
                                                                <br/>
                                                                <div  class="progress progress-striped active" id="totalprogressbar"  role="progressbar" aria-valuemin='0' aria-valuemax='100' aria-valuenow='0'> <div class="progress-bar progress-bar-success bar width-none" data-dz-uploadprogress></div> </div>
                                                                <div class="dz-success-mark"><span>✔</span></div>
                                                                <div class="dz-error-mark"><span>✘</span></div>
                                                                <div class="file-error-message"><strong class="error text-danger" data-dz-errormessage></strong></div>

                                                                <div class="col-md-12 col-md-push-1 no-padding" >
                                                                    <div class="sortable-handle vertical-align btn btn-gray col-md-4 no-padding col-sm-4 col-xs-4 drag-drop-icon">
                                                                        <center><span class="draggable-icon-arrow"><i class="fa fa-bars draggable-icon dropzone-draggable-button"></i>
                                                                             <i class="fa fa-arrows-alt draggable-icon dropzone-draggable-button"></i></span></center>
                                                                    </div>
                                                                    <div class=" col-md-3 no-padding col-md-push-2">
                                                                        <button data-dz-remove="" class="btn btn-danger delete cancel dropzone-delete-button"><i class="glyphicon glyphicon-trash"></i></button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-actions  col-md-12">
                                <input id="submit" name="submit" type="submit" value="Save" class="btn blue save-button" data-ng-click="AddListing()" ng-disabled="!UploadComplete">
                                <input id="cancel" name="cancel" type="button" value="Cancel" class="btn grey" data-ng-click="Cancel()" ng-disabled="!UploadComplete">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </main>
@stop
@section('script')
    {{ $minify::javascript(array('/assets/js/viewjs/property/coaddpropertylisting.js','/assets/js/sitejs/dropzone.js'))->withFullUrl()}}
    {{ $minify::javascript(array('/assets/js/sitejs/jquery-ui-1.9.2.custom.min.js',
                                   '/assets/js/sitejs/jquery.ui.touch-punch.min.js'))->withFullUrl()}}
    {{ $minify::javascript(array('/assets/js/sitejs/exif.js','/assets/js/sitejs/binaryajax.js'))->withFullUrl()}}
    {{ $minify::javascript(array('/assets/js/sitejs/canvasResize.js'))->withFullUrl()}}
@stop