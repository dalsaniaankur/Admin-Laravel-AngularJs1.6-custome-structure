<?php
use Infrastructure\Common;
use BaseController as BA;
$minify = new \CeesVanEgmond\Minify\Facades\Minify;
?>
@extends('layouts.sitemaster')
@section('Title','Listings')
@stop
@section('css')
@stop
@section('content')
<?php echo Form::hidden('ListModel', json_encode($ListModel), $attributes = array('id' => 'ListModel')); ?>
    <div class="page-content" data-ng-controller = "PropertyListController">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo URL::to('/dashboard/'.$encryptedSiteID) ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Listings</span>
                </li>
            </ul>
            <div class="page-toolbar">
                <div class="btn-group pull-right">
                    <a href="<?php echo URL::to('/addlisting/'.$encryptedSiteID); ?>" class="btn btn-primary btn-sm btn-outline"> Add Listing </a>
                </div>
            </div>
        </div>
        <h3 class="page-title"> Listings</h3>
        <div class="row">
            <div class="col-md-12">
                <form>
                    <div class="form-body" ng-cloak>
                            <div class="form-group col-md-3">
                                <label for="MLSNo" class="control-label">MLS#</label>
                                <input type="text" class="form-control" data-ng-model="ListModel.frontSearchModel.MLSNo" id="MLSNo" name="MLSNo" maxlength="20" intype="alphaNumeric">
                            </div>
                            <div class="form-group col-md-3">
                                <label for="Address" class="control-label">Street</label>
                                <input type="text" class="form-control" data-ng-model="ListModel.frontSearchModel.Address" id="Address" name="Address">
                            </div>
                            <div class="form-group col-md-3">
                                <label for="Address" class="control-label">City</label>
                                <input type="text" class="form-control" data-ng-model="ListModel.frontSearchModel.City" id="City" name="City" maxlength="100">
                            </div>
                            <div class="form-group col-md-3">
                                <label for="Address" class="control-label">Zipcode</label>
                                <input type="text" class="form-control" data-ng-model="ListModel.frontSearchModel.ZipCode" id="ZipCode" name="ZipCode" maxlength="9" intype="digit">
                            </div>
                            <div class="form-group col-md-3">
                                <label for="Agent" class="control-label">Agent</label>
                                <select class="form-control" id="Name" name="Name" data-ng-model="ListModel.frontSearchModel.AgentID">
                                    <option value="">Select Agent</option>
                                    <option ng-repeat="data in ListModel.AgentLookup" value="@{{data.UserID}}">@{{data.Name}}</option>
                                </select>
                            </div>
                            <div class="form-group col-md-3">
                                <label for="Status" class="control-label">Status</label>
                                <select class="form-control" id="Status" name="Status" data-ng-model="ListModel.frontSearchModel.StatusID">
                                    <option value="-1">All</option>
                                    <option ng-repeat="data in ListModel.StatusLookup" value="@{{data.StatusID}}">@{{data.Status}}</option>
                                </select>
                            </div>
                            <div class="form-group col-md-2">
                                <div class="search-label-hidden"><label for="Date From" class="control-label">&nbsp;</label></div>
                                <input id="checkbox" type="checkbox"  data-ng-model="ListModel.frontSearchModel.IsHidden" id="IsHidden" name="IsHidden" >
                                <label for="checkbox" class="unselectable"> Show Hidden</label>
                            </div>
                            <div class="form-group col-md-3">
                                <div class="search-label-hidden"><label class="control-label">&nbsp;</label></div>
                                <button data-ng-click="SearchPropertyRecords()" class="btn blue btn-search">Search</button>
                            </div>
                    </div>
                </form>
                <div data-ng-if="PropertyList.length > 0" class="table-responsive col-md-12" ng-cloak>
                    <table class="table dataTable table-striped table-bordered table-hover">
                        <thead class="site-footer">
                        <tr>

                            <th class="sorting" data-ng-click="ListPager.sortColumn('Street')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'Street' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'Street' && !ListPager.reverse)}" >
                                Street
                            </th>
                            <th class="sorting" data-ng-click="ListPager.sortColumn('MLSNo')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'MLSNo' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'MLSNo' && !ListPager.reverse)}" >
                                MLS#
                            </th>
                            <th class="sorting" data-ng-click="ListPager.sortColumn('SquareFeet')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'SquareFeet' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'SquareFeet' && !ListPager.reverse)}" >
                                Square Feet
                            </th>
                            <th class="sorting" data-ng-click="ListPager.sortColumn('NoOfBeds')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'NoOfBeds' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'NoOfBeds' && !ListPager.reverse)}" >
                                Beds
                            </th>

                            <th class="sorting" data-ng-click="ListPager.sortColumn('NoOfFullBaths')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'NoOfFullBaths' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'NoOfFullBaths' && !ListPager.reverse)}" >
                                Baths
                            </th>
                            <th class="sorting" data-ng-click="ListPager.sortColumn('Price')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'Price' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'Price' && !ListPager.reverse)}" >
                                Price
                            </th>
                            <th class="sorting" data-ng-click="ListPager.sortColumn('AgentName')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'AgentName' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'AgentName' && !ListPager.reverse)}" >
                                Listing Agent
                            </th>
                            <th class="sorting" data-ng-click="ListPager.sortColumn('StatusID')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'StatusID' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'StatusID' && !ListPager.reverse)}" >
                                Status
                            </th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody dir-paginate="data in PropertyList | itemsPerPage:ListPager.pageSize" total-items="ListPager.totalRecords" current-page="ListPager.currentPage" pagination-id="ListingID">
                        <tr>

                            <?php if(BA::CheckRoleSitePermission(Common::getRoleITAdminAndAgent(),Common::getSiteMercerVineWoodbridgeColorado())) { ?>
                            <td><a ng-click="editProperty(data)" title="Edit Property" ng-model="EditProperty">@{{data.Street}}</a></td>
                            <?php }else{ ?>
                            <td>@{{data.Street}}</td>
                            <?php } ?>
                            <td>@{{data.MLSNo}}</td>
                            <td class="text-right">@{{data.SquareFeet | number}}</td>
                            <td>@{{data.NoOfBeds}}</td>
                            <td>@{{data.NoOfFullBaths}}</td>
                            <td class="text-right">@{{data.Price | currency}}</td>
                            <td>@{{data.AgentName}}</td>
                            <td>@{{data.Status}}</td>
                            <td>
                                <div>
                                    <?php if(BA::CheckRoleSitePermission(Common::getRoleITAdminAndAgent(),Common::getSiteMercerVineWoodbridgeColorado())) {?>
                                    <a ng-click="editProperty(data)" title="Edit Property" ng-model="EditProperty"><i class="fa fa-pencil text-default" ></i></a>
                                    &nbsp;
                                    <?php } ?>
                                    <a ng-show="data.ListingID > 0 && (data.MLSNo == '' || data.MLSNo == null)" ng-model="deleteProperty" ng-click="DeleteProperty(data)" title="Delete Property" ng-model="DeleteProperty"><i class="fa fa-trash-o text-danger"></i></a>
                                </div>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
                    <div class="col-md-12" data-ng-if="PropertyList.length > 0">
                        <dir-pagination-controls boundary-links="true"  on-page-change="ListPager.pageChanged(newPageNumber)" pagination-id="ListingID">
                        </dir-pagination-controls>
                    </div>

                    <div class="form-group col-md-12 display-none"  align="center" id="nodata">
                        <b>{{ trans('messages.NoPropertyRecordFound') }}</b>
                    </div>
            </div>
        </div>
    </div>
@stop

@section('script')
       {{ $minify::javascript(array('/assets/js/viewjs/property/properties.js'))->withFullUrl()}}
@stop
