<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	  <title>Reset your password</title>
</head>

<body paddingwidth="0" paddingheight="0"   style="padding-top: 20px !important; padding-bottom: 0 !important; padding-top: 0 !important; padding-bottom: 0 !important;
		   margin:20px 0 0 0 !important; width: 100% !important; -webkit-text-size-adjust: 100% !important; -ms-text-size-adjust: 100% !important;
		   -webkit-font-smoothing: antialiased !important; background-color:#666666; background-image:url($bgimagepath); font-family:Helvetica, Arial,serif;
		   color:#404040; background-repeat: repeat-x;" offset="0" toppadding="0" leftpadding="0">

	<table width="520" border="0" cellspacing="0" cellpadding="0" class="tableContent bgBody" align="center" style='background: #ffffff; font-family:Helvetica, Arial,serif;'>
		<tr style="background:#1f1f1f">
			<td height='20'></td>
		</tr>
		<tr style="background:#1f1f1f">
			<td>
				<table width="500" border="0" cellspacing="0" cellpadding="0" align="center" class=''>
					<tr>
						<td width='250' colspan="2"><a href="$emaillogolink"><img src="$logopath" style="outline:none;"  alt='' data-default="placeholder" data-max-width="560"></a></td>
						<!-- <td width='250' colspan="2"><p style="text-align:right; margin:0; font-size:12px; font-weight:bold;"><a href="#" style="font-size:12px; font-weight:bold; color:#258fff; outline:none; text-decoration:none;">Login to DCCLive.com</a></p></td> -->
					</tr>
				</table>
			</td>
		</tr>
		<tr style="background:#1f1f1f">
			<td height='20'></td>
		</tr>
		<tr>
			<td height='10'></td>
		</tr>
		<tr>
			<td>
				<table width="500" border="0" cellspacing="0" cellpadding="0" align="center" class=''>
					<tr>
						<td height='10'></td>
					</tr>			
					<tr>
						<td width="580" class="w580">
							<div align="left" class="article-content">
						<p>To initiate the password reset process for your account, click the button below:</p>
                        <a href="$Link" style="background-color: #337ab7 ; background-image: linear-gradient(to bottom ,#337ab7 , #337ab7) ; background-repeat: repeat-x ; border-color: rgba(0 , 0 , 0 , 0.1) rgba(0 , 0 , 0 , 0.1) #b3b3b3 ; border-radius: 4px ; border-style: solid ; border-width: 1px ; box-shadow: 0 1px 0 rgba(255 , 255 , 255 , 0.2) inset , 0 1px 2px rgba(0 , 0 , 0 , 0.05) ; color: #333333 ; cursor: pointer ; display: inline-block ; font-size: 14px ; line-height: 20px ; margin-bottom: 0 ; padding: 4px 12px ; text-align: center ; text-shadow: 0 1px 1px rgba(255 , 255 , 255 , 0.75) ; vertical-align: middle ; background-color: #286090 ;  background-repeat: repeat-x ; border-color: rgba(0 , 0 , 0 , 0.1) rgba(0 , 0 , 0 , 0.1) rgba(0 , 0 , 0 , 0.25) ; color: #ffffff ; text-shadow: 0 -1px 0 rgba(0 , 0 , 0 , 0.25) ; text-decoration: none ; font-weight: normal" target="_other" rel="nofollow">Reset Password</a>
                        <p>If you've received this mail in error, it's likely that another user entered your email address by mistake while trying to reset a password. If you didn't initiate the request, you don't need to take any further action and can safely disregard this email.</p>
                            </div>
						</td>
					</tr>

					<tr>
						<td height='20'></td>
					</tr>

				</table>
			</td>
		</tr>
		<tr>
			<td style='border-top:1px solid #999999;'>
				<table width="500" border="0" cellspacing="0" cellpadding="10" align="center" class=''>
					<tr>
						<td width='250' colspan="2"><p style="font-size:11px; color:#999999; margin:0; font-weight:bold;">&#169; <?php echo date('Y'); ?> Woodbridge Group of Companies, LLC. All Rights</p></td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</body>
</html>
