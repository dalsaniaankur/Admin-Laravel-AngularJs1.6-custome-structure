<?php
use Jenssegers\Agent\Agent;
use Infrastructure\Constants;
$minify = new \CeesVanEgmond\Minify\Facades\Minify;
$agent = new Agent();
$siteID = \ViewModels\SessionHelper::getSelectedSiteID();
?>
@extends('layouts.sitemaster')
@section('Title','Landing Page Images')

@stop
@section('css')

@stop
@section('content')
    <main id="main" role="main" ng-controller = "LandingPageController">
        <form   name="LandingPage" id="LandingPage" role="form" novalidate ng-submit="checkSave(LandingPage)">
            <?php echo Form::hidden('LandingPageModel', json_encode($LandingPageModel),$attributes = array('id'=>'LandingPageModel')); ?>

            <div class="page-content" >
                <div class="page-bar">
                    <ul class="page-breadcrumb">
                        <li>
                            <a href="<?php echo URL::to('/dashboard/'.$encryptedSiteID) ?>">Home</a>
                            <i class="fa fa-circle"></i>
                        </li>
                        <li>
                            <a href="javascript:void(0);">Landing Page</a>
                        </li>
                    </ul>
                    <div class="page-toolbar">
                        <div class="btn-group pull-right" ng-if="LandingPageModel.PageData.length > 0">
                            <input id="btn-submit" name="submit" type="submit" value="Save" class="btn blue save-button btn-sm" data-ng-click="Save()" ng-disabled="(requestCounter != responseCounter)">
                        </div>
                    </div>
                </div>

                <h3 class="page-title"> Landing Page</h3>

                <div class="row" ng-if="LandingPageModel.PageContentData.length > 0">
                    <div class="col-md-12">
                        <div class="form-body" ng-cloak>
                            <div class="portlet box blue-hoki" ng-cloak>
                                <div class="portlet-title" collapse="true">
                                    <div class="caption">
                                        <i class=""></i>Page Content</div>
                                    <div class="tools">
                                        <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                    </div>
                                </div>

                                <div class="portlet-body">
                                    <div class="row">
                                        <div class="col-md-12 no-padding">
                                            <div class="form-body" ng-cloak>
                                            <div ng-repeat="data in LandingPageModel.PageContentData" ng-init="listIndex = $index+1">
                                                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12" >
                                                    <div class="fileinput fileinput-new">
                                                        <div>
                                                            <label>@{{ data.PageName }}</label>
                                                            <textarea name="Content" data-ng-model="data.LandingpageContent" ck-editor data-ng-class="{'has-submitted' : HomeForm.$submitted }" required></textarea>
                                                        </div>
                                                        
                                                        <!-- <span>&nbsp;</span> -->
                                                        <div class="progress progress-striped display-none progress-striped-landing">
                                                            <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                            </div>
                                                        </div>
                                                        <div class="info-alert font13px" ng-if="(data.AllowedFixHeight > 0 ) && (data.AllowedFixWidth > 0 )"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ data.AllowedFixWidth }}x@{{ data.AllowedFixHeight }}px</lable></div>
                                                    </div>
                                                </div>
                                                <?php if($agent->isTablet()) {?>
                                                <div class="clearboth" ng-if="listIndex % 3 ==0 && $index !=0"></div>
                                                <?php } ?>
                                                <?php if(!$agent->isTablet() &&  !$agent->isMobile()) {?>
                                                <div class="clearboth" ng-if="listIndex % 4 ==0 && $index !=0"></div>
                                                <?php } ?>

                                            </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>

                <div class="row" ng-if="LandingPageModel.PageData.length > 0">
                    <div class="col-md-12">
                        <div class="form-body" ng-cloak>
                            <div class="portlet box blue-hoki" ng-cloak>
                                <div class="portlet-title" collapse>
                                    <div class="caption">
                                        <i class=""></i>Header Images</div>
                                    <div class="tools">
                                        <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                    </div>
                                </div>

                                <div class="portlet-body">
                                    <div class="row">
                                        <div class="col-md-12 no-padding">
                                            <div class="form-body" ng-cloak>
                                            <div ng-repeat="data in LandingPageModel.PageData" ng-init="listIndex = $index+1">
                                                <div class="col-md-12 col-sm-12 col-xs-12" >
                                                    <div class="fileinput fileinput-new">
                                                        <div>
                                                            <label>@{{ data.PageName }}</label>
                                                        </div>
                                                        <div  class="fileinput-new thumbnail image-box fileinput-new-image">
                                                            <img class="display-none loadingImage loadingImageForLandingPage" src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage">
                                                            <img id="actualImage" alt="" src="@{{data.RealImagePath ? data.RealImagePath : LandingPageModel.NoImagePath}}">
                                                        </div>
                                                        <div class="imageblock-btn">
                                                            <form></form>
                                                            <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload">
                                                                <input type="hidden" id="key" name="key" value="">
                                                                <input type="hidden" name="AWSAccessKeyId"  ng-value="LandingPageModel.FileUploadSettings.accesskey">
                                                                <input type="hidden" name="acl"  ng-value="LandingPageModel.FileUploadSettings.acl">
                                                                <input type="hidden" name="success_action_status"  ng-value="LandingPageModel.FileUploadSettings.success_action">
                                                                <input type="hidden" name="policy"  ng-value="LandingPageModel.FileUploadSettings.base64Policy">
                                                                <input type="hidden" name="signature"  ng-value="LandingPageModel.FileUploadSettings.signature">
                                                                <input type="hidden" name="Cache-Control" ng-value="LandingPageModel.FileUploadSettings.cacheControlTime">
                                                                <span  class="btn default btn-file" ><input type="file" name="file" class="file"  id="file" title="Choose Image"> Choose Image</span>
                                                                <a  class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage(data)" ng-show="data.RealImagePath"> Remove </a>
                                                                <span></span>
                                                            </form>
                                                        </div>
                                                        <!-- <span>&nbsp;</span> -->
                                                        <div class="progress progress-striped display-none  progress-striped-landing">
                                                            <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                            </div>
                                                        </div>
                                                        <div class="info-alert font13px" ng-if="(data.AllowedFixHeight > 0 ) && (data.AllowedFixWidth > 0 )"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ data.AllowedFixWidth }}x@{{ data.AllowedFixHeight }}px</lable></div>
                                                    </div>
                                                </div>
                                                <?php if($agent->isTablet()) {?>
                                                <div class="clearboth" ng-if="listIndex % 3 ==0 && $index !=0"></div>
                                                <?php } ?>
                                                <?php if(!$agent->isTablet() &&  !$agent->isMobile()) {?>
                                                <div class="clearboth" ng-if="listIndex % 4 ==0 && $index !=0"></div>
                                                <?php } ?>

                                            </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php if($siteID == Constants::$ColoradoSiteID) {?>
                    <div class="col-md-12 " ng-cloak >
                        <input id="btn-submit" name="submit" type="submit" value="Save" class="btn blue save-button" data-ng-click="Save()" ng-disabled="(requestCounter != responseCounter)">
                        <button type="button" id="cancel" class="btn default" data-ng-click="Cancel()" ng-disabled="(requestCounter != responseCounter)">Cancel</button>
                    </div>
                    <?php }?>
                    
                </div>




                





                <div class="row">
                    <div class="col-md-12" >
                        <div class="form-body" ng-cloak>
                            <div class="portlet box blue-hoki" ng-cloak  ng-if="LandingPageModel.PageRightBottomImageData.length > 0">
                                <div class="portlet-title" collapse>
                                    <div class="caption">
                                        <i class=""></i>Bottom Right corner Images</div>
                                    <div class="tools">
                                        <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                    </div>
                                </div>

                                <div class="portlet-body"  ng-if="LandingPageModel.PageRightBottomImageData.length > 0">
                                    <div class="row">
                                        <div class="col-md-12 no-padding">
                                            <div class="form-body" ng-cloak>
                                                <div ng-repeat="data in LandingPageModel.PageRightBottomImageData" ng-init="listIndex = $index+1">
                                                    <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12" >
                                                        <div class="fileinput fileinput-new">
                                                            <div>
                                                                <label>@{{ data.PageName }}</label>
                                                            </div>
                                                            <div  class="fileinput-new thumbnail image-box">
                                                                <img class="display-none loadingImage loadingImageForLandingPage" src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage">
                                                                <img id="actualImage" alt="" src="@{{data.RealImagePath ? data.RealImagePath : LandingPageModel.NoImagePath}}">
                                                            </div>
                                                            <div>
                                                                <form></form>
                                                                <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload">
                                                                    <input type="hidden" id="key" name="key" value="">
                                                                    <input type="hidden" name="AWSAccessKeyId"  ng-value="LandingPageModel.FileUploadSettings.accesskey">
                                                                    <input type="hidden" name="acl"  ng-value="LandingPageModel.FileUploadSettings.acl">
                                                                    <input type="hidden" name="success_action_status"  ng-value="LandingPageModel.FileUploadSettings.success_action">
                                                                    <input type="hidden" name="policy"  ng-value="LandingPageModel.FileUploadSettings.base64Policy">
                                                                    <input type="hidden" name="signature"  ng-value="LandingPageModel.FileUploadSettings.signature">
                                                                    <input type="hidden" name="Cache-Control" ng-value="LandingPageModel.FileUploadSettings.cacheControlTime">
                                                                    <span  class="btn default btn-file" ><input type="file" name="file" class="file"  id="file" title="Choose Image"> Choose Image</span>
                                                                    <a  class="btn red" href="javascript:void(0);" data-ng-click="RemoveBottomImage(data)" ng-show="data.RealImagePath"> Remove </a>
                                                                    <span></span>
                                                                </form>
                                                            </div>
                                                            <!-- <span>&nbsp;</span> -->
                                                            <div class="progress progress-striped display-none progress-striped-landing">
                                                                <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                </div>
                                                            </div>
                                                            <div class="info-alert font13px" ng-if="(data.AllowedFixHeight > 0 ) && (data.AllowedFixWidth > 0 )"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ data.AllowedFixWidth }}x@{{ data.AllowedFixHeight }}px</lable></div>
                                                        </div>
                                                    </div>
                                                    <?php if($agent->isTablet()) {?>
                                                    <div class="clearboth" ng-if="listIndex % 3 ==0 && $index !=0"></div>
                                                    <?php } ?>
                                                    <?php if(!$agent->isTablet() &&  !$agent->isMobile()) {?>
                                                    <div class="clearboth" ng-if="listIndex % 4 ==0 && $index !=0"></div>
                                                    <?php } ?>

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php if($siteID == Constants::$WoodBridgeWealthSiteID) {?>
                    <div class="col-md-12 " ng-cloak >
                        <input id="btn-submit" name="submit" type="submit" value="Save" class="btn blue save-button" data-ng-click="Save()" ng-disabled="(requestCounter != responseCounter)">
                        <button type="button" id="cancel" class="btn default" data-ng-click="Cancel()" ng-disabled="(requestCounter != responseCounter)">Cancel</button>
                    </div>
                    <?php }?>
                </div>



            </div>
        </form>
</main>
@stop

@section('script')
    {{ $minify::javascript(array('/assets/js/viewjs/landingpage/landingpageimages.js',
                         '/assets/js/library/jquery.fileupload/jquery.ui.widget.js',
                         '/assets/js/library/jquery.fileupload/jquery.fileupload.js',
                         '/assets/js/library/binaryajax.js',
                         '/assets/js/library/exif.js',
                         '/assets/js/library/bootstrap-fileinput.js',
                         '/assets/js/sitejs/canvasResize.js'))->withFullUrl()}}
<script src="{{asset('/assets/js/ckeditor/ckeditor.js')}}" ></script>

    <script>
        window.ImageFileAllowedMessage ="{{ trans('messages.ImageFileAllowedMessage')}}";
        window.ConfirmUploadMessage ="{{ trans('messages.ConfirmUploadMessage')}}";
        window.NoImagePath = '<?php echo asset('/assets/images/Samplephoto.png') ?>';
    </script>
@stop