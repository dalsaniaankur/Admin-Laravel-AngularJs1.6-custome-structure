<?php
    use Infrastructure\Constants;
    $minify = new \CeesVanEgmond\Minify\Facades\Minify;
?>
@extends('layouts.sitemaster')
@section('Title')
    Settings
@stop
@section('css')

@stop
@section('content')
<main id="main" role="main" ng-controller = "ConfigurationController">
    <form name="ConfigurationForm" id="ConfigurationForm" role="form" novalidate ng-clock  ng-submit="checkSave(ConfigurationForm)">
<?php echo Form::hidden('ConfigurationModel', json_encode($ConfigurationModel),$attributes = array('id'=>'ConfigurationModel')); ?>
    <div class="page-content"  ng-clock>
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo URL::to('/dashboard/'.$encryptedSiteID) ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Settings</span>
                </li>
            </ul>
            <div class="page-toolbar">
                    <div class="btn-group pull-right">
                        <input id="submit" name="submit" type="submit" value="Save" class="btn blue save-button btn-sm" data-ng-click="SaveConfiguration()" ng-disabled="DisableButtons">
                    </div>
                </div>
        </div>

        <h3 class="page-title">Settings</h3>
        <div class="row">

                <div class="col-md-12 col-sm-12">
                    <!-- Configuration settings part start -->
                    <div class="clearboth"></div>
                    <div class="portlet box blue-hoki" ng-cloak>
                        <div class="portlet-title" collapse>
                            <div class="caption">
                                <i class=""></i>CONFIGURATION</div>
                            <div class="tools">
                                <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                            </div>
                        </div>
                        <div class="portlet-body">
                            <div class="row">
                                <div class="col-md-12 no-padding">
                                    <div class="form-body" >
                                        <div class="col-md-12 no-padding">
                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12 visible-md visible-xs">
                                                <div class="col-md-12 no-padding">
                                                    <label for="SMTPPassword" class="control-label">Publisher Logo</label>
                                                    <span tooltip data-toggle="tooltip" data-placement="bottom" title="Publisher logo for pages & posts in Google search (SEO)">
                                                                <i class="fa fa-info-circle font-size-18px margin-top-10"></i>
                                                    </span>
                                                </div>
                                                <div class="fileinput fileinput-new">
                                                    <div  class="fileinput-new thumbnail image-box">
                                                        <img  src="<?php echo asset('/assets/images/ajax-loader2.gif'); ?>" id="loadingImage" class="site-loadingImage display-none loadingImage" >
                                                        <img id="actualImage" alt="" src="@{{ConfigurationModel.RealImagePath ? ConfigurationModel.RealImagePath : ConfigurationModel.NoImagePath}}">
                                                    </div>
                                                    <div>
                                                        <form></form>
                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload"  name="ImageForm" role="form" novalidate>
                                                            <input type="hidden" id="key" name="key" value="">
                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="ConfigurationModel.Fileuploadsettings.accesskey">
                                                            <input type="hidden" name="acl"  ng-value="ConfigurationModel.Fileuploadsettings.acl">
                                                            <input type="hidden" name="success_action_status"  ng-value="ConfigurationModel.Fileuploadsettings.success_action">
                                                            <input type="hidden" name="policy"  ng-value="ConfigurationModel.Fileuploadsettings.base64Policy">
                                                            <input type="hidden" name="signature"  ng-value="ConfigurationModel.Fileuploadsettings.signature">
                                                            <input type="hidden" name="Cache-Control" ng-value="ConfigurationModel.Fileuploadsettings.cacheControlTime">
                                                            <span  class="btn default btn-file" ><input type="file" name="file" id="file" title="Choose Image" ng-model="ConfigurationModel.PublisherLogoPath" required> Choose Image</span>
                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage()" ng-hide="((ConfigurationModel.PublisherLogoPath == NULL) || (ConfigurationModel.PublisherLogoPath == ''))"> Remove </a>
                                                            <span></span>
                                                        </form>
                                                    </div>
                                                    <span>&nbsp;</span>
                                                    <div class="progress progress-striped display-none">
                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                        </div>
                                                    </div>
                                                    <div ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ImageForm.file.$error}" class="has-error">
                                                        <div class="help-block" ng-messages="ImageForm.file.$error" ng-if="ConfigurationForm.$submitted">
                                                            <div ng-show="ImageForm.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Publisher Logo'))}}</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                <div class="col-md-12 col-sm-12 col-xs-12  no-padding">
                                                    <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.WebsiteBaseURL.$invalid}">
                                                        <label for="Website Base URL" class="control-label">Website Base URL</label>
                                                        <input class="form-control"  type="text" name="WebsiteBaseURL" ng-model="ConfigurationModel.WebsiteBaseURL" ng-class="{ 'has-submitted' : ConfigurationForm.$submitted }" pattern="<?php echo \Infrastructure\Constants::$WebsiteBaseURLRegex;?>" required />
                                                        <div class="help-block" ng-messages="ConfigurationForm.WebsiteBaseURL.$error" ng-if="ConfigurationForm.$submitted">
                                                            <div ng-show="ConfigurationForm.WebsiteBaseURL.$error.required  && ConfigurationForm.WebsiteBaseURL.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Website Base URL'))}}</div>
                                                            <div ng-show="ConfigurationForm.WebsiteBaseURL.$error.pattern">{{ trans('messages.InvalidWebsiteBaseURL')}}</div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.PublisherName.$invalid}">
                                                        <label for="Publisher Name" class="control-label">Publisher Name</label>
                                                        <span tooltip data-toggle="tooltip" data-placement="bottom" title="Publisher for pages & posts in Google search (SEO)">
                                                            <i class="fa fa-info-circle font-size-18px margin-top-10"></i>
                                                        </span>
                                                        <input class="form-control"  type="text" name="PublisherName" ng-model="ConfigurationModel.PublisherName" ng-class="{ 'has-submitted' : ConfigurationForm.$submitted }" required />
                                                        <div class="help-block" ng-messages="ConfigurationForm.PublisherName.$error" ng-if="ConfigurationForm.$submitted">
                                                            <div ng-show="ConfigurationForm.PublisherName.$error.required  && ConfigurationForm.PublisherName.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Publisher Name'))}}</div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <!--
                                                <div class="col-md-12 col-sm-12 col-xs-12  no-padding">
                                                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                                        <label for="Blog Section" class="control-label">Blog Section</label>
                                                        <input class="form-control"  type="text" name="BlogSection" ng-model="ConfigurationModel.BlogSection" />
                                                    </div>
                                                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                                        <label for="Page Section" class="control-label">Page Section</label>
                                                        <input class="form-control"  type="text" name="PageSection" ng-model="ConfigurationModel.PageSection" />
                                                    </div>
                                                </div>
                                                -->

                                                <div class="col-md-12 col-sm-12 col-xs-12  no-padding">
                                                    <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.Timezone.$invalid}">
                                                        <label for="Timezone" class="control-label">Timezone</label>
                                                        <select class="form-control" id="Timezone" name="Timezone" ng-model="ConfigurationModel.Timezone" ng-options="TimeZones.MySQLTimezone as TimeZones.MySQLTimezone for TimeZones in TimeZonesArray" ng-class="{ 'has-submitted' : ConfigurationForm.$submitted }" required>
                                                            <option value="">Select Timezone</option>
                                                        </select>
                                                        <div class="help-block"  ng-messages="ConfigurationForm.Timezone.$error" ng-if="ConfigurationForm.$submitted">
                                                            <div  ng-show="ConfigurationForm.Timezone.$error.required && ConfigurationForm.Timezone.$invalid">{{ trans('messages.PropertyRequired',array('attribute'=>'Timezone'))}}</div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.GeoAPIKey.$invalid}">
                                                        <label for="Geo API Key" class="control-label">Geo API Key</label>
                                                        <span tooltip data-toggle="tooltip" data-placement="bottom" title="Google Geocoding API key used to get latitude & longitude from an address">
                                                            <i class="fa fa-info-circle font-size-18px margin-top-10"></i>
                                                        </span>
                                                        <input class="form-control"  type="text" name="GeoAPIKey" ng-model="ConfigurationModel.GeoAPIKey" ng-class="{ 'has-submitted' : ConfigurationForm.$submitted }" required />
                                                        <div class="help-block" ng-messages="ConfigurationForm.GeoAPIKey.$error" ng-if="ConfigurationForm.$submitted">
                                                            <div ng-show="ConfigurationForm.GeoAPIKey.$error.required  && ConfigurationForm.GeoAPIKey.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Geo API Key'))}}</div>
                                                        </div>
                                                    </div>





                                                </div>
                                                <!-- Contact Info -->
                                                <div class="col-md-12 col-sm-12 col-xs-12  no-padding">
                                                    <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.ContactNo.$invalid}">
                                                        <label for="Contact Number" class="control-label">Contact Number</label>
                                                        <input class="form-control"  type="text" name="ContactNo" ng-model="ConfigurationModel.ContactNo" ng-class="{ 'has-submitted' : ConfigurationForm.$submitted }" restrict="reject"
                                                        <?php
                                                            switch ($ConfigurationModel->ConfigurationDetails->SiteID) {
                                                                case Constants::$MercerVineSiteID :
                                                                    echo "mask='9.999.999.9999' maxlength='14'";
                                                                    break;

                                                                case Constants::$RiverDaleFundingSiteID :
                                                                    echo "mask='999-999-9999' maxlength='13'";
                                                                    break;

                                                                case Constants::$ColoradoSiteID :
                                                                    echo "mask='999-999-9999' maxlength='13'";
                                                                    break;

                                                                case Constants::$WoodBridgeWealthSiteID :
                                                                    echo "mask='999-999-9999' maxlength='13'";
                                                                    break;

                                                                default:
                                                                    echo "mask='999.999.9999' maxlength='14'";
                                                                    break;
                                                            }
                                                        ?>
                                                        required />
                                                        <div class="help-block" ng-messages="ConfigurationForm.ContactNo.$error" ng-if="ConfigurationForm.$submitted">
                                                            <div ng-show="ConfigurationForm.ContactNo.$error.required  && ConfigurationForm.ContactNo.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Contact Number'))}}</div>
                                                            <div ng-show="ConfigurationForm.ContactNo.$error.mask">{{ trans('messages.InvalidContactNumber')}}</div>
                                                        </div>
                                                    </div>

                                                    <?php if( $ConfigurationModel->ConfigurationDetails->SiteID == ( Constants::$ColoradoSiteID)){ ?>
                                                    <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.Address.$invalid}">
                                                        <label for="Geo Location" class="control-label">Address</label>

                                                        <textarea class="form-control"  type="text" name="Address" ng-model="ConfigurationModel.Address" ng-class="{ 'has-submitted' : ConfigurationForm.$submitted }" required /></textarea>
                                                        <div class="help-block" ng-messages="ConfigurationForm.Address.$error" ng-if="ConfigurationForm.$submitted">
                                                            <div ng-show="ConfigurationForm.Address.$error.required  && ConfigurationForm.Address.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Address'))}}</div>
                                                        </div>
                                                    </div>
                                                    <?php }?>
                                                </div>

                                                <div class="col-md-12 col-sm-12 col-xs-12  no-padding">
                                                    <?php if( $ConfigurationModel->ConfigurationDetails->SiteID == ( Constants::$ColoradoSiteID)){ ?>
                                                    <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.AlternateContactNo.$invalid}">
                                                        <label for="Contact Number" class="control-label">Alternate Contact Number</label>
                                                        <input class="form-control"  type="text" name="AlternateContactNo" ng-model="ConfigurationModel.AlternateContactNo" ng-class="{ 'has-submitted' : ConfigurationForm.$submitted }" restrict="reject"
                                                        <?php
                                                            switch ($ConfigurationModel->ConfigurationDetails->SiteID) {
                                                                case Constants::$MercerVineSiteID :
                                                                    echo "mask='9.999.999.9999' maxlength='14'";
                                                                    break;

                                                                case Constants::$RiverDaleFundingSiteID:
                                                                    echo "mask='999-999-9999' maxlength='13'";
                                                                    break;

                                                                case Constants::$WoodBridgeWealthSiteID:
                                                                    echo "mask='999-999-9999' maxlength='13'";
                                                                    break;

                                                                case Constants::$ColoradoSiteID :
                                                                    echo "mask='999-999-9999' maxlength='13'";
                                                                    break;

                                                            }
                                                        ?>
                                                        required />
                                                        <div class="help-block" ng-messages="ConfigurationForm.AlternateContactNo.$error" ng-if="ConfigurationForm.$submitted">
                                                            <div ng-show="ConfigurationForm.AlternateContactNo.$error.required  && ConfigurationForm.AlternateContactNo.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Alternate Contact Number'))}}</div>
                                                            <div ng-show="ConfigurationForm.AlternateContactNo.$error.mask">{{ trans('messages.InvalidContactNumber')}}</div>
                                                        </div>
                                                    </div>


                                                    <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.Address.$invalid}">
                                                        <label for="Geo Location" class="control-label">Contact Us Page Email-Id</label>
                                                        <input class="form-control"  type="text" name="EmailId" ng-model="ConfigurationModel.EmailId" ng-class="{ 'has-submitted' : ConfigurationForm.$submitted }" pattern="<?php echo \Infrastructure\Constants::$emailRegex?>" required />
                                                        <div class="help-block" ng-messages="ConfigurationForm.EmailId.$error" ng-if="ConfigurationForm.$submitted">
                                                            <div ng-show="ConfigurationForm.EmailId.$error.required  && ConfigurationForm.EmailId.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Email-Id'))}}</div>
                                                            <div ng-show="ConfigurationForm.EmailId.$error.pattern">{{ trans('messages.InvalidAlternateFromEmailAddress')}}</div>
                                                        </div>

                                                    </div>
                                                    <?php }?>
                                                </div>


                                                <!-- Contact Info -->
                                                <div class="col-md-12 col-sm-12 col-xs-12  no-padding">
                                                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                                        <label for=">Script insert before" class="control-label">Script tag to be inserted before &lt;/head&gt;</label>
                                                        <textarea class="form-control" rows="5" name="ScriptBeforeHead" ng-model="ConfigurationModel.ScriptBeforeHead"></textarea>
                                                    </div>
                                                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                                        <label for=">Script insert before" class="control-label">Script tag to be inserted before &lt;/body&gt; </label>
                                                        <textarea class="form-control" rows="5" name="ScriptBeforeBody" ng-model="ConfigurationModel.ScriptBeforeBody"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12 hidden-md hidden-xs">
                                                <div class="col-md-12 no-padding">
                                                    <label for="SMTPPassword" class="control-label">Publisher Logo</label>
                                                    <span tooltip data-toggle="tooltip" data-placement="bottom" title="Publisher logo for pages & posts in Google search (SEO)">
                                                                <i class="fa fa-info-circle font-size-18px margin-top-10"></i>
                                                    </span>
                                                </div>
                                                <div class="fileinput fileinput-new">
                                                    <div  class="fileinput-new thumbnail image-box">
                                                        <img  src="<?php echo asset('/assets/images/ajax-loader2.gif'); ?>" id="loadingImage" class="site-loadingImage display-none loadingImage" >
                                                        <img id="actualImage" alt="" src="@{{ConfigurationModel.RealImagePath ? ConfigurationModel.RealImagePath : ConfigurationModel.NoImagePath}}">
                                                    </div>
                                                    <div>
                                                        <form></form>
                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" id="directupload" name="ImageForm" role="form" novalidate>
                                                            <input type="hidden" id="key" name="key" value="">
                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="ConfigurationModel.Fileuploadsettings.accesskey">
                                                            <input type="hidden" name="acl"  ng-value="ConfigurationModel.Fileuploadsettings.acl">
                                                            <input type="hidden" name="success_action_status"  ng-value="ConfigurationModel.Fileuploadsettings.success_action">
                                                            <input type="hidden" name="policy"  ng-value="ConfigurationModel.Fileuploadsettings.base64Policy">
                                                            <input type="hidden" name="signature"  ng-value="ConfigurationModel.Fileuploadsettings.signature">
                                                            <input type="hidden" name="Cache-Control" ng-value="ConfigurationModel.Fileuploadsettings.cacheControlTime">
                                                            <span  class="btn default btn-file" ><input type="file" name="file" id="file" title="Choose Image" ng-model="ConfigurationModel.PublisherLogoPath" required> Choose Image</span>
                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage()" ng-hide="((ConfigurationModel.PublisherLogoPath == NULL) || (ConfigurationModel.PublisherLogoPath == ''))"> Remove </a>
                                                            <span></span>
                                                        </form>
                                                    </div>
                                                    <span>&nbsp;</span>
                                                    <div class="progress progress-striped display-none">
                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                        </div>
                                                    </div>
                                                    <div ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ImageForm.file.$error}" class="has-error">
                                                        <div class="help-block" ng-messages="ImageForm.file.$error" ng-if="ConfigurationForm.$submitted">
                                                            <div ng-show="ImageForm.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Publisher Logo'))}}</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="clearboth"></div>
                    <!-- Configuration settings part end -->

                    <!-- Social settings part Start -->
                    <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                        <div class="portlet box blue-hoki" ng-cloak>
                            <div class="portlet-title" collapse>
                                <div class="caption">
                                    <i class=""></i>SOCIAL</div>
                                <div class="tools">
                                    <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                </div>
                            </div>
                            <div class="portlet-body">
                                <div class="row">
                                    <div class="col-md-12 no-padding">
                                        <div class="form-body" >
                                            <div class="col-md-9 no-padding">
                                                <div class="col-md-12 col-sm-12 col-xs-12  no-padding">
                                                    <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.FacebookURL.$invalid }">
                                                        <label for="Facebook URL" class="control-label">Facebook URL</label>
                                                        <input class="form-control" type="text" name="FacebookURL" data-ng-model="ConfigurationModel.FacebookURL" pattern="<?php echo \Infrastructure\Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : ConfigurationForm.$submitted }"  ng-required/>
                                                        <div class="help-block" ng-show="(ConfigurationForm.FacebookURL !='') && ( ConfigurationForm.$submitted )">
                                                            <div ng-show="ConfigurationForm.$dirty && ConfigurationForm.FacebookURL.$invalid && ConfigurationModel.FacebookURL != ''">{{ trans('messages.InvalidFacebookURL')}}</div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.InstagramURL.$invalid }">
                                                        <label for="Instagram URL" class="control-label">Instagram URL</label>
                                                        <input class="form-control" type="text" name="InstagramURL" data-ng-model="ConfigurationModel.InstagramURL" pattern="<?php echo \Infrastructure\Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : ConfigurationForm.$submitted }"  ng-required/>
                                                        <div class="help-block" ng-show="(ConfigurationForm.InstagramURL !='') && ( ConfigurationForm.$submitted )">
                                                            <div ng-show="ConfigurationForm.$dirty && ConfigurationForm.InstagramURL.$invalid && ConfigurationModel.InstagramURL != ''">{{ trans('messages.InvalidInstagramURL')}}</div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12 col-sm-12 col-xs-12  no-padding">
                                                    <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.YoutubeURL.$invalid }">
                                                        <label for="Youtube URL" class="control-label">Youtube URL</label>
                                                        <input class="form-control" type="text" name="YoutubeURL" data-ng-model="ConfigurationModel.YoutubeURL" pattern="<?php echo Constants::$YoutubeAnyUrlRegex; ?>" ng-class="{ 'has-submitted' : ConfigurationForm.$submitted }"  ng-required/>
                                                        <div class="help-block" ng-show="(ConfigurationForm.YoutubeURL !='') && ( ConfigurationForm.$submitted )">
                                                            <div ng-show="ConfigurationForm.$dirty && ConfigurationForm.YoutubeURL.$invalid && ConfigurationModel.YoutubeURL != ''">{{ trans('messages.InvalidYoutubeURL')}}</div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.PinterestURL.$invalid }">
                                                        <label for="Pinterest URL" class="control-label">Pinterest URL</label>
                                                        <input class="form-control" type="text" name="PinterestURL" data-ng-model="ConfigurationModel.PinterestURL" pattern="<?php echo \Infrastructure\Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : ConfigurationForm.$submitted }"  ng-required/>
                                                        <div class="help-block" ng-show="(ConfigurationForm.PinterestURL !='') && ( ConfigurationForm.$submitted )">
                                                            <div ng-show="ConfigurationForm.$dirty && ConfigurationForm.PinterestURL.$invalid && ConfigurationModel.PinterestURL != ''">{{ trans('messages.InvalidPinterestURL')}}</div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12 col-sm-12 col-xs-12  no-padding">
                                                    <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.LinkedInURL.$invalid }">
                                                        <label for="LinkedIn URL" class="control-label">LinkedIn URL</label>
                                                        <input class="form-control" type="text" name="LinkedInURL" data-ng-model="ConfigurationModel.LinkedInURL" pattern="<?php echo \Infrastructure\Constants::$LinkedInUrlRegex; ?>" ng-class="{ 'has-submitted' : ConfigurationForm.$submitted }"  ng-required/>
                                                        <div class="help-block" ng-show="(ConfigurationForm.LinkedInURL !='') && ( ConfigurationForm.$submitted )">
                                                            <div ng-show="ConfigurationForm.$dirty && ConfigurationForm.LinkedInURL.$invalid && ConfigurationModel.LinkedInURL != ''">{{ trans('messages.InvalidLinkedInURL')}}</div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.GooglePlusURL.$invalid }">
                                                        <label for="Google Plus URL" class="control-label">Google Plus URL</label>
                                                        <input class="form-control" type="text" name="GooglePlusURL" data-ng-model="ConfigurationModel.GooglePlusURL" pattern="<?php echo \Infrastructure\Constants::$GooglePlusUrlRegex; ?>" ng-class="{ 'has-submitted' : ConfigurationForm.$submitted }"  ng-required/>
                                                        <div class="help-block" ng-show="(ConfigurationForm.GooglePlusURL !='') && ( ConfigurationForm.$submitted )">
                                                            <div ng-show="ConfigurationForm.$dirty && ConfigurationForm.GooglePlusURL.$invalid && ConfigurationModel.GooglePlusURL != ''">{{ trans('messages.InvalidGooglePlusURL')}}</div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12 col-sm-12 col-xs-12  no-padding">
                                                    <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.TwitterUsername.$invalid}">
                                                        <label for="Twitter username" class="control-label">Twitter Username</label>
                                                        <input class="form-control" type="text" name="TwitterUsername" ng-model="ConfigurationModel.TwitterUsername" ng-class="{ 'has-submitted' : ConfigurationForm.$submitted }" required />
                                                        <div class="help-block" ng-messages="ConfigurationForm.TwitterUsername.$error" ng-if="ConfigurationForm.$submitted">
                                                            <div ng-show="ConfigurationForm.TwitterUsername.$error.required  && ConfigurationForm.TwitterUsername.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Twitter Username'))}}</div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.FacebookAppID.$invalid}">
                                                        <label for="Facebook app id" class="control-label">Facebook app id</label>
                                <span tooltip data-toggle="tooltip" data-placement="bottom" title="Needed for login via Facebook">
								    <i class="fa fa-info-circle font-size-18px margin-top-10"></i>
								</span>
                                                        <input class="form-control"  type="text" name="FacebookAppID" ng-model="ConfigurationModel.FacebookAppID"  />
                                                        <!--<div class="help-block" ng-messages="ConfigurationForm.FacebookAppId.$error" ng-if="ConfigurationForm.$submitted">
                                                            <div ng-show="ConfigurationForm.FacebookAppID.$error.required  && ConfigurationForm.FacebookAppID.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Facebook app id'))}}</div>
                                                        </div>-->
                                                    </div>
                                                </div>
                                                <div class="col-md-12 col-sm-12 col-xs-12  no-padding">
                                                    <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.LinkedInAppID.$invalid}">
                                                        <label for="LinkedIn app id" class="control-label">LinkedIn app id</label>
                                <span tooltip data-toggle="tooltip" data-placement="bottom" title="Needed for login via LinkedIn">
								    <i class="fa fa-info-circle font-size-18px margin-top-10"></i>
								</span>
                                                        <input class="form-control"  type="text" name="LinkedInAppID" ng-model="ConfigurationModel.LinkedInAppID" />
                                                        <!--<div class="help-block" ng-messages="ConfigurationForm.LinkedInAppID.$error" ng-if="ConfigurationForm.$submitted">
                                                            <div ng-show="ConfigurationForm.LinkedInAppID.$error.required  && ConfigurationForm.LinkedInAppID.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'LinkedIn app id'))}}</div>
                                                        </div>-->
                                                    </div>
                                                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                                        <label for="Google CSE ID" class="control-label">Google CSE Key</label>
                                                            <span tooltip data-toggle="tooltip" data-placement="bottom" title="Search engine key, needed for Google Site Search">
                                                                <i class="fa fa-info-circle font-size-18px margin-top-10"></i>
                                                            </span>
                                                        <input class="form-control" type="text" name="GoogleCSEKey" ng-model="ConfigurationModel.GoogleCSEKey"/>
                                                    </div>


                                                   <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                                        <label for="Google CSE ID" class="control-label">Google CSE ID</label>
                                                            <span tooltip data-toggle="tooltip" data-placement="bottom" title="Search engine identifier, needed for Google Site Search">
                                                                <i class="fa fa-info-circle font-size-18px margin-top-10"></i>
                                                            </span>
                                                        <input class="form-control" type="text" name="GoogleCSEID" ng-model="ConfigurationModel.GoogleCSEID"/>
                                                   </div>


                                                   <?php if( $ConfigurationModel->ConfigurationDetails->SiteID == ( Constants::$ColoradoSiteID)){ ?>
                                                   <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.houzzURL.$invalid}">
                                                        <label for="Google CSE ID" class="control-label">Houzz Url</label>

                                                        <input class="form-control" type="text" name="houzzURL" ng-model="ConfigurationModel.houzzURL" pattern="<?php echo \Infrastructure\Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : ConfigurationForm.$submitted }"  />
                                                        <div class="help-block" ng-messages="ConfigurationForm.houzzURL.$error" ng-if="ConfigurationForm.$submitted">
                                                            <div ng-show="ConfigurationForm.houzzURL.$error.pattern">{{ trans('messages.InvalidhouzzURL')}}</div>
                                                        </div>
                                                   </div>
                                                    <?php }?>




                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="clearboth"></div>
                    <!-- Social settings part End -->

                    <!-- SMTP settings part Start  -->
                    <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                        <div class="portlet box blue-hoki" ng-cloak>
                            <div class="portlet-title" collapse>
                                <div class="caption">
                                    <i class=""></i>SMTP</div>
                                <div class="tools">
                                    <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                </div>
                            </div>
                            <div class="portlet-body">
                                <div class="row">
                                    <div class="col-md-12 no-padding">
                                        <div class="form-body " ng-cloak >
                                            <div class="col-md-12 col-sm-12 col-xs-12  no-padding">
                                                <div class="form-group col-md-4 col-sm-4 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.SMTPHost.$invalid}">
                                                    <label for="SMTPHost" class="control-label">Host</label>
                                                    <input class="form-control"  type="text" name="SMTPHost" ng-model="ConfigurationModel.SMTPHost" ng-class="{ 'has-submitted' : ConfigurationForm.$submitted }" required />
                                                    <div class="help-block" ng-messages="ConfigurationForm.SMTPHost.$error" ng-if="ConfigurationForm.$submitted">
                                                        <div ng-show="ConfigurationForm.SMTPHost.$error.required  && ConfigurationForm.SMTPHost.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Host'))}}</div>
                                                    </div>
                                                </div>
                                                <div class="form-group col-md-4 col-sm-4 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.SMTPUserName.$invalid}">
                                                    <label for="SMTPUserName" class="control-label">Username</label>
                                                    <input class="form-control"  type="text" name="SMTPUserName" ng-model="ConfigurationModel.SMTPUserName" ng-class="{ 'has-submitted' : ConfigurationForm.$submitted }" required />
                                                    <div class="help-block" ng-messages="ConfigurationForm.SMTPUserName.$error" ng-if="ConfigurationForm.$submitted">
                                                        <div ng-show="ConfigurationForm.SMTPUserName.$error.required  && ConfigurationForm.SMTPUserName.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Username'))}}</div>
                                                    </div>
                                                </div>
                                                <div class="form-group col-md-4 col-sm-4 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.SMTPPassword.$invalid}">
                                                    <label for="SMTPPassword" class="control-label">Password</label>
                                                    <input class="form-control"  type="text" name="SMTPPassword" ng-model="ConfigurationModel.SMTPPassword" ng-class="{ 'has-submitted' : ConfigurationForm.$submitted }" required />
                                                    <div class="help-block" ng-messages="ConfigurationForm.SMTPPassword.$error" ng-if="ConfigurationForm.$submitted">
                                                        <div ng-show="ConfigurationForm.SMTPPassword.$error.required  && ConfigurationForm.SMTPPassword.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Password'))}}</div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                <div class="form-group col-md-4 col-sm-4 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.SMTPPort.$invalid}">
                                                    <label for="SMTPPort" class="control-label">Port</label>
                                                    <input class="form-control"  type="text" name="SMTPPort" ng-model="ConfigurationModel.SMTPPort" ng-class="{ 'has-submitted' : ConfigurationForm.$submitted }" required />
                                                    <div class="help-block" ng-messages="ConfigurationForm.SMTPPort.$error" ng-if="ConfigurationForm.$submitted">
                                                        <div ng-show="ConfigurationForm.SMTPPort.$error.required  && ConfigurationForm.SMTPPort.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Port'))}}</div>
                                                    </div>
                                                </div>
                                                <div class="form-group col-md-4 col-sm-4 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.SMTPFromAddress.$invalid}">
                                                    <label for="SMTPFromAddress" class="control-label">From email address</label>
                                                    <input class="form-control"  type="text" name="SMTPFromAddress" ng-model="ConfigurationModel.SMTPFromAddress" ng-class="{ 'has-submitted' : ConfigurationForm.$submitted }" pattern="<?php echo \Infrastructure\Constants::$emailRegex?>" required />
                                                    <div class="help-block" ng-messages="ConfigurationForm.SMTPFromAddress.$error" ng-if="ConfigurationForm.$submitted">
                                                        <div ng-show="ConfigurationForm.SMTPFromAddress.$error.required  && ConfigurationForm.SMTPFromAddress.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'From email address'))}}</div>
                                                        <div ng-show="ConfigurationForm.SMTPFromAddress.$error.pattern">{{ trans('messages.InvalidFromEmailAddress')}}</div>
                                                    </div>
                                                </div>
                                                <div class="form-group col-md-4 col-sm-4 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.SMTPFromName.$invalid}">
                                                    <label for="SMTPFromName" class="control-label">From Name</label>
                                                    <input class="form-control"  type="text" name="SMTPFromName" ng-model="ConfigurationModel.SMTPFromName" ng-class="{ 'has-submitted' : ConfigurationForm.$submitted }" required />
                                                    <div class="help-block" ng-messages="ConfigurationForm.SMTPFromAddress.$error" ng-if="ConfigurationForm.$submitted">
                                                        <div ng-show="ConfigurationForm.SMTPFromName.$error.required  && ConfigurationForm.SMTPFromName.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'From Name'))}}</div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group col-md-4 col-sm-4 col-xs-12">
                                                <input type="checkbox" name="IsSSL" ng-model="ConfigurationModel.IsSSL" ng-true-value="1" ng-false-value="0"/>
                                                <label for="IsSSL" class="control-label">Use Secured Connection (SSL)</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="clearboth"></div>
                    <!-- SMTP settings part Start -->

                    <!-- REST settings part Start -->
                    <?php if($ConfigurationModel->ConfigurationDetails->SiteID == ( Constants::$MercerVineSiteID) || $ConfigurationModel->ConfigurationDetails->SiteID == ( Constants::$ColoradoSiteID)){ ?>
                    <div class="col-md-12 col-sm-12 col-xs-12  no-padding">
                        <div class="portlet box blue-hoki" ng-cloak>
                            <div class="portlet-title" collapse>
                                <div class="caption">
                                    <i class=""></i>RETS</div>
                                <div class="tools">
                                    <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                </div>
                            </div>
                            <div class="portlet-body">
                                <div class="row">
                                    <div class="col-md-12 no-padding">
                                        <div class="form-body" >
                                            <div class="col-md-12 no-padding">
                                                <div class="form-body " ng-cloak >
                                                    <div class="col-md-9 col-sm-12 col-xs-12 no-padding">
                                                        <div class="col-md-12 col-sm-12 col-xs-12  no-padding">
                                                            <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                                                <label for="RETSUserName" class="control-label">RETS Username</label>
                                                                <input class="form-control"  type="text" name="RETSUserName" ng-model="ConfigurationModel.RETSUserName"/>
                                                            </div>
                                                            <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                                                <label for="RETS Password" class="control-label">RETS Password</label>
                                                                <input class="form-control"  type="text" name="RETSPassword" ng-model="ConfigurationModel.RETSPassword" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="clearboth"></div>
                    <?php } ?>
                    <!-- REST settings part end -->

                    <!-- Home settings part Start -->
                    <?php if($ConfigurationModel->ConfigurationDetails->SiteID == ( Constants::$MercerVineSiteID) || $ConfigurationModel->ConfigurationDetails->SiteID == ( Constants::$RiverDaleFundingSiteID)){ ?>
                    <div class="col-md-12 col-sm-12 col-xs-12  no-padding">
                        <div class="portlet box blue-hoki" ng-cloak>
                            <div class="portlet-title" collapse>
                                <div class="caption">
                                    <i class=""></i>HOME PAGE SETTINGS</div>
                                <div class="tools">
                                    <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                </div>
                            </div>
                            <div class="portlet-body">
                                <div class="row">
                                    <div class="col-md-12 no-padding">
                                        <div class="form-body " ng-cloak >
                                            <div class="col-md-9 col-sm-12 col-xs-12 no-padding">
                                              <!--  <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.NoOfImagesToShowForListing.$invalid}">
                                                    <label for="No. of Images to show for a Listing" class="control-label">No. of Images to show for a Listing</label>
                                                    <input class="form-control"  type="text" name="NoOfImagesToShowForListing" ng-model="ConfigurationModel.NoOfImagesToShowForListing" ng-class="{ 'has-submitted' : ConfigurationForm.$submitted }" intype="digit" required />
                                                    <div class="help-block" ng-messages="ConfigurationForm.NoOfImagesToShowForListing.$error" ng-if="ConfigurationForm.$submitted">
                                                        <div ng-show="ConfigurationForm.NoOfImagesToShowForListing.$error.required && ConfigurationForm.NoOfImagesToShowForListing.$invalid">{{ trans('messages.PropertyRequired',array('attribute'=>'No. of Images to show for a Listing'))}}</div>
                                                    </div>
                                                </div>  -->
                                                <?php if($ConfigurationModel->ConfigurationDetails->SiteID == ( Constants::$MercerVineSiteID )){ ?>
                                                <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.NoOfPropertiesToShowOnExclusiveProperties.$invalid}">
                                                    <label for="No. of Properties to show on" class="control-label">No. of Properties to show on Exclusive Properties</label>
                                                    <input class="form-control"  type="text" name="NoOfPropertiesToShowOnExclusiveProperties" ng-model="ConfigurationModel.NoOfPropertiesToShowOnExclusiveProperties" ng-class="{ 'has-submitted' : ConfigurationForm.$submitted }" intype="digit" required />
                                                    <div class="help-block" ng-messages="ConfigurationForm.NoOfPropertiesToShowOnExclusiveProperties.$error" ng-if="ConfigurationForm.$submitted">
                                                        <div ng-show="ConfigurationForm.NoOfPropertiesToShowOnExclusiveProperties.$error.required && ConfigurationForm.NoOfPropertiesToShowOnExclusiveProperties.$invalid">{{ trans('messages.PropertyRequired',array('attribute'=>'No. of Properties to show on Exclusive Properties'))}}</div>
                                                    </div>
                                                </div>
                                                <?php } ?>
                                                <?php if($ConfigurationModel->ConfigurationDetails->SiteID == ( Constants::$RiverDaleFundingSiteID )){ ?>
                                                <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (ConfigurationForm.$submitted) && ConfigurationForm.RDNoOfLoanClosedToShow.$invalid}">
                                                    <label for="No. of Properties to show on" class="control-label">No. of Loans Closed to show on footer section</label>
                                                    <input class="form-control"  type="text" name="RDNoOfLoanClosedToShow" ng-model="ConfigurationModel.RDNoOfLoanClosedToShow" ng-class="{ 'has-submitted' : ConfigurationForm.$submitted }" intype="digit" required />
                                                    <div class="help-block" ng-messages="ConfigurationForm.RDNoOfLoanClosedToShow.$error" ng-if="ConfigurationForm.$submitted">
                                                        <div ng-show="ConfigurationForm.RDNoOfLoanClosedToShow.$error.required && ConfigurationForm.RDNoOfLoanClosedToShow.$invalid">{{ trans('messages.PropertyRequired',array('attribute'=>'No. of Loans Closed to shown'))}}</div>
                                                    </div>
                                                </div>
                                                <?php } ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="clearboth"></div>
                    <!-- Home settings part Start -->
                    <?php } ?>
                    <!-- Submit part Start -->
                    <div class="col-md-12 no-padding">
                        <input id="submit" name="submit" type="submit" value="Save" class="btn blue save-button" data-ng-click="SaveConfiguration()" ng-disabled="DisableButtons">
                        <button type="button" id="cancel" class="btn default" data-ng-click="Cancel()" ng-disabled="DisableButtons">Cancel</button>
                    </div>
                    <!-- Submit part End -->
             </div>

        </div>
    </div>
    </form>
</main>
@stop

@section('script')
    {{ $minify::javascript(array('/assets/js/viewjs/configuration/addconfiguration.js'))->withFullUrl()}}

    {{ $minify::javascript(array('/assets/js/library/jquery.fileupload/jquery.ui.widget.js',
                                '/assets/js/library/jquery.fileupload/jquery.fileupload.js',
                                '/assets/js/library/binaryajax.js',
                                '/assets/js/library/exif.js',
                                '/assets/js/library/bootstrap-fileinput.js',
                                '/assets/js/sitejs/canvasResize.js'))->withFullUrl()}}
    <script>
        window.ImageFileAllowedMessage ="{{ trans('messages.ImageFileAllowedMessage')}}";
        window.ConfirmUploadMessage ="{{ trans('messages.ConfirmUploadMessage')}}";
        window.DefaultUploadPhotoHeight='<?php echo Constants::$DefaultUploadProfileHeight;?>';
        window.DefaultUploadPhotoWidth='<?php echo Constants::$DefaultUploadProfileWidth?>';
        window.NoImagePath = '<?php echo asset('/assets/images/Samplephoto.png') ?>';
    </script>
@stop