<?php
use Infrastructure\Constants;
$minify = new \CeesVanEgmond\Minify\Facades\Minify;
$FBImageType = Constants::$FBImageType;
$TwitterImageType = Constants::$TwitterImageType;
$GoogleImageType = Constants::$GoogleImageType;
$ImageMaxSize = Constants::$ImageMaxSize;
?>
@extends('layouts.sitemaster')
@section('Title')
    <?php if($BlogModel->BlogDetails->BlogPostID > 0 && $BlogModel->ViewPage==0 && $BlogModel->CanEditSEOFields==0) { print 'View Blog Post'; }else if($BlogModel->BlogDetails->BlogPostID > 0 && ($BlogModel->ViewPage==1 or $BlogModel->CanEditSEOFields==1)){ print 'Edit Blog Post';} else {print 'Add Blog Post';} ?>
@stop
@section('css')
    {{ $minify::stylesheet(array('/assets/css/tagsinput/ng-tags-input.min.css'))->withFullUrl()}}
@stop
@section('content')
    <main id="main" role="main" xmlns="http://www.w3.org/1999/html" data-ng-controller="BlogController">
        <?php echo Form::hidden('BlogModel', htmlspecialchars(json_encode($BlogModel), ENT_QUOTES, 'UTF-8'),$attributes = array('id'=>'BlogModel'));?>
        <form name="BlogForm" id="BlogForm" role="form" novalidate   ng-submit="checkSave(BlogForm)">
            <div class="page-content" >
                <div class="page-bar">
                    <ul class="page-breadcrumb">
                        <li>
                            <a href="<?php echo URL::to('/dashboard/'.$encryptedSiteID) ?>">Home</a>
                            <i class="fa fa-circle"></i>
                        </li>
                        <li>
                            <a href="<?php echo URL::to('/blogposts/'.$encryptedSiteID) ?>">Blog Posts</a>
                            <i class="fa fa-circle"></i>
                        </li>
                        <li>
                            <span><?php if($BlogModel->BlogDetails->BlogPostID > 0 && $BlogModel->ViewPage==0 && $BlogModel->CanEditSEOFields==0) { print 'View Blog Post'; }else if($BlogModel->BlogDetails->BlogPostID > 0 && ($BlogModel->ViewPage==1 or $BlogModel->CanEditSEOFields==1)){ print 'Edit Blog Post';} else {print 'Add Blog Post';} ?></span>
                        </li>
                    </ul>

                    <div class="page-toolbar">
                        <div class="btn-group pull-right" ng-cloak>
                            <input name="submit" type="submit" value="Save" class="btn blue save-button btn-submit btn-sm" ng-hide="BlogModel.ViewPage==0 && BlogModel.CanEditSEOFields==0" data-ng-click="Save()" ng-disabled="requestCounter != responseCounter"/>
                            <input  name="submit" type="submit" value="Approve" class="btn green-meadow save-button btn-submit btn-sm" data-ng-click="Approve()" ng-hide="BlogModel.ShowApproveDenyButton == 0 || BlogModel.ViewPage==0  || BlogModel.currentStatusID == <?php echo Constants::$WorkFlowStatus_Approve;?> || BlogModel.currentStatusID == <?php echo Constants::$WorkFlowStatus_Published;?>" ng-disabled="requestCounter != responseCounter"/>
                            <input  name="submit" type="submit" value="Deny" class="btn red-sunglo save-button btn-submit btn-sm" data-ng-click="Deny()" ng-hide="BlogModel.ShowApproveDenyButton == 0 || BlogModel.ViewPage==0 || BlogModel.currentStatusID == <?php echo Constants::$WorkFlowStatus_Denied;?> || BlogModel.currentStatusID == <?php echo Constants::$WorkFlowStatus_Published;?>" ng-disabled="requestCounter != responseCounter"/>
                            <input name="submit" type="submit" value="Publish" class="btn yellow-mint save-button btn-submit btn-sm" data-ng-click="Publish()" ng-hide="BlogModel.ShowPublishButton==0 || BlogModel.currentStatusID == <?php echo Constants::$WorkFlowStatus_Published;?>" ng-disabled="requestCounter != responseCounter"/>
                            <input id="delete" name="delete" type="button" value="Delete" class="btn btn-danger btn-submit btn-sm btn-outline" data-ng-click="DeleteBlogPost()" ng-show="BlogModel.BlogDetails.BlogPostID > 0 && (BlogModel.BlogDetails.LoggedInUserRoleID == <?php echo Constants::$RoleMarketingDirector;?> || BlogModel.BlogDetails.LoggedInUserRoleID == <?php echo Constants::$RoleITAdmin;?>)" ng-disabled="requestCounter != responseCounter">
                        </div>
                    </div>
                </div>

                <h3 class="page-title">
                    <?php if($BlogModel->BlogDetails->BlogPostID > 0 && $BlogModel->ViewPage==0 && $BlogModel->CanEditSEOFields==0) { print 'View Blog Post'; }else if($BlogModel->BlogDetails->BlogPostID > 0 && ($BlogModel->ViewPage==1 or $BlogModel->CanEditSEOFields==1)){ print 'Edit Blog Post';} else {print 'Add Blog Post';} ?>
                </h3>

                <div class="row">
                    <div class="col-md-12">

                        <div class="portlet box blue-hoki" ng-cloak>
                            <div class="portlet-title" collapse>
                                <div class="caption">
                                    <i class=""></i>Details</div>
                                <div class="tools">
                                    <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                </div>
                            </div>
                            <div class="portlet-body">
                                <div class="row">
                                    <div class="form-body" ng-cloak>
                                        <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12 visible-sm visible-xs">
                                            <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 no-padding">
                                                <label for="Category" class="control-label">Featured Image</label>
                                            </div>
                                            <div class="fileinput fileinput-new">
                                                <div class="fileinput-new thumbnail image-box">
                                                    <img src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                    <img id="actualImage" alt="" ng-src="@{{BlogModel.BlogDetails.RealFeaturedImagePath ? BlogModel.BlogDetails.RealFeaturedImagePath : BlogModel.BlogDetails.NoImagePath}}">
                                                </div>
                                                <div>
                                                    <form></form>
                                                    <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo Constants::$BlogFeaturedImageType; ?>">
                                                        <input type="hidden" id="key" name="key" value="">
                                                        <input type="hidden" name="AWSAccessKeyId"  ng-value="BlogModel.BlogDetails.Fileuploadsettings.accesskey">
                                                        <input type="hidden" name="acl"  ng-value="BlogModel.BlogDetails.Fileuploadsettings.acl">
                                                        <input type="hidden" name="success_action_status"  ng-value="BlogModel.BlogDetails.Fileuploadsettings.success_action">
                                                        <input type="hidden" name="policy"  ng-value="BlogModel.BlogDetails.Fileuploadsettings.base64Policy">
                                                        <input type="hidden" name="signature"  ng-value="BlogModel.BlogDetails.Fileuploadsettings.signature">
                                                        <input type="hidden" name="Cache-Control" ng-value="BlogModel.BlogDetails.Fileuploadsettings.cacheControlTime">
                                                        <span class="btn default btn-file" ><input type="file" name="file" id="file" title="Choose Image" > Choose Image </span>
                                                        <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo Constants::$BlogFeaturedImageType; ?>')" data-ng-hide="BlogModel.BlogDetails.RealFeaturedImagePath ==''">Remove</a>
                                                        <span></span>
                                                    </form>
                                                </div>
                                                <span>&nbsp;</span>
                                                <div class="progress progress-striped display-none">
                                                    <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                    </div>
                                                </div>
                                                <div class="info-alert" ng-if="(AllowedFeatureImageFixWidth > 0 &&  AllowedFeatureImageFixHeight > 0)"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedFeatureImageFixWidth }}x@{{ AllowedFeatureImageFixHeight }}px</lable></div>
                                            </div>
                                        </div>
                                            <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                <div class="col-md-12  no-padding">
                                                    <div class="form-group col-md-6 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (BlogForm.$submitted) && BlogForm.Title.$invalid}">
                                                        <label for="Title" class="control-label">Title</label>
                                                        <input class="form-control"  type="text" name="Title"  maxlength="200" data-ng-model="BlogModel.BlogDetails.Title" data-ng-class="{'has-submitted' : BlogForm.$submitted }"  ng-disabled="BlogModel.ViewPage==0" required />
                                                        <span class="error-text-color" ng-show="BlogForm.$submitted">
                                                            <span ng-show="BlogForm.Title.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Title'))}}</span>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-12  no-padding">
                                                    <div class="form-group col-md-6 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (BlogForm.$submitted) && BlogForm.Slug.$invalid}">
                                                        <label for="Slug" class="control-label">Slug</label>
                                                        <input class="form-control"  type="text" name="Slug"  maxlength="200" data-ng-model="BlogModel.BlogDetails.Slug" data-ng-class="{'has-submitted' : BlogForm.$submitted }" is-edit=BlogModel.BlogDetails.BlogPostID slug="BlogModel.BlogDetails.Title" required ng-disabled="BlogModel.ViewPage==0"/>
                                                        <span class="error-text-color" ng-show="BlogForm.$submitted">
                                                            <span ng-show="BlogForm.Slug.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Slug'))}}</span>
                                                        </span>
                                                    </div>
                                                    <div class="form-group col-md-6 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (BlogForm.$submitted) && BlogForm.Author.$invalid}">
                                                        <label for="Author" class="control-label">Author</label>
                                                        <select class="form-control" name="Author" ng-model="BlogModel.BlogDetails.AuthorID" ng-options="At.UserID as At.Name for At in BlogModel.AuthorListArray" data-ng-class="{'has-submitted' : BlogForm.$submitted }" required  ng-disabled="BlogModel.ViewPage==0"></select>
                                                        <span class="error-text-color" ng-show="BlogForm.$submitted">
                                                            <span ng-show="BlogForm.Author.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Author'))}}</span>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-12  no-padding">
                                                    <div class="form-group col-md-6 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (BlogForm.$submitted) && BlogForm.PostDate.$invalid}">
                                                        <label for="PostDate" class="control-label padding-bottom6px">Post Date</label>
                                                        <div class='input-group date col-md-8'>
                                                            <input type="text" class="form-control" id="PostDate"  name="PostDate" data-ng-model="BlogModel.BlogDetails.PostDate"  datepicker data-ng-class="{'has-submitted' : BlogForm.$submitted }" ng-disabled="BlogModel.ViewPage==0"  required />
                                                    <span class="input-group-addon" id="PostDateIcon">
                                                        <span class="glyphicon glyphicon-calendar"></span>
                                                    </span>
                                                        </div>
                                                <span class="error-text-color" ng-show="BlogForm.$submitted">
                                                    <span ng-show="BlogForm.PostDate.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Post Date'))}}</span>
                                                </span>
                                                    </div>

                                                    <div class="form-group col-md-6 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (BlogForm.$submitted) && ShowTagError}">
                                                        <label for="Tag" class="control-label">Tag</label>
                                                        <tags-input  ng-model="BlogModel.BlogDetails.Tag"
                                                                     display-property="Tag"
                                                                     replace-spaces-with-dashes="false"
                                                                     add-from-autocomplete-only="true"  class="ngTagsInput" ng-class="{ 'has-submitted' : BlogForm.$submitted }" ng-disabled="BlogModel.ViewPage==0" >
                                                            <auto-complete source="loadTags($query)"  min-length="0" load-on-focus="true" load-on-empty="false" template="my-custom-template" ></auto-complete>
                                                        </tags-input>
                                                        <script type="text/ng-template" id="my-custom-template">
                                                            <span ng-bind-html="$highlight($getDisplayText())"></span>
                                                        </script>
                                                <span class="error-text-color" ng-if="ShowTagError">
                                                    <span  ng-show="ShowTagError">{{ trans('messages.InvalidTag')}}</span>
                                                </span>
                                                    </div>


                                                    <div class="form-group col-md-12 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (BlogForm.$submitted) && BlogForm.Content.$invalid}">
                                                        <label for="Content" class="control-label">Content</label>
                                                        <textarea   name="Content" data-ng-model="BlogModel.BlogDetails.Content" id="content_desc" ck-editor data-ng-class="{'has-submitted' : BlogForm.$submitted }" required ng-disabled="BlogModel.ViewPage==0"></textarea>
                                                <span class="error-text-color" ng-show="BlogForm.$submitted">
                                                    <span ng-show="BlogForm.Content.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Content'))}}</span>
                                                </span>
                                                    </div>
                                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                        <label for="Summary" class="control-label">Quick Summary</label>
                                                        <textarea rows="6" class="form-control" name="Summary" data-ng-model="BlogModel.BlogDetails.Summary" ng-disabled="BlogModel.ViewPage==0"></textarea>
                                                    </div>

                                                    <?php if($BlogModel->SiteID == Constants::$MercerVineSiteID || $BlogModel->SiteID == Constants::$ColoradoSiteID ){?>
                                                    <div class="form-group col-md-6 col-sm-12 col-xs-12">
                                                        <label for="TagAgent" class="control-label">Tag Agent</label>
                                                         <span ng-if="BlogModel.IsDisabledTagAgent > 0">
                                                            <span tooltip data-toggle="tooltip" data-placement="bottom" title="Some agents are disabled">
                                                                    <i class="fa fa-info-circle font-size-18px margin-top-10"></i>
                                                            </span>
                                                        </span>
                                                        <select class="form-control"
                                                                name="TagAgent"
                                                                ng-model="BlogModel.BlogDetails.TagAgent"
                                                                ng-options="ta.UserID as ta.Name for ta in BlogModel.TagAgentListArray"
                                                                multiple  ng-disabled="BlogModel.ViewPage==0">
                                                        </select>
                                                    </div>
                                                    <?php }?>

                                                    <div class="form-group col-md-6 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (BlogForm.$submitted) && BlogForm.Category.$invalid}">
                                                        <label for="Category" class="control-label">Categories</label>
                                                        <select class="form-control" multiple ng-model="BlogModel.BlogDetails.Category"
                                                                ng-options="ct.CategoryID as ct.Category for ct in BlogModel.Category" id="Category" name="Category"
                                                                data-ng-class="{'has-submitted' : BlogForm.$submitted }" required  ng-disabled="BlogModel.ViewPage==0"></select>
                                                <span class="error-text-color" ng-show="BlogForm.$submitted">
                                                    <span ng-show="BlogForm.Category.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Category'))}}</span>
                                                </span>
                                                    </div>

                                                </div>


                                            </div>
                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12 hidden-sm hidden-xs">
                                                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 no-padding">
                                                    <label for="Category" class="control-label">Featured Image</label>
                                                </div>
                                            <div class="fileinput fileinput-new">
                                                <div class="fileinput-new thumbnail image-box">
                                                    <img src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                    <img id="actualImage" alt="" ng-src="@{{BlogModel.BlogDetails.RealFeaturedImagePath ? BlogModel.BlogDetails.RealFeaturedImagePath : BlogModel.BlogDetails.NoImagePath}}">
                                                </div>
                                                <div>
                                                    <form></form>
                                                    <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo Constants::$BlogFeaturedImageType; ?>" name="FormImageBlogFeatured" role="form" novalidate>
                                                        <input type="hidden" id="key" name="key" value="">
                                                        <input type="hidden" name="AWSAccessKeyId"  ng-value="BlogModel.BlogDetails.Fileuploadsettings.accesskey">
                                                        <input type="hidden" name="acl"  ng-value="BlogModel.BlogDetails.Fileuploadsettings.acl">
                                                        <input type="hidden" name="success_action_status"  ng-value="BlogModel.BlogDetails.Fileuploadsettings.success_action">
                                                        <input type="hidden" name="policy"  ng-value="BlogModel.BlogDetails.Fileuploadsettings.base64Policy">
                                                        <input type="hidden" name="signature"  ng-value="BlogModel.BlogDetails.Fileuploadsettings.signature">
                                                        <input type="hidden" name="Cache-Control" ng-value="BlogModel.BlogDetails.Fileuploadsettings.cacheControlTime">
                                                        <span class="btn default btn-file" ><input type="file" name="file" id="file" title="Choose Image" ng-model="BlogModel.BlogDetails.RealFeaturedImagePath" ng-required="BlogModel.SiteID == <?php echo Constants::$ColoradoSiteID;?>"> Choose Image </span>
                                                        <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo Constants::$BlogFeaturedImageType; ?>')" data-ng-hide="BlogModel.BlogDetails.RealFeaturedImagePath ==''">Remove</a>
                                                        <span></span>
                                                    </form>
                                                </div>
                                                <span>&nbsp;</span>
                                                <div class="progress progress-striped display-none">
                                                    <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                    </div>
                                                </div>
                                                <div class="info-alert" ng-if="(AllowedFeatureImageFixWidth > 0 &&  AllowedFeatureImageFixHeight > 0)"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedFeatureImageFixWidth }}x@{{ AllowedFeatureImageFixHeight }}px</lable></div>
                                                <div ng-class="{ 'has-error' : (BlogForm.$submitted) && FormImageBlogFeatured.file.$error}" class="has-error">
                                                    <div class="help-block" ng-messages="FormImageBlogFeatured.file.$error" ng-if="BlogForm.$submitted">
                                                        <div ng-show="FormImageBlogFeatured.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Featured Image'))}}</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="portlet box blue-hoki" ng-cloak>
                            <div class="portlet-title" collapse="true" >
                                <div class="caption">
                                    <i class=""></i>SEO</div>
                                <div class="tools">
                                    <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                </div>
                            </div>
                            <div class="portlet-body">
                                <div class="row">
                                    <div class="form-body" ng-cloak>
                                            <div class="col-md-12  no-padding">
                                                <div class="col-md-12  no-padding">
                                                    <div class="col-md-9  no-padding">
                                                        <div class="form-group col-md-6 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (BlogForm.$submitted) && BlogForm.BrowserTitle.$invalid}">
                                                            <label for="BrowserTitle" class="control-label">Browser Title</label>
                                                            <input class="form-control"  type="text" name="BrowserTitle"  maxlength="200" data-ng-model="BlogModel.BlogDetails.BrowserTitle" data-ng-class="{'has-submitted' : BlogForm.$submitted }" required ng-disabled="BlogModel.ViewPage==0 &&  BlogModel.CanEditSEOFields==0"/>
                                                            <span class="error-text-color" ng-show="BlogForm.$submitted">
                                                                <span ng-show="BlogForm.BrowserTitle.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Browser Title'))}}</span>
                                                            </span>
                                                        </div>
                                                        <div class="form-group col-md-6 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (BlogForm.$submitted) && BlogForm.CanonicalURL.$invalid}">
                                                            <label for="CanonicalURL" class="control-label">Canonical URL</label>
                                                            <input class="form-control"  type="text" name="CanonicalURL" data-ng-model="BlogModel.BlogDetails.CanonicalURL" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>" maxlength="200" ng-disabled="BlogModel.ViewPage==0 &&  BlogModel.CanEditSEOFields==0" required="" />
                                                             <span class="error-text-color" ng-show="BlogForm.$submitted">
                                                                <span ng-show="BlogForm.CanonicalURL.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Canonical URL'))}}</span>
                                                                <span ng-show="BlogForm.CanonicalURL.$error.pattern">{{ trans('messages.InvalidCanonicalUrl') }}</span>
                                                             </span>
                                                        </div>

                                                        <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                            <label for="MetaDescription" class="control-label">Meta-Description</label>
                                                            <textarea rows="6" class="form-control" name="MetaDescription" data-ng-model="BlogModel.BlogDetails.MetaDescription" ng-disabled="BlogModel.ViewPage==0 &&  BlogModel.CanEditSEOFields==0"></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-md-12 col-sm-12 col-xs-12 no-padding margin-top-15"><hr class="hr-section margin-top-15"></div>
                                                    <div class="col-md-12  no-padding ">
                                                    <div class="form-group col-md-12 col-sm-12 col-xs-12 rich-margin">
                                                        <h3 class="page-title font-size19px">Facebook</h3>
                                                    </div>

                                                    <div class="form-group col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                        <label for="FBTitle" class="control-label">Facebook Title</label>
                                                        <input class="form-control" type="text" name="FBTitle"  maxlength="200" data-ng-model="BlogModel.BlogDetails.FBTitle" ng-disabled="BlogModel.ViewPage==0 &&  BlogModel.CanEditSEOFields==0"/>
                                                    </div>
                                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                        <label for="FBDescription" class="control-label">Facebook-Description</label>
                                                        <textarea rows="6" class="form-control" name="FBDescription" data-ng-model="BlogModel.BlogDetails.FBDescription" ng-disabled="BlogModel.ViewPage==0 &&  BlogModel.CanEditSEOFields==0"></textarea>
                                                    </div>
                                                    </div>
                                                    <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12">
                                                        <label for="FBImage" class="control-label">Facebook Image</label>
                                                    </div>
                                                    <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12 margin-top1pr">
                                                        <div class="fileinput fileinput-new">
                                                            <div class="fileinput-new thumbnail image-box">
                                                                <img src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                <img id="actualImage" alt="" ng-src="@{{BlogModel.BlogDetails.FBRealImagePath ? BlogModel.BlogDetails.FBRealImagePath : BlogModel.BlogDetails.NoImagePath}}">
                                                            </div>
                                                            <div>
                                                                <form></form>
                                                                <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo $FBImageType;?>">
                                                                    <input type="hidden" id="key" name="key" value="">
                                                                    <input type="hidden" name="AWSAccessKeyId"  ng-value="BlogModel.BlogDetails.Fileuploadsettings.accesskey">
                                                                    <input type="hidden" name="acl"  ng-value="BlogModel.BlogDetails.Fileuploadsettings.acl">
                                                                    <input type="hidden" name="success_action_status"  ng-value="BlogModel.BlogDetails.Fileuploadsettings.success_action">
                                                                    <input type="hidden" name="policy"  ng-value="BlogModel.BlogDetails.Fileuploadsettings.base64Policy">
                                                                    <input type="hidden" name="signature"  ng-value="BlogModel.BlogDetails.Fileuploadsettings.signature">
                                                                    <input type="hidden" name="Cache-Control" ng-value="BlogModel.BlogDetails.Fileuploadsettings.cacheControlTime">
                                                                    <span class="btn default btn-file" ><input type="file" name="file" id="file" title="Choose Image" ng-disabled="BlogModel.ViewPage==0 &&  BlogModel.CanEditSEOFields==0" > Choose Image </span>
                                                                    <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage(<?php echo "'".$FBImageType."'"; ?>)" data-ng-hide="BlogModel.BlogDetails.FBRealImagePath ==''  || (BlogModel.ViewPage==0 &&  BlogModel.CanEditSEOFields==0)">Remove</a>
                                                                    <span></span>
                                                                </form>
                                                            </div>
                                                            <span>&nbsp;</span>
                                                            <div class="progress progress-striped display-none">
                                                                <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    </div>
                                                    <div class="form-group col-md-12 col-sm-12 col-xs-12 no-padding"><hr class="hr-section"></div>

                                                <div class="col-md-12  no-padding">
                                                    <div class="form-group col-md-12 col-sm-12 col-xs-12 rich-margin">
                                                            <h3 class="page-title font-size19px">Twitter</h3>
                                                    </div>
                                                    <div class="form-group col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                        <label for="TwitterCard" class="control-label">Twitter Card</label>
                                                        <input class="form-control" type="text" name="TwitterCard"  maxlength="50" data-ng-model="BlogModel.BlogDetails.TwitterCard" ng-disabled="BlogModel.ViewPage==0 &&  BlogModel.CanEditSEOFields==0"/>
                                                    </div>
                                                    <div class="form-group col-md-6 col-sm-12 col-xs-12">
                                                        <label for="TwitterSite" class="control-label">Twitter Site</label>
                                                        <input class="form-control"  type="text" name="TwitterSite"  maxlength="200" data-ng-model="BlogModel.BlogDetails.TwitterSite" ng-disabled="BlogModel.ViewPage==0 &&  BlogModel.CanEditSEOFields==0"/>
                                                    </div>
                                                    <div class="form-group col-md-6 col-sm-12 col-xs-12">
                                                        <label for="TwitterTitle" class="control-label">Twitter Title</label>
                                                        <input class="form-control"  type="text" name="TwitterTitle"  maxlength="200" data-ng-model="BlogModel.BlogDetails.TwitterTitle" ng-disabled="BlogModel.ViewPage==0 &&  BlogModel.CanEditSEOFields==0"/>
                                                    </div>
                                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                        <label for="TwitterDescription" class="control-label">Twitter-Description</label>
                                                        <textarea rows="6" class="form-control" name="TwitterDescription" data-ng-model="BlogModel.BlogDetails.TwitterDescription" ng-disabled="BlogModel.ViewPage==0 &&  BlogModel.CanEditSEOFields==0"></textarea>
                                                    </div>
                                                        </div>
                                                    <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12">
                                                        <label for="TwitterImage" class="control-label">Twitter Image</label>
                                                    </div>
                                                    <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12 margin-top1pr">
                                                        <div class="fileinput fileinput-new">
                                                            <div class="fileinput-new thumbnail image-box">
                                                                <img src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                <img id="actualImage" alt="" ng-src="@{{BlogModel.BlogDetails.TwitterRealImagePath ? BlogModel.BlogDetails.TwitterRealImagePath : BlogModel.BlogDetails.NoImagePath}}">
                                                            </div>
                                                            <div>
                                                                <form></form>
                                                                <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo $TwitterImageType;?>">
                                                                    <input type="hidden" id="key" name="key" value="">
                                                                    <input type="hidden" name="AWSAccessKeyId"  ng-value="BlogModel.BlogDetails.Fileuploadsettings.accesskey">
                                                                    <input type="hidden" name="acl"  ng-value="BlogModel.BlogDetails.Fileuploadsettings.acl">
                                                                    <input type="hidden" name="success_action_status"  ng-value="BlogModel.BlogDetails.Fileuploadsettings.success_action">
                                                                    <input type="hidden" name="policy"  ng-value="BlogModel.BlogDetails.Fileuploadsettings.base64Policy">
                                                                    <input type="hidden" name="signature"  ng-value="BlogModel.BlogDetails.Fileuploadsettings.signature">
                                                                    <input type="hidden" name="Cache-Control" ng-value="BlogModel.BlogDetails.Fileuploadsettings.cacheControlTime">
                                                                    <span class="btn default btn-file"><input type="file" name="file" id="file" title="Choose Image" ng-disabled="BlogModel.ViewPage==0 &&  BlogModel.CanEditSEOFields==0"> Choose Image </span>
                                                                    <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage(<?php echo "'".$TwitterImageType."'"; ?>)" data-ng-hide="BlogModel.BlogDetails.TwitterRealImagePath==''  || (BlogModel.ViewPage==0 &&  BlogModel.CanEditSEOFields==0)">Remove</a>
                                                                    <span></span>
                                                                </form>
                                                            </div>
                                                            <span>&nbsp;</span>
                                                            <div class="progress progress-striped display-none">
                                                                <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                    <div class="form-group col-md-12 col-sm-12 col-xs-12 no-padding"><hr class="hr-section"></div>

                                                    <div class="col-md-12  no-padding">
                                                <div class="form-group col-md-12 col-sm-12 col-xs-12 rich-margin">
                                                    <h3 class="page-title font-size19px">Rich Snippets</h3>
                                                </div>

                                                <div class="col-md-12  no-padding">
                                                    <div class="form-group col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                        <label for="Headline" class="control-label">Headline</label>
                                                        <input class="form-control"  type="text" name="Headline"  maxlength="200" data-ng-model="BlogModel.BlogDetails.Headline" ng-disabled="BlogModel.ViewPage==0 &&  BlogModel.CanEditSEOFields==0"/>
                                                    </div>
                                                        <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                            <label for="TwitterDescription" class="control-label">Description</label>
                                                            <textarea  rows="6" class="form-control" name="Description" data-ng-model="BlogModel.BlogDetails.Description" ng-disabled="BlogModel.ViewPage==0 &&  BlogModel.CanEditSEOFields==0"></textarea>

                                                        </div>
                                                        </div>
                                                    <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12">
                                                        <label for="TwitterImage" class="control-label">Image Upload</label>
                                                    </div>
                                                    <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12 margin-top1pr">
                                                        <div class="fileinput fileinput-new">
                                                            <div class="fileinput-new thumbnail image-box">
                                                                <img src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                <img id="actualImage" alt="" src="@{{BlogModel.BlogDetails.GoogleRealImagePath ? BlogModel.BlogDetails.GoogleRealImagePath : BlogModel.BlogDetails.NoImagePath}}">
                                                            </div>
                                                            <div>
                                                                <form></form>
                                                                <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo $GoogleImageType;?>">
                                                                    <input type="hidden" id="key" name="key" value="">
                                                                    <input type="hidden" name="AWSAccessKeyId"  ng-value="BlogModel.BlogDetails.Fileuploadsettings.accesskey">
                                                                    <input type="hidden" name="acl"  ng-value="BlogModel.BlogDetails.Fileuploadsettings.acl">
                                                                    <input type="hidden" name="success_action_status"  ng-value="BlogModel.BlogDetails.Fileuploadsettings.success_action">
                                                                    <input type="hidden" name="policy"  ng-value="BlogModel.BlogDetails.Fileuploadsettings.base64Policy">
                                                                    <input type="hidden" name="signature"  ng-value="BlogModel.BlogDetails.Fileuploadsettings.signature">
                                                                    <input type="hidden" name="Cache-Control" ng-value="BlogModel.BlogDetails.Fileuploadsettings.cacheControlTime">
                                                                    <span class="btn default btn-file" ><input type="file" name="file" id="file" title="Choose Image" ng-disabled="BlogModel.ViewPage==0 &&  BlogModel.CanEditSEOFields==0"> Choose Image </span>
                                                                    <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage(<?php echo "'".$GoogleImageType."'"; ?>)" data-ng-hide="BlogModel.BlogDetails.GoogleRealImagePath == '' || (BlogModel.ViewPage==0 &&  BlogModel.CanEditSEOFields==0)">Remove</a>
                                                                    <span></span>
                                                                </form>
                                                            </div>
                                                            <span>&nbsp;</span>
                                                            <div class="progress progress-striped display-none">
                                                                <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>


                                                </div>
                                            </div>
                                          </div>
                                    </div>
                                </div>
                                </div>
                            </div>
                        </div>
                        <div class="portlet box blue-hoki" ng-cloak>
                            <div class="portlet-title" collapse>
                                <div class="caption">
                                    <i class=""></i>Assign for approval</div>
                                <div class="tools">
                                    <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                </div>
                            </div>
                            <div class="portlet-body">
                                <div class="row">
                                    <div class="form-body" ng-cloak>
                                        <div class="col-md-12  no-padding">
                                            <div class="form-group col-md-9 col-sm-12 col-xs-12 no-padding">
                                                <div class="form-group col-md-6 col-sm-12 col-xs-12">
                                                    <label for="Assign" class="control-label">Assign To</label>
                                                    <select class="form-control" name="AssignTo" ng-model="BlogModel.BlogDetails.AssignedID" ng-options="As.UserID as As.Name for As in BlogModel.AssignListArray" data-ng-class="{'has-submitted' : BlogForm.$submitted }" required ng-disabled="BlogModel.ViewPage==0"></select>
                                                    <span class="error-text-color" ng-show="BlogForm.$submitted">
                                                        <span ng-show="BlogForm.AssignTo.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Assign To'))}}</span>
                                                    </span>
                                                </div>
                                                <div class="form-group col-md-6 col-sm-12 col-xs-12">
                                                    <label for="Status" class="control-label">Status</label>
                                                    <select class="form-control" name="Status" ng-model="BlogModel.BlogDetails.StatusID" ng-options="St.StatusID as St.Status for St in BlogModel.StatusListArray" ng-disabled="BlogModel.ViewPage==0"></select>
                                                </div>
                                            </div>
                                            <div class="col-md-12  no-padding">
                                                <div class="form-group col-md-9 col-sm-12 col-xs-12">
                                                    <label for="TwitterDescription" class="control-label">Message</label>
                                                    <textarea  id="deny-message"  rows="6" class="form-control" name="Message" data-ng-model="BlogModel.BlogDetails.Message" ng-disabled="BlogModel.ViewPage==0 &&  BlogModel.CanEditSEOFields==0"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php if($BlogModel->BlogDetails->BlogPostID > 0) {?>
                            <div class="col-md-12 no-padding margin-bottom-10" ng-show="BlogModel.BlogDetails.BlogPostID > 0" ng-clock>
                                <span class="font13px help-block info-alert display-none" >
                                        <span><span class="bold">Note:</span> {{ trans('messages.NoteForImageInProgressEdit')}}</span>
                                </span>
                            </div>
                        <?php } ?>
                        <?php if($BlogModel->BlogDetails->BlogPostID == 0) {?>
                            <div class="col-md-12 no-padding margin-bottom-10" ng-show="BlogModel.BlogDetails.BlogPostID == 0" ng-clock>
                                <span class="font13px help-block info-alert display-none" >
                                        <span><span class="bold">Note:</span> {{ trans('messages.NoteForImageInProgressAdd')}}</span>
                                </span>
                            </div>
                        <?php } ?>
                        <div class="col-md-12 no-padding">
                            <div class="form-actions  col-md-12 col-sm-12 col-xs-12 no-padding" ng-cloak>
                                <input name="submit" type="submit" value="Save" class="btn blue save-button btn-submit" ng-hide="BlogModel.ViewPage==0 && BlogModel.CanEditSEOFields==0" data-ng-click="Save()" ng-disabled="requestCounter != responseCounter"/>
                                <input name="submit" type="submit" value="Approve" class="btn green-meadow save-button btn-submit" data-ng-click="Approve()" ng-hide="BlogModel.ShowApproveDenyButton == 0 || BlogModel.ViewPage==0 || BlogModel.currentStatusID == <?php echo Constants::$WorkFlowStatus_Approve;?> || BlogModel.currentStatusID == <?php echo Constants::$WorkFlowStatus_Published;?>" ng-disabled="requestCounter != responseCounter"/>
                                <input name="submit" type="submit" value="Deny" class="btn red-sunglo save-button btn-submit" data-ng-click="Deny()" ng-hide="BlogModel.ShowApproveDenyButton == 0 || BlogModel.ViewPage==0 || BlogModel.currentStatusID == <?php echo Constants::$WorkFlowStatus_Denied;?> || BlogModel.currentStatusID == <?php echo Constants::$WorkFlowStatus_Published;?>" ng-disabled="requestCounter != responseCounter"/>
                                <input name="submit" type="submit" value="Publish" class="btn yellow-mint save-button btn-submit" data-ng-click="Publish()" ng-hide="BlogModel.ShowPublishButton==0 || BlogModel.currentStatusID == <?php echo Constants::$WorkFlowStatus_Published;?>" ng-disabled="requestCounter != responseCounter"/>
                                <button type="button" id="cancel" name="cancel" class="btn default" data-ng-click="Cancel()" ng-disabled="requestCounter != responseCounter">Cancel</button>
                            </div>
                        </div>
                        <div class="clearboth"></div>

                        <div class="col-md-12 no-padding">
                            <div class="portlet box blue-hoki margin-top-25" ng-cloak ng-show="BlogModel.BlogDetails.BlogPostID >0 && BlogModel.Messages.length >0">
                            <div class="portlet-title" collapse>
                                <div class="caption"><i class=""></i>Message History</div>
                                <div class="tools">
                                    <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                </div>
                            </div>
                            <div class="portlet-body">
                                <div class="row">
                                    <div class="form-body" ng-cloak>
                                            <div class="col-md-12  no-padding">
                                                <div class="col-md-12 col-sm-12" ng-show="BlogModel.BlogDetails.BlogPostID >0 && BlogModel.Messages.length >0">
                                                    <div class="portlet light bordered msg-history">

                                                        <div class="portlet-body" id="chats">
                                                            <div class="scroller history-scroll"   data-always-visible="1" data-rail-visible1="1">
                                                                <ul class="chats" data-ng-repeat="data in BlogModel.Messages">
                                                                    <li ng-class="{'out': data.ClassIn==1,'in':data.ClassIn==0}">
                                                                        <img class="avatar" alt="" src="@{{data.ImageURL ? data.ImageURL : BlogModel.BlogDetails.NoProfileImagePath}}"/>
                                                                        <div class="message">
                                                                            <span class="arrow"> </span>
                                                                            <a href="javascript:void(0);" class="name">@{{data.Name}}</a>
                                                                            <span class="datetime"> at @{{ data.CreatedDate }} </span>
                                                                            <span class="body">@{{data.Message}}</span>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                    </div>
                                </div>
                                </div>
                             </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </main>
@stop
@section('script')
    {{$minify::javascript(array('/assets/js/viewjs/blogposts/addblog.js',
                              //'/assets/js/ckeditor/ckeditor.js',
                              '/assets/js/library/jquery.fileupload/jquery.ui.widget.js',
                              '/assets/js/library/jquery.fileupload/jquery.fileupload.js',
                              '/assets/js/library/binaryajax.js',
                              '/assets/js/library/exif.js',
                              '/assets/js/library/bootstrap-fileinput.js',
                              '/assets/js/sitejs/canvasResize.js'))->withFullUrl()}}

    <script src="{{asset('/assets/js/ckeditor/ckeditor.js')}}" defer></script>

    {{$minify::javascript(array('/assets/js/sitejs/jquery-ui-1.9.2.custom.min.js',
                                  '/assets/js/sitejs/jquery.ui.touch-punch.min.js'))->withFullUrl()}}
    <script>
        window.ImageFileAllowedMessage ="{{ trans('messages.ImageFileAllowedMessage')}}";
        window.ConfirmUploadMessage ="{{ trans('messages.ConfirmUploadMessage')}}";
        window.FBMaxFileSizeErrorMessage = "{{trans('messages.FBImageErrorMessage')}}";
        window.TwitterMaxFileSizeErrorMessage = "{{trans('messages.TwitterImageErrorMessage')}}";
        window.GoogleMaxFileSizeErrorMessage = "{{trans('messages.GoogleImageErrorMessage')}}";
        window.DefaultUploadPhotoHeight='<?php echo Constants::$DefaultUploadProfileHeight;?>';
        window.DefaultUploadPhotoWidth='<?php echo Constants::$DefaultUploadProfileWidth;?>';
        window.ImageSize = '<?php echo $ImageMaxSize; ?>';
        window.NoImagePath = '<?php echo asset('/assets/images/Samplephoto.png') ?>';
        window.FBImageType = '<?php echo $FBImageType; ?>';
        window.TwitterImageType = '<?php echo $TwitterImageType; ?>';
        window.GoogleImageType = '<?php echo $GoogleImageType; ?>';
        window.BlogFeaturedImageType = '<?php echo Constants::$BlogFeaturedImageType; ?>';
        window.MessageRequired = "{{ trans('messages.MessageRequired')}}";
        window.NoProfileImagePath = '<?php echo asset('/assets/images/no-user.png') ?>';
        $( "#PostDateIcon" ).click(function() {
            $( "#PostDate" ).focus();
        });
    </script>
@stop