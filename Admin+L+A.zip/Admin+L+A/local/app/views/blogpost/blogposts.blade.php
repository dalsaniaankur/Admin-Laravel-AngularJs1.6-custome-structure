<?php $minify = new \CeesVanEgmond\Minify\Facades\Minify;
use Infrastructure\Constants;
use BaseController as BA;
use Infrastructure\Common;
?>
@extends('layouts.sitemaster')
@section('Title','BlogPosts')
@stop
@section('content')
<?php echo Form::hidden('ListModel', json_encode($ListModel), $attributes = array('id' => 'ListModel'));?>

<div class="page-content" auto-input-focus-off="true" data-ng-controller="BlogPostController">
    <div class="page-bar">
        <ul class="page-breadcrumb">
            <li>
                <a href="<?php echo URL::to('/dashboard/' . $encryptedSiteID) ?>">Home</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <span> Blog Posts</span>
            </li>
        </ul>
        <div class="page-toolbar">
            <div class="btn-group pull-right">
                <?php if(BA::CheckRoleSitePermission(Common::getRoleBloggerMDITSEOAgent(),Common::getAllSiteArray())) {?>
                <a href="<?php echo URL::to('/addblog/'.$encryptedSiteID)?>" class="btn btn-primary btn-sm btn-outline">Add  Blog Post</a>
                <?php } ?>
            </div>
        </div>
    </div>

    <h3 class="page-title">  Blog Posts</h3>
    <div class="portlet-body">
        <ul class="nav nav-tabs development">
            <li class="active">
                <a href="#tab_1_1" data-toggle="tab" aria-expanded="true" data-ng-click="getList()">All</a>
            </li>
            <li class="">
                <a href="#tab_1_2" data-toggle="tab" aria-expanded="false" data-ng-click="getList({{\Infrastructure\Constants::$WorkFlowStatus_Draft}})">Draft</a>
            </li>
            <li class="">
                <a href="#tab_1_1" data-toggle="tab" aria-expanded="false" data-ng-click="getList({{\Infrastructure\Constants::$WorkFlowStatus_PendingReview}})">Pending Review</a>
            </li>
            <li class="">
                <a href="#tab_1_1" data-toggle="tab" aria-expanded="false" data-ng-click="getList({{\Infrastructure\Constants::$WorkFlowStatus_PendingLegal}})">Pending Legal</a>
            </li>
            <li class="">
                <a href="#tab_1_1" data-toggle="tab" aria-expanded="false" data-ng-click="getList({{\Infrastructure\Constants::$WorkFlowStatus_Approve}})">Approved</a>
            </li>
            <li class="">
                <a href="#tab_1_1" data-toggle="tab" aria-expanded="false" data-ng-click="getList({{\Infrastructure\Constants::$WorkFlowStatus_Published}})">Published</a>
            </li>
            <li class="">
                <a href="#tab_1_1" data-toggle="tab" aria-expanded="false" data-ng-click="getList({{\Infrastructure\Constants::$WorkFlowStatus_Denied}})">Denied</a>
            </li>
        </ul>

    <div class="row">
        <div class="col-md-12">
            <form>
                <div class="form-body" ng-cloak>
                    <div class="form-group col-md-2">
                        <label for="Date From" class="control-label">Date From</label>
                        <input class="form-control form-control-inline date-picker" size="16"
                               data-ng-model="ListModel.frontSearchModel.DateFrom" id="DateFrom"
                               ng-maxdate="ListModel.frontSearchModel.Today"
                               name="DateFrom" autocomplete="off" datepicker>

                    </div>
                    <div class="form-group col-md-2">
                        <label for="Date To" class="control-label">Date To</label>
                        <input type="text" class="form-control form-control-inline date-picker"
                               data-ng-model="ListModel.frontSearchModel.DateTo"
                               ng-mindate="ListModel.frontSearchModel.DateFrom"
                               ng-maxdate="ListModel.frontSearchModel.Today"
                               id="DateTo" name="DateTo" autocomplete="off" datepicker>
                    </div>
                    <div class="form-group col-md-3">
                        <label for="Category" class="control-label">Category</label>
                        <select class="form-control" id="Category" name="Category"
                                data-ng-model="ListModel.frontSearchModel.CategoryID">
                            <option ng-repeat="data in ListModel.CategoryLookup"
                                    value="@{{data.CategoryID}}">@{{data.Category}}</option>
                        </select>
                    </div>
                    <div class="form-group col-md-2">
                        <div class="search-label-hidden"><label for="Date From" class="control-label">&nbsp;</label>
                        </div>
                        <button data-ng-click="SearchBlogPostRecords()" class="btn blue btn-search">Search</button>
                    </div>
                </div>
            </form>
            <div data-ng-if="BlogPostList.length > 0" class="table-responsive col-md-12" ng-cloak>
                <table class="table dataTable table-striped table-bordered table-hover">
                    <thead class="site-footer">
                    <tr>
                        <th class="sorting" data-ng-click="ListPager.sortColumn('Title')"
                            data-ng-class="{sorting_desc: (ListPager.sortIndex === 'Title' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'Title' && !ListPager.reverse)}">
                            Post Title
                        </th>
                        <th class="sorting" data-ng-click="ListPager.sortColumn('Author')"
                            data-ng-class="{sorting_desc: (ListPager.sortIndex === 'Author' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'Author' && !ListPager.reverse)}">
                            Author
                        </th>
                        <th class="sorting" data-ng-click="ListPager.sortColumn('PostDate')"
                            data-ng-class="{sorting_desc: (ListPager.sortIndex === 'PostDate' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'PostDate' && !ListPager.reverse)}">
                            Post Date
                        </th>
                        <th class="sorting" data-ng-click="ListPager.sortColumn('CreatedDate')"
                            data-ng-class="{sorting_desc: (ListPager.sortIndex === 'CreatedDate' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'CreatedDate' && !ListPager.reverse)}">
                            Created Date
                        </th>
                        <th class="sorting" data-ng-click="ListPager.sortColumn('ModifiedDate')"
                            data-ng-class="{sorting_desc: (ListPager.sortIndex === 'ModifiedDate' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'ModifiedDate' && !ListPager.reverse)}">
                            Last Updated
                        </th>
                        <th class="sorting" data-ng-click="ListPager.sortColumn('ModifiedBy')"
                            data-ng-class="{sorting_desc: (ListPager.sortIndex === 'ModifiedBy' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'ModifiedBy' && !ListPager.reverse)}">
                            Last Updated By
                        </th>
                        <th class="sorting" data-ng-click="ListPager.sortColumn('AssignedTo')"
                            data-ng-class="{sorting_desc: (ListPager.sortIndex === 'AssignedTo' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'AssignedTo' && !ListPager.reverse)}">
                            Assigned To
                        </th>
                        <th class="sorting" data-ng-click="ListPager.sortColumn('Status')"
                            data-ng-class="{sorting_desc: (ListPager.sortIndex === 'Status' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'Status' && !ListPager.reverse)}">
                            Status
                        </th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody dir-paginate="blog in BlogPostList | itemsPerPage:ListPager.pageSize"
                           total-items="ListPager.totalRecords" current-page="ListPager.currentPage"
                           pagination-id="UserID">
                    <tr>
                        <td><a ng-click="EditBlog(blog)" title="Edit Page">@{{ blog.Title }}</a></td>
                        <td>@{{ blog.Author }}</td>
                        <td>@{{ blog.PostDate }}</td>
                        <td>@{{ blog.CreatedDate }}</td>
                        <td>@{{ blog.ModifiedDate }}</td>
                        <td>@{{ blog.ModifiedBy }}</td>
                        <td>@{{ blog.AssignedTo }}</td>
                        <td>@{{ blog.Status }}</td>
                        <td>
                            <div>
                                <a ng-click="EditBlog(blog)" title="Edit Page"><i class="fa fa-pencil text-default"></i></a>
                                &nbsp;
                                <a ng-click="DeleteBlogPost(blog)" title="Delete Page"><i
                                            class="fa fa-trash-o text-danger" ng-if="blog.LoggedInUserRoleID ==<?php echo Constants::$RoleITAdmin;?> || blog.LoggedInUserRoleID ==<?php echo Constants::$RoleMarketingDirector;?>"></i></a>
                            </div>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>
            <div class="col-md-12" data-ng-if="BlogPostList.length > 0">
                <dir-pagination-controls boundary-links="true" on-page-change="ListPager.pageChanged(newPageNumber)"
                                         pagination-id="UserID">
                </dir-pagination-controls>
            </div>
            <div class="form-group col-md-12 display-none" align="center" id="nodata">
                <b>{{ trans('messages.NoBlogRecordFound') }}</b>
            </div>
        </div>
    </div>
        </div>
</div>
@stop
@section('script')
    {{ $minify::javascript(array('/assets/js/viewjs/blogposts/blogposts.js'))->withFullUrl()}}
@stop