<?php
    use Infrastructure\Constants;
    $minify = new \CeesVanEgmond\Minify\Facades\Minify;
?>
@extends('layouts.sitemaster')
@section('Title')
    Home
@stop
@section('css')
    {{ $minify::stylesheet(array('/assets/css/dropzone/dropzone.css'))->withFullUrl()}}
@stop
@section('content')
<main id="main" role="main">
    <?php echo Form::hidden('HomeModel',htmlspecialchars(json_encode($HomeModel), ENT_QUOTES, 'UTF-8'),$attributes = array('id'=>'HomeModel')); ?>
    <?php //echo Form::hidden('SliderModel',htmlspecialchars(json_encode($SliderModel), ENT_QUOTES, 'UTF-8'),$attributes = array('id'=>'SliderModel')); ?>
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo URL::to('/dashboard/'.$encryptedSiteID) ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Home</span>
                </li>
            </ul>
        </div>
        <h3 class="page-title">Home</h3>
        <!--<ul class="nav nav-tabs">
            <li class="active">
                <a href="#tab_1_1" data-toggle="tab" aria-expanded="true">Home</a>
            </li>
            <li class="">
                <a href="#tab_1_2" data-toggle="tab" aria-expanded="false">Slider of WW</a>
            </li>
        </ul>-->
        <div class="row">
            <div class="col-md-12">
                <div class="tab-content">
                    <div class="tab-pane active" id="tab_1_1">
                        <form name="HomeForm" id="HomeForm" role="form" novalidate ng-controller = "HomeController" ng-clock ng-submit="checkSave(HomeForm)">
                            <div class="form-body" ng-cloak>
                                <!-- Slider start -->
                                <div class="clearboth"></div>
                                <div class="portlet box blue-hoki" ng-cloak>
                                    <div class="portlet-title" collapse>
                                        <div class="caption">
                                            <i class=""></i>Header Section</div>
                                        <div class="tools">
                                            <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                        </div>
                                    </div>
                                    <div class="portlet-body">
                                        <div class="row">
                                            <div class="col-md-12 no-padding">
                                                <div class="form-body" >
                                                    <!--<div class="form-group col-md-12">
                                                        <input type="checkbox"  ng-model="HomeModel.ShowSliderSection" id="ShowSliderSection" name="ShowSliderSection" ng-true-value="1" ng-false-value="0">
                                                        <label for="ShowSliderSection">Show this section?</label>
                                                    </div>-->
                                                    <div class="col-md-12 no-padding">

                                                        <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12" >
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Image" class="control-label">Slider Image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealSliderImagePath ? HomeModel.RealSliderImagePath : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$WWSliderImageType; ?>" name="FormImageSlider" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealSliderImagePath" id="file" title="Choose Image" ng-required="(HomeModel.ShowSliderSection)"> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$WWSliderImageType; ?>')" ng-hide="(HomeModel.RealSliderImagePath == '' || HomeModel.RealSliderImagePath == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedSliderImagesFixWidth > 0 &&  AllowedSliderImagesFixHeight > 0)"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedSliderImagesFixWidth }}x@{{ AllowedSliderImagesFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormImageSlider.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormImageSlider.file.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormImageSlider.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Slider image'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.SliderTitle.$invalid}">
                                                                    <label for="SliderTitle" class="control-label">Title</label>
                                                                    <input class="form-control"  type="text" name="SliderTitle" ng-model="HomeModel.SliderTitle" ng-class="{ 'has-submitted' : HomeForm.$submitted }" maxlength="100" ng-required="(HomeModel.ShowSliderSection)"/>
                                                                    <div  class="help-block" ng-messages="HomeForm.SliderTitle.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.SliderTitle.$error.required  && HomeForm.SliderTitle.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Title'))}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.SliderDescription.$invalid}">
                                                                    <label for="Description" class="control-label">Description</label>
                                                                    <textarea class="form-control" rows="4" name="SliderDescription" ng-model="HomeModel.SliderDescription" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="(HomeModel.ShowSliderSection)"></textarea>
                                                                    <div  class="help-block" ng-messages="HomeForm.SliderDescription.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.SliderDescription.$error.required && HomeForm.SliderDescription.$invalid">{{ trans('messages.PropertyRequired',array('attribute'=>'Description'))}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-12 no-padding">
                                                                    <div class="form-group col-md-6" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.SliderLinkText.$invalid}">
                                                                        <label for="Link Text" class="control-label">Link Text</label>
                                                                        <input class="form-control"  type="text" name="SliderLinkText" ng-model="HomeModel.SliderLinkText" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="(HomeModel.ShowSliderSection && HomeModel.SliderLink)"/>
                                                                        <div  class="help-block" ng-messages="HomeForm.SliderLinkText.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.SliderLinkText.$error.required  && HomeForm.SliderLinkText.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link Text'))}}</div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group col-md-6" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.SliderLink.$invalid}">
                                                                        <label for="Slider Link" class="control-label">Link URL</label>
                                                                        <input class="form-control"  type="text" name="SliderLink" ng-model="HomeModel.SliderLink" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="(HomeModel.ShowSliderSection && HomeModel.SliderLinkText)"/>
                                                                        <div  class="help-block" ng-messages="HomeForm.SliderLink.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.SliderLink.$error.required  && HomeForm.SliderLink.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link URL'))}}</div>
                                                                            <div  ng-show="HomeForm.SliderLink.$error.pattern ">{{ trans('messages.InvalidLink')}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>


                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Slider end -->
                                <div class="clearboth"></div>
                                <div class="portlet box blue-hoki" ng-cloak>
                                    <div class="portlet-title" collapse>
                                        <div class="caption">
                                            <i class=""></i>Offers Section</div>
                                        <div class="tools">
                                            <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                        </div>
                                    </div>
                                    <div class="portlet-body">
                                        <div class="row">
                                            <div class="col-md-12 no-padding">
                                                <div class="form-body" >
                                                    <div class="form-group col-md-12">
                                                        <input type="checkbox"  ng-model="HomeModel.ShowTopCTASection" id="ShowTopCTASection" name="ShowTopCTASection" ng-true-value="1" ng-false-value="0">
                                                        <label for="ShowTopCTASection">Show this section?</label>
                                                    </div>
                                                    <div class="col-md-12 no-padding">
                                                        <!-- Block 1 start -->
                                                        <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                            <h5 class="caption-subject form-section uppercase col-md-12">Block 1</h5>
                                                            <div class="col-md-4 col-lg-3 col-sm-5 col-xs-12">
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Image" class="control-label">Block 1 Image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealTopCTAImagePath1 ? HomeModel.RealTopCTAImagePath1 : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$WWHomeTopCTABlock1ImageType; ?>" name="FormImageTopBlock1" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealTopCTAImagePath1" id="file" title="Choose Image" ng-required="(HomeModel.ShowTopCTASection1 && HomeModel.ShowTopCTASection)"> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$WWHomeTopCTABlock1ImageType; ?>')" ng-hide="(HomeModel.RealTopCTAImagePath1 == '' || HomeModel.RealTopCTAImagePath1 == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedTopBlockImagesFixWidth > 0 &&  AllowedTopBlockImagesFixHeight > 0)"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedTopBlockImagesFixWidth }}x@{{ AllowedTopBlockImagesFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormImageTopBlock1.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormImageTopBlock1.file.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormImageTopBlock1.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Block 1 image'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-4 col-lg-3 col-sm-5 col-xs-12">
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Image" class="control-label">Block 1 Hover Image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealTopCTAHoverImagePath1 ? HomeModel.RealTopCTAHoverImagePath1 : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$WWHomeTopCTABlock1HoverImageType; ?>" name="FormHoverImageTopBlock1" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealTopCTAHoverImagePath1" id="file" title="Choose Image" ng-required="(HomeModel.ShowTopCTASection1 && HomeModel.ShowTopCTASection)"> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$WWHomeTopCTABlock1HoverImageType; ?>')" ng-hide="(HomeModel.RealTopCTAHoverImagePath1 == '' || HomeModel.RealTopCTAHoverImagePath1 == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedTopBlockImagesFixWidth > 0 &&  AllowedTopBlockImagesFixHeight > 0)"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedTopBlockImagesFixWidth }}x@{{ AllowedTopBlockImagesFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormHoverImageTopBlock1.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormHoverImageTopBlock1.file.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormHoverImageTopBlock1.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Block 1 hover image'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12 col-lg-6 col-sm-12 col-xs-12 no-padding">
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.TopCTATitle1.$invalid}">
                                                                    <label for="Title" class="control-label">Title</label>
                                                                    <input class="form-control"  type="text" name="TopCTATitle1" ng-model="HomeModel.TopCTATitle1" ng-class="{ 'has-submitted' : HomeForm.$submitted }" maxlength="100" ng-required="(HomeModel.ShowTopCTASection1 && HomeModel.ShowTopCTASection)"/>
                                                                    <div  class="help-block" ng-messages="HomeForm.TopCTATitle1.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.TopCTATitle1.$error.required  && HomeForm.TopCTATitle1.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Title'))}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.TopCTADescription1.$invalid}">
                                                                    <label for="Description" class="control-label">Description</label>
                                                                    <textarea class="form-control" rows="3" name="TopCTADescription1" ng-model="HomeModel.TopCTADescription1" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="(HomeModel.ShowTopCTASection1 && HomeModel.ShowTopCTASection)"></textarea>
                                                                    <div  class="help-block" ng-messages="HomeForm.TopCTADescription1.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.TopCTADescription1.$error.required && HomeForm.TopCTADescription1.$invalid">{{ trans('messages.PropertyRequired',array('attribute'=>'Description'))}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-12 no-padding">
                                                                    <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.TopCTALinkText1.$invalid}">
                                                                        <label for="Link Text" class="control-label">Link Text</label>
                                                                        <input class="form-control"  type="text" name="TopCTALinkText1" ng-model="HomeModel.TopCTALinkText1" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="(HomeModel.ShowTopCTASection1 && HomeModel.ShowTopCTASection)"/>
                                                                        <div  class="help-block" ng-messages="HomeForm.TopCTALinkText1.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.TopCTALinkText1.$error.required  && HomeForm.TopCTALinkText1.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link Text'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.TopCTALinkURL1.$invalid}">
                                                                        <label for="Link URL" class="control-label">Link URL</label>
                                                                        <input class="form-control"  type="text" name="TopCTALinkURL1" ng-model="HomeModel.TopCTALinkURL1" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="(HomeModel.ShowTopCTASection1 && HomeModel.ShowTopCTASection)"/>
                                                                        <div  class="help-block" ng-messages="HomeForm.TopCTALinkURL1.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.TopCTALinkURL1.$error.required  && HomeForm.TopCTALinkURL1.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link URL'))}}</div>
                                                                            <div  ng-show="HomeForm.TopCTALinkURL1.$error.pattern ">{{ trans('messages.InvalidLink')}}</div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group col-md-12">
                                                                        <input type="checkbox" ng-model="HomeModel.ShowTopCTASection1" id="ShowTopCTASection1" name="ShowTopCTASection1" ng-true-value="1" ng-false-value="0">
                                                                        <label for="ShowTopCTASection1">Show Block 1?</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- Block 1 end -->

                                                        <!-- Block 2 start -->
                                                        <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                            <h5 class="caption-subject form-section uppercase col-md-12">Block 2</h5>
                                                            <div class="col-md-4 col-lg-3 col-sm-5 col-xs-12">
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Image" class="control-label">Block 2 Image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealTopCTAImagePath2 ? HomeModel.RealTopCTAImagePath2 : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$WWHomeTopCTABlock2ImageType; ?>" name="FormImageTopBlock2" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealTopCTAImagePath2" id="file" title="Choose Image" ng-required="(HomeModel.ShowTopCTASection2 && HomeModel.ShowTopCTASection)"> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$WWHomeTopCTABlock2ImageType; ?>')" ng-hide="(HomeModel.RealTopCTAImagePath2 == '' || HomeModel.RealTopCTAImagePath2 == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedTopBlockImagesFixWidth > 0 &&  AllowedTopBlockImagesFixHeight > 0)"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedTopBlockImagesFixWidth }}x@{{ AllowedTopBlockImagesFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormImageTopBlock2.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormImageTopBlock2.file.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormImageTopBlock2.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Block 2 image'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                            <div class="col-md-4 col-lg-3 col-sm-5 col-xs-12">
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Image" class="control-label">Block 2 Hover Image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealTopCTAHoverImagePath2 ? HomeModel.RealTopCTAHoverImagePath2 : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$WWHomeTopCTABlock2HoverImageType; ?>" name="FormHoverImageTopBlock2" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealTopCTAHoverImagePath2" id="file" title="Choose Image" ng-required="(HomeModel.ShowTopCTASection2 && HomeModel.ShowTopCTASection)"> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$WWHomeTopCTABlock2HoverImageType; ?>')" ng-hide="(HomeModel.RealTopCTAHoverImagePath2 == '' || HomeModel.RealTopCTAHoverImagePath2 == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedTopBlockImagesFixWidth > 0 &&  AllowedTopBlockImagesFixHeight > 0)"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedTopBlockImagesFixWidth }}x@{{ AllowedTopBlockImagesFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormHoverImageTopBlock2.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormHoverImageTopBlock2.file.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormHoverImageTopBlock2.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Block 2 hover image'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12 col-lg-6 col-sm-12 col-xs-12 no-padding">
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.TopCTATitle2.$invalid}">
                                                                    <label for="Title" class="control-label">Title</label>
                                                                    <input class="form-control"  type="text" name="TopCTATitle2" ng-model="HomeModel.TopCTATitle2" ng-class="{ 'has-submitted' : HomeForm.$submitted }" maxlength="100" ng-required="(HomeModel.ShowTopCTASection2 && HomeModel.ShowTopCTASection)"/>
                                                                    <div  class="help-block" ng-messages="HomeForm.TopCTATitle2.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.TopCTATitle2.$error.required  && HomeForm.TopCTATitle2.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Title'))}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.TopCTADescription2.$invalid}">
                                                                    <label for="Description" class="control-label">Description</label>
                                                                    <textarea class="form-control" rows="3" name="TopCTADescription2" ng-model="HomeModel.TopCTADescription2" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="(HomeModel.ShowTopCTASection2 && HomeModel.ShowTopCTASection)"></textarea>
                                                                    <div  class="help-block" ng-messages="HomeForm.TopCTADescription2.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.TopCTADescription2.$error.required && HomeForm.TopCTADescription2.$invalid">{{ trans('messages.PropertyRequired',array('attribute'=>'Description'))}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-12 no-padding">
                                                                    <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.TopCTALinkText2.$invalid}">
                                                                        <label for="Link Text" class="control-label">Link Text</label>
                                                                        <input class="form-control"  type="text" name="TopCTALinkText2" ng-model="HomeModel.TopCTALinkText2" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="(HomeModel.ShowTopCTASection2 && HomeModel.ShowTopCTASection)" />
                                                                        <div  class="help-block" ng-messages="HomeForm.TopCTALinkText2.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="HomeForm.TopCTALinkText2.$error.required  && HomeForm.TopCTALinkText2.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link Text'))}}</div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.TopCTALinkURL2.$invalid}">
                                                                        <label for="Link URL" class="control-label">Link URL</label>
                                                                        <input class="form-control"  type="text" name="TopCTALinkURL2" ng-model="HomeModel.TopCTALinkURL2" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="(HomeModel.ShowTopCTASection2 && HomeModel.ShowTopCTASection)"/>
                                                                        <div  class="help-block" ng-messages="HomeForm.Block2URL1.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.TopCTALinkURL2.$error.required  && HomeForm.TopCTALinkURL2.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link URL'))}}</div>
                                                                            <div  ng-show="HomeForm.TopCTALinkURL2.$error.pattern ">{{ trans('messages.InvalidLink')}}</div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group col-md-12">
                                                                        <input type="checkbox" ng-model="HomeModel.ShowTopCTASection2" id="ShowTopCTASection2" name="ShowTopCTASection2" ng-true-value="1" ng-false-value="0">
                                                                        <label for="ShowTopCTASection2">Show Block 2?</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- Block 2 end -->

                                                        <!-- Block 3 start -->
                                                        <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                            <h5 class="caption-subject form-section uppercase col-md-12">Block 3</h5>
                                                            <div class="col-md-4 col-lg-3 col-sm-5 col-xs-12" >
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Image" class="control-label">Block 3 Image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealTopCTAImagePath3 ? HomeModel.RealTopCTAImagePath3 : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$WWHomeTopCTABlock3ImageType; ?>" name="FormImageTopBlock3" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealTopCTAImagePath3" id="file" title="Choose Image" ng-required="(HomeModel.ShowTopCTASection3 && HomeModel.ShowTopCTASection)"> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$WWHomeTopCTABlock3ImageType; ?>')" ng-hide="(HomeModel.RealTopCTAImagePath3 == '' || HomeModel.RealTopCTAImagePath3 == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedTopBlockImagesFixWidth > 0 &&  AllowedTopBlockImagesFixHeight > 0)"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedTopBlockImagesFixWidth }}x@{{ AllowedTopBlockImagesFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormImageTopBlock3.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormImageTopBlock3.file.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormImageTopBlock3.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Block 3 image'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                            <div class="col-md-4 col-lg-3 col-sm-5 col-xs-12">
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Image" class="control-label">Block 3 Hover Image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealTopCTAHoverImagePath3 ? HomeModel.RealTopCTAHoverImagePath3 : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$WWHomeTopCTABlock3HoverImageType; ?>" name="FormHoverImageTopBlock3" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealTopCTAHoverImagePath3" id="file" title="Choose Image" ng-required="(HomeModel.ShowTopCTASection3 && HomeModel.ShowTopCTASection)"> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$WWHomeTopCTABlock3HoverImageType; ?>')" ng-hide="(HomeModel.RealTopCTAHoverImagePath3 == '' || HomeModel.RealTopCTAHoverImagePath3 == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedTopBlockImagesFixWidth > 0 &&  AllowedTopBlockImagesFixHeight > 0)"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedTopBlockImagesFixWidth }}x@{{ AllowedTopBlockImagesFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormHoverImageTopBlock3.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormHoverImageTopBlock3.file.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormHoverImageTopBlock3.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Block 3 hover image'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                            <div class="col-md-12 col-lg-6 col-sm-12 col-xs-12 no-padding">
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.TopCTATitle3.$invalid}">
                                                                    <label for="Title" class="control-label">Title</label>
                                                                    <input class="form-control"  type="text" name="TopCTATitle3" ng-model="HomeModel.TopCTATitle3" ng-class="{ 'has-submitted' : HomeForm.$submitted }" maxlength="100" ng-required="(HomeModel.ShowTopCTASection3 && HomeModel.ShowTopCTASection)"/>
                                                                    <div  class="help-block" ng-messages="HomeForm.TopCTATitle3.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.TopCTATitle3.$error.required  && HomeForm.TopCTATitle3.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Title'))}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.TopCTADescription3.$invalid}">
                                                                    <label for="Description" class="control-label">Description</label>
                                                                    <textarea class="form-control" rows="3" name="TopCTADescription3" ng-model="HomeModel.TopCTADescription3" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="(HomeModel.ShowTopCTASection3 && HomeModel.ShowTopCTASection)"></textarea>
                                                                    <div  class="help-block" ng-messages="HomeForm.TopCTADescription3.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.TopCTADescription3.$error.required && HomeForm.TopCTADescription3.$invalid">{{ trans('messages.PropertyRequired',array('attribute'=>'Description'))}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-12 no-padding">
                                                                    <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.TopCTALinkText3.$invalid}">
                                                                        <label for="Link Text" class="control-label">Link Text</label>
                                                                        <input class="form-control"  type="text" name="TopCTALinkText3" ng-model="HomeModel.TopCTALinkText3" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="(HomeModel.ShowTopCTASection3 && HomeModel.ShowTopCTASection)"/>
                                                                        <div  class="help-block" ng-messages="HomeForm.TopCTALinkText3.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.TopCTALinkText3.$error.required  && HomeForm.TopCTALinkText3.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link Text'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.TopCTALinkURL3.$invalid}">
                                                                        <label for="Link URL" class="control-label">Link URL</label>
                                                                        <input class="form-control"  type="text" name="TopCTALinkURL3" ng-model="HomeModel.TopCTALinkURL3" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="(HomeModel.ShowTopCTASection3 && HomeModel.ShowTopCTASection)"/>
                                                                        <div  class="help-block" ng-messages="HomeForm.TopCTALinkURL3.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.TopCTALinkURL3.$error.required  && HomeForm.TopCTALinkURL3.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link URL'))}}</div>
                                                                            <div  ng-show="HomeForm.TopCTALinkURL3.$error.pattern ">{{ trans('messages.InvalidLink')}}</div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group col-md-12">
                                                                        <input type="checkbox" ng-model="HomeModel.ShowTopCTASection3" id="ShowTopCTASection3" name="ShowTopCTASection3" ng-true-value="1" ng-false-value="0">
                                                                        <label for="ShowTopCTASection3">Show Block 3?</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- Block 3 end -->

                                                        <!-- Block 4 start -->
                                                        <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                            <h5 class="caption-subject form-section uppercase col-md-12">Block 4</h5>
                                                            <div class="col-md-4 col-lg-3 col-sm-5 col-xs-12" >
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Image" class="control-label">Block 1 Image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealTopCTAImagePath4 ? HomeModel.RealTopCTAImagePath4 : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$WWHomeTopCTABlock4ImageType; ?>" name="FormImageTopBlock4" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealTopCTAImagePath4" id="file" title="Choose Image" ng-required="(HomeModel.ShowTopCTASection4 && HomeModel.ShowTopCTASection)"> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$WWHomeTopCTABlock4ImageType; ?>')" ng-hide="(HomeModel.RealTopCTAImagePath4 == '' || HomeModel.RealTopCTAImagePath4 == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedTopBlockImagesFixWidth > 0 &&  AllowedTopBlockImagesFixHeight > 0)"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedTopBlockImagesFixWidth }}x@{{ AllowedTopBlockImagesFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormImageTopBlock4.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormImageTopBlock4.file.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormImageTopBlock4.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Block 4 image'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                            <div class="col-md-4 col-lg-3 col-sm-5 col-xs-12">
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Image" class="control-label">Block 4 Hover Image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealTopCTAHoverImagePath4 ? HomeModel.RealTopCTAHoverImagePath4 : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$WWHomeTopCTABlock4HoverImageType; ?>" name="FormHoverImageTopBlock4" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealTopCTAHoverImagePath4" id="file" title="Choose Image" ng-required="(HomeModel.ShowTopCTASection4 && HomeModel.ShowTopCTASection)"> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$WWHomeTopCTABlock4HoverImageType; ?>')" ng-hide="(HomeModel.RealTopCTAHoverImagePath4 == '' || HomeModel.RealTopCTAHoverImagePath4 == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedTopBlockImagesFixWidth > 0 &&  AllowedTopBlockImagesFixHeight > 0)"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedTopBlockImagesFixWidth }}x@{{ AllowedTopBlockImagesFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormHoverImageTopBlock4.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormHoverImageTopBlock4.file.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormHoverImageTopBlock4.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Block 4 hover image'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12 col-lg-6 col-sm-12 col-xs-12 no-padding">
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.TopCTATitle4.$invalid}">
                                                                    <label for="Title" class="control-label">Title</label>
                                                                    <input class="form-control"  type="text" name="TopCTATitle4" ng-model="HomeModel.TopCTATitle4" ng-class="{ 'has-submitted' : HomeForm.$submitted }" maxlength="100" ng-required="(HomeModel.ShowTopCTASection4 && HomeModel.ShowTopCTASection)"/>
                                                                    <div  class="help-block" ng-messages="HomeForm.TopCTATitle4.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.TopCTATitle4.$error.required  && HomeForm.TopCTATitle4.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Title'))}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.TopCTADescription4.$invalid}">
                                                                    <label for="Description" class="control-label">Description</label>
                                                                    <textarea class="form-control" rows="3" name="TopCTADescription4" ng-model="HomeModel.TopCTADescription4" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="(HomeModel.ShowTopCTASection4 && HomeModel.ShowTopCTASection)"></textarea>
                                                                    <div  class="help-block" ng-messages="HomeForm.TopCTADescription4.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.TopCTADescription4.$error.required && HomeForm.TopCTADescription4.$invalid">{{ trans('messages.PropertyRequired',array('attribute'=>'Description'))}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-12 no-padding">
                                                                    <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.TopCTALinkText4.$invalid}">
                                                                        <label for="Link Text" class="control-label">Link Text</label>
                                                                        <input class="form-control"  type="text" name="TopCTALinkText4" ng-model="HomeModel.TopCTALinkText4" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="(HomeModel.ShowTopCTASection4 && HomeModel.ShowTopCTASection)"/>
                                                                        <div  class="help-block" ng-messages="HomeForm.TopCTALinkText4.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.TopCTALinkText4.$error.required && HomeForm.TopCTALinkText4.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link Text'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.TopCTALinkURL4.$invalid}">
                                                                        <label for="Link URL" class="control-label">Link URL</label>
                                                                        <input class="form-control"  type="text" name="TopCTALinkURL4" ng-model="HomeModel.TopCTALinkURL4" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="(HomeModel.ShowTopCTASection4 && HomeModel.ShowTopCTASection)"/>
                                                                        <div  class="help-block" ng-messages="HomeForm.TopCTALinkURL4.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.TopCTALinkURL4.$error.required  && HomeForm.TopCTALinkURL4.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link URL'))}}</div>
                                                                            <div  ng-show="HomeForm.TopCTALinkURL4.$error.pattern ">{{ trans('messages.InvalidLink')}}</div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group col-md-12">
                                                                        <input type="checkbox" ng-model="HomeModel.ShowTopCTASection4" id="ShowTopCTASection4" name="ShowTopCTASection4" ng-true-value="1" ng-false-value="0">
                                                                        <label for="ShowTopCTASection4">Show Block 4?</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- Block 4 end -->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="clearboth"></div>
                                <div class="portlet box blue-hoki" ng-cloak>
                                    <div class="portlet-title" collapse>
                                        <div class="caption">
                                            <i class=""></i>Bottom CTA Section</div>
                                        <div class="tools">
                                            <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                        </div>
                                    </div>
                                    <div class="portlet-body">
                                        <div class="row">
                                            <div class="col-md-12 no-padding">
                                                <div class="form-body" >
                                                    <div class="form-group col-md-12">
                                                        <input type="checkbox"  ng-model="HomeModel.ShowBottomCTASection" id="ShowBottomCTASection" name="ShowBottomCTASection" ng-true-value="1" ng-false-value="0">
                                                        <label for="ShowBottomCTASection">Show this section?</label>
                                                    </div>
                                                    <div class="col-md-12 no-padding">
                                                        <!-- Block 1 start -->
                                                        <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                            <h5 class="caption-subject form-section uppercase col-md-12">Block 1</h5>
                                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12" >
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Image" class="control-label">Block 1 Image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealBottomCTAImagePath1 ? HomeModel.RealBottomCTAImagePath1 : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$WWHomeBottomCTABlock1ImageType; ?>" name="FormImageBottomBlock1" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealBottomCTAImagePath1" id="file" title="Choose Image" ng-required="(HomeModel.ShowBottomCTASection1 && HomeModel.ShowBottomCTASection)"> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$WWHomeBottomCTABlock1ImageType; ?>')" ng-hide="(HomeModel.RealBottomCTAImagePath1 == '' || HomeModel.RealBottomCTAImagePath1 == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedBottomBlockImagesFixWidth > 0 &&  AllowedBottomBlockImagesFixHeight > 0)"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedBottomBlockImagesFixWidth }}x@{{ AllowedBottomBlockImagesFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormImageBottomBlock1.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormImageBottomBlock1.file.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormImageBottomBlock1.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Block 1 image'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.BottomCTAHeaderText1.$invalid}">
                                                                    <label for="Title" class="control-label">Header</label>
                                                                    <input class="form-control"  type="text" name="BottomCTAHeaderText1" ng-model="HomeModel.BottomCTAHeaderText1" ng-class="{ 'has-submitted' : HomeForm.$submitted }" maxlength="100" ng-required="(HomeModel.ShowBottomCTASection1 && HomeModel.ShowBottomCTASection)"/>
                                                                    <div  class="help-block" ng-messages="HomeForm.BottomCTAHeaderText1.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.BottomCTAHeaderText1.$error.required  && HomeForm.BottomCTAHeaderText1.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Header'))}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.BottomCTAHeaderTitle1.$invalid}">
                                                                    <label for="Title" class="control-label">Title</label>
                                                                    <input class="form-control"  type="text" name="BottomCTAHeaderTitle1" ng-model="HomeModel.BottomCTAHeaderTitle1" ng-class="{ 'has-submitted' : HomeForm.$submitted }" maxlength="100" ng-required="(HomeModel.ShowBottomCTASection1 && HomeModel.ShowBottomCTASection)"/>
                                                                    <div  class="help-block" ng-messages="HomeForm.BottomCTAHeaderTitle1.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.BottomCTAHeaderTitle1.$error.required  && HomeForm.BottomCTAHeaderTitle1.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Title'))}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.BottomCTADescription1.$invalid}">
                                                                    <label for="Description" class="control-label">Description</label>
                                                                    <textarea class="form-control" rows="4" name="BottomCTADescription1" ng-model="HomeModel.BottomCTADescription1" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="(HomeModel.ShowBottomCTASection1 && HomeModel.ShowBottomCTASection)"></textarea>
                                                                    <div  class="help-block" ng-messages="HomeForm.BottomCTADescription1.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.BottomCTADescription1.$error.required && HomeForm.BottomCTADescription1.$invalid">{{ trans('messages.PropertyRequired',array('attribute'=>'Description'))}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-12 no-padding">
                                                                    <div class="form-group col-md-6" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.BottomCTAButtonText1.$invalid}">
                                                                        <label for="Link Text" class="control-label">Link Text</label>
                                                                        <input class="form-control"  type="text" name="BottomCTAButtonText1" ng-model="HomeModel.BottomCTAButtonText1" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="(HomeModel.ShowBottomCTASection1 && HomeModel.ShowBottomCTASection)"/>
                                                                        <div  class="help-block" ng-messages="HomeForm.BottomCTAButtonText1.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.BottomCTAButtonText1.$error.required  && HomeForm.BottomCTAButtonText1.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link Text'))}}</div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group col-md-6" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.BottomCTAButtonLink1.$invalid}">
                                                                        <label for="Link URL" class="control-label">Link URL</label>
                                                                        <input class="form-control"  type="text" name="BottomCTAButtonLink1" ng-model="HomeModel.BottomCTAButtonLink1" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="(HomeModel.ShowBottomCTASection1 && HomeModel.ShowBottomCTASection)"/>
                                                                        <div  class="help-block" ng-messages="HomeForm.BottomCTAButtonLink1.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.BottomCTAButtonLink1.$error.required  && HomeForm.BottomCTAButtonLink1.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link URL'))}}</div>
                                                                            <div  ng-show="HomeForm.BottomCTAButtonLink1.$error.pattern ">{{ trans('messages.InvalidLink')}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-md-12">
                                                                    <input type="checkbox" ng-model="HomeModel.ShowBottomCTASection1" id="ShowBottomCTASection1" name="ShowBottomCTASection1" ng-true-value="1" ng-false-value="0">
                                                                    <label for="ShowBottomCTASection1">Show Block 1?</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- Block 1 end -->

                                                        <!-- Block 2 start -->
                                                        <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                            <h5 class="caption-subject form-section uppercase col-md-12">Block 2</h5>
                                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12" >
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Image" class="control-label">Block 2 Image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealBottomCTAImagePath2 ? HomeModel.RealBottomCTAImagePath2 : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$WWHomeBottomCTABlock2ImageType; ?>" name="FormImageBottomBlock2" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealBottomCTAImagePath2" id="file" title="Choose Image" ng-required="(HomeModel.ShowBottomCTASection2 && HomeModel.ShowBottomCTASection)"> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$WWHomeBottomCTABlock2ImageType; ?>')" ng-hide="(HomeModel.RealBottomCTAImagePath2 == '' || HomeModel.RealBottomCTAImagePath2 == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedBottomBlockImagesFixWidth > 0 &&  AllowedBottomBlockImagesFixHeight > 0)"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedBottomBlockImagesFixWidth }}x@{{ AllowedBottomBlockImagesFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormImageBottomBlock2.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormImageBottomBlock2.file.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormImageBottomBlock2.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Block 2 image'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.BottomCTAHeaderText2.$invalid}">
                                                                    <label for="Title" class="control-label">Header</label>
                                                                    <input class="form-control"  type="text" name="BottomCTAHeaderText2" ng-model="HomeModel.BottomCTAHeaderText2" ng-class="{ 'has-submitted' : HomeForm.$submitted }" maxlength="100" ng-required="(HomeModel.ShowBottomCTASection2 && HomeModel.ShowBottomCTASection)"/>
                                                                    <div  class="help-block" ng-messages="HomeForm.BottomCTAHeaderText2.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.BottomCTAHeaderText2.$error.required  && HomeForm.BottomCTAHeaderText2.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Header'))}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.BottomCTAHeaderTitle2.$invalid}">
                                                                    <label for="Title" class="control-label">Title</label>
                                                                    <input class="form-control"  type="text" name="BottomCTAHeaderTitle2" ng-model="HomeModel.BottomCTAHeaderTitle2" ng-class="{ 'has-submitted' : HomeForm.$submitted }" maxlength="100" ng-required="(HomeModel.ShowBottomCTASection2 && HomeModel.ShowBottomCTASection)"/>
                                                                    <div  class="help-block" ng-messages="HomeForm.BottomCTAHeaderTitle2.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.BottomCTAHeaderTitle2.$error.required  && HomeForm.BottomCTAHeaderTitle2.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Title'))}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.BottomCTADescription2.$invalid}">
                                                                    <label for="Description" class="control-label">Description</label>
                                                                    <textarea class="form-control" rows="4" name="BottomCTADescription2" ng-model="HomeModel.BottomCTADescription2" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="(HomeModel.ShowBottomCTASection2 && HomeModel.ShowBottomCTASection)"></textarea>
                                                                    <div  class="help-block" ng-messages="HomeForm.BottomCTADescription2.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.BottomCTADescription2.$error.required && HomeForm.BottomCTADescription2.$invalid">{{ trans('messages.PropertyRequired',array('attribute'=>'Description'))}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-12 no-padding">
                                                                    <div class="form-group col-md-6" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.BottomCTAButtonText2.$invalid}">
                                                                        <label for="Link Text" class="control-label">Link Text</label>
                                                                        <input class="form-control"  type="text" name="BottomCTAButtonText2" ng-model="HomeModel.BottomCTAButtonText2" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="(HomeModel.ShowBottomCTASection2 && HomeModel.ShowBottomCTASection)"/>
                                                                        <div  class="help-block" ng-messages="HomeForm.BottomCTAButtonText2.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.BottomCTAButtonText2.$error.required  && HomeForm.BottomCTAButtonText2.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link Text'))}}</div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group col-md-6" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.BottomCTAButtonLink2.$invalid}">
                                                                        <label for="Link URL" class="control-label">Link URL</label>
                                                                        <input class="form-control"  type="text" name="BottomCTAButtonLink2" ng-model="HomeModel.BottomCTAButtonLink2" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="(HomeModel.ShowBottomCTASection2 && HomeModel.ShowBottomCTASection)"/>
                                                                        <div  class="help-block" ng-messages="HomeForm.BottomCTAButtonLink2.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.BottomCTAButtonLink2.$error.required  && HomeForm.BottomCTAButtonLink1.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link URL'))}}</div>
                                                                            <div  ng-show="HomeForm.BottomCTAButtonLink2.$error.pattern ">{{ trans('messages.InvalidLink')}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-md-12">
                                                                    <input type="checkbox" ng-model="HomeModel.ShowBottomCTASection2" id="ShowBottomCTASection2" name="ShowBottomCTASection2" ng-true-value="1" ng-false-value="0">
                                                                    <label for="ShowBottomCTASection2">Show Block 2?</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- Block 2 end -->

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="clearboth"></div>
                                <div class="portlet box blue-hoki" ng-cloak>
                                    <div class="portlet-title" collapse="true">
                                        <div class="caption">
                                            <i class=""></i>SEO</div>
                                        <div class="tools">
                                            <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                        </div>
                                    </div>
                                    <div class="portlet-body ">
                                        <div class="row">
                                            <div class="form-body" ng-cloak>
                                                <div class="col-md-12 no-padding">
                                                    <div class="col-md-12 no-padding">
                                                        <div class="col-md-9  no-padding">
                                                            <div class="form-group col-md-6 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.BrowserTitle.$invalid}">
                                                                <label for="BrowserTitle" class="control-label">Browser Title</label>
                                                                <input class="form-control"  type="text" name="BrowserTitle"  maxlength="200" data-ng-model="HomeModel.BrowserTitle" data-ng-class="{'has-submitted' : HomeForm.$submitted }" required/>
                                                                <span class="error-text-color" ng-show="HomeForm.$submitted">
                                                                    <span ng-show="HomeForm.BrowserTitle.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Browser Title'))}}</span>
                                                                </span>
                                                            </div>
                                                            <div class="form-group col-md-6 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.CanonicalURL.$invalid}">
                                                                <label class="control-label">Canonical URL</label>
                                                                <input class="form-control"  type="text" name="CanonicalURL" ng-model="HomeModel.CanonicalURL" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>" maxlength="200" required/>
                                                                <span class="error-text-color" ng-show="HomeForm.$submitted">
                                                                        <span ng-show="HomeForm.CanonicalURL.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'CanonicalURL'))}}</span>
                                                                        <span ng-show="HomeForm.CanonicalURL.$error.pattern">{{ trans('messages.InvalidCanonicalUrl') }}</span>
                                                                </span>
                                                            </div>
                                                            <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                <label for="MetaDescription" class="control-label">Meta-Description</label>
                                                                <textarea rows="6" class="form-control" name="MetaDescription" data-ng-model="HomeModel.MetaDescription"></textarea>
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-md-12 col-sm-12 col-xs-12 no-padding margin-top-15"><hr class="hr-section margin-top-15"></div>
                                                        <div class="col-md-12 no-padding ">
                                                            <div class="form-group col-md-12 col-sm-12 col-xs-12 rich-margin">
                                                                <h3 class="page-title font-size19px">Facebook</h3>
                                                            </div>
                                                            <div class="form-group col-md-8 col-lg-9 col-sm-12 col-xs-12  no-padding">
                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                    <label for="FBTitle" class="control-label">Facebook Title</label>
                                                                    <input class="form-control" type="text" name="FBTitle"  maxlength="200" data-ng-model="HomeModel.FBTitle"/>
                                                                </div>
                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                    <label for="FBDescription" class="control-label">Facebook-Description</label>
                                                                    <textarea rows="6" class="form-control" name="FBDescription" data-ng-model="HomeModel.FBDescription"></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12">
                                                                <label for="FBImage" class="control-label">Facebook Image</label>
                                                            </div>
                                                            <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12 margin-top1pr">
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealFacebookImagePath ? HomeModel.RealFacebookImagePath : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$WWFacebookImageType; ?>" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealFacebookImagePath" id="file" title="Choose Image" > Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$WWFacebookImageType; ?>')" ng-hide="(HomeModel.RealFacebookImagePath == '' || HomeModel.RealFacebookImagePath == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                     </div>
                                                    <div class="form-group col-md-12 col-sm-12 col-xs-12 no-padding"><hr class="hr-section"></div>
                                                    <div class="col-md-12 no-padding">
                                                        <div class="form-group col-md-12 col-sm-12 col-xs-12 rich-margin">
                                                            <h3 class="page-title font-size19px">Twitter</h3>
                                                        </div>
                                                        <div class="form-group col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                            <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                <label for="TwitterCard" class="control-label">Twitter Card</label>
                                                                <input class="form-control" type="text" name="TwitterCard"  maxlength="50" data-ng-model="HomeModel.TwitterCard" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"/>
                                                            </div>
                                                            <div class="form-group col-md-6 col-sm-12 col-xs-12">
                                                                <label for="TwitterSite" class="control-label">Twitter Site</label>
                                                                <input class="form-control"  type="text" name="TwitterSite"  maxlength="200" data-ng-model="HomeModel.TwitterSite" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"/>
                                                            </div>
                                                            <div class="form-group col-md-6 col-sm-12 col-xs-12">
                                                                <label for="TwitterTitle" class="control-label">Twitter Title</label>
                                                                <input class="form-control"  type="text" name="TwitterTitle"  maxlength="200" data-ng-model="HomeModel.TwitterTitle" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"/>
                                                            </div>
                                                            <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                <label for="TwitterDescription" class="control-label">Twitter-Description</label>
                                                                <textarea rows="6" class="form-control" name="TwitterDescription" data-ng-model="HomeModel.TwitterDescription" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"></textarea>
                                                            </div>

                                                        </div>
                                                        <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12">
                                                            <label for="TwitterImage" class="control-label">Twitter Image</label>
                                                        </div>
                                                        <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12 margin-top1pr">
                                                            <div class="fileinput fileinput-new">
                                                                <div  class="fileinput-new thumbnail image-box">
                                                                    <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                    <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealTwitterImagePath ? HomeModel.RealTwitterImagePath : HomeModel.NoImagePath}}">
                                                                </div>
                                                                <div>
                                                                    <form></form>
                                                                    <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$WWTwitterImageType; ?>" role="form" novalidate>
                                                                        <input type="hidden" id="key" name="key" value="">
                                                                        <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                        <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                        <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                        <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                        <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                        <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                        <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealTwitterImagePath" id="file" title="Choose Image" > Choose Image</span>
                                                                        <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$WWTwitterImageType; ?>')" ng-hide="(HomeModel.RealTwitterImagePath == '' || HomeModel.RealTwitterImagePath == null)"> Remove </a>
                                                                        <span></span>
                                                                    </form>
                                                                </div>
                                                                <span>&nbsp;</span>
                                                                <div class="progress progress-striped display-none background">
                                                                    <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-md-12 col-sm-12 col-xs-12 no-padding"><hr class="hr-section"></div>
                                                    <div class="form-group col-md-12 col-sm-12 col-xs-12 rich-margin">
                                                        <h3 class="page-title font-size19px">Rich Snippets</h3>
                                                    </div>
                                                    <div class="col-md-12  no-padding">
                                                        <div class="col-md-12  no-padding">
                                                            <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                    <label for="Headline" class="control-label">Headline</label>
                                                                    <input class="form-control"  type="text" name="Headline"  maxlength="200" data-ng-model="HomeModel.Headline" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"/>
                                                                </div>
                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                    <label for="TwitterDescription" class="control-label">Description</label>
                                                                    <textarea rows="6" class="form-control" name="Description" data-ng-model="HomeModel.Description" ng-disabled="PageModel.ViewPage==0 && PageModel.CanEditSEOFields==0"></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12">
                                                                <label for="TwitterImage" class="control-label">Image Upload</label>
                                                            </div>
                                                            <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12 margin-top1pr">
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealRichSnippetImagePath ? HomeModel.RealRichSnippetImagePath : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$WWRichSnippetsImageType; ?>" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealRichSnippetImagePath" id="file" title="Choose Image" > Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$WWRichSnippetsImageType; ?>')" ng-hide="(HomeModel.RealRichSnippetImagePath == '' || HomeModel.RealRichSnippetImagePath == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                    <input id="submit-home" name="submit" type="submit" value="Save" class="btn blue save-button" data-ng-click="SaveHome()" ng-disabled="(DisableButtons || requestCounter != responseCounter)">
                                    <button type="button" id="cancel-home" class="btn default" data-ng-click="Cancel()" ng-disabled="(DisableButtons || requestCounter != responseCounter)">Cancel</button>
                                </div>

                            </div>
                        </form>
                    </div>
                    <!--<div class="tab-pane fade" id="tab_1_2">
                        <form name="SliderForm" id="SliderForm" role="form" novalidate ng-controller = "SliderController" ng-clock ng-submit="checkSaveSlider(SliderForm)">
                            <div class="form-body">
                                <div class="clearboth"></div>
                                <!-- For Slider section start -->
                          <!--      <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                    <div class="clearboth"></div>
                                    <div class="portlet box blue-hoki" ng-cloak>
                                        <div class="portlet-title" collapse>
                                            <div class="caption">
                                                <i class=""></i>Details</div>
                                            <div class="tools">
                                                <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                            </div>
                                        </div>
                                        <div class="portlet-body">
                                            <div class="row">
                                                <div class="col-md-12 no-padding">
                                                    <div class="form-body" >
                                                        <div class="col-md-12 no-padding">
                                                            <h3 class="caption-subject form-section uppercase col-md-12">@{{ SliderModel.Slider.HomePageSliderID > 0 ? 'Edit Slider' : 'Add Slider' }}</h3>
                                                            <!-- For Slider image upload section start -->
                                                        <!--    <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12 visible-sm visible-xs">
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Slider image" class="control-label">Slider image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new" ng-clock>
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src="@{{ SliderModel.Slider.RealBackgroundImagePath ? SliderModel.Slider.RealBackgroundImagePath : SliderModel.NoImagePath }}" ng-clock>
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload-slider" name="FormSliderImage" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="SliderModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="acl"  ng-value="SliderModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="success_action_status"  ng-value="SliderModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="policy"  ng-value="SliderModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="SliderModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="SliderModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="SliderModel.Slider.RealBackgroundImagePath" id="file" title="Choose Image" required> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage()" ng-hide="(SliderModel.Slider.RealBackgroundImagePath == '' || SliderModel.Slider.RealBackgroundImagePath == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedSliderFixHeight > 0 ) && (AllowedSliderFixWidth > 0 )"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedSliderFixWidth }}x@{{ AllowedSliderFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (SliderForm.$submitted) && FormSliderImage.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormSliderImage.file.$error" ng-if="SliderForm.$submitted">
                                                                            <div ng-show="FormSliderImage.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Slider images'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- For Slider image upload section end -->
                    <!--   <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                                <div class="form-group col-md-12 ">
                                                                    <label class="control-label margin-right-10">Text Color:</label>
                                                                    <label class="margin-right-10"><input type="radio" id="IsLight" ng-model="SliderModel.Slider.IsLight" name="IsLight" value="0"/>  Dark</label>
                                                                    <label><input type="radio" id="IsLight" ng-model="SliderModel.Slider.IsLight" name="IsLight"  value="1"/> Light</label>
                                                                </div>
                                                                <div class="form-group col-md-12">
                                                                    <label for="Title" class="control-label">Title</label>
                                                                    <input class="form-control" type="text" name="Title" ng-model="SliderModel.Slider.Title" id="SliderTitle"/>
                                                                </div>
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (SliderForm.$submitted) && SliderForm.LinkText.$invalid}">
                                                                    <label for="Link Text" class="control-label">Link Text</label>
                                                                    <input class="form-control" type="text" name="LinkText" ng-model="SliderModel.Slider.LinkText" ng-class="{ 'has-submitted' : SliderForm.$submitted }" ng-required="!( SliderModel.Slider.LinkURL == '' || SliderModel.Slider.LinkURL == null )" />
                                                                    <div  class="help-block" ng-messages="SliderForm.LinkText.$error" ng-if="SliderForm.$submitted">
                                                                        <div ng-show="SliderForm.LinkText.$error.required  && SliderForm.LinkText.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link Text'))}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (SliderForm.$submitted) && SliderForm.LinkURL.$invalid}">
                                                                    <label for="LinkURL" class="control-label">Link</label>
                                                                    <input class="form-control" type="text" name="LinkURL" ng-model="SliderModel.Slider.LinkURL" pattern="<?php echo \Infrastructure\Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : SliderForm.$submitted }" ng-required="!( SliderModel.Slider.LinkText == '' || SliderModel.Slider.LinkText == null )" />
                                                                    <div  class="help-block" ng-messages="SliderForm.LinkURL.$error" ng-if="SliderForm.$submitted">
                                                                        <div ng-show="SliderForm.LinkURL.$error.required  && SliderForm.LinkURL.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link'))}}</div>
                                                                        <div ng-show="SliderForm.LinkURL.$error.pattern ">{{ trans('messages.InvalidLink')}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-md-12">
                                                                    <label for="Description" class="control-label">Description</label>
                                                                    <textarea class="form-control" rows="4" name="Description" ng-model="SliderModel.Slider.Description" ></textarea>
                                                                </div>
                                                            </div>
                                                            <!-- For Slider image upload section start -->
                    <!--    <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12 hidden-sm hidden-xs">
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Slider image" class="control-label">Slider image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new" ng-clock>
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src="@{{ SliderModel.Slider.RealBackgroundImagePath ? SliderModel.Slider.RealBackgroundImagePath : SliderModel.NoImagePath }}" ng-clock>
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload-slider" name="FormSliderImage" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="SliderModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="acl"  ng-value="SliderModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="success_action_status"  ng-value="SliderModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="policy"  ng-value="SliderModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="SliderModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="SliderModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="SliderModel.Slider.RealBackgroundImagePath" id="file" title="Choose Image" required> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage()" ng-hide="(SliderModel.Slider.RealBackgroundImagePath == '' || SliderModel.Slider.RealBackgroundImagePath == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedSliderFixHeight > 0 ) && (AllowedSliderFixWidth > 0 )"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedSliderFixWidth }}x@{{ AllowedSliderFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (SliderForm.$submitted) && FormSliderImage.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormSliderImage.file.$error" ng-if="SliderForm.$submitted">
                                                                            <div ng-show="FormSliderImage.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Slider images'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- For Slider image upload section end -->
                    <!--</div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- For Slider File Upload End -->

                    <!--  <div class="form-actions  col-md-12 no-padding">
                          <input id="submit-slider" name="submit" type="submit" value="Save" class="btn blue save-button" data-ng-click="SaveSlider()" ng-disabled="DisableButtons">
                          <button type="button" id="cancel-slider" class="btn default" data-ng-click="CancelSlider()" ng-disabled="DisableButtons">Cancel</button>
                      </div>
                      <!-- Slider list start -->
                    <!--  <div class="col-md-12 no-padding">
                                        <div data-ng-if="SliderListArray.length > 0" class="table-scrollable sortablestory" ng-cloak>
                                            <div>
                                                <table class="table table-striped table-bordered table-hover" sortable-list="SliderListArray"  sortable-callback="updateSortOrderSlider" sortable-containment='sortablestory'>
                                                    <thead class="site-footer">
                                                    <tr role="row">
                                                        <th data-ng-if="SliderListArray.length > 1"><span class="anchor_color vertical-align"></span></th>
                                                        <th class="vertical-align home-slider-dp-width"><span class="anchor_color">Slider</span></th>
                                                        <th class="vertical-align"><span class="anchor_color">Title</span></th>
                                                        <th class="vertical-align">Action</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody class="drag-faq-list">
                                                    <tr ng-repeat="data in SliderListArray" class="sortable-row" role="row">
                                                        <td class="sortable-handle vertical-align" data-ng-if="SliderListArray.length > 1">
                                                            <span class="draggable-icon-arrow">
                                                                <i class="fa fa-bars draggable-icon"></i>
                                                                <i class="fa fa-arrows-alt draggable-icon"></i>
                                                            </span>
                                                        </td>
                                                        <td class="vertical-align"><img src="@{{data.RealBackgroundImagePath ? data.RealBackgroundImagePath : SliderModel.NoImagePath}}" class="homepage-sm-img" width="70px" height="70px"></td>
                                                        <td class="vertical-align"><a ng-click="EditSlider(data)" title="Edit Slider" ng-model="EditSlider"><div class="faq-ellipsis">@{{data.Title}}</div></a></td>
                                                        <td class="faq-action-part vertical-align">
                                                            <div>
                                                                <a ng-click="EditSlider(data)" title="Edit Slider" ng-model="EditSlider"><i class="fa fa-pencil text-default" ></i></a>
                                                                &nbsp;
                                                                <a ng-click="DeleteSlider(data)" title="Delete Slider" ng-model="DeleteSlider"><i class="fa fa-trash-o text-danger"></i></a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <div class="form-group col-md-12 display-none" align="center" id="nodata">
                                            <b>Sorry, no slider found</b>
                                        </div>
                                    </div>
                                    <!-- Slider list end -->
                    <!--       </div>
                           <!-- For Slider section end -->
                    <!--    </div>
                    </form>-->
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
@stop

@section('script')
    {{ $minify::javascript(array('/assets/js/viewjs/home/ww_home.js'))->withFullUrl()}}
    {{ $minify::javascript(array('/assets/js/sitejs/dropzone.js',
                                     '/assets/js/library/jquery.fileupload/jquery.ui.widget.js',
                                     '/assets/js/library/jquery.fileupload/jquery.fileupload.js',
                                     '/assets/js/library/binaryajax.js',
                                     '/assets/js/library/exif.js',
                                     '/assets/js/library/bootstrap-fileinput.js',
                                     '/assets/js/sitejs/canvasResize.js'))->withFullUrl()}}
    <script src="{{asset('/assets/js/ckeditor/ckeditor.js')}}" ></script>
    <!--For slider images upload start-->
    {{ $minify::javascript(array('/assets/js/sitejs/jquery-ui-1.9.2.custom.min.js',
                                   '/assets/js/sitejs/jquery.ui.touch-punch.min.js'))->withFullUrl()}}

    <script>
        window.ImageFileAllowedMessage ="{{ trans('messages.ImageFileAllowedMessage')}}";
        window.NoImagePath = '<?php echo asset('/assets/images/Samplephoto.png') ?>';

        window.WWHomeTopCTABlock1ImageType='<?php echo Constants::$WWHomeTopCTABlock1ImageType;?>';
        window.WWHomeTopCTABlock1HoverImageType='<?php echo Constants::$WWHomeTopCTABlock1HoverImageType;?>';
        window.WWHomeTopCTABlock2ImageType='<?php echo Constants::$WWHomeTopCTABlock2ImageType;?>';
        window.WWHomeTopCTABlock2HoverImageType='<?php echo Constants::$WWHomeTopCTABlock2HoverImageType;?>';
        window.WWHomeTopCTABlock3ImageType='<?php echo Constants::$WWHomeTopCTABlock3ImageType;?>';
        window.WWHomeTopCTABlock3HoverImageType='<?php echo Constants::$WWHomeTopCTABlock3HoverImageType;?>';
        window.WWHomeTopCTABlock4ImageType='<?php echo Constants::$WWHomeTopCTABlock4ImageType;?>';
        window.WWHomeTopCTABlock4HoverImageType='<?php echo Constants::$WWHomeTopCTABlock4HoverImageType;?>';

        window.WWHomeBottomCTABlock1ImageType='<?php echo Constants::$WWHomeBottomCTABlock1ImageType;?>';
        window.WWHomeBottomCTABlock2ImageType='<?php echo Constants::$WWHomeBottomCTABlock2ImageType;?>';

        window.WWFacebookImageType='<?php echo Constants::$WWFacebookImageType;?>';
        window.WWTwitterImageType='<?php echo Constants::$WWTwitterImageType;?>';
        window.WWRichSnippetsImageType='<?php echo Constants::$WWRichSnippetsImageType;?>';

        window.WWHomeSliderImageType='<?php echo Constants::$WWSliderImageType;?>';

    </script>
@stop