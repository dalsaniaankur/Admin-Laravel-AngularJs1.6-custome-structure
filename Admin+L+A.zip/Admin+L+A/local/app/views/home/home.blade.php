<?php
    use Infrastructure\Constants;
    $minify = new \CeesVanEgmond\Minify\Facades\Minify;
?>
@extends('layouts.sitemaster')
@section('Title')
    Home
@stop
@section('css')
    {{ $minify::stylesheet(array('/assets/css/dropzone/dropzone.css'))->withFullUrl()}}
@stop
@section('content')
<main id="main" role="main">
    <?php  echo Form::hidden('HomeModel',htmlspecialchars(json_encode($HomeModel), ENT_QUOTES, 'UTF-8'),$attributes = array('id'=>'HomeModel')); ?>
    <?php  echo Form::hidden('StoryModel',htmlspecialchars(json_encode($StoryModel), ENT_QUOTES, 'UTF-8'),$attributes = array('id'=>'StoryModel')); ?>
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo URL::to('/dashboard/'.$encryptedSiteID) ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Home</span>
                </li>
            </ul>
        </div>
        <h3 class="page-title">Home</h3>
        <ul class="nav nav-tabs">
            <li class="active">
                <a href="#tab_1_1" data-toggle="tab" aria-expanded="true">Home</a>
            </li>
            <li class="">
                <a href="#tab_1_2" data-toggle="tab" aria-expanded="false">Story of MV</a>
            </li>
        </ul>
        <div class="row">
            <div class="col-md-12">
                <div class="tab-content">
                    <div class="tab-pane active" id="tab_1_1">
                        <form name="HomeForm" id="StoryForm" role="form" novalidate ng-controller = "HomeController" ng-clock ng-submit="checkSave(HomeForm)">
                            <div class="form-body" ng-cloak>
                                <div class="clearboth"></div>
                                <div class="portlet box blue-hoki" ng-cloak>
                                    <div class="portlet-title" collapse>
                                        <div class="caption">
                                            <i class=""></i>Landing</div>
                                        <div class="tools">
                                            <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                        </div>
                                    </div>
                                    <div class="portlet-body">
                                        <div class="row">
                                            <div class="col-md-12 no-padding">
                                                <div class="form-body" >
                                                    <div class="col-md-12 no-padding">
                                                        <div class="form-group col-md-10" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.HeaderText.$invalid}">
                                                            <label for="Header text" class="control-label">Header text</label>
                                                            <input class="form-control" type="text" name="HeaderText" ng-model="HomeModel.HeaderText" ng-class="{ 'has-submitted' : HomeForm.$submitted }" maxlength="255" required />
                                                            <div  class="help-block" ng-messages="HomeForm.HeaderText.$error" ng-if="HomeForm.$submitted">
                                                                <div ng-show="HomeForm.HeaderText.$error.required  && HomeForm.HeaderText.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Header text'))}}</div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-md-4 col-sm-12 col-xs-12">
                                                            <label class="control-label margin-right-10">Landing section type: </label>
                                                            <label class="margin-right-10"><input type="radio" id="FirstSectionType" name="FirstSectionType" ng-model="HomeModel.FirstSectionType" value="1" data-ng-change="ChangeSectionType()"> Image</label>
                                                            <label><input type="radio" id="FirstSectionType" name="FirstSectionType" ng-model="HomeModel.FirstSectionType" value="2" data-ng-change="ChangeSectionType()"> Video</label>
                                                        </div>
                                                        <div class="col-md-12 col-sm-12 col-xs-12  no-padding">
                                                            <!-- For lending Images section start -->

                                                            <!-- For hover image upload section start -->
                                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12 " ng-show="(HomeModel.FirstSectionType == <?php echo Constants::$HomeSectionSimpleType;?>)">
                                                                <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                                    <label for="Hover images" class="control-label">Hover image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" ng-src = "@{{ HomeModel.RealHoverPath ? HomeModel.RealHoverPath : HomeModel.NoImagePath }}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$HoverImagesType; ?>" name="FormHoverImage" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealHoverPath" id="file" title="Choose Image" ng-required="HomeModel.FirstSectionType == <?php echo Constants::$HomeSectionSimpleType;?>"> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$HoverImagesType; ?>')" ng-hide="HomeModel.RealHoverPath == ''"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormHoverImage.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormHoverImage.file.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormHoverImage.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Hover image'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- For hover image upload section end -->

                                                            <!-- For lending Video section end -->
                                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12" ng-show="(HomeModel.FirstSectionType == <?php echo Constants::$HomeSectionVideoType;?>)">
                                                                <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                                    <div class="col-md-12 col-sm-12 col-xs-12 no-padding margin-bottom-15">
                                                                        <label for="Video" class="control-label">MP4 Video</label>
                                                                    </div>
                                                                    <div class="fileinput fileinput-new">
                                                                        <div class="video-name-ellipsis uploaded-video-name" ng-bind="HomeModel.MP3VideoName"></div>
                                                                        <div>
                                                                            <form></form>
                                                                            <form method="POST" id="directupload" enctype="multipart/form-data" class="directuploadvideo" video-type="<?php echo  Constants::$HomePageVideoMP3Type; ?>" name="FormVideoMP3" role="form" novalidate>
                                                                                <input type="hidden" id="key" name="key" value="">
                                                                                <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                                <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                                <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                                <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                                <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                                <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                                <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealMP3VideoPath"  title="Choose Image" ng-required="HomeModel.FirstSectionType == <?php echo Constants::$HomeSectionVideoType;?>"> Choose Video</span>
                                                                                <a class="btn red" href="javascript:void(0);" data-ng-click="DeleteVideo('<?php echo  Constants::$HomePageVideoMP3Type; ?>')" ng-hide="HomeModel.RealMP3VideoPath == ''"> Remove </a>
                                                                                <span></span>
                                                                            </form>
                                                                        </div>
                                                                        <span>&nbsp;</span>
                                                                        <div class="progress progress-striped display-none video">
                                                                            <div class="progress-bar bar progress-bar-success bg-green-jungle" id="videobar" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                                                                        </div>
                                                                        <div class="info-alert"><lable>Allowed extension: .mp4</lable></div>
                                                                        <div class="info-alert"><lable>Max file size: 100 MB</lable></div>
                                                                        <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormVideoMP3.file.$error}" class="has-error">
                                                                            <div class="help-block" ng-messages="FormVideoMP3.file.$error" ng-if="HomeForm.$submitted">
                                                                                <div ng-show="FormVideoMP3.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'MP4 Video'))}}</div>
                                                                            </div>
                                                                        </div>


                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12 " ng-show="(HomeModel.FirstSectionType == <?php echo Constants::$HomeSectionVideoType;?>)">
                                                                <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                                    <div class="col-md-12 col-sm-12 col-xs-12 no-padding margin-bottom-15">
                                                                        <label for="Video" class="control-label">Ogg Video</label>
                                                                    </div>
                                                                    <div class="fileinput fileinput-new">
                                                                        <div class="video-name-ellipsis uploaded-video-name" ng-bind="HomeModel.OggVideoName"></div>
                                                                        <div>
                                                                            <form></form>
                                                                            <form method="POST" id="directupload" enctype="multipart/form-data" class="directuploadvideo" video-type="<?php echo  Constants::$HomePageVideoOggType; ?>" name="FormVideoOgg" role="form" novalidate>
                                                                                <input type="hidden" id="key" name="key" value="">
                                                                                <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                                <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                                <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                                <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                                <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                                <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                                <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealOggVideoPath"  title="Choose Image" ng-required="HomeModel.FirstSectionType == <?php echo Constants::$HomeSectionVideoType;?>"> Choose Video</span>
                                                                                <a class="btn red" href="javascript:void(0);" data-ng-click="DeleteVideo('<?php echo  Constants::$HomePageVideoOggType; ?>')" ng-hide="HomeModel.RealOggVideoPath == ''"> Remove </a>
                                                                                <span></span>
                                                                            </form>
                                                                        </div>
                                                                        <span>&nbsp;</span>
                                                                        <div class="progress progress-striped display-none video">
                                                                            <div class="progress-bar bar progress-bar-success bg-green-jungle" id="videobar" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                                                                        </div>
                                                                        <div class="info-alert"><lable>Allowed extension: .ogv</lable></div>
                                                                        <div class="info-alert"><lable>Max file size: 100 MB</lable></div>
                                                                        <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormVideoOgg.file.$error}" class="has-error">
                                                                            <div class="help-block" ng-messages="FormVideoOgg.file.$error" ng-if="HomeForm.$submitted">
                                                                                <div ng-show="FormVideoOgg.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Ogg Video'))}}</div>
                                                                            </div>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12 " ng-show="(HomeModel.FirstSectionType == <?php echo Constants::$HomeSectionVideoType;?>)">
                                                                <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                                    <div class="col-md-12 col-sm-12 col-xs-12 no-padding margin-bottom-15">
                                                                        <label for="Video" class="control-label">Webm Video</label>
                                                                    </div>
                                                                    <div class="fileinput fileinput-new">
                                                                        <div class="video-name-ellipsis uploaded-video-name" ng-bind="HomeModel.WebmVideoName"></div>
                                                                        <div>
                                                                            <form></form>
                                                                            <form method="POST" id="directupload" enctype="multipart/form-data" class="directuploadvideo" video-type="<?php echo  Constants::$HomePageVideoWebmType; ?>" name="FormVideoWebm" role="form" novalidate>
                                                                                <input type="hidden" id="key" name="key" value="">
                                                                                <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                                <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                                <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                                <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                                <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                                <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                                <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealWebmVideoPath"  title="Choose Image" ng-required="HomeModel.FirstSectionType == <?php echo Constants::$HomeSectionVideoType;?>"> Choose Video</span>
                                                                                <a class="btn red" href="javascript:void(0);" data-ng-click="DeleteVideo('<?php echo  Constants::$HomePageVideoWebmType; ?>')" ng-hide="HomeModel.RealWebmVideoPath == ''"> Remove </a>
                                                                                <span></span>
                                                                            </form>
                                                                        </div>
                                                                        <span>&nbsp;</span>
                                                                        <div class="progress progress-striped display-none video">
                                                                            <div class="progress-bar bar progress-bar-success bg-green-jungle" id="videobar" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                                                                        </div>
                                                                        <div class="info-alert"><lable>Allowed extension: .webm</lable></div>
                                                                        <div class="info-alert"><lable>Max file size: 100 MB</lable></div>
                                                                        <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormVideoWebm.file.$error}" class="has-error">
                                                                            <div class="help-block" ng-messages="FormVideoWebm.file.$error" ng-if="HomeForm.$submitted">
                                                                                <div ng-show="FormVideoWebm.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Webm Video'))}}</div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <!-- For lending Video section end -->

                                                            <!-- For Background image upload section start -->
                                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12" ng-show="((HomeModel.FirstSectionType == <?php echo Constants::$HomeSectionVideoType;?>) || (HomeModel.FirstSectionType == <?php echo Constants::$HomeSectionSimpleType;?>))">
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Background image" class="control-label">Background image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new" ng-clock>
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src="@{{ HomeModel.RealBackgroundPath ? HomeModel.RealBackgroundPath : HomeModel.NoImagePath }}" ng-clock>
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$BackgroundImagesType; ?>" name="FormBackgroundImage" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealBackgroundPath" id="file" title="Choose Image" required> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$BackgroundImagesType; ?>')" ng-hide="HomeModel.RealBackgroundPath == ''"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormBackgroundImage.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormBackgroundImage.file.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormBackgroundImage.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Background images'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- For Background image upload section end -->
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="clearboth"></div>
                                <div class="portlet box blue-hoki" ng-cloak>
                                    <div class="portlet-title" collapse>
                                        <div class="caption">
                                            <i class=""></i>Video: Discover the world of Mercer Vine</div>
                                        <div class="tools">
                                            <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                        </div>
                                    </div>
                                    <div class="portlet-body">
                                        <div class="row">
                                            <div class="col-md-12 no-padding">
                                                <div class="form-body" >
                                                    <div class="col-md-12 no-padding">
                                                        <!-- For youtube video section start -->
                                                        <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12">
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Image" class="control-label">Video preview image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src="@{{HomeModel.RealYoutubeVideoImagesPath ? HomeModel.RealYoutubeVideoImagesPath : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$YoutubeVideoImageType; ?>"  name="FormYoutubeVideoImage" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealYoutubeVideoImagesPath" id="file" title="Choose Image" ng-required="HomeModel.YoutubeURL !=''"> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$YoutubeVideoImageType; ?>')" ng-hide="HomeModel.RealYoutubeVideoImagesPath == '' || HomeModel.RealYoutubeVideoImagesPath == null"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedVideoImagesFixHeight > 0 ) && (AllowedVideoImagesFixWidth > 0 )"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedVideoImagesFixWidth }}x@{{ AllowedVideoImagesFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormYoutubeVideoImage.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormYoutubeVideoImage.file.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormYoutubeVideoImage.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Youtube video image'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">

                                                                <div class="form-group col-md-10" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.YoutubeURL.$invalid}">
                                                                    <label for="Youtube Link" class="control-label">Youtube Link</label>
                                                                    <input class="form-control"  type="text" name="YoutubeURL" ng-model="HomeModel.YoutubeURL" pattern="<?php echo \Infrastructure\Constants::$YoutubeRegex; ?>" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="!(HomeModel.RealYoutubeVideoImagesPath == '' || HomeModel.RealYoutubeVideoImagesPath == null)" />
                                                                    <div  class="help-block" ng-messages="HomeForm.YoutubeURL.$error" ng-if="HomeForm.$submitted">
                                                                        <div ng-show="HomeForm.YoutubeURL.$error.required  && HomeForm.YoutubeURL.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Youtube URL'))}}</div>
                                                                        <div ng-show="HomeForm.YoutubeURL.$error.pattern ">{{ trans('messages.InvalidYoutubeLink')}}</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- For youtube video section end -->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="clearboth"></div>
                                <div class="portlet box blue-hoki" ng-cloak>
                                    <div class="portlet-title" collapse>
                                        <div class="caption">
                                            <i class=""></i>More from MV</div>
                                        <div class="tools">
                                            <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                        </div>
                                    </div>
                                    <div class="portlet-body">
                                        <div class="row">
                                            <div class="col-md-12 no-padding">
                                                <div class="form-body" >
                                                    <div class="form-group col-md-12">
                                                        <input type="checkbox"  ng-model="HomeModel.ShowMVSection" id="ShowMVSection" name="ShowMVSection" ng-true-value="1" ng-false-value="0">
                                                        <label for="ShowMVSection">Show this section?</label>
                                                    </div>
                                                    <div class="col-md-12 no-padding">
                                                        <!-- More from MV Box 1 start -->
                                                        <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                            <h5 class="caption-subject form-section uppercase col-md-12">Box 1 </h5>
                                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12" >
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Image" class="control-label">Image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealMVItem1Path ? HomeModel.RealMVItem1Path : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$MVItem1ImageType; ?>" name="FormImageSection1" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealMVItem1Path" id="file" title="Choose Image" ng-required="HomeModel.ShowMVSection == 1"> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$MVItem1ImageType; ?>')" ng-hide="(HomeModel.RealMVItem1Path == '' || HomeModel.RealMVItem1Path == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormImageSection1.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormImageSection1.file.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormImageSection1.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Box 1 images'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                                <div class="form-group col-md-10" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.MVItem1Title.$invalid}">
                                                                    <label for="Title" class="control-label">Title</label>
                                                                    <input class="form-control"  type="text" name="MVItem1Title" ng-model="HomeModel.MVItem1Title" ng-class="{ 'has-submitted' : HomeForm.$submitted }" maxlength="100" ng-required="HomeModel.ShowMVSection == 1" />
                                                                    <div  class="help-block" ng-messages="HomeForm.MVItem1Title.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.MVItem1Title.$error.required  && HomeForm.MVItem1Title.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Title'))}}</div>
                                                                    </div>
                                                                </div>

                                                                <div class="form-group col-md-10" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.MVItem1Subtitle.$invalid}">
                                                                    <label for="Subtitle" class="control-label">Subtitle</label>
                                                                    <input class="form-control"  type="text" name="MVItem1Subtitle" ng-model="HomeModel.MVItem1Subtitle" ng-class="{ 'has-submitted' : HomeForm.$submitted }" maxlength="150" ng-required="HomeModel.ShowMVSection == 1" />
                                                                    <div  class="help-block" ng-messages="HomeForm.MVItem1Subtitle.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.MVItem1Subtitle.$error.required  && HomeForm.MVItem1Subtitle.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Subtitle'))}}</div>
                                                                    </div>
                                                                </div>

                                                                <div class="form-group col-md-10" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.MVItem1Link.$invalid}">
                                                                    <label for="Link" class="control-label">Link</label>
                                                                    <input class="form-control"  type="text" name="MVItem1Link" ng-model="HomeModel.MVItem1Link" pattern="<?php echo \Infrastructure\Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="HomeModel.ShowMVSection == 1" />
                                                                    <div  class="help-block" ng-messages="HomeForm.MVItem1Link.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.MVItem1Link.$error.required  && HomeForm.MVItem1Link.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link'))}}</div>
                                                                        <div  ng-show="HomeForm.MVItem1Link.$error.pattern ">{{ trans('messages.InvalidLink')}}</div>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                        <!-- More from MV Box 1 end -->

                                                        <!-- More from MV Box 2 start -->
                                                        <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                            <h5 class="caption-subject form-section uppercase col-md-12">Box 2</h5>
                                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12" >
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Image" class="control-label">Image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src="@{{HomeModel.RealMVItem2Path ? HomeModel.RealMVItem2Path : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$MVItem2ImageType; ?>"  name="FormImageSection2" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealMVItem2Path" id="file" title="Choose Image" ng-required="HomeModel.ShowMVSection == 1"> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$MVItem2ImageType; ?>')" ng-hide="(HomeModel.RealMVItem2Path == '' || HomeModel.RealMVItem2Path == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormImageSection2.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="file.RealMVItem2Path.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormImageSection2.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Box 2 images'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                                <div class="form-group col-md-10" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.MVItem2Title.$invalid}">
                                                                    <label for="Title" class="control-label">Title</label>
                                                                    <input class="form-control"  type="text" name="MVItem2Title" ng-model="HomeModel.MVItem2Title" ng-class="{ 'has-submitted' : HomeForm.$submitted }" maxlength="100" ng-required="HomeModel.ShowMVSection == 1" />
                                                                    <div  class="help-block" ng-messages="HomeForm.MVItem2Title.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.MVItem2Title.$error.required  && HomeForm.MVItem2Title.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Title'))}}</div>
                                                                    </div>
                                                                </div>

                                                                <div class="form-group col-md-10" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.MVItem2Subtitle.$invalid}">
                                                                    <label for="Subtitle" class="control-label">Subtitle</label>
                                                                    <input class="form-control"  type="text" name="MVItem2Subtitle" ng-model="HomeModel.MVItem2Subtitle" ng-class="{ 'has-submitted' : HomeForm.$submitted }" maxlength="150" ng-required="HomeModel.ShowMVSection == 1" />
                                                                    <div  class="help-block" ng-messages="HomeForm.MVItem2Subtitle.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.MVItem2Subtitle.$error.required  && HomeForm.MVItem2Subtitle.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Subtitle'))}}</div>
                                                                    </div>
                                                                </div>

                                                                <div class="form-group col-md-10" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.MVItem2Link.$invalid}">
                                                                    <label for="Link" class="control-label">Link</label>
                                                                    <input class="form-control"  type="text" name="MVItem2Link" ng-model="HomeModel.MVItem2Link" pattern="<?php echo \Infrastructure\Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="HomeModel.ShowMVSection == 1" />
                                                                    <div  class="help-block" ng-messages="HomeForm.MVItem2Link.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.MVItem2Link.$error.required  && HomeForm.MVItem2Link.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link'))}}</div>
                                                                        <div  ng-show="HomeForm.MVItem2Link.$error.pattern ">{{ trans('messages.InvalidLink')}}</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- More from MV Box 2 end -->

                                                        <!-- More from MV Box 3 start -->
                                                        <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                            <h5 class="caption-subject form-section uppercase col-md-12">Box 3 </h5>
                                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12" >
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Image" class="control-label">Image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage"  class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src="@{{HomeModel.RealMVItem3Path ? HomeModel.RealMVItem3Path : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$MVItem3ImageType; ?>"  name="FormImageSection3" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">

                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealMVItem3Path" id="file" title="Choose Image" ng-required="HomeModel.ShowMVSection == 1"> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$MVItem3ImageType; ?>')" ng-hide="(HomeModel.RealMVItem3Path == '' || HomeModel.RealMVItem3Path == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormImageSection3.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormImageSection3.file.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormImageSection3.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Box 3 images'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                                <div class="form-group col-md-10" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.MVItem3Title.$invalid}">
                                                                    <label for="Title" class="control-label">Title</label>
                                                                    <input class="form-control"  type="text" name="MVItem3Title" ng-model="HomeModel.MVItem3Title" ng-class="{ 'has-submitted' : HomeForm.$submitted }" maxlength="100" ng-required="HomeModel.ShowMVSection == 1" />
                                                                    <div  class="help-block" ng-messages="HomeForm.MVItem3Title.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.MVItem3Title.$error.required  && HomeForm.MVItem3Title.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Title'))}}</div>
                                                                    </div>
                                                                </div>

                                                                <div class="form-group col-md-10" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.MVItem3Subtitle.$invalid}">
                                                                    <label for="Subtitle" class="control-label">Subtitle</label>
                                                                    <input class="form-control"  type="text" name="MVItem3Subtitle" ng-model="HomeModel.MVItem3Subtitle" ng-class="{ 'has-submitted' : HomeForm.$submitted }" maxlength="150" ng-required="HomeModel.ShowMVSection == 1" />
                                                                    <div  class="help-block" ng-messages="HomeForm.MVItem3Subtitle.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.MVItem3Subtitle.$error.required  && HomeForm.MVItem3Subtitle.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Subtitle'))}}</div>
                                                                    </div>
                                                                </div>

                                                                <div class="form-group col-md-10" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.MVItem3Link.$invalid}">
                                                                    <label for="Link" class="control-label">Link</label>
                                                                    <input class="form-control"  type="text" name="MVItem3Link" ng-model="HomeModel.MVItem3Link" pattern="<?php echo \Infrastructure\Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="HomeModel.ShowMVSection == 1" />
                                                                    <div  class="help-block" ng-messages="HomeForm.MVItem3Link.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.MVItem3Link.$error.required  && HomeForm.MVItem3Link.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link'))}}</div>
                                                                        <div  ng-show="HomeForm.MVItem3Link.$error.pattern ">{{ trans('messages.InvalidLink')}}</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- More from MV Box 3 end -->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Testing -->
                                <div class="clearboth"></div>
                                <div class="portlet box blue-hoki" ng-cloak>
                                    <div class="portlet-title" collapse="true">
                                        <div class="caption">
                                            <i class=""></i>SEO</div>
                                        <div class="tools">
                                            <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                        </div>
                                    </div>
                                    <div class="portlet-body ">
                                        <div class="row">
                                            <div class="form-body" ng-cloak>
                                                <div class="col-md-12 no-padding">
                                                    <div class="col-md-12 no-padding">
                                                        <div class="col-md-9  no-padding">
                                                            <div class="form-group col-md-6 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.BrowserTitle.$invalid}">
                                                                <label for="BrowserTitle" class="control-label">Browser Title</label>
                                                                <input class="form-control"  type="text" name="BrowserTitle"  maxlength="200" data-ng-model="HomeModel.BrowserTitle" data-ng-class="{'has-submitted' : HomeForm.$submitted }" required/>
                                                                <span class="error-text-color" ng-show="HomeForm.$submitted">
                                                                    <span ng-show="HomeForm.BrowserTitle.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Browser Title'))}}</span>
                                                                </span>
                                                            </div>
                                                            <div class="form-group col-md-6 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.CanonicalURL.$invalid}">
                                                                <label class="control-label">Canonical URL</label>
                                                                <input class="form-control"  type="text" name="CanonicalURL" ng-model="HomeModel.CanonicalURL" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>" maxlength="200" required/>
                                                                <span class="error-text-color" ng-show="HomeForm.$submitted">
                                                                        <span ng-show="HomeForm.CanonicalURL.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'CanonicalURL'))}}</span>
                                                                        <span ng-show="HomeForm.CanonicalURL.$error.pattern">{{ trans('messages.InvalidCanonicalUrl') }}</span>
                                                                </span>
                                                            </div>
                                                            <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                <label for="MetaDescription" class="control-label">Meta-Description</label>
                                                                <textarea rows="6" class="form-control" name="MetaDescription" data-ng-model="HomeModel.MetaDescription"></textarea>
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-md-12 col-sm-12 col-xs-12 no-padding margin-top-15"><hr class="hr-section margin-top-15"></div>
                                                        <div class="col-md-12 no-padding ">
                                                            <div class="form-group col-md-12 col-sm-12 col-xs-12 rich-margin">
                                                                <h3 class="page-title font-size19px">Facebook</h3>
                                                            </div>
                                                            <div class="form-group col-md-8 col-lg-9 col-sm-12 col-xs-12  no-padding">
                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                    <label for="FBTitle" class="control-label">Facebook Title</label>
                                                                    <input class="form-control" type="text" name="FBTitle"  maxlength="200" data-ng-model="HomeModel.FBTitle"/>
                                                                </div>
                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                    <label for="FBDescription" class="control-label">Facebook-Description</label>
                                                                    <textarea rows="6" class="form-control" name="FBDescription" data-ng-model="HomeModel.FBDescription"></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12">
                                                                <label for="FBImage" class="control-label">Facebook Image</label>
                                                            </div>
                                                            <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12 margin-top1pr">
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.FBRealImagePath ? HomeModel.FBRealImagePath : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$HomeFacebookImageType; ?>" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">

                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.FBRealImagePath" id="file" title="Choose Image" > Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$HomeFacebookImageType; ?>')" ng-hide="(HomeModel.FBRealImagePath == '' || HomeModel.FBRealImagePath == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                     </div>
                                                    <div class="form-group col-md-12 col-sm-12 col-xs-12 no-padding"><hr class="hr-section"></div>
                                                    <div class="col-md-12 no-padding">
                                                        <div class="form-group col-md-12 col-sm-12 col-xs-12 rich-margin">
                                                            <h3 class="page-title font-size19px">Twitter</h3>
                                                        </div>
                                                        <div class="form-group col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                            <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                <label for="TwitterCard" class="control-label">Twitter Card</label>
                                                                <input class="form-control" type="text" name="TwitterCard"  maxlength="50" data-ng-model="HomeModel.TwitterCard" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"/>
                                                            </div>
                                                            <div class="form-group col-md-6 col-sm-12 col-xs-12">
                                                                <label for="TwitterSite" class="control-label">Twitter Site</label>
                                                                <input class="form-control"  type="text" name="TwitterSite"  maxlength="200" data-ng-model="HomeModel.TwitterSite" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"/>
                                                            </div>
                                                            <div class="form-group col-md-6 col-sm-12 col-xs-12">
                                                                <label for="TwitterTitle" class="control-label">Twitter Title</label>
                                                                <input class="form-control"  type="text" name="TwitterTitle"  maxlength="200" data-ng-model="HomeModel.TwitterTitle" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"/>
                                                            </div>
                                                            <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                <label for="TwitterDescription" class="control-label">Twitter-Description</label>
                                                                <textarea rows="6" class="form-control" name="TwitterDescription" data-ng-model="HomeModel.TwitterDescription" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"></textarea>
                                                            </div>

                                                        </div>
                                                        <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12">
                                                            <label for="TwitterImage" class="control-label">Twitter Image</label>
                                                        </div>
                                                        <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12 margin-top1pr">
                                                            <div class="fileinput fileinput-new">
                                                                <div  class="fileinput-new thumbnail image-box">
                                                                    <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                    <img id="actualImage" alt="" ng-src=" @{{HomeModel.TwitterRealImagePath ? HomeModel.TwitterRealImagePath : HomeModel.NoImagePath}}">
                                                                </div>
                                                                <div>
                                                                    <form></form>
                                                                    <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$HomeTwitterImageType; ?>" role="form" novalidate>
                                                                        <input type="hidden" id="key" name="key" value="">
                                                                        <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                        <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                        <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                        <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                        <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                        <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                        <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.TwitterRealImagePath" id="file" title="Choose Image" > Choose Image</span>
                                                                        <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$HomeTwitterImageType; ?>')" ng-hide="(HomeModel.TwitterRealImagePath == '' || HomeModel.TwitterRealImagePath == null)"> Remove </a>
                                                                        <span></span>
                                                                    </form>
                                                                </div>
                                                                <span>&nbsp;</span>
                                                                <div class="progress progress-striped display-none background">
                                                                    <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-md-12 col-sm-12 col-xs-12 no-padding"><hr class="hr-section"></div>
                                                    <div class="form-group col-md-12 col-sm-12 col-xs-12 rich-margin">
                                                        <h3 class="page-title font-size19px">Rich Snippets</h3>
                                                    </div>
                                                    <div class="col-md-12  no-padding">
                                                        <div class="col-md-12  no-padding">
                                                            <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                    <label for="Headline" class="control-label">Headline</label>
                                                                    <input class="form-control"  type="text" name="Headline"  maxlength="200" data-ng-model="HomeModel.Headline" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"/>
                                                                </div>
                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                    <label for="TwitterDescription" class="control-label">Description</label>
                                                                    <textarea rows="6" class="form-control" name="Description" data-ng-model="HomeModel.Description" ng-disabled="PageModel.ViewPage==0 && PageModel.CanEditSEOFields==0"></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12">
                                                                <label for="TwitterImage" class="control-label">Image Upload</label>
                                                            </div>
                                                            <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12 margin-top1pr">
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RichSnippetsRealImagePath ? HomeModel.RichSnippetsRealImagePath : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$HomeRichSnippetsImageType; ?>" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RichSnippetsRealImagePath" id="file" title="Choose Image" > Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$HomeRichSnippetsImageType; ?>')" ng-hide="(HomeModel.RichSnippetsRealImagePath == '' || HomeModel.RichSnippetsRealImagePath == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Testing -->

                                <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                    <input id="submit-home" name="submit" type="submit" value="Save" class="btn blue save-button" data-ng-click="SaveHome()" ng-disabled="(DisableButtons || requestCounter != responseCounter)">
                                    <button type="button" id="cancel-home" class="btn default" data-ng-click="Cancel()" ng-disabled="(DisableButtons || requestCounter != responseCounter)">Cancel</button>
                                </div>

                            </div>
                        </form>
                    </div>
                    <div class="tab-pane fade" id="tab_1_2">
                        <form name="StoryForm" id="StoryForm" role="form" novalidate ng-controller = "StoryController" ng-clock ng-submit="checkSaveStory(StoryForm)">
                            <div class="form-body">
                                <div class="clearboth"></div>
                                <!-- For story section start -->
                               <div class="col-md-12 col-sm-12 col-xs-12 no-padding">

                                   <div class="clearboth"></div>
                                   <div class="portlet box blue-hoki" ng-cloak>
                                       <div class="portlet-title" collapse>
                                           <div class="caption">
                                               <i class=""></i>Details</div>
                                           <div class="tools">
                                               <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                           </div>
                                       </div>
                                       <div class="portlet-body">
                                           <div class="row">
                                               <div class="col-md-12 no-padding">
                                                   <div class="form-body" >
                                                       <div class="col-md-12 no-padding">
                                                           <h3 class="caption-subject form-section uppercase col-md-12">@{{ StoryModel.Story.HomePageStoryID > 0 ? 'Edit Story' : 'Add Story' }}</h3>
                                                           <!-- For Story image upload section start -->
                                                           <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12 visible-sm visible-xs">
                                                               <div class="col-md-12 no-padding">
                                                                   <label for="Story image" class="control-label">Story image</label>
                                                               </div>
                                                               <div class="fileinput fileinput-new" ng-clock>
                                                                   <div  class="fileinput-new thumbnail image-box">
                                                                       <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                       <img id="actualImage" alt="" ng-src="@{{ StoryModel.Story.RealImagePath ? StoryModel.Story.RealImagePath : StoryModel.NoImagePath }}" ng-clock>
                                                                   </div>
                                                                   <div>
                                                                       <form></form>
                                                                       <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload-story-image" name="FormStoryImage" role="form" novalidate>
                                                                           <input type="hidden" id="key" name="key" value="">
                                                                           <input type="hidden" name="AWSAccessKeyId"  ng-value="StoryModel.FileUploadSettings.accesskey">
                                                                           <input type="hidden" name="acl"  ng-value="StoryModel.FileUploadSettings.acl">
                                                                           <input type="hidden" name="success_action_status"  ng-value="StoryModel.FileUploadSettings.success_action">
                                                                           <input type="hidden" name="policy"  ng-value="StoryModel.FileUploadSettings.base64Policy">
                                                                           <input type="hidden" name="signature"  ng-value="StoryModel.FileUploadSettings.signature">
                                                                           <input type="hidden" name="Cache-Control" ng-value="StoryModel.FileUploadSettings.cacheControlTime">
                                                                           <span  class="btn default btn-file" ><input type="file" name="file" ng-model="StoryModel.Story.RealImagePath" id="file" title="Choose Image" required> Choose Image</span>
                                                                           <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage()" ng-hide="StoryModel.Story.RealImagePath == ''"> Remove </a>
                                                                           <span></span>
                                                                       </form>
                                                                   </div>
                                                                   <span>&nbsp;</span>
                                                                   <div class="progress progress-striped display-none background">
                                                                       <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                       </div>
                                                                   </div>
                                                                   <div class="info-alert" ng-if="(AllowedStoryFixHeight > 0 ) && (AllowedStoryFixWidth > 0 )"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedStoryFixWidth }}x@{{ AllowedStoryFixHeight }}px</lable></div>
                                                                   <div ng-class="{ 'has-error' : (StoryForm.$submitted) && FormStoryImage.file.$error}" class="has-error">
                                                                       <div class="help-block" ng-messages="FormStoryImage.file.$error" ng-if="StoryForm.$submitted">
                                                                           <div ng-show="FormStoryImage.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Story images'))}}</div>
                                                                       </div>
                                                                   </div>
                                                               </div>
                                                           </div>
                                                           <!-- For Story image upload section end -->
                                                           <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                               <div class="form-group col-md-12 ">
                                                                   <label class="control-label margin-right-10">Text Color:</label>
                                                                       <label class="margin-right-10"><input type="radio" id="IsLight" ng-model="StoryModel.Story.IsLight" name="IsHidden"  value="0"/>  Dark</label>
                                                                       <label><input type="radio" id="IsLight" ng-model="StoryModel.Story.IsLight" name="IsHidden"  value="1"/> Light</label>

                                                               </div>
                                                               <div class="form-group col-md-12 " ng-class="{ 'has-error' : (StoryForm.$submitted) && StoryForm.StoryTitle.$invalid}">
                                                                   <label for="Title" class="control-label">Title</label>
                                                                   <input class="form-control" type="text" name="StoryTitle" ng-model="StoryModel.Story.Title" id="StoryTitle" ng-class="{ 'has-submitted' : StoryForm.$submitted }" required />
                                                                   <div  class="help-block" ng-messages="StoryForm.StoryTitle.$error" ng-if="StoryForm.$submitted">
                                                                       <div ng-show="StoryForm.StoryTitle.$error.required  && StoryForm.StoryTitle.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Title'))}}</div>
                                                                   </div>
                                                               </div>
                                                               <div class="form-group col-md-12" ng-class="{ 'has-error' : (StoryForm.$submitted) && StoryForm.StoryLinkText.$invalid}">
                                                                   <label for="Link Text" class="control-label">Link Text</label>
                                                                   <input class="form-control" type="text" name="StoryLinkText" ng-model="StoryModel.Story.LinkText" ng-class="{ 'has-submitted' : StoryForm.$submitted }" required />
                                                                   <div  class="help-block" ng-messages="StoryForm.StoryLinkText.$error" ng-if="StoryForm.$submitted">
                                                                       <div ng-show="StoryForm.StoryLinkText.$error.required  && StoryForm.StoryLinkText.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link Text'))}}</div>
                                                                   </div>
                                                               </div>
                                                               <div class="form-group col-md-12" ng-class="{ 'has-error' : (StoryForm.$submitted) && StoryForm.StoryLink.$invalid}">
                                                                   <label for="Link" class="control-label">Link</label>
                                                                   <input class="form-control" type="text" name="StoryLink" ng-model="StoryModel.Story.Link" pattern="<?php echo \Infrastructure\Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : StoryForm.$submitted }" required />
                                                                   <div  class="help-block" ng-messages="StoryForm.StoryLink.$error" ng-if="StoryForm.$submitted">
                                                                       <div ng-show="StoryForm.StoryLink.$error.required  && StoryForm.StoryLink.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link'))}}</div>
                                                                       <div ng-show="StoryForm.StoryLink.$error.pattern ">{{ trans('messages.InvalidLink')}}</div>
                                                                   </div>
                                                               </div>
                                                               <div class="form-group col-md-12" ng-class="{ 'has-error' : (StoryForm.$submitted) && StoryForm.StoryDescription.$invalid}">
                                                                   <label for="Description" class="control-label">Description</label>
                                                                   <textarea class="form-control" rows="5" name="StoryDescription" ng-model="StoryModel.Story.Description" ng-class="{ 'has-submitted' : StoryForm.$submitted }" required ></textarea>
                                                                   <div  class="help-block" ng-messages="StoryForm.StoryDescription.$error" ng-if="StoryForm.$submitted">
                                                                       <div  ng-show="StoryForm.StoryDescription.$error.required && StoryForm.StoryDescription.$invalid">{{ trans('messages.PropertyRequired',array('attribute'=>'Description'))}}</div>
                                                                   </div>
                                                               </div>
                                                           </div>
                                                           <!-- For Story image upload section start -->
                                                           <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12 hidden-sm hidden-xs">
                                                               <div class="col-md-12 no-padding">
                                                                   <label for="Story image" class="control-label">Story image</label>
                                                               </div>
                                                               <div class="fileinput fileinput-new" ng-clock>
                                                                   <div  class="fileinput-new thumbnail image-box">
                                                                       <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                       <img id="actualImage" alt="" ng-src="@{{ StoryModel.Story.RealImagePath ? StoryModel.Story.RealImagePath : StoryModel.NoImagePath }}" ng-clock>
                                                                   </div>
                                                                   <div>
                                                                       <form></form>
                                                                       <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload-story-image" name="FormStoryImage" role="form" novalidate>
                                                                           <input type="hidden" id="key" name="key" value="">
                                                                           <input type="hidden" name="AWSAccessKeyId"  ng-value="StoryModel.FileUploadSettings.accesskey">
                                                                           <input type="hidden" name="acl"  ng-value="StoryModel.FileUploadSettings.acl">
                                                                           <input type="hidden" name="success_action_status"  ng-value="StoryModel.FileUploadSettings.success_action">
                                                                           <input type="hidden" name="policy"  ng-value="StoryModel.FileUploadSettings.base64Policy">
                                                                           <input type="hidden" name="signature"  ng-value="StoryModel.FileUploadSettings.signature">
                                                                           <input type="hidden" name="Cache-Control" ng-value="StoryModel.FileUploadSettings.cacheControlTime">
                                                                           <span  class="btn default btn-file" ><input type="file" name="file" ng-model="StoryModel.Story.RealImagePath" id="file" title="Choose Image" required> Choose Image</span>
                                                                           <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage()" ng-hide="StoryModel.Story.RealImagePath == ''"> Remove </a>
                                                                           <span></span>
                                                                       </form>
                                                                   </div>
                                                                   <span>&nbsp;</span>
                                                                   <div class="progress progress-striped display-none background">
                                                                       <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                       </div>
                                                                   </div>
                                                                   <div class="info-alert" ng-if="(AllowedStoryFixHeight > 0 ) && (AllowedStoryFixWidth > 0 )"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedStoryFixWidth }}x@{{ AllowedStoryFixHeight }}px</lable></div>
                                                                   <div ng-class="{ 'has-error' : (StoryForm.$submitted) && FormStoryImage.file.$error}" class="has-error">
                                                                       <div class="help-block" ng-messages="FormStoryImage.file.$error" ng-if="StoryForm.$submitted">
                                                                           <div ng-show="FormStoryImage.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Story images'))}}</div>
                                                                       </div>
                                                                   </div>
                                                               </div>
                                                           </div>
                                                           <!-- For Story image upload section end -->
                                                       </div>
                                                   </div>
                                               </div>
                                           </div>
                                       </div>
                                   </div>

                                    <!-- For Story File Upload End -->

                                    <div class="form-actions  col-md-12 no-padding">
                                        <input id="submit-story" name="submit" type="submit" value="Save" class="btn blue save-button" data-ng-click="AddStory()" ng-disabled="DisableButtons || (responseCounter != requestCounter)">
                                        <button type="button" id="cancel-story" class="btn default" data-ng-click="CancelStory()" ng-disabled="DisableButtons || (responseCounter != requestCounter)">Cancel</button>
                                    </div>
                                    <div class="col-md-12 no-padding">
                                        <div data-ng-if="StoryListArray.length > 0" class="table-scrollable sortablestory" ng-cloak>
                                            <div>
                                                <table class="table table-striped table-bordered table-hover" sortable-list="StoryListArray"  sortable-callback="updateSortOrderStory" sortable-containment='sortablestory'>
                                                    <thead class="site-footer">
                                                    <tr role="row">
                                                        <th data-ng-if="StoryListArray.length > 1"><span class="anchor_color vertical-align"></span></th>
                                                        <th class="vertical-align"><span class="anchor_color">Title</span></th>
                                                        <th class="vertical-align"><span class="anchor_color">Link</span></th>
                                                        <th class="vertical-align">Action</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody class="drag-faq-list">
                                                    <tr ng-repeat="data in StoryListArray" class="sortable-row" role="row">
                                                        <td class="sortable-handle vertical-align" data-ng-if="StoryListArray.length > 1">
                                                            <span class="draggable-icon-arrow">
                                                                <i class="fa fa-bars draggable-icon"></i>
                                                                <i class="fa fa-arrows-alt draggable-icon"></i>
                                                            </span>
                                                        </td>
                                                        <td class="vertical-align"><a ng-click="EditStory(data)" title="Edit Story" ng-model="EditStory"><div class="faq-ellipsis">@{{data.Title}}</div></a></td>
                                                        <td class="vertical-align"><div class="faq-ellipsis">@{{data.Link}}</div></td>
                                                        <td class="faq-action-part vertical-align">
                                                            <div>
                                                                <a ng-click="EditStory(data)" title="Edit Story" ng-model="EditStory"><i class="fa fa-pencil text-default" ></i></a>
                                                                &nbsp;
                                                                <a ng-click="deleteStory(data)" title="Delete Story" ng-model="DeleteStory"><i class="fa fa-trash-o text-danger"></i></a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <div class="form-group col-md-12 display-none" align="center" id="nodata">
                                            <b>Sorry, no story found</b>
                                        </div>
                                    </div>
                                </div>
                                <!-- For story section end -->
                           </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
@stop

@section('script')
    {{ $minify::javascript(array('/assets/js/viewjs/home/home.js',
                                '/assets/js/sitejs/dropzone.js',
                                '/assets/js/library/jquery.fileupload/jquery.ui.widget.js',
                                 '/assets/js/library/jquery.fileupload/jquery.fileupload.js',
                                 '/assets/js/library/binaryajax.js',
                                 '/assets/js/library/exif.js',
                                 '/assets/js/library/bootstrap-fileinput.js',
                                 '/assets/js/sitejs/canvasResize.js'))->withFullUrl()}}
    <!--For slider images upload start-->
    {{ $minify::javascript(array('/assets/js/sitejs/jquery-ui-1.9.2.custom.min.js',
                                   '/assets/js/sitejs/jquery.ui.touch-punch.min.js'))->withFullUrl()}}
    <!--For slider images upload end -->
    <!--For hover images upload start-->
    <script>
        window.ImageFileAllowedMessage ="{{ trans('messages.ImageFileAllowedMessage')}}";
        window.VideoFileAllowedMessage ="{{ trans('messages.VideoFileAllowedMessage')}}";
        window.VideoMP4FileAllowedMessage ="{{ trans('messages.VideoMP4FileAllowedMessage')}}";
        window.VideoOggFileAllowedMessage ="{{ trans('messages.VideoOggFileAllowedMessage')}}";
        window.VideoWebmFileAllowedMessage ="{{ trans('messages.VideoWebmFileAllowedMessage')}}";
        window.StoryImageRequire ="{{ trans('messages.NoteForStoryImages')}}";
        window.ConfirmUploadMessage ="{{ trans('messages.ConfirmUploadMessage')}}";
        window.HomePageVideoMaxFileSizeMessage ="{{ trans('messages.HomePageVideoMaxFileSizeMessage')}}";
        window.DefaultUploadPhotoHeight='<?php echo Constants::$DefaultUploadProfileHeight;?>';
        window.DefaultUploadPhotoWidth='<?php echo Constants::$DefaultUploadProfileWidth?>';
        window.NoImagePath = '<?php echo asset('/assets/images/Samplephoto.png') ?>';
        window.BackgroundImagesType='<?php echo Constants::$BackgroundImagesType;?>';
        window.HoverImagesType='<?php echo Constants::$HoverImagesType;?>';
        window.MVItem1ImageType='<?php echo Constants::$MVItem1ImageType;?>';
        window.MVItem2ImageType='<?php echo Constants::$MVItem2ImageType;?>';
        window.MVItem3ImageType='<?php echo Constants::$MVItem3ImageType;?>';
        window.HomeFacebookImageType='<?php echo Constants::$HomeFacebookImageType;?>';
        window.HomeTwitterImageType='<?php echo Constants::$HomeTwitterImageType;?>';
        window.HomeRichSnippetsImageType='<?php echo Constants::$HomeRichSnippetsImageType;?>';
        window.YoutubeVideoImageType='<?php echo Constants::$YoutubeVideoImageType;?>';
        window.HomeSectionSimpleType='<?php echo Constants::$HomeSectionSimpleType;?>';
        window.HomeSectionSliderType='<?php echo Constants::$HomeSectionSliderType;?>';
        window.HomePageVideoMP3Type='<?php echo Constants::$HomePageVideoMP3Type;?>';
        window.HomePageVideoOggType='<?php echo Constants::$HomePageVideoOggType;?>';
        window.HomePageVideoWebmType='<?php echo Constants::$HomePageVideoWebmType;?>';
        window.HomePageVideoMaxFileSize='<?php echo Constants::$HomePageVideoMaxFileSize;?>';
    </script>
    <!--For hover images upload end-->
@stop