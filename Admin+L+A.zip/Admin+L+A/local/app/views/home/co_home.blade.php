<?php
    use Infrastructure\Constants;
    $minify = new \CeesVanEgmond\Minify\Facades\Minify;
?>
@extends('layouts.sitemaster')
@section('Title')
    Home
@stop
@section('css')
    {{ $minify::stylesheet(array('/assets/css/dropzone/dropzone.css'))->withFullUrl()}}
@stop
@section('content')
<main id="main" role="main">
    <?php  echo Form::hidden('HomeModel',htmlspecialchars(json_encode($HomeModel), ENT_QUOTES, 'UTF-8'),$attributes = array('id'=>'HomeModel')); ?>
    <?php  echo Form::hidden('SliderModel',htmlspecialchars(json_encode($SliderModel), ENT_QUOTES, 'UTF-8'),$attributes = array('id'=>'SliderModel')); ?>
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo URL::to('/dashboard/'.$encryptedSiteID) ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Home</span>
                </li>
            </ul>
        </div>
        <h3 class="page-title">Home</h3>
        <ul class="nav nav-tabs">
            <li class="active">
                <a href="#tab_1_1" data-toggle="tab" aria-expanded="true">Home</a>
            </li>
            <li class="">
                <a href="#tab_1_2" data-toggle="tab" aria-expanded="false">Slider of CO</a>
            </li>
        </ul>
        <div class="row">
            <div class="col-md-12">
                <div class="tab-content">
                    <div class="tab-pane active" id="tab_1_1">
                        <form name="HomeForm" id="HomeForm" role="form" novalidate ng-controller = "HomeController" ng-clock ng-submit="checkSave(HomeForm)">
                            <div class="form-body" ng-cloak>
                                <div class="clearboth"></div>
                                <div class="portlet box blue-hoki" ng-cloak>
                                    <div class="portlet-title" collapse>
                                        <div class="caption">
                                            <i class=""></i>Content</div>
                                        <div class="tools">
                                            <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                        </div>
                                    </div>
                                    <div class="portlet-body">
                                        <div class="row">
                                            <div class="col-md-12 no-padding">
                                                <div class="form-body" >
                                                    <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                        <div class="form-group col-md-12 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.Content.$invalid}">
                                                            <label for="Block1Description" class="control-label">Content</label>
                                                            <textarea name="Content" data-ng-model="HomeModel.Content" ck-editor data-ng-class="{'has-submitted' : HomeForm.$submitted }" required></textarea>
                                                            <span class="error-text-color" ng-show="HomeForm.$submitted">
                                                                <span ng-show="HomeForm.Content.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Content'))}}</span>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="clearboth"></div>
                                <div class="portlet box blue-hoki" ng-cloak>
                                    <div class="portlet-title" collapse>
                                        <div class="caption">
                                            <i class=""></i>Top CTA Section</div>
                                        <div class="tools">
                                            <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                        </div>
                                    </div>
                                    <div class="portlet-body">
                                        <div class="row">
                                            <div class="col-md-12 no-padding">
                                                <div class="form-body" >
                                                    <div class="form-group col-md-12">
                                                        <input type="checkbox"  ng-model="HomeModel.ShowTopCTASection" id="ShowTopCTASection" name="ShowTopCTASection" ng-true-value="1" ng-false-value="0">
                                                        <label for="ShowTopCTASection">Show this section?</label>
                                                    </div>
                                                    <div class="col-md-12 no-padding">
                                                        <!-- Block 1 start -->
                                                        <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                            <h5 class="caption-subject form-section uppercase col-md-12">Block 1</h5>
                                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12" >
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Image" class="control-label">Block 1 Image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealTopCTAImagePath1 ? HomeModel.RealTopCTAImagePath1 : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$COHomeTopCTABlock1ImageType; ?>" name="FormImageTopBlock1" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealTopCTAImagePath1" id="file" title="Choose Image" required> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$COHomeTopCTABlock1ImageType; ?>')" ng-hide="(HomeModel.RealTopCTAImagePath1 == '' || HomeModel.RealTopCTAImagePath1 == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedTopBlockImagesFixWidth > 0 &&  AllowedTopBlockImagesFixHeight > 0)"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedTopBlockImagesFixWidth }}x@{{ AllowedTopBlockImagesFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormImageTopBlock1.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormImageTopBlock1.file.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormImageTopBlock1.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Block 1 image'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.TopCTATitle1.$invalid}">
                                                                    <label for="Title" class="control-label">Title</label>
                                                                    <input class="form-control"  type="text" name="TopCTATitle1" ng-model="HomeModel.TopCTATitle1" ng-class="{ 'has-submitted' : HomeForm.$submitted }" maxlength="100" required/>
                                                                    <div  class="help-block" ng-messages="HomeForm.TopCTATitle1.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.TopCTATitle1.$error.required  && HomeForm.TopCTATitle1.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Title'))}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-12 no-padding">
                                                                    <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.TopCTALinkText1.$invalid}">
                                                                        <label for="Link Text" class="control-label">Link Text</label>
                                                                        <input class="form-control"  type="text" name="TopCTALinkText1" ng-model="HomeModel.TopCTALinkText1" ng-class="{ 'has-submitted' : HomeForm.$submitted }" required/>
                                                                        <div  class="help-block" ng-messages="HomeForm.TopCTALinkText1.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.TopCTALinkText1.$error.required  && HomeForm.TopCTALinkText1.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link Text'))}}</div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.TopCTALinkURL1.$invalid}">
                                                                        <label for="Link URL" class="control-label">Link URL</label>
                                                                        <input class="form-control"  type="text" name="TopCTALinkURL1" ng-model="HomeModel.TopCTALinkURL1" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : HomeForm.$submitted }" required/>
                                                                        <div  class="help-block" ng-messages="HomeForm.TopCTALinkURL1.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.TopCTALinkURL1.$error.required  && HomeForm.TopCTALinkURL1.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link URL'))}}</div>
                                                                            <div  ng-show="HomeForm.TopCTALinkURL1.$error.pattern ">{{ trans('messages.InvalidLink')}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- Block 1 end -->

                                                        <!-- Block 2 start -->
                                                        <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                            <h5 class="caption-subject form-section uppercase col-md-12">Block 2</h5>
                                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12" >
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Image" class="control-label">Block 2 Image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealTopCTAImagePath2 ? HomeModel.RealTopCTAImagePath2 : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$COHomeTopCTABlock2ImageType; ?>" name="FormImageTopBlock2" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealTopCTAImagePath2" id="file" title="Choose Image" required> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$COHomeTopCTABlock2ImageType; ?>')" ng-hide="(HomeModel.RealTopCTAImagePath2 == '' || HomeModel.RealTopCTAImagePath2 == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedTopBlockImagesFixWidth > 0 &&  AllowedTopBlockImagesFixHeight > 0)"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedTopBlockImagesFixWidth }}x@{{ AllowedTopBlockImagesFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormImageTopBlock2.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormImageTopBlock2.file.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormImageTopBlock2.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Block 2 image'))}}</div>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                            <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.TopCTATitle2.$invalid}">
                                                                    <label for="Title" class="control-label">Title</label>
                                                                    <input class="form-control"  type="text" name="TopCTATitle2" ng-model="HomeModel.TopCTATitle2" ng-class="{ 'has-submitted' : HomeForm.$submitted }" maxlength="100" required/>
                                                                    <div  class="help-block" ng-messages="HomeForm.TopCTATitle2.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.TopCTATitle2.$error.required  && HomeForm.TopCTATitle2.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Title'))}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-12 no-padding">
                                                                    <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.TopCTALinkText2.$invalid}">
                                                                        <label for="Link Text" class="control-label">Link Text</label>
                                                                        <input class="form-control"  type="text" name="TopCTALinkText2" ng-model="HomeModel.TopCTALinkText2" ng-class="{ 'has-submitted' : HomeForm.$submitted }" required/>
                                                                        <div  class="help-block" ng-messages="HomeForm.TopCTALinkText2.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="HomeForm.TopCTALinkText2.$error.required  && HomeForm.TopCTALinkText2.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link Text'))}}</div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.TopCTALinkURL2.$invalid}">
                                                                        <label for="Link URL" class="control-label">Link URL</label>
                                                                        <input class="form-control"  type="text" name="TopCTALinkURL2" ng-model="HomeModel.TopCTALinkURL2" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : HomeForm.$submitted }" required/>
                                                                        <div  class="help-block" ng-messages="HomeForm.Block2URL1.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.TopCTALinkURL2.$error.required  && HomeForm.TopCTALinkURL2.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link URL'))}}</div>
                                                                            <div  ng-show="HomeForm.TopCTALinkURL2.$error.pattern ">{{ trans('messages.InvalidLink')}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- Block 2 end -->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="clearboth"></div>
                                <div class="portlet box blue-hoki" ng-cloak>
                                    <div class="portlet-title" collapse>
                                        <div class="caption">
                                            <i class=""></i>Video Section</div>
                                        <div class="tools">
                                            <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                        </div>
                                    </div>
                                    <div class="portlet-body">
                                        <div class="row">
                                            <div class="col-md-12 no-padding">
                                                <div class="form-body" >
                                                    <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                        <!-- For lending Video section end -->
                                                        <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12">
                                                            <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                                <div class="col-md-12 col-sm-12 col-xs-12 no-padding margin-bottom-15">
                                                                    <label for="Video" class="control-label">MP4 Video</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div class="video-name-ellipsis uploaded-video-name" ng-bind="HomeModel.MP4VideoName"></div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="directuploadvideo" video-type="<?php echo  Constants::$COHomeVideoMP4Type; ?>" name="FormVideoMP4" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealMP4VideoPath"  title="Choose Image" required> Choose Video</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="DeleteVideo('<?php echo  Constants::$COHomeVideoMP4Type; ?>')" ng-hide="(HomeModel.RealMP4VideoPath == '' || HomeModel.RealMP4VideoPath == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none video">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" id="videobar" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                                                                    </div>
                                                                    <div class="info-alert"><lable>Allowed extension: .mp4</lable></div>
                                                                    <div class="info-alert"><lable>Max file size: 100 MB</lable></div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormVideoMP3.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormVideoMP4.file.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormVideoMP4.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'MP4 Video'))}}</div>
                                                                        </div>
                                                                    </div>


                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12">
                                                            <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                                <div class="col-md-12 col-sm-12 col-xs-12 no-padding margin-bottom-15">
                                                                    <label for="Video" class="control-label">Ogg Video</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div class="video-name-ellipsis uploaded-video-name" ng-bind="HomeModel.OggVideoName"></div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="directuploadvideo" video-type="<?php echo  Constants::$COHomeVideoOggType; ?>" name="FormVideoOgg" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealOggVideoPath" title="Choose Image"> Choose Video</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="DeleteVideo('<?php echo Constants::$COHomeVideoOggType; ?>')" ng-hide="(HomeModel.RealOggVideoPath == '' || HomeModel.RealOggVideoPath == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none video">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" id="videobar" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                                                                    </div>
                                                                    <div class="info-alert"><lable>Allowed extension: .ogv</lable></div>
                                                                    <div class="info-alert"><lable>Max file size: 100 MB</lable></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12">
                                                            <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                                <div class="col-md-12 col-sm-12 col-xs-12 no-padding margin-bottom-15">
                                                                    <label for="Video" class="control-label">Webm Video</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div class="video-name-ellipsis uploaded-video-name" ng-bind="HomeModel.WebmVideoName"></div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="directuploadvideo" video-type="<?php echo  Constants::$COHomeVideoWebmType; ?>" name="FormVideoWebm" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealWebmVideoPath"  title="Choose Image" > Choose Video</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="DeleteVideo('<?php echo  Constants::$COHomeVideoWebmType; ?>')" ng-hide="(HomeModel.RealWebmVideoPath == '' || HomeModel.RealWebmVideoPath == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none video">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" id="videobar" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                                                                    </div>
                                                                    <div class="info-alert"><lable>Allowed extension: .webm</lable></div>
                                                                    <div class="info-alert"><lable>Max file size: 100 MB</lable></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12">
                                                            <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                                <div class="col-md-12 col-sm-12 col-xs-12 no-padding margin-bottom-15">
                                                                    <label for="Video" class="control-label">Video Poster</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealVideoPosterPath ? HomeModel.RealVideoPosterPath : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$COVideoPosterType; ?>" name="FormImageVideoPoster" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealVideoPosterPath" id="file" title="Choose Image" required> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$COVideoPosterType; ?>')" ng-hide="(HomeModel.RealVideoPosterPath == '' || HomeModel.RealVideoPosterPath == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedVideoPosterFixWidth > 0 &&  AllowedVideoPosterFixHeight > 0)"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedVideoPosterFixWidth }}x@{{ AllowedVideoPosterFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormImageVideoPoster.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormImageVideoPoster.file.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormImageVideoPoster.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Video Poster'))}}</div>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- For lending Video section end -->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="clearboth"></div>
                                <div class="portlet box blue-hoki" ng-cloak>
                                    <div class="portlet-title" collapse>
                                        <div class="caption">
                                            <i class=""></i>Bottom CTA Section</div>
                                        <div class="tools">
                                            <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                        </div>
                                    </div>
                                    <div class="portlet-body">
                                        <div class="row">
                                            <div class="col-md-12 no-padding">
                                                <div class="form-body" >
                                                    <div class="form-group col-md-12">
                                                        <input type="checkbox"  ng-model="HomeModel.ShowBottomCTASection" id="ShowBottomCTASection" name="ShowBottomCTASection" ng-true-value="1" ng-false-value="0">
                                                        <label for="ShowBottomCTASection">Show this section?</label>
                                                    </div>
                                                    <div class="col-md-12 no-padding">
                                                        <!-- Block 1 start -->
                                                        <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                            <h5 class="caption-subject form-section uppercase col-md-12">Block 1</h5>
                                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12" >
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Image" class="control-label">Block 1 Image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealBottomCTAImagePath1 ? HomeModel.RealBottomCTAImagePath1 : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$COHomeBottomCTABlock1ImageType; ?>" name="FormImageBottomBlock1" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealBottomCTAImagePath1" id="file" title="Choose Image" required> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$COHomeBottomCTABlock1ImageType; ?>')" ng-hide="(HomeModel.RealBottomCTAImagePath1 == '' || HomeModel.RealBottomCTAImagePath1 == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedBottomBlockImagesFixWidth > 0 &&  AllowedBottomBlockImagesFixHeight > 0)"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedBottomBlockImagesFixWidth }}x@{{ AllowedBottomBlockImagesFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormImageBottomBlock1.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormImageBottomBlock1.file.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormImageBottomBlock1.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Block 1 image'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.BottomCTATitle1.$invalid}">
                                                                    <label for="Title" class="control-label">Title</label>
                                                                    <input class="form-control"  type="text" name="BottomCTATitle1" ng-model="HomeModel.BottomCTATitle1" ng-class="{ 'has-submitted' : HomeForm.$submitted }" maxlength="100" required/>
                                                                    <div  class="help-block" ng-messages="HomeForm.BottomCTATitle1.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.BottomCTATitle1.$error.required  && HomeForm.BottomCTATitle1.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Title'))}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-12 no-padding">
                                                                    <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.BottomCTALinkText1.$invalid}">
                                                                        <label for="Link Text" class="control-label">Link Text</label>
                                                                        <input class="form-control"  type="text" name="BottomCTALinkText1" ng-model="HomeModel.BottomCTALinkText1" ng-class="{ 'has-submitted' : HomeForm.$submitted }" required/>
                                                                        <div  class="help-block" ng-messages="HomeForm.TopCTALinkText1.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.BottomCTALinkText1.$error.required  && HomeForm.BottomCTALinkText1.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link Text'))}}</div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.BottomCTALinkURL1.$invalid}">
                                                                        <label for="Link URL" class="control-label">Link URL</label>
                                                                        <input class="form-control"  type="text" name="BottomCTALinkURL1" ng-model="HomeModel.BottomCTALinkURL1" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : HomeForm.$submitted }" required/>
                                                                        <div  class="help-block" ng-messages="HomeForm.BottomCTALinkURL1.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.BottomCTALinkURL1.$error.required  && HomeForm.BottomCTALinkURL1.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link URL'))}}</div>
                                                                            <div  ng-show="HomeForm.BottomCTALinkURL1.$error.pattern ">{{ trans('messages.InvalidLink')}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- Block 1 end -->

                                                        <!-- Block 2 start -->
                                                        <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                            <h5 class="caption-subject form-section uppercase col-md-12">Block 2</h5>
                                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12" >
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Image" class="control-label">Block 2 Image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealBottomCTAImagePath2 ? HomeModel.RealBottomCTAImagePath2 : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$COHomeBottomCTABlock2ImageType; ?>" name="FormImageBottomBlock2" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealBottomCTAImagePath2" id="file" title="Choose Image" required> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$COHomeBottomCTABlock2ImageType; ?>')" ng-hide="(HomeModel.RealBottomCTAImagePath2 == '' || HomeModel.RealBottomCTAImagePath2 == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedBottomBlockImagesFixWidth > 0 &&  AllowedBottomBlockImagesFixHeight > 0)"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedBottomBlockImagesFixWidth }}x@{{ AllowedBottomBlockImagesFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormImageBottomBlock2.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormImageBottomBlock2.file.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormImageBottomBlock2.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Block 2 image'))}}</div>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                            <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.BottomCTATitle2.$invalid}">
                                                                    <label for="Title" class="control-label">Title</label>
                                                                    <input class="form-control"  type="text" name="BottomCTATitle2" ng-model="HomeModel.BottomCTATitle2" ng-class="{ 'has-submitted' : HomeForm.$submitted }" maxlength="100" required/>
                                                                    <div  class="help-block" ng-messages="HomeForm.BottomCTATitle2.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.BottomCTATitle2.$error.required  && HomeForm.BottomCTATitle2.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Title'))}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-12 no-padding">
                                                                    <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.BottomCTALinkText2.$invalid}">
                                                                        <label for="Link Text" class="control-label">Link Text</label>
                                                                        <input class="form-control"  type="text" name="BottomCTALinkText2" ng-model="HomeModel.BottomCTALinkText2" ng-class="{ 'has-submitted' : HomeForm.$submitted }" required/>
                                                                        <div  class="help-block" ng-messages="HomeForm.BottomCTALinkText2.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="HomeForm.BottomCTALinkText2.$error.required  && HomeForm.BottomCTALinkText2.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link Text'))}}</div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.BottomCTALinkURL2.$invalid}">
                                                                        <label for="Link URL" class="control-label">Link URL</label>
                                                                        <input class="form-control"  type="text" name="BottomCTALinkURL2" ng-model="HomeModel.BottomCTALinkURL2" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : HomeForm.$submitted }" required/>
                                                                        <div  class="help-block" ng-messages="HomeForm.BottomCTALinkURL2.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.BottomCTALinkURL2.$error.required  && HomeForm.BottomCTALinkURL2.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link URL'))}}</div>
                                                                            <div  ng-show="HomeForm.BottomCTALinkURL2.$error.pattern ">{{ trans('messages.InvalidLink')}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- Block 2 end -->

                                                        <!-- Block 3 start -->
                                                        <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                            <h5 class="caption-subject form-section uppercase col-md-12">Block 3</h5>
                                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12" >
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Image" class="control-label">Block 3 Image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealBottomCTAImagePath3 ? HomeModel.RealBottomCTAImagePath3 : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$COHomeBottomCTABlock3ImageType; ?>" name="FormImageBottomBlock3" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealBottomCTAImagePath3" id="file" title="Choose Image" required> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$COHomeBottomCTABlock3ImageType; ?>')" ng-hide="(HomeModel.RealBottomCTAImagePath3 == '' || HomeModel.RealBottomCTAImagePath3 == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedBottomBlockImagesFixWidth > 0 &&  AllowedBottomBlockImagesFixHeight > 0)"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedBottomBlockImagesFixWidth }}x@{{ AllowedBottomBlockImagesFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormImageBottomBlock3.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormImageBottomBlock3.file.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormImageBottomBlock3.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Block 3 image'))}}</div>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                            <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.BottomCTATitle3.$invalid}">
                                                                    <label for="Title" class="control-label">Title</label>
                                                                    <input class="form-control"  type="text" name="BottomCTATitle3" ng-model="HomeModel.BottomCTATitle3" ng-class="{ 'has-submitted' : HomeForm.$submitted }" maxlength="100" required/>
                                                                    <div  class="help-block" ng-messages="HomeForm.BottomCTATitle3.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.BottomCTATitle3.$error.required  && HomeForm.BottomCTATitle3.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Title'))}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-12 no-padding">
                                                                    <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.BottomCTALinkText3.$invalid}">
                                                                        <label for="Link Text" class="control-label">Link Text</label>
                                                                        <input class="form-control"  type="text" name="BottomCTALinkText3" ng-model="HomeModel.BottomCTALinkText3" ng-class="{ 'has-submitted' : HomeForm.$submitted }" required/>
                                                                        <div  class="help-block" ng-messages="HomeForm.BottomCTALinkText3.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="HomeForm.BottomCTALinkText3.$error.required  && HomeForm.BottomCTALinkText3.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link Text'))}}</div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.BottomCTALinkURL3.$invalid}">
                                                                        <label for="Link URL" class="control-label">Link URL</label>
                                                                        <input class="form-control"  type="text" name="BottomCTALinkURL3" ng-model="HomeModel.BottomCTALinkURL3" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : HomeForm.$submitted }" required/>
                                                                        <div  class="help-block" ng-messages="HomeForm.Block2URL1.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.BottomCTALinkURL3.$error.required  && HomeForm.BottomCTALinkURL3.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link URL'))}}</div>
                                                                            <div  ng-show="HomeForm.BottomCTALinkURL3.$error.pattern ">{{ trans('messages.InvalidLink')}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- Block 2 end -->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="clearboth"></div>
                                <div class="portlet box blue-hoki" ng-cloak>
                                    <div class="portlet-title" collapse="true">
                                        <div class="caption">
                                            <i class=""></i>SEO</div>
                                        <div class="tools">
                                            <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                        </div>
                                    </div>
                                    <div class="portlet-body ">
                                        <div class="row">
                                            <div class="form-body" ng-cloak>
                                                <div class="col-md-12 no-padding">
                                                    <div class="col-md-12 no-padding">
                                                        <div class="col-md-9  no-padding">
                                                            <div class="form-group col-md-6 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.BrowserTitle.$invalid}">
                                                                <label for="BrowserTitle" class="control-label">Browser Title</label>
                                                                <input class="form-control"  type="text" name="BrowserTitle"  maxlength="200" data-ng-model="HomeModel.BrowserTitle" data-ng-class="{'has-submitted' : HomeForm.$submitted }" required/>
                                                                <span class="error-text-color" ng-show="HomeForm.$submitted">
                                                                    <span ng-show="HomeForm.BrowserTitle.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Browser Title'))}}</span>
                                                                </span>
                                                            </div>
                                                            <div class="form-group col-md-6 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.CanonicalURL.$invalid}">
                                                                <label class="control-label">Canonical URL</label>
                                                                <input class="form-control"  type="text" name="CanonicalURL" ng-model="HomeModel.CanonicalURL" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>" maxlength="200" required/>
                                                                <span class="error-text-color" ng-show="HomeForm.$submitted">
                                                                        <span ng-show="HomeForm.CanonicalURL.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'CanonicalURL'))}}</span>
                                                                        <span ng-show="HomeForm.CanonicalURL.$error.pattern">{{ trans('messages.InvalidCanonicalUrl') }}</span>
                                                                </span>
                                                            </div>
                                                            <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                <label for="MetaDescription" class="control-label">Meta-Description</label>
                                                                <textarea rows="6" class="form-control" name="MetaDescription" data-ng-model="HomeModel.MetaDescription"></textarea>
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-md-12 col-sm-12 col-xs-12 no-padding margin-top-15"><hr class="hr-section margin-top-15"></div>
                                                        <div class="col-md-12 no-padding ">
                                                            <div class="form-group col-md-12 col-sm-12 col-xs-12 rich-margin">
                                                                <h3 class="page-title font-size19px">Facebook</h3>
                                                            </div>
                                                            <div class="form-group col-md-8 col-lg-9 col-sm-12 col-xs-12  no-padding">
                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                    <label for="FBTitle" class="control-label">Facebook Title</label>
                                                                    <input class="form-control" type="text" name="FBTitle"  maxlength="200" data-ng-model="HomeModel.FBTitle"/>
                                                                </div>
                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                    <label for="FBDescription" class="control-label">Facebook-Description</label>
                                                                    <textarea rows="6" class="form-control" name="FBDescription" data-ng-model="HomeModel.FBDescription"></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12">
                                                                <label for="FBImage" class="control-label">Facebook Image</label>
                                                            </div>
                                                            <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12 margin-top1pr">
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealFacebookImagePath ? HomeModel.RealFacebookImagePath : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$COHomeFacebookImageType; ?>" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealFacebookImagePath" id="file" title="Choose Image" > Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$COHomeFacebookImageType; ?>')" ng-hide="(HomeModel.RealFacebookImagePath == '' || HomeModel.RealFacebookImagePath == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                     </div>
                                                    <div class="form-group col-md-12 col-sm-12 col-xs-12 no-padding"><hr class="hr-section"></div>
                                                    <div class="col-md-12 no-padding">
                                                        <div class="form-group col-md-12 col-sm-12 col-xs-12 rich-margin">
                                                            <h3 class="page-title font-size19px">Twitter</h3>
                                                        </div>
                                                        <div class="form-group col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                            <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                <label for="TwitterCard" class="control-label">Twitter Card</label>
                                                                <input class="form-control" type="text" name="TwitterCard"  maxlength="50" data-ng-model="HomeModel.TwitterCard" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"/>
                                                            </div>
                                                            <div class="form-group col-md-6 col-sm-12 col-xs-12">
                                                                <label for="TwitterSite" class="control-label">Twitter Site</label>
                                                                <input class="form-control"  type="text" name="TwitterSite"  maxlength="200" data-ng-model="HomeModel.TwitterSite" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"/>
                                                            </div>
                                                            <div class="form-group col-md-6 col-sm-12 col-xs-12">
                                                                <label for="TwitterTitle" class="control-label">Twitter Title</label>
                                                                <input class="form-control"  type="text" name="TwitterTitle"  maxlength="200" data-ng-model="HomeModel.TwitterTitle" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"/>
                                                            </div>
                                                            <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                <label for="TwitterDescription" class="control-label">Twitter-Description</label>
                                                                <textarea rows="6" class="form-control" name="TwitterDescription" data-ng-model="HomeModel.TwitterDescription" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"></textarea>
                                                            </div>

                                                        </div>
                                                        <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12">
                                                            <label for="TwitterImage" class="control-label">Twitter Image</label>
                                                        </div>
                                                        <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12 margin-top1pr">
                                                            <div class="fileinput fileinput-new">
                                                                <div  class="fileinput-new thumbnail image-box">
                                                                    <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                    <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealTwitterImagePath ? HomeModel.RealTwitterImagePath : HomeModel.NoImagePath}}">
                                                                </div>
                                                                <div>
                                                                    <form></form>
                                                                    <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$COHomeTwitterImageType; ?>" role="form" novalidate>
                                                                        <input type="hidden" id="key" name="key" value="">
                                                                        <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                        <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                        <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                        <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                        <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                        <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                        <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealTwitterImagePath" id="file" title="Choose Image" > Choose Image</span>
                                                                        <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$COHomeTwitterImageType; ?>')" ng-hide="(HomeModel.RealTwitterImagePath == '' || HomeModel.RealTwitterImagePath == null)"> Remove </a>
                                                                        <span></span>
                                                                    </form>
                                                                </div>
                                                                <span>&nbsp;</span>
                                                                <div class="progress progress-striped display-none background">
                                                                    <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-md-12 col-sm-12 col-xs-12 no-padding"><hr class="hr-section"></div>
                                                    <div class="form-group col-md-12 col-sm-12 col-xs-12 rich-margin">
                                                        <h3 class="page-title font-size19px">Rich Snippets</h3>
                                                    </div>
                                                    <div class="col-md-12  no-padding">
                                                        <div class="col-md-12  no-padding">
                                                            <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                    <label for="Headline" class="control-label">Headline</label>
                                                                    <input class="form-control"  type="text" name="Headline"  maxlength="200" data-ng-model="HomeModel.Headline" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"/>
                                                                </div>
                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                    <label for="TwitterDescription" class="control-label">Description</label>
                                                                    <textarea rows="6" class="form-control" name="Description" data-ng-model="HomeModel.Description" ng-disabled="PageModel.ViewPage==0 && PageModel.CanEditSEOFields==0"></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12">
                                                                <label for="TwitterImage" class="control-label">Image Upload</label>
                                                            </div>
                                                            <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12 margin-top1pr">
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealRichSnippetImagePath ? HomeModel.RealRichSnippetImagePath : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$COHomeRichSnippetsImageType; ?>" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealRichSnippetImagePath" id="file" title="Choose Image" > Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$COHomeRichSnippetsImageType; ?>')" ng-hide="(HomeModel.RealRichSnippetImagePath == '' || HomeModel.RealRichSnippetImagePath == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                    <input id="submit-home" name="submit" type="submit" value="Save" class="btn blue save-button" data-ng-click="SaveHome()" ng-disabled="(DisableButtons || requestCounter != responseCounter)">
                                    <button type="button" id="cancel-home" class="btn default" data-ng-click="Cancel()" ng-disabled="(DisableButtons || requestCounter != responseCounter)">Cancel</button>
                                </div>

                            </div>
                        </form>
                    </div>
                    <div class="tab-pane fade" id="tab_1_2">
                        <form name="SliderForm" id="SliderForm" role="form" novalidate ng-controller = "SliderController" ng-clock ng-submit="checkSaveSlider(SliderForm)">
                            <div class="form-body">
                                <div class="clearboth"></div>
                                <!-- For Slider section start -->
                                <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                    <div class="clearboth"></div>
                                    <div class="portlet box blue-hoki" ng-cloak>
                                        <div class="portlet-title" collapse>
                                            <div class="caption">
                                                <i class=""></i>Details</div>
                                            <div class="tools">
                                                <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                            </div>
                                        </div>
                                        <div class="portlet-body">
                                            <div class="row">
                                                <div class="col-md-12 no-padding">
                                                    <div class="form-body" >
                                                        <div class="col-md-12 no-padding">
                                                            <h3 class="caption-subject form-section uppercase col-md-12">@{{ SliderModel.Slider.HomePageSliderID > 0 ? 'Edit Slider' : 'Add Slider' }}</h3>
                                                            <!-- For Slider image upload section start -->
                                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12 visible-sm visible-xs">
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Slider image" class="control-label">Slider image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new" ng-clock>
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src="@{{ SliderModel.Slider.RealBackgroundImagePath ? SliderModel.Slider.RealBackgroundImagePath : SliderModel.NoImagePath }}" ng-clock>
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload-slider" name="FormSliderImage" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="SliderModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="acl"  ng-value="SliderModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="success_action_status"  ng-value="SliderModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="policy"  ng-value="SliderModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="SliderModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="SliderModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="SliderModel.Slider.RealBackgroundImagePath" id="file" title="Choose Image" required> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage()" ng-hide="(SliderModel.Slider.RealBackgroundImagePath == '' || SliderModel.Slider.RealBackgroundImagePath == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedSliderFixHeight > 0 ) && (AllowedSliderFixWidth > 0 )"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedSliderFixWidth }}x@{{ AllowedSliderFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (SliderForm.$submitted) && FormSliderImage.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormSliderImage.file.$error" ng-if="SliderForm.$submitted">
                                                                            <div ng-show="FormSliderImage.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Slider images'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- For Slider image upload section end -->
                                                            <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                                <div class="form-group col-md-12 ">
                                                                    <label class="control-label margin-right-10">Text Color:</label>
                                                                    <label class="margin-right-10"><input type="radio" id="IsLight" ng-model="SliderModel.Slider.IsLight" name="IsLight" value="0"/>  Dark</label>
                                                                    <label><input type="radio" id="IsLight" ng-model="SliderModel.Slider.IsLight" name="IsLight"  value="1"/> Light</label>
                                                                </div>

                                                                <div class="form-group col-md-12 " ng-class="{ 'has-error' : (SliderForm.$submitted) && SliderForm.Header.$invalid}">
                                                                    <label for="Header" class="control-label">Header</label>
                                                                    <input class="form-control" type="text" name="Header" ng-model="SliderModel.Slider.Header" id="Header" maxlength="90"/>
                                                                </div>
                                                            </div>
                                                            <!-- For Slider image upload section start -->
                                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12 hidden-sm hidden-xs">
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Slider image" class="control-label">Slider image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new" ng-clock>
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src="@{{ SliderModel.Slider.RealBackgroundImagePath ? SliderModel.Slider.RealBackgroundImagePath : SliderModel.NoImagePath }}" ng-clock>
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload-slider" name="FormSliderImage" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="SliderModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="acl"  ng-value="SliderModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="success_action_status"  ng-value="SliderModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="policy"  ng-value="SliderModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="SliderModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="SliderModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="SliderModel.Slider.RealBackgroundImagePath" id="file" title="Choose Image" required> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage()" ng-hide="(SliderModel.Slider.RealBackgroundImagePath == '' || SliderModel.Slider.RealBackgroundImagePath == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedSliderFixHeight > 0 ) && (AllowedSliderFixWidth > 0 )"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedSliderFixWidth }}x@{{ AllowedSliderFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (SliderForm.$submitted) && FormSliderImage.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormSliderImage.file.$error" ng-if="SliderForm.$submitted">
                                                                            <div ng-show="FormSliderImage.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Slider images'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- For Slider image upload section end -->
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- For Slider File Upload End -->

                                    <div class="form-actions  col-md-12 no-padding">
                                        <input id="submit-slider" name="submit" type="submit" value="Save" class="btn blue save-button" data-ng-click="SaveSlider()" ng-disabled="DisableButtons">
                                        <button type="button" id="cancel-slider" class="btn default" data-ng-click="CancelSlider()" ng-disabled="DisableButtons">Cancel</button>
                                    </div>
                                    <!-- Slider list start -->
                                    <div class="col-md-12 no-padding">
                                        <div data-ng-if="SliderListArray.length > 0" class="table-scrollable sortablestory" ng-cloak>
                                            <div>
                                                <table class="table table-striped table-bordered table-hover" sortable-list="SliderListArray"  sortable-callback="updateSortOrderSlider" sortable-containment='sortablestory'>
                                                    <thead class="site-footer">
                                                    <tr role="row">
                                                        <th data-ng-if="SliderListArray.length > 1"><span class="anchor_color vertical-align"></span></th>
                                                        <th class="vertical-align home-slider-dp-width"><span class="anchor_color">Slider</span></th>
                                                        <th class="vertical-align"><span class="anchor_color">Header</span></th>
                                                        <th class="vertical-align">Action</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody class="drag-faq-list">
                                                    <tr ng-repeat="data in SliderListArray" class="sortable-row" role="row">
                                                        <td class="sortable-handle vertical-align" data-ng-if="SliderListArray.length > 1">
                                                            <span class="draggable-icon-arrow">
                                                                <i class="fa fa-bars draggable-icon"></i>
                                                                <i class="fa fa-arrows-alt draggable-icon"></i>
                                                            </span>
                                                        </td>
                                                        <td class="vertical-align"><img src="@{{data.RealBackgroundImagePath ? data.RealBackgroundImagePath : SliderModel.NoImagePath}}" class="homepage-sm-img" width="70px" height="70px"></td>
                                                        <td class="vertical-align"><a ng-click="EditSlider(data)" title="Edit Slider" ng-model="EditSlider"><div class="faq-ellipsis">@{{data.Header}}</div></a></td>
                                                        <td class="faq-action-part vertical-align">
                                                            <div>
                                                                <a ng-click="EditSlider(data)" title="Edit Slider" ng-model="EditSlider"><i class="fa fa-pencil text-default" ></i></a>
                                                                &nbsp;
                                                                <a ng-click="DeleteSlider(data)" title="Delete Slider" ng-model="DeleteSlider"><i class="fa fa-trash-o text-danger"></i></a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <div class="form-group col-md-12 display-none" align="center" id="nodata">
                                            <b>Sorry, no slider found</b>
                                        </div>
                                    </div>
                                    <!-- Slider list end -->
                                </div>
                                <!-- For Slider section end -->
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
@stop

@section('script')
    {{ $minify::javascript(array('/assets/js/viewjs/home/co_home.js'))->withFullUrl()}}
    {{ $minify::javascript(array('/assets/js/sitejs/dropzone.js',
                                     '/assets/js/library/jquery.fileupload/jquery.ui.widget.js',
                                     '/assets/js/library/jquery.fileupload/jquery.fileupload.js',
                                     '/assets/js/library/binaryajax.js',
                                     '/assets/js/library/exif.js',
                                     '/assets/js/library/bootstrap-fileinput.js',
                                     '/assets/js/sitejs/canvasResize.js'))->withFullUrl()}}
    <script src="{{asset('/assets/js/ckeditor/ckeditor.js')}}" ></script>
    <!--For slider images upload start-->
    {{ $minify::javascript(array('/assets/js/sitejs/jquery-ui-1.9.2.custom.min.js',
                                   '/assets/js/sitejs/jquery.ui.touch-punch.min.js'))->withFullUrl()}}

    <script>
        window.ImageFileAllowedMessage ="{{ trans('messages.ImageFileAllowedMessage')}}";
        window.VideoMP4FileAllowedMessage ="{{ trans('messages.VideoMP4FileAllowedMessage')}}";
        window.VideoOggFileAllowedMessage ="{{ trans('messages.VideoOggFileAllowedMessage')}}";
        window.VideoWebmFileAllowedMessage ="{{ trans('messages.VideoWebmFileAllowedMessage')}}";
        window.NoImagePath = '<?php echo asset('/assets/images/Samplephoto.png') ?>';
        window.COHomeTopCTABlock1ImageType='<?php echo Constants::$COHomeTopCTABlock1ImageType;?>';
        window.COHomeTopCTABlock2ImageType='<?php echo Constants::$COHomeTopCTABlock2ImageType;?>';
        window.COHomeBottomCTABlock1ImageType='<?php echo Constants::$COHomeBottomCTABlock1ImageType;?>';
        window.COHomeBottomCTABlock2ImageType='<?php echo Constants::$COHomeBottomCTABlock2ImageType;?>';
        window.COHomeBottomCTABlock3ImageType='<?php echo Constants::$COHomeBottomCTABlock3ImageType;?>';
        window.COHomeFacebookImageType='<?php echo Constants::$COHomeFacebookImageType;?>';
        window.COHomeTwitterImageType='<?php echo Constants::$COHomeTwitterImageType;?>';
        window.COHomeRichSnippetsImageType='<?php echo Constants::$COHomeRichSnippetsImageType;?>';
        window.COHomeVideoMP4Type='<?php echo Constants::$COHomeVideoMP4Type;?>';
        window.COHomeVideoOggType='<?php echo Constants::$COHomeVideoOggType;?>';
        window.COHomeVideoWebmType='<?php echo Constants::$COHomeVideoWebmType;?>';
        window.COVideoPosterType='<?php echo Constants::$COVideoPosterType;?>';
    </script>
@stop