<?php
    use Infrastructure\Constants;
    $minify = new \CeesVanEgmond\Minify\Facades\Minify;
?>

@extends('layouts.sitemaster')
@section('Title')
    Home
@stop
@section('css')
    {{ $minify::stylesheet(array('/assets/css/dropzone/dropzone.css'))->withFullUrl()}}
@stop
@section('content')
<main id="main" role="main">
    <?php  echo Form::hidden('HomeModel',htmlspecialchars(json_encode($HomeModel), ENT_QUOTES, 'UTF-8'),$attributes = array('id'=>'HomeModel')); ?>
    <?php  echo Form::hidden('SliderModel',htmlspecialchars(json_encode($SliderModel), ENT_QUOTES, 'UTF-8'),$attributes = array('id'=>'SliderModel')); ?>
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo URL::to('/dashboard/'.$encryptedSiteID) ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Home</span>
                </li>
            </ul>
        </div>
        <h3 class="page-title">Home</h3>
        <ul class="nav nav-tabs">
            <li class="active">
                <a href="#tab_1_1" data-toggle="tab" aria-expanded="true">Home</a>
            </li>
            <li class="">
                <a href="#tab_1_2" data-toggle="tab" aria-expanded="false">Slider of RD</a>
            </li>
        </ul>
        <div class="row">
            <div class="col-md-12">
                <div class="tab-content">
                    <div class="tab-pane active" id="tab_1_1">
                        <form name="HomeForm" id="HomeForm" role="form" novalidate ng-controller = "HomeController" ng-clock ng-submit="checkSave(HomeForm)">
                            <div class="form-body" ng-cloak>
                                <div class="clearboth"></div>
                                <div class="portlet box blue-hoki" ng-cloak>
                                    <div class="portlet-title" collapse>
                                        <div class="caption">
                                            <i class=""></i>CTA Section</div>
                                        <div class="tools">
                                            <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                        </div>
                                    </div>
                                    <div class="portlet-body">
                                        <div class="row">
                                            <div class="col-md-12 no-padding">
                                                <div class="form-body" >
                                                    <div class="col-md-12 no-padding">
                                                        <!-- Block 1 start -->
                                                        <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                            <h5 class="caption-subject form-section uppercase col-md-12">Block 1</h5>
                                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12" >
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Image" class="control-label">Block 1 Image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealBlock1ImagePath ? HomeModel.RealBlock1ImagePath : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$RDHomeBlock1ImageType; ?>" name="FormImageBlock1" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealBlock1ImagePath" id="file" title="Choose Image" required> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$RDHomeBlock1ImageType; ?>')" ng-hide="(HomeModel.RealBlock1ImagePath == '' || HomeModel.RealBlock1ImagePath == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedBlock1ImagesFixWidth > 0 &&  AllowedBlock1ImagesFixHeight > 0)"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedBlock1ImagesFixWidth }}x@{{ AllowedBlock1ImagesFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormImageBlock1.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormImageBlock1.file.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormImageBlock1.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Block 1 image'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.Block1Title.$invalid}">
                                                                    <label for="Title" class="control-label">Title</label>
                                                                    <input class="form-control"  type="text" name="Block1Title" ng-model="HomeModel.Block1Title" ng-class="{ 'has-submitted' : HomeForm.$submitted }" maxlength="100" required/>
                                                                    <div  class="help-block" ng-messages="HomeForm.Block1Title.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.Block1Title.$error.required  && HomeForm.Block1Title.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Title'))}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-12 no-padding">
                                                                    <div class="form-group col-md-6" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.Block1LinkText1.$invalid}">
                                                                        <label for="Link 1 Text" class="control-label">Link 1 Text</label>
                                                                        <input class="form-control"  type="text" name="Block1LinkText1" ng-model="HomeModel.Block1LinkText1" ng-class="{ 'has-submitted' : HomeForm.$submitted }" required/>
                                                                        <div  class="help-block" ng-messages="HomeForm.Block1LinkText1.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.Block1LinkText1.$error.required  && HomeForm.Block1LinkText1.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link 1 Text'))}}</div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group col-md-6" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.Block1URL1.$invalid}">
                                                                        <label for="Link 1 URL" class="control-label">Link 1 URL</label>
                                                                        <input class="form-control"  type="text" name="Block1URL1" ng-model="HomeModel.Block1URL1" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : HomeForm.$submitted }" required/>
                                                                        <div  class="help-block" ng-messages="HomeForm.Block1URL1.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.Block1URL1.$error.required  && HomeForm.Block1URL1.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link 1 URL'))}}</div>
                                                                            <div  ng-show="HomeForm.Block1URL1.$error.pattern ">{{ trans('messages.InvalidLink')}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-12 no-padding">
                                                                    <div class="form-group col-md-6" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.Block1LinkText2.$invalid}">
                                                                        <label for="Link 2 Text" class="control-label">Link 2 Text</label>
                                                                        <input class="form-control"  type="text" name="Block1LinkText2" ng-model="HomeModel.Block1LinkText2" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="!(HomeModel.Block1URL2 == '' || HomeModel.Block1URL2 == null)"/>
                                                                        <div  class="help-block" ng-messages="HomeForm.Block1LinkText2.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.Block1LinkText2.$error.required  && HomeForm.Block1LinkText2.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link 2 Text'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group col-md-6" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.Block1URL2.$invalid}">
                                                                        <label for="Link 2 URL" class="control-label">Link 2 URL</label>
                                                                        <input class="form-control"  type="text" name="Block1URL2" ng-model="HomeModel.Block1URL2" pattern="<?php echo \Infrastructure\Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : HomeForm.$submitted }" ng-required="!(HomeModel.Block1LinkText2 == '' || HomeModel.Block1LinkText2 == null)"/>
                                                                        <div  class="help-block" ng-messages="HomeForm.Block1URL2.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.Block1URL2.$error.required  && HomeForm.Block1URL2.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link'))}}</div>
                                                                            <div  ng-show="HomeForm.Block1URL2.$error.pattern ">{{ trans('messages.InvalidLink')}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.Block1Description.$invalid}">
                                                                    <label for="Block1Description" class="control-label">Description</label>
                                                                    <textarea name="Block1Description" data-ng-model="HomeModel.Block1Description" ck-editor data-ng-class="{'has-submitted' : HomeForm.$submitted }" required></textarea>
                                                                    <span class="error-text-color" ng-show="HomeForm.$submitted">
                                                                        <span ng-show="HomeForm.Block1Description.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Description'))}}</span>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- Block 1 end -->

                                                        <!-- Block 2 start -->
                                                        <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                            <h5 class="caption-subject form-section uppercase col-md-12">Block 2</h5>
                                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12" >
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Image" class="control-label">Block 2 Image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealBlock2ImagePath ? HomeModel.RealBlock2ImagePath : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$RDHomeBlock2ImageType; ?>" name="FormImageBlock2" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealBlock2ImagePath" id="file" title="Choose Image" required> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$RDHomeBlock2ImageType; ?>')" ng-hide="(HomeModel.RealBlock2ImagePath == '' || HomeModel.RealBlock2ImagePath == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedBlock2ImagesFixWidth > 0 &&  AllowedBlock2ImagesFixHeight > 0)"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedBlock2ImagesFixWidth }}x@{{ AllowedBlock2ImagesFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormImageBlock2.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormImageBlock2.file.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormImageBlock2.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Block 2 image'))}}</div>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                            <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.Block2Title.$invalid}">
                                                                    <label for="Title" class="control-label">Title</label>
                                                                    <input class="form-control"  type="text" name="Block2Title" ng-model="HomeModel.Block2Title" ng-class="{ 'has-submitted' : HomeForm.$submitted }" maxlength="100" required/>
                                                                    <div  class="help-block" ng-messages="HomeForm.Block2Title.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.Block2Title.$error.required  && HomeForm.Block2Title.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Title'))}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-12 no-padding">
                                                                    <div class="form-group col-md-6" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.Block2LinkText1.$invalid}">
                                                                        <label for="Link 1 Text" class="control-label">Link 1 Text</label>
                                                                        <input class="form-control"  type="text" name="Block2LinkText1" ng-model="HomeModel.Block2LinkText1" ng-class="{ 'has-submitted' : HomeForm.$submitted }" required/>
                                                                        <div  class="help-block" ng-messages="HomeForm.Block2LinkText1.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="HomeForm.Block2LinkText1.$error.required  && HomeForm.Block2LinkText1.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link 2 Text'))}}</div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group col-md-6" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.Block2URL1.$invalid}">
                                                                        <label for="Link 1 URL" class="control-label">Link 1 URL</label>
                                                                        <input class="form-control"  type="text" name="Block2URL1" ng-model="HomeModel.Block2URL1" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : HomeForm.$submitted }" required/>
                                                                        <div  class="help-block" ng-messages="HomeForm.Block2URL1.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.Block2URL1.$error.required  && HomeForm.Block2URL1.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link 1 URL'))}}</div>
                                                                            <div  ng-show="HomeForm.Block2URL1.$error.pattern ">{{ trans('messages.InvalidLink')}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.Block2Description.$invalid}">
                                                                    <label for="Block2Description" class="control-label">Description</label>
                                                                    <textarea name="Block2Description" data-ng-model="HomeModel.Block2Description" ck-editor data-ng-class="{'has-submitted' : HomeForm.$submitted }" required></textarea>
                                                                    <span class="error-text-color" ng-show="HomeForm.$submitted">
                                                                        <span ng-show="HomeForm.Block2Description.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Description'))}}</span>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- Block 2 end -->

                                                        <!-- Block 3 start -->
                                                        <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                                            <h5 class="caption-subject form-section uppercase col-md-12">Block 3</h5>
                                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12" >
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Image" class="control-label">Block 3 Image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealBlock3ImagePath ? HomeModel.RealBlock3ImagePath : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$RDHomeBlock3ImageType; ?>" name="FormImageBlock3" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealBlock3ImagePath" id="file" title="Choose Image" required> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$RDHomeBlock3ImageType; ?>')" ng-hide="(HomeModel.RealBlock3ImagePath == '' || HomeModel.RealBlock3ImagePath == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedBlock3ImagesFixWidth > 0 &&  AllowedBlock3ImagesFixHeight > 0)"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedBlock3ImagesFixWidth }}x@{{ AllowedBlock3ImagesFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (HomeForm.$submitted) && FormImageBlock1.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormImageBlock3.file.$error" ng-if="HomeForm.$submitted">
                                                                            <div ng-show="FormImageBlock3.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Block 1 image'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.Block3Title.$invalid}">
                                                                    <label for="Title" class="control-label">Title</label>
                                                                    <input class="form-control"  type="text" name="Block3Title" ng-model="HomeModel.Block3Title" ng-class="{ 'has-submitted' : HomeForm.$submitted }" maxlength="100" required/>
                                                                    <div  class="help-block" ng-messages="HomeForm.Block3Title.$error" ng-if="HomeForm.$submitted">
                                                                        <div  ng-show="HomeForm.Block3Title.$error.required  && HomeForm.Block3Title.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Title'))}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-12 no-padding">
                                                                    <div class="form-group col-md-6" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.Block3LinkText1.$invalid}">
                                                                        <label for="Link 1 Text" class="control-label">Link 1 Text</label>
                                                                        <input class="form-control"  type="text" name="Block3LinkText1" ng-model="HomeModel.Block3LinkText1" ng-class="{ 'has-submitted' : HomeForm.$submitted }" required/>
                                                                        <div  class="help-block" ng-messages="HomeForm.Block3LinkText1.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.Block3LinkText1.$error.required  && HomeForm.Block3LinkText1.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link 1 Text'))}}</div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group col-md-6" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.Block3URL1.$invalid}">
                                                                        <label for="Link 1 URL" class="control-label">Link 1 URL</label>
                                                                        <input class="form-control"  type="text" name="Block3URL1" ng-model="HomeModel.Block3URL1" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : HomeForm.$submitted }" required/>
                                                                        <div  class="help-block" ng-messages="HomeForm.Block3URL1.$error" ng-if="HomeForm.$submitted">
                                                                            <div  ng-show="HomeForm.Block3URL1.$error.required  && HomeForm.Block3URL1.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link 1 URL'))}}</div>
                                                                            <div  ng-show="HomeForm.Block3URL1.$error.pattern ">{{ trans('messages.InvalidLink')}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.Block3Description.$invalid}">
                                                                    <label for="Block3Description" class="control-label">Description</label>
                                                                    <textarea name="Block3Description" data-ng-model="HomeModel.Block3Description" ck-editor data-ng-class="{'has-submitted' : HomeForm.$submitted }" required></textarea>
                                                                    <span class="error-text-color" ng-show="HomeForm.$submitted">
                                                                        <span ng-show="HomeForm.Block3Description.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Description'))}}</span>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- Block 3 end -->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Testing -->
                                <div class="clearboth"></div>
                                <div class="portlet box blue-hoki" ng-cloak>
                                    <div class="portlet-title" collapse="true">
                                        <div class="caption">
                                            <i class=""></i>SEO</div>
                                        <div class="tools">
                                            <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                        </div>
                                    </div>
                                    <div class="portlet-body ">
                                        <div class="row">
                                            <div class="form-body" ng-cloak>
                                                <div class="col-md-12 no-padding">
                                                    <div class="col-md-12 no-padding">
                                                        <div class="col-md-9  no-padding">
                                                            <div class="form-group col-md-6 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.BrowserTitle.$invalid}">
                                                                <label for="BrowserTitle" class="control-label">Browser Title</label>
                                                                <input class="form-control"  type="text" name="BrowserTitle"  maxlength="200" data-ng-model="HomeModel.BrowserTitle" data-ng-class="{'has-submitted' : HomeForm.$submitted }" required/>
                                                                <span class="error-text-color" ng-show="HomeForm.$submitted">
                                                                    <span ng-show="HomeForm.BrowserTitle.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Browser Title'))}}</span>
                                                                </span>
                                                            </div>
                                                            <div class="form-group col-md-6 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (HomeForm.$submitted) && HomeForm.CanonicalURL.$invalid}">
                                                                <label class="control-label">Canonical URL</label>
                                                                <input class="form-control"  type="text" name="CanonicalURL" ng-model="HomeModel.CanonicalURL" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>" maxlength="200" required/>
                                                                <span class="error-text-color" ng-show="HomeForm.$submitted">
                                                                        <span ng-show="HomeForm.CanonicalURL.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'CanonicalURL'))}}</span>
                                                                        <span ng-show="HomeForm.CanonicalURL.$error.pattern">{{ trans('messages.InvalidCanonicalUrl') }}</span>
                                                                </span>
                                                            </div>
                                                            <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                <label for="MetaDescription" class="control-label">Meta-Description</label>
                                                                <textarea rows="6" class="form-control" name="MetaDescription" data-ng-model="HomeModel.MetaDescription"></textarea>
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-md-12 col-sm-12 col-xs-12 no-padding margin-top-15"><hr class="hr-section margin-top-15"></div>
                                                        <div class="col-md-12 no-padding ">
                                                            <div class="form-group col-md-12 col-sm-12 col-xs-12 rich-margin">
                                                                <h3 class="page-title font-size19px">Facebook</h3>
                                                            </div>
                                                            <div class="form-group col-md-8 col-lg-9 col-sm-12 col-xs-12  no-padding">
                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                    <label for="FBTitle" class="control-label">Facebook Title</label>
                                                                    <input class="form-control" type="text" name="FBTitle"  maxlength="200" data-ng-model="HomeModel.FBTitle"/>
                                                                </div>
                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                    <label for="FBDescription" class="control-label">Facebook-Description</label>
                                                                    <textarea rows="6" class="form-control" name="FBDescription" data-ng-model="HomeModel.FBDescription"></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12">
                                                                <label for="FBImage" class="control-label">Facebook Image</label>
                                                            </div>
                                                            <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12 margin-top1pr">
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealFacebookImagePath ? HomeModel.RealFacebookImagePath : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$RDHomeFacebookImageType; ?>" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealFacebookImagePath" id="file" title="Choose Image" > Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$RDHomeFacebookImageType; ?>')" ng-hide="(HomeModel.RealFacebookImagePath == '' || HomeModel.RealFacebookImagePath == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-md-12 col-sm-12 col-xs-12 no-padding"><hr class="hr-section"></div>
                                                    <div class="col-md-12 no-padding">
                                                        <div class="form-group col-md-12 col-sm-12 col-xs-12 rich-margin">
                                                            <h3 class="page-title font-size19px">Twitter</h3>
                                                        </div>
                                                        <div class="form-group col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                            <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                <label for="TwitterCard" class="control-label">Twitter Card</label>
                                                                <input class="form-control" type="text" name="TwitterCard"  maxlength="50" data-ng-model="HomeModel.TwitterCard" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"/>
                                                            </div>
                                                            <div class="form-group col-md-6 col-sm-12 col-xs-12">
                                                                <label for="TwitterSite" class="control-label">Twitter Site</label>
                                                                <input class="form-control"  type="text" name="TwitterSite"  maxlength="200" data-ng-model="HomeModel.TwitterSite" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"/>
                                                            </div>
                                                            <div class="form-group col-md-6 col-sm-12 col-xs-12">
                                                                <label for="TwitterTitle" class="control-label">Twitter Title</label>
                                                                <input class="form-control"  type="text" name="TwitterTitle"  maxlength="200" data-ng-model="HomeModel.TwitterTitle" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"/>
                                                            </div>
                                                            <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                <label for="TwitterDescription" class="control-label">Twitter-Description</label>
                                                                <textarea rows="6" class="form-control" name="TwitterDescription" data-ng-model="HomeModel.TwitterDescription" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"></textarea>
                                                            </div>

                                                        </div>
                                                        <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12">
                                                            <label for="TwitterImage" class="control-label">Twitter Image</label>
                                                        </div>
                                                        <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12 margin-top1pr">
                                                            <div class="fileinput fileinput-new">
                                                                <div  class="fileinput-new thumbnail image-box">
                                                                    <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                    <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealTwitterImagePath ? HomeModel.RealTwitterImagePath : HomeModel.NoImagePath}}">
                                                                </div>
                                                                <div>
                                                                    <form></form>
                                                                    <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$RDHomeTwitterImageType; ?>" role="form" novalidate>
                                                                        <input type="hidden" id="key" name="key" value="">
                                                                        <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                        <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                        <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                        <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                        <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                        <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                        <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealTwitterImagePath" id="file" title="Choose Image" > Choose Image</span>
                                                                        <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$RDHomeTwitterImageType; ?>')" ng-hide="(HomeModel.RealTwitterImagePath == '' || HomeModel.RealTwitterImagePath == null)"> Remove </a>
                                                                        <span></span>
                                                                    </form>
                                                                </div>
                                                                <span>&nbsp;</span>
                                                                <div class="progress progress-striped display-none background">
                                                                    <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-md-12 col-sm-12 col-xs-12 no-padding"><hr class="hr-section"></div>
                                                    <div class="form-group col-md-12 col-sm-12 col-xs-12 rich-margin">
                                                        <h3 class="page-title font-size19px">Rich Snippets</h3>
                                                    </div>
                                                    <div class="col-md-12  no-padding">
                                                        <div class="col-md-12  no-padding">
                                                            <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                    <label for="Headline" class="control-label">Headline</label>
                                                                    <input class="form-control"  type="text" name="Headline"  maxlength="200" data-ng-model="HomeModel.Headline" ng-disabled="PageModel.ViewPage==0 &&  PageModel.CanEditSEOFields==0"/>
                                                                </div>
                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                    <label for="TwitterDescription" class="control-label">Description</label>
                                                                    <textarea rows="6" class="form-control" name="Description" data-ng-model="HomeModel.Description" ng-disabled="PageModel.ViewPage==0 && PageModel.CanEditSEOFields==0"></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12">
                                                                <label for="TwitterImage" class="control-label">Image Upload</label>
                                                            </div>
                                                            <div class="form-group col-md-4 col-lg-3 col-sm-12 col-xs-12 margin-top1pr">
                                                                <div class="fileinput fileinput-new">
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src=" @{{HomeModel.RealRichSnippetImagePath ? HomeModel.RealRichSnippetImagePath : HomeModel.NoImagePath}}">
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$RDHomeRichSnippetImageType; ?>" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="HomeModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="acl"  ng-value="HomeModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="success_action_status"  ng-value="HomeModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="policy"  ng-value="HomeModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="HomeModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" ng-value="HomeModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="HomeModel.RealRichSnippetImagePath" id="file" title="Choose Image" > Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$RDHomeRichSnippetImageType; ?>')" ng-hide="(HomeModel.RealRichSnippetImagePath == '' || HomeModel.RealRichSnippetImagePath == null)"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Testing -->

                                <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                    <input id="submit-home" name="submit" type="submit" value="Save" class="btn blue save-button" data-ng-click="SaveHome()" ng-disabled="(DisableButtons || requestCounter != responseCounter)">
                                    <button type="button" id="cancel-home" class="btn default" data-ng-click="Cancel()" ng-disabled="(DisableButtons || requestCounter != responseCounter)">Cancel</button>
                                </div>

                            </div>
                        </form>
                    </div>
                    <div class="tab-pane fade" id="tab_1_2">
                        <form name="SliderForm" id="SliderForm" role="form" novalidate ng-controller = "SliderController" ng-clock ng-submit="checkSaveSlider(SliderForm)">
                            <div class="form-body">
                                <div class="clearboth"></div>
                                <!-- For Slider section start -->
                                <div class="col-md-12 col-sm-12 col-xs-12 no-padding">
                                    <div class="clearboth"></div>
                                    <div class="portlet box blue-hoki" ng-cloak>
                                        <div class="portlet-title" collapse>
                                            <div class="caption">
                                                <i class=""></i>Details</div>
                                            <div class="tools">
                                                <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                            </div>
                                        </div>
                                        <div class="portlet-body">
                                            <div class="row">
                                                <div class="col-md-12 no-padding">
                                                    <div class="form-body" >
                                                        <div class="col-md-12 no-padding">
                                                            <h3 class="caption-subject form-section uppercase col-md-12">@{{ SliderModel.Slider.HomePageSliderID > 0 ? 'Edit Slider' : 'Add Slider' }}</h3>
                                                            <!-- For Slider image upload section start -->
                                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12 visible-sm visible-xs">
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Slider image" class="control-label">Slider image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new" ng-clock>
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src="@{{ SliderModel.Slider.RealBackgroundImagePath ? SliderModel.Slider.RealBackgroundImagePath : SliderModel.NoImagePath }}" ng-clock>
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload-slider-image" name="FormSliderImage" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="SliderModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="acl"  ng-value="SliderModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="success_action_status"  ng-value="SliderModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="policy"  ng-value="SliderModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="SliderModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" value="SliderModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="SliderModel.Slider.RealBackgroundImagePath" id="file" title="Choose Image" required> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage()" ng-hide="SliderModel.Slider.RealBackgroundImagePath == ''"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedSliderFixHeight > 0 ) && (AllowedSliderFixWidth > 0 )"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedSliderFixWidth }}x@{{ AllowedSliderFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (SliderForm.$submitted) && FormSliderImage.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormSliderImage.file.$error" ng-if="SliderForm.$submitted">
                                                                            <div ng-show="FormSliderImage.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Slider images'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- For Slider image upload section end -->
                                                            <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                                                                <div class="form-group col-md-12 ">
                                                                    <label class="control-label margin-right-10">Text Color:</label>
                                                                    <label class="margin-right-10"><input type="radio" id="IsLight" ng-model="SliderModel.Slider.IsLight" name="IsLight" value="0"/>  Dark</label>
                                                                    <label><input type="radio" id="IsLight" ng-model="SliderModel.Slider.IsLight" name="IsLight"  value="1"/> Light</label>
                                                                </div>

                                                                <div class="form-group col-md-12 " ng-class="{ 'has-error' : (SliderForm.$submitted) && SliderForm.Header.$invalid}">
                                                                    <label for="Header" class="control-label">Header</label>
                                                                    <input class="form-control" type="text" name="Header" ng-model="SliderModel.Slider.Header" id="Header" maxlength="90"/>
                                                                </div>
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (SliderForm.$submitted) && SliderForm.LinkText.$invalid}">
                                                                    <label for="Link Text" class="control-label">Link Text</label>
                                                                    <input class="form-control" type="text" name="LinkText" ng-model="SliderModel.Slider.LinkText" ng-class="{ 'has-submitted' : SliderForm.$submitted }" ng-required="!( SliderModel.Slider.LinkURL == '' || SliderModel.Slider.LinkURL == null )" />
                                                                    <div  class="help-block" ng-messages="SliderForm.LinkText.$error" ng-if="SliderForm.$submitted">
                                                                        <div ng-show="SliderForm.LinkText.$error.required  && SliderForm.LinkText.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link Text'))}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-md-12" ng-class="{ 'has-error' : (SliderForm.$submitted) && SliderForm.LinkURL.$invalid}">
                                                                    <label for="Link URL" class="control-label">Link URL</label>
                                                                    <input class="form-control" type="text" name="LinkURL" ng-model="SliderModel.Slider.LinkURL" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : SliderForm.$submitted }" ng-required="!( SliderModel.Slider.LinkText == '' || SliderModel.Slider.LinkText == null )" />
                                                                    <div  class="help-block" ng-messages="SliderForm.LinkURL.$error" ng-if="SliderForm.$submitted">
                                                                        <div ng-show="SliderForm.LinkURL.$error.required  && SliderForm.LinkURL.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Link URL'))}}</div>
                                                                        <div ng-show="SliderForm.LinkURL.$error.pattern ">{{ trans('messages.InvalidLink')}}</div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-md-12">
                                                                    <label for="Description" class="control-label">Description</label>
                                                                    <textarea class="form-control" rows="5" name="Description" maxlength="150" ng-model="SliderModel.Slider.Description"></textarea>
                                                                </div>
                                                            </div>
                                                            <!-- For Slider image upload section start -->
                                                            <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12 hidden-sm hidden-xs">
                                                                <div class="col-md-12 no-padding">
                                                                    <label for="Slider image" class="control-label">Slider image</label>
                                                                </div>
                                                                <div class="fileinput fileinput-new" ng-clock>
                                                                    <div  class="fileinput-new thumbnail image-box">
                                                                        <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                                        <img id="actualImage" alt="" ng-src="@{{ SliderModel.Slider.RealBackgroundImagePath ? SliderModel.Slider.RealBackgroundImagePath : SliderModel.NoImagePath }}" ng-clock>
                                                                    </div>
                                                                    <div>
                                                                        <form></form>
                                                                        <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload-slider-image" name="FormSliderImage" role="form" novalidate>
                                                                            <input type="hidden" id="key" name="key" value="">
                                                                            <input type="hidden" name="AWSAccessKeyId"  ng-value="SliderModel.FileUploadSettings.accesskey">
                                                                            <input type="hidden" name="acl"  ng-value="SliderModel.FileUploadSettings.acl">
                                                                            <input type="hidden" name="success_action_status"  ng-value="SliderModel.FileUploadSettings.success_action">
                                                                            <input type="hidden" name="policy"  ng-value="SliderModel.FileUploadSettings.base64Policy">
                                                                            <input type="hidden" name="signature"  ng-value="SliderModel.FileUploadSettings.signature">
                                                                            <input type="hidden" name="Cache-Control" value="SliderModel.FileUploadSettings.cacheControlTime">
                                                                            <span  class="btn default btn-file" ><input type="file" name="file" ng-model="SliderModel.Slider.RealBackgroundImagePath" id="file" title="Choose Image" required> Choose Image</span>
                                                                            <a class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage()" ng-hide="SliderModel.Slider.RealBackgroundImagePath == ''"> Remove </a>
                                                                            <span></span>
                                                                        </form>
                                                                    </div>
                                                                    <span>&nbsp;</span>
                                                                    <div class="progress progress-striped display-none background">
                                                                        <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                                        </div>
                                                                    </div>
                                                                    <div class="info-alert" ng-if="(AllowedSliderFixHeight > 0 ) && (AllowedSliderFixWidth > 0 )"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedSliderFixWidth }}x@{{ AllowedSliderFixHeight }}px</lable></div>
                                                                    <div ng-class="{ 'has-error' : (SliderForm.$submitted) && FormSliderImage.file.$error}" class="has-error">
                                                                        <div class="help-block" ng-messages="FormSliderImage.file.$error" ng-if="SliderForm.$submitted">
                                                                            <div ng-show="FormSliderImage.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Slider images'))}}</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- For Slider image upload section end -->
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- For Slider File Upload End -->

                                    <div class="form-actions  col-md-12 no-padding">
                                        <input id="submit-slider" name="submit" type="submit" value="Save" class="btn blue save-button" data-ng-click="SaveSlider()" ng-disabled="DisableButtons || (responseCounter != requestCounter)">
                                        <button type="button" id="cancel-slider" class="btn default" data-ng-click="CancelSlider()" ng-disabled="DisableButtons || (responseCounter != requestCounter)">Cancel</button>
                                    </div>
                                    <!-- Slider list start -->
                                    <div class="col-md-12 no-padding">
                                        <div data-ng-if="SliderListArray.length > 0" class="table-scrollable sortablestory" ng-cloak>
                                            <div>
                                                <table class="table table-striped table-bordered table-hover" sortable-list="SliderListArray"  sortable-callback="updateSortOrderSlider" sortable-containment='sortablestory'>
                                                    <thead class="site-footer">
                                                    <tr role="row">
                                                        <th data-ng-if="SliderListArray.length > 1"><span class="anchor_color vertical-align"></span></th>
                                                        <th class="vertical-align home-slider-dp-width"><span class="anchor_color">Slider</span></th>
                                                        <th class="vertical-align"><span class="anchor_color">Header</span></th>
                                                        <th class="vertical-align"><span class="anchor_color">Link Text</span></th>
                                                        <th class="vertical-align">Action</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody class="drag-faq-list">
                                                    <tr ng-repeat="data in SliderListArray" class="sortable-row" role="row">
                                                        <td class="sortable-handle vertical-align" data-ng-if="SliderListArray.length > 1">
                                                            <span class="draggable-icon-arrow">
                                                                <i class="fa fa-bars draggable-icon"></i>
                                                                <i class="fa fa-arrows-alt draggable-icon"></i>
                                                            </span>
                                                        </td>
                                                        <td class="vertical-align"><img src="@{{data.RealBackgroundImagePath ? data.RealBackgroundImagePath : SliderModel.NoImagePath}}" class="homepage-sm-img" width="70px" height="70px"></td>
                                                        <td class="vertical-align"><a ng-click="EditSlider(data)" title="Edit Slider" ng-model="EditSlider"><div class="faq-ellipsis">@{{data.Header}}</div></a></td>
                                                        <td class="vertical-align"><div class="faq-ellipsis">@{{data.LinkText}}</div></td>
                                                        <td class="faq-action-part vertical-align">
                                                            <div>
                                                                <a ng-click="EditSlider(data)" title="Edit Slider" ng-model="EditSlider"><i class="fa fa-pencil text-default" ></i></a>
                                                                &nbsp;
                                                                <a ng-click="DeleteSlider(data)" title="Delete Slider" ng-model="DeleteSlider"><i class="fa fa-trash-o text-danger"></i></a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <div class="form-group col-md-12 display-none" align="center" id="nodata">
                                            <b>Sorry, no slider found</b>
                                        </div>
                                    </div>
                                    <!-- Slider list end -->
                                </div>
                                <!-- For Slider section end -->
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
@stop

@section('script')
    {{ $minify::javascript(array('/assets/js/viewjs/home/rd_home.js',
                                '/assets/js/sitejs/dropzone.js',
                                '/assets/js/library/jquery.fileupload/jquery.ui.widget.js',
                                 '/assets/js/library/jquery.fileupload/jquery.fileupload.js',
                                 '/assets/js/library/binaryajax.js',
                                 '/assets/js/library/exif.js',
                                 '/assets/js/library/bootstrap-fileinput.js',
                                 '/assets/js/sitejs/canvasResize.js'))->withFullUrl()}}
    <script src="{{asset('/assets/js/ckeditor/ckeditor.js')}}" ></script>
    <!--For slider images upload start-->
    {{ $minify::javascript(array('/assets/js/sitejs/jquery-ui-1.9.2.custom.min.js',
                                   '/assets/js/sitejs/jquery.ui.touch-punch.min.js'))->withFullUrl()}}

    <!--For slider images upload end -->
    <!--For hover images upload start-->
    <script>
        window.NoImagePath = '<?php echo asset('/assets/images/Samplephoto.png') ?>';
        window.RDHomeBlock1ImageType='<?php echo Constants::$RDHomeBlock1ImageType; ?>';
        window.RDHomeBlock2ImageType='<?php echo Constants::$RDHomeBlock2ImageType; ?>';
        window.RDHomeBlock3ImageType='<?php echo Constants::$RDHomeBlock3ImageType; ?>';
        window.RDHomeFacebookImageType='<?php echo Constants::$RDHomeFacebookImageType; ?>';
        window.RDHomeTwitterImageType='<?php echo Constants::$RDHomeTwitterImageType; ?>';
        window.RDHomeRichSnippetImageType='<?php echo Constants::$RDHomeRichSnippetImageType; ?>';
    </script>
    <!--For hover images upload end-->
@stop