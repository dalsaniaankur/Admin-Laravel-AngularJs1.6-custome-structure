<?php
$minify = new \CeesVanEgmond\Minify\Facades\Minify;
use Infrastructure\Constants;
?>
@extends('layouts.sitemaster')

@section('Title','Dashboard')
@stop

@section('content')
<main id="main" role="main">
<?php
    echo Form::hidden('BlogListModel', json_encode($BlogListModel), $attributes = array('id' => 'BlogListModel'));
    echo Form::hidden('PageListModel', json_encode($PageListModel), $attributes = array('id' => 'PageListModel'));
?>
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo URL::to('/dashboard/'.$encryptedSiteID) ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Dashboard</span>
                </li>
            </ul>
        </div>

        <h3 class="page-title">Dashboard</h3>
        <div class="row">
            <div class="col-md-12 no-padding">
                <!-- Blog list start -->
                <div data-ng-controller = "BlogListController">
                    <div data-ng-if="BlogList.length > 0" class="col-md-12" ng-clock> <h4 ng-clock> <span ng-bind="'Blogs assigned to me (' + ListPager.totalRecords + ')'"> </span></h4></div>
                    <div data-ng-if="BlogList.length > 0" class="table-responsive col-md-12"  ng-cloak>
                        <table class="table dataTable table-striped table-bordered table-hover">
                            <thead class="site-footer">
                            <tr>
                                <th class="sorting" data-ng-click="ListPager.sortColumn('Title')"
                                    data-ng-class="{sorting_desc: (ListPager.sortIndex === 'Title' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'Title' && !ListPager.reverse)}">
                                    Post Title
                                </th>
                                <th class="sorting" data-ng-click="ListPager.sortColumn('Author')"
                                    data-ng-class="{sorting_desc: (ListPager.sortIndex === 'Author' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'Author' && !ListPager.reverse)}">
                                    Author
                                </th>
                                <th class="sorting" data-ng-click="ListPager.sortColumn('PostDate')"
                                    data-ng-class="{sorting_desc: (ListPager.sortIndex === 'PostDate' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'PostDate' && !ListPager.reverse)}">
                                    Post Date
                                </th>
                                <th class="sorting" data-ng-click="ListPager.sortColumn('CreatedDate')"
                                    data-ng-class="{sorting_desc: (ListPager.sortIndex === 'CreatedDate' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'CreatedDate' && !ListPager.reverse)}">
                                    Created Date
                                </th>
                                <th class="sorting" data-ng-click="ListPager.sortColumn('ModifiedDate')"
                                    data-ng-class="{sorting_desc: (ListPager.sortIndex === 'ModifiedDate' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'ModifiedDate' && !ListPager.reverse)}">
                                    Last Updated
                                </th>
                                <th class="sorting" data-ng-click="ListPager.sortColumn('ModifiedBy')"
                                    data-ng-class="{sorting_desc: (ListPager.sortIndex === 'ModifiedBy' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'ModifiedBy' && !ListPager.reverse)}">
                                    Last Updated By
                                </th>
                                <th class="sorting" data-ng-click="ListPager.sortColumn('Status')"
                                    data-ng-class="{sorting_desc: (ListPager.sortIndex === 'Status' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'Status' && !ListPager.reverse)}">
                                    Status
                                </th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody dir-paginate="data in BlogList | itemsPerPage:ListPager.pageSize" total-items="ListPager.totalRecords" current-page="ListPager.currentPage" pagination-id="BlogPostID">
                            <tr>
                                <td><a ng-click="EditBlog(data)" title="Edit Page">@{{data.Title}}</a></td>
                                <td>@{{ data.Author }}</td>
                                <td>@{{ data.PostDate }}</td>
                                <td>@{{ data.CreatedDate }}</td>
                                <td>@{{ data.ModifiedDate }}</td>
                                <td>@{{ data.ModifiedBy }}</td>
                                <td>@{{ data.Status }}</td>
                                <td>
                                    <div>
                                        <a ng-click="EditBlog(data)" title="Edit Page"><i class="fa fa-pencil text-default"></i></a>
                                        &nbsp;
                                        <a ng-click="DeleteBlogPost(data)" title="Delete Page"><i
                                                    class="fa fa-trash-o text-danger" ng-if="data.LoggedInUserRoleID ==<?php echo Constants::$RoleITAdmin;?> || data.LoggedInUserRoleID ==<?php echo Constants::$RoleMarketingDirector;?>"></i></a>
                                    </div>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="col-md-12" data-ng-if="BlogList.length > 0">
                        <dir-pagination-controls boundary-links="true"  on-page-change="ListPager.pageChanged(newPageNumber)" pagination-id="BlogPostID">
                        </dir-pagination-controls>
                    </div>

                    <!--<div class="form-group col-md-12 display-none"  align="center" id="nodata">
                    <b>{{ trans('messages.NoBlogRecordFound') }}</b>
                     </div>-->
                    <div class="dashboard-total-count" data-ng-if="BlogList.length <= ListPager.pageSize" ng-clock></div>

                </div>
                <!-- Blog list end -->

                <!-- Pages list start -->
                <div data-ng-controller = "pageListController">
                    <div data-ng-if="PageList.length > 0" class="col-md-12" ng-clock><h4 ng-clock> <span ng-bind="'Pages assigned to me (' + ListPager.totalRecords + ')'"> </span></h4></div>
                    <div data-ng-if="PageList.length > 0" class="table-responsive col-md-12"  ng-cloak>
                        <table class="table dataTable table-striped table-bordered table-hover">
                            <thead class="site-footer">
                            <tr>
                                <th class="sorting" data-ng-click="ListPager.sortColumn('Title')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'Title' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'Title' && !ListPager.reverse)}">
                                    Title
                                </th>
                                <th class="sorting" data-ng-click="ListPager.sortColumn('CreatedDate')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'CreatedDate' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'CreatedDate' && !ListPager.reverse)}">
                                    Created Date
                                </th>
                                <th class="sorting" data-ng-click="ListPager.sortColumn('ModifiedDate')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'ModifiedDate' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'ModifiedDate' && !ListPager.reverse)}">
                                    Last Updated
                                </th>
                                <th class="sorting" data-ng-click="ListPager.sortColumn('ModifiedBy')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'ModifiedBy' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'ModifiedBy' && !ListPager.reverse)}">
                                    Last Updated By
                                </th>
                                <th class="sorting" data-ng-click="ListPager.sortColumn('Status')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'Status' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'Status' && !ListPager.reverse)}">
                                    Status
                                </th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody dir-paginate="data in PageList | itemsPerPage:ListPager.pageSize" total-items="ListPager.totalRecords" current-page="ListPager.currentPage" pagination-id="PageID">
                            <tr>
                                <td><a ng-click="EditPage(data)" title="Edit Page">@{{ data.Title }}</a></td>
                                <td>@{{ data.CreatedDate }}</td>
                                <td>@{{ data.ModifiedDate }}</td>
                                <td>@{{ data.ModifiedBy }}</td>
                                <td>@{{ data.Status }}</td>
                                <td>
                                    <div>
                                        <a ng-click="EditPage(data)" title="Edit Page"><i class="fa fa-pencil text-default"></i></a>
                                        &nbsp;
                                        <a ng-click="DeletePage(data)" title="Delete Page"><i class="fa fa-trash-o text-danger" ng-if="data.LoggedInUserID == <?php echo Constants::$RoleITAdmin;?>"></i></a>
                                    </div>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="col-md-12" data-ng-if="PageList.length > 0">
                        <dir-pagination-controls boundary-links="true"  on-page-change="ListPager.pageChanged(newPageNumber)" pagination-id="PageID">
                        </dir-pagination-controls>
                    </div>

                    <!-- <div class="form-group col-md-12 display-none"  align="center" id="nodata">
                        <b>{{ trans('messages.NoPageRecordFound') }}</b>
                    </div> -->
                    <div class="dashboard-total-count" data-ng-if="PageList.length <= ListPager.pageSize" ng-clock></div>
                </div>
                <!-- Page list end -->
            </div>
        </div>
   </div>
</main>
@stop

@section('script')
    {{ $minify::javascript(array('/assets/js/viewjs/dashboard/dashboard.js'))->withFullUrl()}}
@stop