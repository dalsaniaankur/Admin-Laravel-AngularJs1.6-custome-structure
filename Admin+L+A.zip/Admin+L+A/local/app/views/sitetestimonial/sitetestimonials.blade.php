<?php
use Infrastructure\Constants;
use Infrastructure\Common;
use BaseController as BA;
$minify = new \CeesVanEgmond\Minify\Facades\Minify;
?>
@extends('layouts.sitemaster')
@section('Title','Site Testimonials')
@stop
@section('css')

@stop
@section('content')
<?php echo Form::hidden('SiteTestimonialModel', json_encode($SiteTestimonialModel), $attributes = array('id' => 'SiteTestimonialModel')); ?>
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content" data-ng-controller = "SiteTestimonialListController">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo URL::to('/dashboard/'.$encryptedSiteID) ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Site Testimonials </span>
                </li>
            </ul>
            
        </div>

        <h4 class="page-title" ng-cloak>
                                            @{{ SiteTestimonialModel.TestDetails.TestimonialID > 0 ? 'Edit Testimonial' : 'Add Testimonial' }}
                                        </h4>
                                        <!-- END PAGE TITLE-->
                                        <!-- BEGIN Form Design-->
                                        <div class="row">
                                            <div class="col-md-12">
                                                <!-- BEGIN SAMPLE FORM PORTLET-->
                                                <form name="SiteTestimonialListForm" id="SiteTestimonialListForm" role="form" novalidate>
                                                    <div class="form-body"  ng-cloak>
                                                <div class="portlet box blue-hoki" ng-cloak>
                                                    <div class="portlet-title" collapse>
                                                        <div class="caption">
                                                            <i class=""></i>Details</div>
                                                        <div class="tools">
                                                            <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                                        </div>
                                                    </div>
                                                    <div class="portlet-body">
                                                        <div class="row">
                                                            <div class="col-md-12 no-padding">
                                                                <div class="form-body" >
                                                        <div class="col-md-9  no-padding">
                                                            <div class="col-md-12  no-padding">
                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12"  ng-class="{ 'has-error' : (SiteTestimonialListForm.$submitted) && SiteTestimonialListForm.Testimonial.$invalid}">
                                                                    <label for="Testimonial" class="control-label">Testimonial</label>
                                                                    <textarea rows="4" class="form-control" name="Testimonial" id="Testimonial" data-ng-model="SiteTestimonialModel.TestDetails.Testimonial" data-ng-class="{'has-submitted' : SiteTestimonialListForm.$submitted }" required autofocus="autofocus"></textarea>
                                                                    <span class="error-text-color" ng-show="SiteTestimonialListForm.$submitted">
                                                                        <span ng-show="SiteTestimonialListForm.Testimonial.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Testimonial'))}}</span>
                                                                    </span>
                                                                </div>
                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                    <label for="Attribution" class="control-label">Attribution</label>
                                                                    <input class="form-control"  type="text" name="Attribution" id="Attribution" data-ng-model="SiteTestimonialModel.TestDetails.Attribution" data-ng-class="{'has-submitted' : SiteTestimonialListForm.$submitted }" required maxlength="50"/>
                                                                    <span class="error-text-color" ng-show="SiteTestimonialListForm.$submitted">
                                                                        <span ng-show="SiteTestimonialListForm.Attribution.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Attribution'))}}</span>
                                                                    </span>
                                                                </div>

                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                    <label for="AttributionURL" class="control-label"> Attribution URL</label>
                                                                    <input class="form-control"  type="text" name="AttributionURL" id="AttributionURL" data-ng-class="{'has-submitted' : SiteTestimonialListForm.$submitted }" pattern="<?php echo \Infrastructure\Constants::$WebsiteUrlRegex; ?>" data-ng-model="SiteTestimonialModel.TestDetails.AttributionURL" maxlength="50"/>
                                                                    <span class="error-text-color" ng-show="SiteTestimonialListForm.$submitted">
                                                                        <span ng-show="SiteTestimonialListForm.AttributionURL.$error.pattern">{{ trans('messages.InvalidWebsiteUrl')}}</span>
                                                                    </span>
                                                                </div>

                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                    <label for="CompanyName" class="control-label">Company Name</label>
                                                                    <input class="form-control"  type="text" name="CompanyName" id="CompanyName" data-ng-class="{'has-submitted' : SiteTestimonialListForm.$submitted }" data-ng-model="SiteTestimonialModel.TestDetails.CompanyName" maxlength="50"/>
                                                                </div>

                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                    <label for="CompanyURL" class="control-label"> Company URL</label>
                                                                    <input class="form-control"  type="text" name="CompanyURL" id="CompanyURL" data-ng-class="{'has-submitted' : SiteTestimonialListForm.$submitted }" pattern="<?php echo \Infrastructure\Constants::$WebsiteUrlRegex; ?>" data-ng-model="SiteTestimonialModel.TestDetails.CompanyURL" maxlength="500"/>
                                                                    <span class="error-text-color" ng-show="SiteTestimonialListForm.$submitted">
                                                                        <span ng-show="SiteTestimonialListForm.CompanyURL.$error.pattern">{{ trans('messages.InvalidWebsiteUrl')}}</span>
                                                                    </span>
                                                                </div>

                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                    <label for="IsVisible" class="control-label">Visible</label>
                                                                    <input type="checkbox" ng-model="SiteTestimonialModel.TestDetails.IsVisible" ng-true-value="1" ng-false-value="0"/>
                                                                </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                           </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12 no-padding">
                                                        <input id="submit" name="submit" type="submit" value="Save" class="btn blue save-button" data-ng-click="Save()"  ng-disabled="DisableButtons">
                                                        <input  type="button" id="cancel" class="btn default" data-ng-click="Cancel(data)" value="Cancel" ng-disabled="DisableButtons">
                                                    </div>
                                                </div>
                                                </form>
                                            </div>
                                        </div>



        <h3 class="page-title">Site Testimonials </h3>
        <div class="row">
            <div class="col-md-12">
                <div data-ng-if="SiteTestimonialListArray.length > 0" class="table-scrollable sortable" ng-cloak>
                    <div>
                    <table class="table table-striped table-bordered table-hover" sortable-list="SiteTestimonialListArray" sortable-callback="updateSortOrder">
                        <thead class="site-footer">
                        <tr role="row">
                            <th data-ng-if="SiteTestimonialListArray.length > 1"><span class="anchor_color vertical-align"></span></th>
                            <th class="vertical-align"><span class="anchor_color">Testimonial</span></th>
                            <th class="vertical-align"><span class="anchor_color">Attribution</span></th>
                            <th class="vertical-align"><span class="anchor_color">Visible</span></th>

                         
                            <th class="vertical-align">Action</th>
                        </tr>
                        </thead>
                        <tbody class="drag-loan-list">
                        <tr ng-repeat="item in SiteTestimonialListArray" class="sortable-row" role="row">
                            <td class="sortable-handle vertical-align" data-ng-if="SiteTestimonialListArray.length > 1">
                                <span class="draggable-icon-arrow">
                                    <i class="fa fa-bars draggable-icon"></i>
                                    <i class="fa fa-arrows-alt draggable-icon"></i>
                                </span>
                            </td>
                           
                            <td class="vertical-align"><div class="faq-ellipsis">@{{item.Testimonial}}</div></td>
                            <td class="vertical-align"><div class="faq-ellipsis">@{{item.Attribution}}</div></td>
                            <td class="vertical-align">@{{item.VisibleText}}</td>
                            <td class="loan-action-part vertical-align">
                                <div>
                                    <a ng-click="EditSiteTestimonial(item)" title="Edit Loan" ng-model="EditLoan"><i class="fa fa-pencil text-default" ></i></a>
                                    &nbsp;
                                    <?php if(BA::CheckRoleSitePermission(Common::getRoleITAdminProcesing(),Common::getSiteRiverDaleColoradoWW())) {?>
                                    <a ng-model="deleteLoan" ng-click="deleteSiteTestimonial(item)" title="Delete Loan" ng-model="DeleteLoan"><i class="fa fa-trash-o text-danger"></i></a>
                                    <?php } ?>
                                </div>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                    </div>
                </div>
                <div class="form-group col-md-12 display-none" align="center" id="nodata">
                    <b>Sorry, no testimonial found</b>
                </div>
            </div>
        </div>
    </div>
@stop
@section('script')
       {{ $minify::javascript(array('/assets/js/sitejs/jquery-ui-1.9.2.custom.min.js', '/assets/js/viewjs/sitetestimonial/sitetestimonials.js', '/assets/js/sitejs/jquery.ui.touch-punch.min.js'))->withFullUrl()}}
@stop
