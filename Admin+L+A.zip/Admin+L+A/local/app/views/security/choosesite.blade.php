<?php $value = Session::get('UserSite');
use ViewModels\SessionHelper;
$minify = new \CeesVanEgmond\Minify\Facades\Minify;
?>
@extends('layouts.choosesitemaster')
@section('Title',' | ChooseSite')

@stop
@section('css')
@stop
@section('content')
    <main id="main" role="main">
        <?php echo Form::hidden('ChooseSiteModel', json_encode($ChooseSiteModel),$attributes = array('id'=>'ChooseSiteModel')); ?>
        <!-- BEGIN CONTENT BODY -->
        <div class="page-content"  ng-controller = "ChooseSiteController">

            <div class="padding15p" align="center">
                <div ng-repeat="data in UserSiteList" ng-cloak>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" >
                        <a href="" ng-click="SelectSite(data.SiteID)">
                            <div class="dashboard-stat red">
                                <div class="visual">
                                    <i class="fa fa-comments"></i>
                                </div>
                                <div class="details">
                                    <div class="number">
                                        <span data-counter="counterup" data-value="1349"></span>
                                    </div>
                                    <div class="desc">@{{data.SiteName}}</div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>

        </div>
        <!-- END CONTENT BODY -->
    </main>
@stop

@section('script')
    {{ $minify::javascript(array('/assets/js/viewjs/choosesite/choosesite.js',
                             '/assets/js/library/ngMask.min.js'))->withFullUrl()}}

    {{ $minify::javascript(array('/assets/js/sitejs/angularjs/angular-route.min.js',
                            '/assets/js/library/treeview/ui-bootstrap-tpls.js',
                            '/assets/js/library/treeview/main.js',
                            '/assets/js/library/treeview/handleCtrl.js',
                            '/assets/js/library/treeview/nodeCtrl.js',
                            '/assets/js/library/treeview/nodesCtrl.js',
                            '/assets/js/library/treeview/treeCtrl.js',
                            '/assets/js/library/treeview/uiTree.js',
                            '/assets/js/library/treeview/uiTreeHandle.js',
                            '/assets/js/library/treeview/uiTreeNode.js',
                            '/assets/js/library/treeview/uiTreeNodes.js',
                            '/assets/js/library/treeview/helper.js'))->withFullUrl()}}
@stop