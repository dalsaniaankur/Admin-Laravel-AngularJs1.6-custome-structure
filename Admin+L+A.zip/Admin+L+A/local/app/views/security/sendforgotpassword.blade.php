<?php $minify = new \CeesVanEgmond\Minify\Facades\Minify; ?>
@extends('layouts.loginmaster')
@section('Title','Forgot password')

@stop
@section('css')
@stop

@section('content')
    <!-- BEGIN FORGOT PASSWORD FORM -->

    <form class="login-form" name="ResetPasswordForm"  novalidate>
        <div class="form-body" ng-controller = "SecurityController" ng-cloak>
            <h3 class="form-title font-green">Request Password Reset</h3>

            <div class="form-group">
                <label class="control-label visible-ie8 visible-ie9">Email</label>
                <input class="form-control" type="email"  placeholder="Email" name="Email"  ng-model="ResetPasswordModel.Email" pattern="<?php echo \Infrastructure\Constants::$emailRegex?>" ng-class="{ 'has-submitted' : ResetPasswordForm.$submitted}" required />
            <span class="error-text-color" ng-show="ResetPasswordForm.$submitted">
                    <span ng-show="ResetPasswordForm.Email.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Email'))}}</span>
                    <span ng-show="ResetPasswordForm.Email.$error.pattern">{{ trans('messages.InvalidEmail')}}</span>
	         </span>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn green uppercase" data-ng-click="ResetPassword()">Request Reset Password </button>
            </div>
            <div class="form-group">
                    <a href="<?php echo URL::to('/')?>/">Found Password?</a>
            </div>
            <span ng-if="ResetPasswordModel.IsPending">Sorry, your account has not been yet activated, please click <a ng-click="SendVerificationEmail(ResetPasswordModel)">here</a > to re-send a verification email.</span>
            <span ng-if="ResetPasswordModel.IsPendingSuccess">We have sent a verification email, please follow instructions in the email to activate your account.</span>
        </div>
    </form>
    <!-- END FORGOT PASSWORD FORM -->
@stop

@section('script')
    {{ $minify::javascript(array('/assets/js/viewjs/security/sendforgotpassword.js'))->withFullUrl()}}
@stop