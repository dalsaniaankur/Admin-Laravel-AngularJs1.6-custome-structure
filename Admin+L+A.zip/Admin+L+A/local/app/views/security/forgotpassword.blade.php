<?php $minify = new \CeesVanEgmond\Minify\Facades\Minify; ?>
@extends('layouts.loginmaster')
@section('Title')
    <?php if($ForgotModel->IsForVerification==1) {echo "Activate your account";}else{echo "Reset Password";}?>
@stop
@section('content')

    <?php echo Form::hidden('ForgotModel', htmlspecialchars(json_encode($ForgotModel), ENT_QUOTES, 'UTF-8'),$attributes = array('id'=>'ForgotModel')); ?>
    <form class="login-form" name="ForgotForm"  novalidate>
        <div class="form-body" ng-controller = "SecurityController" ng-cloak>
         <h3 class="form-title font-green verify-font" ng-if="ForgotModel.IsForVerification==1">Create a password to activate your account</h3>
         <h3 class="form-title font-green" ng-if="ForgotModel.IsForVerification!=1">Reset Password</h3>

        <div class="form-group">
            <label class="control-label visible-ie8 visible-ie9">Password</label>
            <input class="form-control form-control-solid placeholder-no-fix" type="password"  maxlength="50" placeholder="Password" name="Password"  ng-model="ForgotModel.Password" ng-class="{ 'has-submitted' : ForgotForm.$submitted}" required  ng-pattern="<?php echo \Infrastructure\Constants::$passwordRegex;?>"/>
            <span class="error-text-color" ng-show="ForgotForm.$submitted ">
                <span ng-show="ForgotForm.Password.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Password'))}}</span>
                <span class="error-text-color" ng-show="ForgotForm.Password.$error.pattern">{{ trans('messages.PasswordRegex') }}</span>
            </span>
        </div>

        <div class="form-group">
            <label class="control-label visible-ie8 visible-ie9">Confirm Password</label>
            <input class="form-control form-control-solid placeholder-no-fix" type="password" maxlength="50" placeholder="Confirm Password" name="ConfirmPassword" nx-equal-ex="ForgotModel.Password"  ng-model="ForgotModel.ConfirmPassword" ng-class="{ 'has-submitted' : ForgotForm.$submitted }" required />
            <span class="error-text-color" ng-show="ForgotForm.$submitted">
                <span ng-show="ForgotForm.ConfirmPassword.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Confirm Password'))}}</span>
                <span class="error-text-color" ng-show="ForgotForm.ConfirmPassword.$error.nxEqualEx">{{ trans('messages.PasswordMatch') }}</span>
            </span>
        </div>

        <span class="font12px help-block" ng-if="ForgotModel.IsForVerification==1">Hint: Password must contain 12 characters, at least 1 uppercase, 1 number and 1 symbol</span>

         <div class="form-actions">
                <button type="submit" class="btn green uppercase" data-ng-click="ResetPassword()">Save Password</button>
         </div>

       </div>
    </form>
@stop

@section('script')
    {{ $minify::javascript(array('/assets/js/viewjs/security/forgotpassword.js', '/assets/js/viewjs/directive.js' ))->withFullUrl()}}
@stop