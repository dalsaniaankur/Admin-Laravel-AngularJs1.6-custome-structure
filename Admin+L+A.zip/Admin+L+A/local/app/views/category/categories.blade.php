<?php
    $minify = new \CeesVanEgmond\Minify\Facades\Minify;
?>
@extends('layouts.sitemaster')
@section('Title')
    Categories & Tags
@stop
@section('css')
@stop
@section('content')
<main id="main" role="main">
<?php echo Form::hidden('CategoryModel', json_encode($CategoryModel),$attributes = array('id'=>'CategoryModel')); ?>
<?php echo Form::hidden('TagModel', json_encode($TagModel),$attributes = array('id'=>'TagModel')); ?>
    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo URL::to('/dashboard/'.$encryptedSiteID) ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <a href="<?php echo URL::to('/category/'.$encryptedSiteID) ?>">Blog Posts</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Categories & Tags</span>
                </li>
            </ul>
        </div>
        <h3 class="page-title">Categories & Tags</h3>
        <ul class="nav nav-tabs">
            <li class="active">
                <a href="#tab_1_1" data-toggle="tab" aria-expanded="true">Category</a>
            </li>
            <li class="">
                <a href="#tab_1_2" data-toggle="tab" aria-expanded="false">Tag</a>
            </li>
        </ul>
        <div class="row">
                 <div class="col-md-12 col-sm-12 col-xs-12 no-padding" ng-cloak>
                        <div class="tab-content">
                            <div class="tab-pane active col-md-12" id="tab_1_1" data-ng-controller = "CategoryListController" ng-cloak>
                                <h3 class="page-title" ng-cloak> @{{ CategoryModel.TestDetails.CategoryID > 0 ? 'Edit Category' : 'Add Category' }}</h3>
                                <form name="CategoryForm" id="CategoryForm" role="form" novalidate>
                                    <div class="form-body">
                                        <div class="portlet box blue-hoki" ng-cloak>
                                            <div class="portlet-title" collapse>
                                                <div class="caption">
                                                    <i class=""></i>Details</div>
                                                <div class="tools">
                                                    <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                                </div>
                                            </div>
                                            <div class="portlet-body">
                                                <div class="row">
                                                    <div class="col-md-12 no-padding">
                                                        <div class="form-group col-md-9" ng-class="{ 'has-error' : (CategoryForm.$submitted) && CategoryForm.Category.$invalid}">
                                                            <label for="Category" class="control-label">Category</label>
                                                            <input class="form-control"  type="text" name="Category" id ="Category" ng-model="CategoryModel.TestDetails.Category" ng-class="{ 'has-submitted' : CategoryForm.$submitted }"  maxlength="100" required/>
                                                            <div  class="help-block" ng-messages="CategoryForm.Category.$error" ng-if="CategoryForm.$submitted">
                                                                <div  ng-show="CategoryForm.Category.$error.required  && CategoryForm.Category.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Category'))}}</div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-md-9" ng-class="{ 'has-error' : (CategoryForm.$submitted) && CategoryForm.Slug.$invalid}">
                                                            <label for="Slug" class="control-label">Slug</label>
                                                            <input class="form-control"  type="text" id ="Slug" name="Slug" ng-model="CategoryModel.TestDetails.Slug" ng-class="{ 'has-submitted' : CategoryForm.$submitted }" is-edit=CategoryModel.TestDetails.CategoryID  slug="CategoryModel.TestDetails.Category" maxlength="100" required />
                                                            <div  class="help-block" ng-messages="CategoryForm.Slug.$error" ng-if="CategoryForm.$submitted">
                                                                <div  ng-show="CategoryForm.Slug.$error.required  && CategoryForm.Slug.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Slug'))}}</div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-actions col-md-12">
                                            <input id="submit" name="submit" type="submit" value="Save" class="btn blue save-button" data-ng-click="AddCategory()" ng-disabled="DisableButtons">
                                            <button type="button" id="cancel" class="btn default" data-ng-click="CancelCategory()" ng-disabled="DisableButtons">Cancel</button>
                                        </div>

                                    </div>
                                </form>
                                <div class="col-md-9 no-padding">
                                    <h3 class="page-title">Categories</h3>
                                    <div data-ng-if="CategoryList.length > 0" class="table-responsive col-md-12" ng-cloak>
                                        <table class="table dataTable table-striped table-bordered table-hover">
                                            <thead class="site-footer">
                                            <tr>
                                                <th class="sorting" data-ng-click="ListPager.sortColumn('Category')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'Category' && !ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'Category' && ListPager.reverse)}" >
                                                    Category
                                                </th>
                                                <th>Action</th>
                                            </tr>
                                            </thead>
                                            <tbody dir-paginate="data in CategoryList | itemsPerPage:ListPager.pageSize" total-items="ListPager.totalRecords" current-page="ListPager.currentPage" pagination-id="CategoryID">
                                            <tr>
                                                <td ng-hide="@{{data.IsUpdateAllowed}} == 0"><div class="category-ellipsis"><a ng-click="EditCategory(data)"  title="Edit Category" ng-model="EditCategory">@{{data.Category}}</a></div></td>
                                                <td ng-show="@{{data.IsUpdateAllowed}} == 0"><div class="category-ellipsis">@{{data.Category}}</div></td>
                                                <td>
                                                    <div>
                                                        <a ng-click="EditCategory(data)" ng-hide="@{{data.IsUpdateAllowed}}==0" title="Edit Category" ng-model="EditCategory"><i class="fa fa-pencil text-default" ></i></a>
                                                        &nbsp;
                                                        <a ng-click="deleteCategory(data)" ng-hide="@{{data.IsUpdateAllowed}}==0" title="Delete Category" ng-model="DeleteCategory"><i class="fa fa-trash-o text-danger"></i></a>
                                                    </div>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="col-md-12" data-ng-if="CategoryList.length > 0">
                                        <dir-pagination-controls boundary-links="true"  on-page-change="ListPager.pageChanged(newPageNumber)" pagination-id="CategoryID"></dir-pagination-controls>
                                    </div>
                                    <div class="form-group col-md-12 display-none" align="center" id="nodata" data-ng-if="CategoryList.length == 0"><b>{{ trans('messages.NoCategoryRecordFound') }}</b></div>
                                </div>
                            </div>
                            <div class="form-group col-md-12 tab-pane fade" id="tab_1_2" data-ng-controller = "TagListController" ng-cloak>
                                <div class="col-md-12 no-padding">
                                    <h3 class="page-title" ng-cloak> @{{ TagModel.TestDetails.TagID > 0 ? 'Edit Tag' : 'Add Tag' }}</h3>
                                    <form name="TagForm" id="TagForm" role="form" novalidate>
                                        <div class="form-body" ng-cloak>
                                            <div class="portlet box blue-hoki" ng-cloak>
                                                <div class="portlet-title" collapse>
                                                    <div class="caption">
                                                        <i class=""></i>Details</div>
                                                    <div class="tools">
                                                        <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                                    </div>
                                                </div>
                                                <div class="portlet-body">
                                                    <div class="row">
                                                        <div class="col-md-12 no-padding">
                                                            <div class="form-group col-md-9" ng-class="{ 'has-error' : (TagForm.$submitted) && TagForm.Tag.$invalid}">
                                                                <label for="Tag" class="control-label">Tag</label>
                                                                <input class="form-control"  type="text" name="Tag" id ="Tag" ng-model="TagModel.TestDetails.Tag" ng-class="{ 'has-submitted' : TagForm.$submitted }"  maxlength="100" required/>
                                                                <div  class="help-block" ng-messages="TagForm.Tag.$error" ng-if="TagForm.$submitted">
                                                                    <div  ng-show="TagForm.Tag.$error.required  && TagForm.Tag.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Tag'))}}</div>
                                                                </div>
                                                            </div>

                                                            <div class="form-group col-md-9" ng-class="{ 'has-error' : (TagForm.$submitted) && TagForm.Slug.$invalid}">
                                                                <label for="Slug" class="control-label">Slug</label>
                                                                <input class="form-control"  type="text" id ="Slug" name="Slug" ng-model="TagModel.TestDetails.Slug" ng-class="{ 'has-submitted' : TagForm.$submitted }" is-edit=TagModel.TestDetails.TagID slug="TagModel.TestDetails.Tag" maxlength="100" required />
                                                                <div  class="help-block" ng-messages="TagForm.Slug.$error" ng-if="TagForm.$submitted">
                                                                    <div  ng-show="TagForm.Slug.$error.required  && TagForm.Slug.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Slug'))}}</div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


                                            <div class="form-actions  col-md-12">
                                                <input id="submit" name="submit" type="submit" value="Save" class="btn blue save-button" data-ng-click="AddTag()" ng-disabled="DisableButtons">
                                                <button type="button" id="cancel" class="btn default" data-ng-click="CancelTag()" ng-disabled="DisableButtons">Cancel</button>
                                            </div>

                                        </div>
                                    </form>
                                </div>
                                <div class="col-md-9 no-padding" ng-cloak>
                                    <h3 class="page-title">Tags</h3>
                                    <div data-ng-if="TagList.length > 0" class="table-responsive col-md-12" ng-cloak>
                                        <table class="table dataTable table-striped table-bordered table-hover">
                                            <thead class="site-footer">
                                            <tr>
                                                <th class="sorting" data-ng-click="TagListPager.sortColumn('Tag')" data-ng-class="{sorting_desc: (TagListPager.sortIndex === 'Tag' && !TagListPager.reverse), sorting_asc: (TagListPager.sortIndex === 'Tag' && TagListPager.reverse)}" >
                                                    Tag
                                                </th>
                                                <th>Action</th>
                                            </tr>
                                            </thead>
                                            <tbody dir-paginate="data in TagList | itemsPerPage:TagListPager.pageSize" total-items="TagListPager.totalRecords" current-page="TagListPager.currentPage" pagination-id="TagID">
                                            <tr>
                                                <td><div class="category-ellipsis"><a ng-click="EditTag(data)" title="Edit Tag" ng-model="EditTag">@{{data.Tag}}</a></div></td>
                                                <td>
                                                    <div>
                                                        <a ng-click="EditTag(data)" title="Edit Tag" ng-model="EditTag"><i class="fa fa-pencil text-default" ></i></a>
                                                        &nbsp;
                                                        <a ng-click="deleteTag(data)" title="Delete Tag" ng-model="DeleteTag"><i class="fa fa-trash-o text-danger"></i></a>
                                                    </div>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="col-md-12" data-ng-if="TagList.length > 0">
                                        <dir-pagination-controls boundary-links="true"  on-page-change="TagListPager.pageChanged(newPageNumber)" pagination-id="TagID"></dir-pagination-controls>
                                    </div>
                                    <div class="form-group col-md-12 display-none" align="center" id="TagNoData" data-ng-if="TagList.length == 0"><b>{{ trans('messages.NoTagRecordFound') }}</b></div>
                                </div>
                            </div>
                        </div>
                </div>
        </div>
    </div>
</main>
@stop
@section('script')
    {{ $minify::javascript(array('/assets/js/viewjs/category/category.js'))->withFullUrl()}}
@stop
<script>
    window.PageSize = 15;
</script>
