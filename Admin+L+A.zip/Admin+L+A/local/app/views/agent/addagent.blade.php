<?php
use Infrastructure\Constants;
use ViewModels\SessionHelper;
$minify = new \CeesVanEgmond\Minify\Facades\Minify;
$siteID = SessionHelper::getSelectedSiteID();
?>
@extends('layouts.sitemaster')
@section('Title')
    <?php if($AgentModel->AgentDetails->UserID == 0){ print 'Add Agent';}else if($AgentModel->AgentDetails->IsUpdateProfile==0 && $AgentModel->AgentDetails->UserID> 0){ print 'Edit Agent';}else{print 'Update Profile';}?>

@stop
@section('content')
    <main id="main" role="main">
        <?php echo Form::hidden('AgentModel',htmlspecialchars(json_encode($AgentModel), ENT_QUOTES, 'UTF-8'),$attributes = array('id'=>'AgentModel'));?>
        <?php echo Form::hidden('MVModel', json_encode($MVModel),$attributes = array('id'=>'MVModel')); ?>
        <?php echo Form::hidden('ListModel', json_encode($ListModel), $attributes = array('id' => 'ListModel')); ?>
        <?php //echo Form::hidden('StylisticInfluencesModel', json_encode($StylisticInfluencesModel), $attributes = array('id' => 'StylisticInfluencesModel')); ?>
        <div class="page-content">
            <div class="page-bar">
                <ul class="page-breadcrumb">
                    <li>
                        <?php if(isset($encryptedSiteID)){ ?>
                            <a href="<?php echo URL::to('/dashboard/'.$encryptedSiteID) ?>">Home</a>
                        <?php }else {?>
                            <a href="<?php echo URL::to('/choosesite') ?>">Home</a>
                        <?php }?>
                        <i class="fa fa-circle"></i>
                    </li>
                    <?php if($AgentModel->AgentDetails->IsUpdateProfile==0){ ?>
                    <li>
                        <a href="<?php echo URL::to('/agents/'.$encryptedSiteID) ?>">Agents</a>
                        <i class="fa fa-circle"></i>
                    </li>
                    <?php } ?>

                    <li>
                        <span><?php if($AgentModel->AgentDetails->UserID == 0){ print 'Add Agent';}else if($AgentModel->AgentDetails->IsUpdateProfile==0 && $AgentModel->AgentDetails->UserID> 0){ print 'Edit Agent';}else{print 'Update Profile';}?></span>
                    </li>

                </ul>
            </div>
            <h3 class="page-title"><?php if($AgentModel->AgentDetails->UserID == 0){ print 'Add Agent';}else if($AgentModel->AgentDetails->IsUpdateProfile==0 && $AgentModel->AgentDetails->UserID> 0){ print 'Edit Agent';}else{print 'Update Profile';}?></h3>
            <?php if($AgentModel->AgentDetails->UserID>0) { ?>
            <?php echo Form::hidden('TestimonialModel', json_encode($TestimonialModel),$attributes = array('id'=>'TestimonialModel')); ?>

            <?php if(isset($AgentModel->AgentDetails->SiteID)) { ?>
            <ul class="nav nav-tabs">
                <li class="active">
                    <a href="#tab_1_1" data-toggle="tab" aria-expanded="true">Overview</a>
                </li>
                <li class="">
                    <a href="#tab_1_2" data-toggle="tab" aria-expanded="false">Testimonials</a>
                </li>
                <li class="">
                    <a href="#tab_1_3" data-toggle="tab" aria-expanded="false">Listings</a>
                </li>
            <!--    <li class="">
                    <a href="#tab_1_4" data-toggle="tab" aria-expanded="false">Stylistic Influences</a>
                </li> -->
            </ul>
            <?php } ?>
            <?php } ?>

            <div class="row">
                <div class="col-md-12 no-padding">
                    <div class="tab-content">
                        <div class="tab-pane active" id="tab_1_1" ng-controller = "AgentController"  ng-cloak>
                            <div class="col-md-12">
                                <form name="AgentForm" id="AgentForm" role="form" novalidate ng-submit="checkSave(AgentForm)">
                                <div class="form-body" ng-cloak>
            <div class="portlet box blue-hoki" ng-cloak>
                <div class="portlet-title" collapse>
                    <div class="caption">
                        <i class=""></i>Details</div>
                    <div class="tools">
                        <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                    </div>
                </div>
                <div class="portlet-body">
                    <div class="row">
                        <div class="col-md-12 no-padding">
                            <div class="form-body" >
                                <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12 visible-sm visible-xs">
                                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 no-padding">
                                        <label for="WebsiteURL" class="control-label col-md-12 profile-lbl">Profile image</label>
                                    </div>
                                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 no-padding">

                                        <div class="fileinput fileinput-new">
                                            <div class="fileinput-new thumbnail image-box">
                                                <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                <img id="actualImage" alt="" src="@{{AgentModel.RealSmallerImagesPath ? AgentModel.RealSmallerImagesPath : AgentModel.NoImagePath}}">
                                            </div>
                                            <div>
                                                <form></form>
                                                <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$AgentSmallerImageType; ?>" name="FormAgentSmallerImage">
                                                    <input type="hidden" id="key" name="key" value="">
                                                    <input type="hidden" name="AWSAccessKeyId"  ng-value="AgentModel.Fileuploadsettings.accesskey">
                                                    <input type="hidden" name="acl"  ng-value="AgentModel.Fileuploadsettings.acl">
                                                    <input type="hidden" name="success_action_status"  ng-value="AgentModel.Fileuploadsettings.success_action">
                                                    <input type="hidden" name="policy"  ng-value="AgentModel.Fileuploadsettings.base64Policy">
                                                    <input type="hidden" name="signature"  ng-value="AgentModel.Fileuploadsettings.signature">
                                                    <input type="hidden" name="Cache-Control" ng-value="AgentModel.Fileuploadsettings.cacheControlTime">
                                                    <span  class="btn default btn-file" ><input type="file" name="file" id="file" title="Choose Image" required> Choose Image</span>
                                                    <a  class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$AgentSmallerImageType; ?>')" ng-hide="AgentModel.RealSmallerImagesPath ==''"> Remove </a>
                                                    <span></span>
                                                </form>
                                            </div>
                                            <span>&nbsp;</span>
                                            <div class="progress progress-striped display-none">
                                                <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                </div>
                                            </div>
                                            <div class="info-alert" ng-if="(AllowedsmallerFixHeight > 0 ) && (AllowedSmallerFixWidth > 0 )"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedSmallerFixWidth }}x@{{ AllowedsmallerFixHeight}}px</lable></div>
                                            <div ng-class="{ 'has-error' : (AgentForm.$submitted) && FormAgentSmallerImage.file.$error}" class="has-error">
                                                <div class="help-block" ng-messages="FormAgentSmallerImage.file.$error" ng-if="FormAgentSmallerImage.$submitted">
                                                    <div ng-show="FormAgentSmallerImage.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Profile image'))}}</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-8 col-lg-9 col-sm-12 col-xs-12 no-padding">
                            <div class="col-md-12 col-sm-12 col-xs-12  no-padding">
                            <div class="form-group col-md-4" ng-class="{ 'has-error' : (AgentForm.$submitted) && AgentForm.FirstName.$invalid}">
                                <label for="First Name" class="control-label">First Name</label>
                                <input class="form-control"  type="text" name="FirstName" ng-model="AgentModel.FirstName" maxlength="50" ng-class="{ 'has-submitted' : AgentForm.$submitted }" required />
                                <div  class="help-block" ng-messages="AgentForm.FirstName.$error" ng-if="AgentForm.$submitted">
                                    <div ng-show="AgentForm.FirstName.$error.required  && AgentForm.FirstName.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'First Name'))}}</div>
                                </div>
                            </div>

                            <div class="form-group col-md-4" ng-class="{ 'has-error' : (AgentForm.$submitted) && AgentForm.LastName.$invalid}">
                                <label for="First Name" class="control-label">Last Name</label>
                                <input class="form-control"  type="text" name="LastName" ng-model="AgentModel.LastName" maxlength="50" ng-class="{ 'has-submitted' : AgentForm.$submitted }" required />
                                <div  class="help-block" ng-messages="AgentForm.LastName.$error" ng-if="AgentForm.$submitted">
                                    <div  ng-show="AgentForm.LastName.$error.required  && AgentForm.LastName.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Last Name'))}}</div>
                                </div>
                            </div>
                            <div class="form-group col-md-4" ng-class="{ 'has-error' : (((AgentForm.$submitted) && AgentForm.CalBRENo.$invalid) || CalBRENoError) }" >
                                <label for="CalBRE" class="control-label">License #</label>
                                <input class="form-control"  type="text" name="CalBRENo" ng-model="AgentModel.CalBRENo" ng-class="{ 'has-submitted' : AgentForm.$submitted }" pattern="<?php echo \Infrastructure\Constants::$CalBreNoRegex;?>" minlength="8" maxlength="15" intype="alphaNumeric" data-ng-blur="CheckUniqueLicense()" />
                                <div  class="help-block" ng-messages="AgentForm.CalBRENo.$error" ng-if="(AgentForm.$submitted || CalBRENoError)">
                                    <div ng-show="CalBRENoError">{{ trans('messages.CalBreNoAlreadyExist')}}</div>
                                    <div ng-show="AgentForm.CalBRENo.$error.pattern">{{ trans('messages.InvalidCalBreNo')}}</div>
                                </div>
                            </div>

                        </div>

                        <div class="col-md-12 col-sm-12 col-xs-12  no-padding">
                            <div class="form-group col-md-4 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (AgentForm.$submitted) && AgentForm.Slug.$invalid}">
                                <label for="Slug" class="control-label">Slug</label>
                                <input class="form-control"  type="text" name="Slug" ng-model="AgentModel.Slug" is-edit=AgentModel.UserID  slug="AgentModel.FirstName + '-' + AgentModel.LastName" ng-class="{ 'has-submitted' : AgentForm.$submitted }" required />
                                <div  class="help-block" ng-messages="AgentForm.Slug.$error" ng-if="AgentForm.$submitted">
                                    <div ng-show="AgentForm.Slug.$error.required  && AgentForm.Slug.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Slug'))}}</div>
                                </div>
                            </div>

                            <div class="form-group col-md-4 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (AgentForm.$submitted) && AgentForm.AgentURL.$invalid}">
                                <label class="control-label">Agent URL</label>
                                <input class="form-control"  type="text" name="AgentURL" ng-model="AgentModel.AgentURL" maxlength="200" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>" readonly="readonly" required/>
                            <span class="error-text-color" ng-show="AgentForm.$submitted">
                                    <span ng-show="AgentForm.AgentURL.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Agent URL'))}}</span>
                                    <span ng-show="AgentForm.AgentURL.$error.pattern">{{ trans('messages.InvalidAgentUrl') }}</span>
                            </span>
                            </div>
                            <div class="form-group col-md-4 col-sm-12 col-xs-12" ng-if="AgentModel.UserID > 0">
                                <label class="control-label">Account Verified?</label><br/>
                                <p class="form-control-static" ng-if="AgentModel.IsVerified==<?php echo Constants::$IsVerified_True?>">Yes</p>
                                <p class="form-control-static" ng-if="AgentModel.IsVerified==<?php echo Constants::$IsVerified_False?>">No</p>
                            </div>
                                    </div>
                                    <div class="col-md-12 col-sm-12 col-xs-12  no-padding" >

                                    <div class="form-group col-md-4 col-sm-12 col-xs-12" ng-class="{ 'has-error' : (((AgentForm.$submitted) && AgentForm.Email.$invalid) || EmailError)}">
                                        <label for="Email" class="control-label">Email</label>
                                        <input class="form-control"  type="text" name="Email" ng-model="AgentModel.Email" pattern="<?php echo \Infrastructure\Constants::$emailRegex;?>" ng-class="{ 'has-submitted' : AgentForm.$submitted }" data-ng-blur="CheckUniqueEmail()" required />
                                        <div  class="help-block" ng-messages="AgentForm.Email.$error" ng-if="(AgentForm.$submitted || EmailError)">
                                            <div ng-show="EmailError">{{ trans('messages.EmailAlreadyExist')}}</div>
                                            <div ng-show="(AgentForm.Email.$error.required  && AgentForm.Email.$invalid) ">{{ trans('messages.PropertyRequired',array('attribute'=>'Email'))}}</div>
                                            <div ng-show="AgentForm.Email.$error.pattern">{{ trans('messages.InvalidEmail')}}</div>
                                        </div>
                                    </div>

                                        <div class="form-group col-md-4 col-sm-12 col-xs-12" ng-class="{ 'has-error' : AgentForm.Password.$invalid }" ng-if="AgentModel.UserID > 0">
                                            <label class="control-label">Password</label>
                                            <input type="password" class="form-control" ng-pattern=<?php echo \Infrastructure\Constants::$passwordRegex;?>  id="Password" name="Password"  maxlength="50" data-ng-model="AgentModel.Password" ng-required/>
                                            <span class="error-text-color" ng-show="AgentForm.Password !=''">
                                                <span  ng-show="AgentForm.$dirty && AgentForm.Password.$invalid && AgentForm.Password !=''">{{ trans('messages.PasswordRegex')}}</span>
                                            </span>
                                        </div>

                                        <div class="form-group col-md-4 col-sm-12 col-xs-12" ng-if="AgentModel.UserID > 0" ng-class="{ 'has-error' : AgentForm.ConfirmPassword.$error.pwmatch}">
                                            <label class="control-label">Confirm Password</label>
                                            <input type="password" class="form-control" id="ConfirmPassword" name="ConfirmPassword"  data-ng-model="AgentModel.ConfirmPassword" maxlength="50" ng-required pw-check="Password"/>
                                            <div class="msg-block error-text-color" ng-show="AgentForm.$error">
                                                <span class="msg-error" ng-show="AgentForm.ConfirmPassword.$error.pwmatch">{{trans('messages.PasswordDoesNotMatch')}}</span>
                                            </div>
                                        </div>
                                    </div>

                                    <?php if($siteID == \Infrastructure\Constants::$MercerVineSiteID){ ?>
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <div class="form-group col-md-2 col-sm-6 col-xs-12">
                                            <label for="IsAgent" class="radio-inline padding-bottom7px padding-left0px">
                                                <input  type="checkbox" id="IsAgent" name="IsAgent" ng-model="AgentModel.IsAgent" ng-true-value="1" ng-false-value="0" /> Agent
                                            </label>
                                        </div>

                                        <div class="form-group col-md-3 col-sm-6 col-xs-12">
                                            <label for="IsFoundingMember" class="radio-inline padding-bottom7px padding-left0px">
                                                <input  type="checkbox" id="IsFoundingMember" name="IsFoundingMember" ng-model="AgentModel.IsFoundingMember"  ng-true-value="1" ng-false-value="0" /> Founding Member
                                            </label>
                                        </div>

                                        <div class="form-group col-md-3 col-sm-6 col-xs-12">
                                            <label for="IsTeamMember" class="radio-inline padding-bottom7px padding-left0px">
                                                <input  type="checkbox" id="IsTeamMember" name="IsTeamMember" ng-model="AgentModel.IsTeamMember" ng-true-value="1" ng-false-value="0" /> Team Member
                                            </label>
                                        </div>
                                    </div>
                                   <?php }?>

                                    <div class="form-group col-md-12">
                                        <label for="Bio" class="control-label">Bio</label>
                                        <!--<textarea class="form-control" rows="4" name="Bio" ng-model="AgentModel.Bio"></textarea>-->
                                        <textarea rows="4" name="Bio" ng-model="AgentModel.Bio" ck-editor></textarea>
                                    </div>








                            <div class="col-md-12 col-sm-12 col-xs-12  no-padding">

                                <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                            <label for="Address" class="control-label">Address</label>
                                            <input class="form-control" type="text" name="Address" ng-model="AgentModel.Address"/>
                                        </div>

                                        <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                    <label for="City" class="control-label">City</label>
                                    <input class="form-control" type="text" name="City" ng-model="AgentModel.City"/>
                                </div>

                                    </div>
                                    <div class="col-md-12 col-sm-12 col-xs-12  no-padding">

                                        <div class="col-md-12 col-sm-12 col-xs-12  no-padding">

                                <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                    <label for="State" class="control-label">State</label>
                                    <select class="form-control" id="StateID" name="StateID" ng-model="AgentModel.StateID" ng-options="St.StateID as St.StateName for St in AgentModel.StateArray">
                                        <option value="">-- select --</option>
                                    </select>
                                </div>

                                <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (AgentForm.$submitted) && AgentForm.Zip.$invalid }">
                                    <label for="Zip" class="control-label">Zip</label>
                                    <input class="form-control" type="text" name="Zip" data-ng-model="AgentModel.Zip" ng-pattern="<?php echo \Infrastructure\Constants::$zipRegex; ?>" ng-class="{ 'has-submitted' : AgentForm.$submitted }"  intype="digit" maxlength="5" ng-required/>
                                    <div class="help-block" ng-show="(AgentForm.Zip !='') && ( AgentForm.$submitted )">
                                        <div ng-show="AgentForm.$dirty && AgentForm.Zip.$invalid && AgentModel.Zip != ''">{{ trans('messages.InvalidZip')}}</div>
                                    </div>
                                </div>
                                    </div>

                            <div class="col-md-12 col-sm-12 col-xs-12  no-padding">
                                <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (AgentForm.$submitted) && AgentForm.JivePhone.$invalid}">
                                    <label for="Jive Phone" class="control-label"><?php if(SessionHelper::getSelectedSiteID() != Constants::$ColoradoSiteID){?>Jive<?php }?> Phone#</label>
                                    <input class="form-control"  type="text" name="JivePhone" ng-model="AgentModel.JivePhone"  ng-class="{ 'has-submitted' : AgentForm.$submitted }"  restrict="reject" <?php if($siteID != Constants::$ColoradoSiteID) echo "clean='true'"; ?>  mask="999.999.9999" maxlength="13"  required />
                                    <div  class="help-block" ng-messages="AgentForm.JivePhone.$error" ng-if="AgentForm.$submitted">
                                        <?php if(SessionHelper::getSelectedSiteID() != Constants::$ColoradoSiteID){?>
                                        <div ng-show="AgentForm.JivePhone.$error.required  && AgentForm.JivePhone.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Jive Phone#'))}}</div>
                                        <div ng-show="AgentForm.JivePhone.$error.mask">{{ trans('messages.InvalidJivePhone')}}</div>
                                        <?php }else{?>
                                        <div ng-show="AgentForm.JivePhone.$error.required  && AgentForm.JivePhone.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Phone#'))}}</div>
                                        <div ng-show="AgentForm.JivePhone.$error.mask">{{ trans('messages.InvalidColardoPhone')}}</div>
                                        <?php }?>
                                    </div>
                                </div>

                                <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (AgentForm.$submitted) && AgentForm.Fax.$invalid}">
                                    <label for="Fax" class="control-label">Fax</label>
                                    <input class="form-control"  type="text" name="Fax"  ng-model="AgentModel.Fax" mask="999.999.9999" clean="true" restrict="reject" ng-class="{ 'has-submitted' : AgentForm.$submitted }" maxlength="13" required />
                                    <div  class="help-block" ng-messages="AgentForm.Fax.$error" ng-if="AgentForm.$submitted">
                                        <div ng-show="AgentForm.Fax.$error.required  && AgentForm.Fax.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Fax'))}}</div>
                                        <div ng-show="AgentForm.Fax.$error.mask">{{ trans('messages.InvalidFax')}}</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12  no-padding">
                                <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (AgentForm.$submitted) && AgentForm.MobilePhone.$invalid}">
                                    <label for="Mobile Phone" class="control-label">Mobile Phone#</label>
                                    <input class="form-control"  type="text" name="MobilePhone" ng-model="AgentModel.MobilePhone" ng-class="{ 'has-submitted' : AgentForm.$submitted }" mask="999.999.9999"  restrict="reject" maxlength="13" required />
                                    <div  class="help-block" ng-messages="AgentForm.MobilePhone.$error" ng-if="AgentForm.$submitted">
                                        <div ng-show="AgentForm.MobilePhone.$error.required  && AgentForm.MobilePhone.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Mobile Phone#'))}}</div>
                                        <div ng-show="AgentForm.MobilePhone.$error.mask">{{ trans('messages.InvalidMobilePhone')}}</div>
                                    </div>
                                </div>
                                <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (AgentForm.$submitted) && AgentForm.Title.$invalid}">
                                    <label for="Title" class="control-label">Title</label>
                                    <input class="form-control"  type="text" name="Title" ng-model="AgentModel.Title" maxlength="50" ng-class="{ 'has-submitted' : AgentForm.$submitted }" required />
                                    <div  class="help-block" ng-messages="AgentForm.Title.$error" ng-if="AgentForm.$submitted">
                                        <div  ng-show="AgentForm.Title.$error.required  && AgentForm.Title.$invalid ">{{ trans('messages.PropertyRequired',array('attribute'=>'Title'))}}</div>
                                    </div>
                                </div>

                            </div>

                            <div class="col-md-12 col-sm-12 col-xs-12  no-padding">
                                <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (AgentForm.$submitted) && AgentForm.FacebookName.$invalid}">
                                    <label for="FacebookName" class="control-label">Facebook URL</label>
                                    <input class="form-control" type="text" name="FacebookName" data-ng-model="AgentModel.FacebookName" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>"/>
                                    <div class="help-block" ng-if="AgentForm.$submitted">
                                        <span ng-if="AgentForm.FacebookName.$error.pattern">{{ trans('messages.InvalidFacebookURL') }}</span>
                                    </div>
                                    <span class="font13px help-block info-alert">
                                        <span class="custome-hint"><span class="bold">Example: </span>https://www.facebook.com/username</span>
                                    </span>
                                </div>

                                <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (AgentForm.$submitted) && AgentForm.LinkedInName.$invalid}">
                                    <label for="LinkedInName" class="control-label">LinkedIn URL</label>
                                    <input class="form-control" type="text" name="LinkedInName" data-ng-model="AgentModel.LinkedInName" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>"/>
                                    <div class="help-block" ng-if="AgentForm.$submitted">
                                        <span ng-if="AgentForm.LinkedInName.$error.pattern">{{ trans('messages.InvalidLinkedInURL') }}</span>
                                    </div>
                                    <span class="font13px help-block info-alert">
                                        <span class="custome-hint"><span class="bold">Example: </span>https://www.linkedin.com/in/username</span>
                                    </span>
                                </div>

                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12  no-padding">
                                <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (AgentForm.$submitted) && AgentForm.TwitterName.$invalid}">
                                    <label for="TwitterName" class="control-label">Twitter URL</label>
                                    <input class="form-control" type="text" name="TwitterName" data-ng-model="AgentModel.TwitterName" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>"/>
                                    <div class="help-block" ng-if="AgentForm.$submitted">
                                        <span ng-if="AgentForm.TwitterName.$error.pattern">{{ trans('messages.InvalidTwitterURL') }}</span>
                                    </div>
                                    <span class="font13px help-block info-alert">
                                        <span class="custome-hint"><span class="bold">Example: </span>https://twitter.com/username</span>
                                    </span>
                                </div>

                                <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (AgentForm.$submitted) && AgentForm.InstagramName.$invalid}">
                                    <label for="InstagramName" class="control-label">Instagram URL</label>
                                    <input class="form-control" type="text" name="InstagramName" data-ng-model="AgentModel.InstagramName" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>"/>
                                    <div class="help-block" ng-if="AgentForm.$submitted">
                                        <span ng-if="AgentForm.InstagramName.$error.pattern">{{ trans('messages.InvalidInstagramURL') }}</span>
                                    </div>
                                    <span class="font13px help-block info-alert">
                                        <span class="custome-hint"><span class="bold">Example: </span>http://Instagram.com/username</span>
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12  no-padding">
                                <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (AgentForm.$submitted) && AgentForm.YoutubeName.$invalid }">
                                    <label for="YoutubeName" class="control-label">YouTube URL</label>
                                    <input class="form-control" type="text" name="YoutubeName" data-ng-model="AgentModel.YoutubeName" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>"/>
                                    <div class="help-block" ng-if="AgentForm.$submitted">
                                        <span ng-if="AgentForm.YoutubeName.$error.pattern">{{ trans('messages.InvalidYoutubeURL') }}</span>
                                    </div>
                                    <span class="font13px help-block info-alert">
                                        <span class="custome-hint"><span class="bold">Example: </span>https://www.youtube.com/user/username</span>
                                    </span>
                                </div>

                                <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (AgentForm.$submitted) && AgentForm.SnapchatName.$invalid }">
                                    <label for="SnapchatName" class="control-label">SnapChat URL</label>
                                    <input class="form-control" type="text" name="SnapchatName" data-ng-model="AgentModel.SnapchatName" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>" />
                                    <div class="help-block" ng-if="AgentForm.$submitted">
                                        <span ng-if="AgentForm.SnapchatName.$error.pattern">{{ trans('messages.InvalidSnapChatURL') }}</span>
                                    </div>
                                    <span class="font13px help-block info-alert">
                                        <span class="custome-hint"><span class="bold">Example: </span>http://www.snapchat.com/add/username</span>
                                    </span>
                                </div>

                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12  no-padding">
                                <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (AgentForm.$submitted) && AgentForm.PinterestName.$invalid }">
                                    <label for="PinterestName" class="control-label">Pinterest URL</label>
                                    <input class="form-control" type="text" name="PinterestName" data-ng-model="AgentModel.PinterestName" pattern="<?php echo Constants::$WebsiteUrlRegex; ?>"/>
                                    <div class="help-block" ng-if="AgentForm.$submitted">
                                        <span ng-if="AgentForm.PinterestName.$error.pattern">{{ trans('messages.InvalidPinterestURL') }}</span>
                                    </div>
                                    <span class="font13px help-block info-alert">
                                        <span class="custome-hint"><span class="bold custome-hint">Example: </span>http://www.pinterest.com/username</span>
                                    </span>
                                </div>

                                <div class="form-group col-md-6 col-sm-6 col-xs-12" ng-class="{ 'has-error' : (AgentForm.$submitted) && AgentForm.WebsiteURL.$invalid }">
                                    <label for="WebsiteURL" class="control-label">Website URL</label>
                                    <input class="form-control" type="text" name="WebsiteURL" data-ng-model="AgentModel.WebsiteURL" pattern="<?php echo \Infrastructure\Constants::$WebsiteUrlRegex; ?>" ng-class="{ 'has-submitted' : AgentForm.$submitted }"  ng-required/>
                                    <div class="help-block" ng-show="(AgentForm.PinterestName !='') && ( AgentForm.$submitted )">
                                        <div ng-show="AgentForm.$dirty && AgentForm.WebsiteURL.$invalid && AgentModel.WebsiteURL != ''">{{ trans('messages.InvalidWebsiteUrl')}}</div>
                                    </div>
                                </div>
                            </div>

                        </div>
                             </div>
                                <div class="col-md-4 col-lg-3 col-sm-12 col-xs-12 hidden-sm hidden-xs">
                                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 no-padding">
                                        <label for="WebsiteURL" class="control-label profile-lbl">Profile image</label>
                                        <div class="fileinput fileinput-new">
                                            <div class="fileinput-new thumbnail image-box">
                                                <img  src="<?php echo asset('/assets/images/ajax-loader1.gif'); ?>" id="loadingImage" class="display-none loadingImage">
                                                <img id="actualImage" alt="" src="@{{AgentModel.RealSmallerImagesPath ? AgentModel.RealSmallerImagesPath : AgentModel.NoImagePath}}">
                                            </div>
                                            <div>
                                                <form></form>
                                                <form method="POST" id="directupload" enctype="multipart/form-data" class="direct-upload" img-type="<?php echo  Constants::$AgentSmallerImageType; ?>" name="FormAgentSmallerImage" role="form" novalidate>
                                                    <input type="hidden" id="key" name="key" value="">
                                                    <input type="hidden" name="AWSAccessKeyId"  ng-value="AgentModel.Fileuploadsettings.accesskey">
                                                    <input type="hidden" name="acl"  ng-value="AgentModel.Fileuploadsettings.acl">
                                                    <input type="hidden" name="success_action_status"  ng-value="AgentModel.Fileuploadsettings.success_action">
                                                    <input type="hidden" name="policy"  ng-value="AgentModel.Fileuploadsettings.base64Policy">
                                                    <input type="hidden" name="signature"  ng-value="AgentModel.Fileuploadsettings.signature">
                                                    <input type="hidden" name="Cache-Control" ng-value="AgentModel.Fileuploadsettings.cacheControlTime">
                                                    <span  class="btn default btn-file" ><input type="file" name="file" id="file" title="Choose Image" ng-model="AgentModel.RealSmallerImagesPath" required> Choose Image</span>
                                                    <a  class="btn red" href="javascript:void(0);" data-ng-click="RemoveImage('<?php echo  Constants::$AgentSmallerImageType; ?>')" ng-hide="AgentModel.RealSmallerImagesPath ==''"> Remove </a>
                                                    <span></span>
                                                </form>
                                            </div>
                                            <span>&nbsp;</span>
                                            <div class="progress progress-striped display-none">
                                                <div class="progress-bar bar progress-bar-success bg-green-jungle" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                                </div>
                                            </div>
                                            <div class="info-alert" ng-if="(AllowedsmallerFixHeight > 0 ) && (AllowedSmallerFixWidth > 0 )"><lable>{{ trans('messages.ImageRecommendedDimensionsMessage')}} @{{ AllowedSmallerFixWidth }}x@{{ AllowedsmallerFixHeight }}px</lable></div>
                                            <div ng-class="{ 'has-error' : (AgentForm.$submitted) && FormAgentSmallerImage.file.$error}" class="has-error">
                                                <div class="help-block" ng-messages="FormAgentSmallerImage.file.$error" ng-if="AgentForm.$submitted">
                                                    <div ng-show="FormAgentSmallerImage.file.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Profile image'))}}</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                                    <div class="col-md-12 no-padding">
                                                    <input id="btn-submit" name="submit" type="submit" value="Save" class="btn blue save-button" data-ng-click="AddAgent()" ng-disabled="DisableButtons || (responseCounter != requestCounter)">
                                                    <button  type="button" id="cancel" class="btn default" data-ng-click="Cancel()" ng-disabled="DisableButtons || (responseCounter != requestCounter)">Cancel</button>
                                                </div>
                                            </div>
                                    </form>
                                </div>
                        </div>
                                <?php if($AgentModel->AgentDetails->UserID>0) { ?>
                                 <div class="form-group col-md-12 tab-pane fade" id="tab_1_2" data-ng-controller="TestimonialController" ng-clock>
                            <div>
                                        <!-- BEGIN PAGE TITLE-->
                                        <h4 class="page-title">
                                            @{{ TestimonialModel.TestDetails.TestimonialID > 0 ? 'Edit Testimonial' : 'Add Testimonial' }}
                                        </h4>
                                        <!-- END PAGE TITLE-->
                                        <!-- BEGIN Form Design-->
                                        <div class="row">
                                            <div class="col-md-12">
                                                <!-- BEGIN SAMPLE FORM PORTLET-->
                                                <form name="TestimonialForm" id="TestimonialForm" role="form" novalidate>
                                                    <div class="form-body"  ng-cloak>
                                                <div class="portlet box blue-hoki" ng-cloak>
                                                    <div class="portlet-title" collapse>
                                                        <div class="caption">
                                                            <i class=""></i>Details</div>
                                                        <div class="tools">
                                                            <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                                        </div>
                                                    </div>
                                                    <div class="portlet-body">
                                                        <div class="row">
                                                            <div class="col-md-12 no-padding">
                                                                <div class="form-body" >
                                                        <div class="col-md-9  no-padding">
                                                            <div class="col-md-12  no-padding">
                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12"  ng-class="{ 'has-error' : (TestimonialForm.$submitted) && TestimonialForm.Testimonial.$invalid}">
                                                                    <label for="Testimonial" class="control-label">Testimonial</label>
                                                                    <textarea rows="4" class="form-control" name="Testimonial" id="Testimonial" data-ng-model="TestimonialModel.TestDetails.Testimonial" data-ng-class="{'has-submitted' : TestimonialForm.$submitted }" required autofocus="autofocus"></textarea>
                                                                <span class="error-text-color" ng-show="TestimonialForm.$submitted">
                                                                    <span ng-show="TestimonialForm.Testimonial.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Testimonial'))}}</span>
                                                                </span>
                                                                </div>
                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                    <label for="Attribution" class="control-label">Attribution</label>
                                                                    <input class="form-control"  type="text" name="Attribution" id="Attribution" data-ng-model="TestimonialModel.TestDetails.Attribution" maxlength="150"/>
                                                                </div>
                                                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                                                    <label for="IsVisible" class="control-label">Visible</label>
                                                                    <input type="checkbox" ng-model="TestimonialModel.TestDetails.IsVisible" ng-true-value="1" ng-false-value="0"/>
                                                                </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                           </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12 no-padding">
                                                        <input id="submit" name="submit" type="submit" value="Save" class="btn blue save-button" data-ng-click="Save()"  ng-disabled="DisableButtons">
                                                        <input  type="button" id="cancel" class="btn default" data-ng-click="Cancel(data)" value="Cancel" ng-disabled="DisableButtons">
                                                    </div>
                                                </div>
                                                </form>
                                            </div>
                                        </div>
                                        <!-- END DASHBOARD STATS 1-->
                                        <br/>
                                        <br/>
                                        <h4 class="page-title">
                                            Testimonials
                                        </h4>
                                        <div class="">
                                            <div class="col-md-12">
                                                <!-- BEGIN SAMPLE FORM PORTLET-->
                                                <div data-ng-if="TestimonialModel.TestimonialListArray.length > 0" class="table-scrollable sortable" ng-cloak>
                                                    <div>
                                                        <table class="table table-striped table-bordered table-hover" sortable-list="TestimonialModel.TestimonialListArray"  sortable-reset-width="true" sortable-callback="updateSortOrder">
                                                            <thead class="">
                                                            <tr role="row">
                                                                <th ng-if="TestimonialModel.TestimonialListArray.length>1">
                                                                    <span class=""></span>
                                                                </th>
                                                                <th><span class="">Testimonial</span></th>
                                                                <th><span class="">Attribution</span></th>
                                                                <th><span class="">Visible</span></th>
                                                                <th>Action</th>
                                                            </tr>
                                                            </thead>
                                                            <tbody class="drag-faq-list">
                                                            <tr data-ng-repeat="item in TestimonialModel.TestimonialListArray" class="sortable-row" role="row">
                                                                <td class="sortable-handle" data-ng-if="TestimonialModel.TestimonialListArray.length > 1" >
                                                                        <span class="draggable-icon-arrow">
                                                                            <i class="fa fa-bars draggable-icon"></i>
                                                                            <i class="fa fa-arrows-alt draggable-icon"></i>
                                                                        </span>
                                                                </td>
                                                                <td>
                                                                    <div class="faq-ellipsis">@{{item.Testimonial}}</div>
                                                                </td>
                                                                <td>
                                                                    <div class="faq-ellipsis">@{{item.Attribution}}</div>
                                                                </td>
                                                                <td>@{{item.VisibleText}}</td>
                                                                <td class="faq-action-part vertical-align">
                                                                    <div>
                                                                        <a ng-click="EditTestimonial(item)" title="Edit Testimonial">
                                                                            <i class="fa fa-pencil text-default"></i>
                                                                        </a>
                                                                        &nbsp;
                                                                        <a ng-click="DeleteTestimonial(item)" title="Delete Testimonial">
                                                                            <i class="fa fa-trash-o text-danger"></i>
                                                                        </a>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                <div class="form-group col-md-12"  align="center" data-ng-if="TestimonialModel.TestimonialListArray.length == 0">
                                                    <b>{{ trans('messages.NoTestimonialFound') }}</b>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                 <div class="form-group col-md-12 tab-pane fade" id="tab_1_3">
                                    <div data-ng-controller="PropertyListController">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <h4 class="page-title ng-binding">Listings</h4>
                                                <form>
                                                    <div class="form-body" ng-cloak>
                                                        <div class="form-group col-md-3">
                                                            <label for="MLSNo" class="control-label">MLS#</label>
                                                            <input type="text" class="form-control" data-ng-model="ListModel.frontSearchModel.MLSNo" id="MLSNo" name="MLSNo" maxlength="20" intype="alphaNumeric">
                                                        </div>
                                                        <div class="form-group col-md-3">
                                                            <label for="Status" class="control-label">Status</label>
                                                            <select class="form-control" id="Status" name="Status" data-ng-model="ListModel.frontSearchModel.StatusID">
                                                                <option value="-1">All</option>
                                                                <option ng-repeat="data in ListModel.StatusLookup" value="@{{data.StatusID}}">@{{data.Status}}</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-md-2">
                                                            <div class="search-label-hidden"><label for="Date From" class="control-label">&nbsp;</label></div>
                                                            <input id="checkbox" type="checkbox"  data-ng-model="ListModel.frontSearchModel.IsFeatured" id="IsFeatured" name="IsFeatured" >
                                                            <label for="IsFeatured"> Featured</label>
                                                        </div>
                                                        <div class="form-group col-md-2">
                                                            <div class="search-label-hidden"><label class="control-label">&nbsp;</label></div>
                                                            <button data-ng-click="SearchPropertyRecords()" class="btn blue btn-search">Search</button>
                                                        </div>

                                                    </div>
                                                </form>

                                                <div data-ng-if="PropertyList.length > 0" class="table-responsive col-md-12" ng-cloak>
                                                    <table class="table dataTable table-striped table-bordered table-hover">
                                                        <thead class="site-footer">
                                                        <tr>
                                                            <th class="agent-featured">Featured</th>
                                                            <th class="sorting agent-Street" data-ng-click="ListPager.sortColumn('Street')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'Street' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'SquareFeet' && !ListPager.reverse)}" >
                                                                Street
                                                            </th>
                                                            <th class="sorting agent-mls" data-ng-click="ListPager.sortColumn('MLSNo')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'MLSNo' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'MLSNo' && !ListPager.reverse)}" >
                                                                MLS#
                                                            </th>
                                                            <th class="sorting agent-square-feet" data-ng-click="ListPager.sortColumn('SquareFeet')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'SquareFeet' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'SquareFeet' && !ListPager.reverse)}" >
                                                                Square Feet
                                                            </th>
                                                            <th class="sorting" data-ng-click="ListPager.sortColumn('NoOfBeds')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'NoOfBeds' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'NoOfBeds' && !ListPager.reverse)}" >
                                                                Beds
                                                            </th>

                                                            <th class="sorting" data-ng-click="ListPager.sortColumn('NoOfFullBaths')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'NoOfFullBaths' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'NoOfFullBaths' && !ListPager.reverse)}" >
                                                                Baths
                                                            </th>
                                                            <th class="sorting" data-ng-click="ListPager.sortColumn('Price')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'Price' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'Price' && !ListPager.reverse)}" >
                                                                Price
                                                            </th>
                                                            <th class="sorting" data-ng-click="ListPager.sortColumn('StatusID')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'StatusID' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'StatusID' && !ListPager.reverse)}" >
                                                                Status
                                                            </th>

                                                        </tr>
                                                        </thead>
                                                        <tbody dir-paginate="data in PropertyList | itemsPerPage:ListPager.pageSize" total-items="ListPager.totalRecords" current-page="ListPager.currentPage" pagination-id="ListingID">
                                                        <tr>
                                                            <td><input type="checkbox" data-ng-model="data.IsFeatured" ng-change="FeaturedChange(data)" ng-true-value="1" ng-false-value="0"></td>
                                                            <td>@{{data.Street}}</td>
                                                            <td>@{{data.MLSNo}}</td>
                                                            <td>@{{data.SquareFeet}}</td>
                                                            <td>@{{data.NoOfBeds}}</td>
                                                            <td>@{{data.NoOfFullBaths}}</td>
                                                            <td>@{{data.Price}}</td>
                                                            <td>@{{data.Status}}</td>
                                                        </tr>
                                                        </tbody>
                                                    </table>
                                                </div>

                                                <div class="col-md-12" data-ng-if="PropertyList.length > 0">
                                                    <dir-pagination-controls boundary-links="true"  on-page-change="ListPager.pageChanged(newPageNumber)" pagination-id="ListingID">
                                                    </dir-pagination-controls>
                                                </div>

                                                <div class="form-group col-md-12 display-none"  align="center" id="nodata">
                                                    <b>{{ trans('messages.NoPropertyRecordFound') }}</b>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- <div class="form-group col-md-12 tab-pane fade" id="tab_1_4" data-ng-controller="StylisticInfluencesController" ng-clock>
                                <div>
                                <!-- BEGIN PAGE TITLE-->
                        <!--<h4 class="page-title" ng-clock>
                                    @{{ StylisticInfluencesModel.TestDetails.StylisticInfluencesID > 0 ? 'Edit Stylistic influence' : 'Add Stylistic influence' }}
                                </h4>
                                <!-- END PAGE TITLE-->
                                <!-- BEGIN Form Design-->
                        <!--    <div class="row">
                                <div class="col-md-12">
                                    <!-- BEGIN SAMPLE FORM PORTLET-->
                        <!--            <form name="StylisticInfluencesForm" id="StylisticInfluencesForm" role="form" novalidate>
                                            <div class="form-body"  ng-cloak>
                                                <div class="portlet box blue-hoki" ng-cloak>
                                                    <div class="portlet-title" collapse>
                                                        <div class="caption">
                                                            <i class=""></i>Details</div>
                                                        <div class="tools">
                                                            <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                                        </div>
                                                    </div>
                                                    <div class="portlet-body">
                                                        <div class="row">
                                                            <div class="col-md-12 no-padding">
                                                                <div class="form-body" >
                                                                    <div class="col-md-9  no-padding">
                                                                        <div class="col-md-12  no-padding">
                                                                            <div class="form-group col-md-12 col-sm-12 col-xs-12"  ng-class="{ 'has-error' : (StylisticInfluencesForm.$submitted) && StylisticInfluencesForm.StylisticInfluences.$invalid}">
                                                                                <label for="Stylistic Influence" class="control-label">Stylistic Influence</label>
                                                                                <textarea rows="4" class="form-control" name="StylisticInfluences" id="StylisticInfluences" data-ng-model="StylisticInfluencesModel.TestDetails.StylisticInfluences" data-ng-class="{'has-submitted' : StylisticInfluencesForm.$submitted }" required autofocus="autofocus"></textarea>
                                                                                <span class="error-text-color" ng-show="StylisticInfluencesForm.$submitted">
                                                                                    <span ng-show="StylisticInfluencesForm.StylisticInfluences.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Stylistic Influence'))}}</span>
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12 no-padding">
                                                    <input id="submit" name="submit" type="submit" value="Save" class="btn blue save-button" data-ng-click="Save()" ng-disabled="DisableButtons">
                                                    <input  type="button" id="cancel" class="btn default" data-ng-click="Cancel()" value="Cancel" ng-disabled="DisableButtons">
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <!-- END DASHBOARD STATS 1-->
                        <!--      <br/>
                                <br/>
                                <h4 class="page-title">
                                    Stylistic influences
                                </h4>
                                <div class="col-md-12 no-padding">
                                    <div data-ng-if="StylisticInfluencesListArray.length > 0" class="table-scrollable sortablestylisticinfluences" ng-cloak>
                                        <div>
                                            <table class="table table-striped table-bordered table-hover" sortable-list="StylisticInfluencesListArray" sortable-callback="updateSortOrder" sortable-containment='sortablestylisticinfluences'>
                                                <thead class="site-footer">
                                                <tr role="row">
                                                    <th data-ng-if="StylisticInfluencesListArray.length > 1"><span class="anchor_color vertical-align"></span></th>
                                                    <th class="vertical-align"><span class="anchor_color">Stylistic Influence</span></th>
                                                    <th class="vertical-align">Action</th>
                                                </tr>
                                                </thead>
                                                <tbody class="drag-faq-list">
                                                <tr ng-repeat="item in StylisticInfluencesListArray" class="sortable-row" role="row" ng-clock>
                                                    <td class="sortable-handle vertical-align" data-ng-if="StylisticInfluencesListArray.length > 1" ng-clock>
                                                        <span class="draggable-icon-arrow">
                                                            <i class="fa fa-bars draggable-icon"></i>
                                                            <i class="fa fa-arrows-alt draggable-icon"></i>
                                                        </span>
                                                    </td>
                                                    <td class="vertical-align"><div class="stylistic-influences-ellipsis"><a ng-click="EditStylisticInfluences(item)"  title="Edit StylisticInfluences" ng-model="EditStylisticInfluences">@{{item.StylisticInfluences}}</a></div></td>
                                                    <td class="faq-action-part vertical-align">
                                                        <div>
                                                            <a ng-click="EditStylisticInfluences(item)"  title="Edit Stylistic Influences" ng-model="EditStylisticInfluences"><i class="fa fa-pencil text-default" ></i></a>
                                                            &nbsp;
                                                            <a ng-click="deleteStylisticInfluences(item)" title="Delete Stylistic Influences" ng-model="DeleteStylisticInfluences"><i class="fa fa-trash-o text-danger"></i></a>
                                                        </div>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-12 display-none" align="center" id="stylisticinfluencesnodata">
                                        <b><b>{{ trans('messages.NoStylisticInfluencesRecordFound') }}</b></b>
                                    </div>
                                </div>

                            </div>
                        </div>  -->
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
    </main>
@stop

@section('script')
    {{ $minify::javascript(array('/assets/js/viewjs/agent/addagent.js',
                               // '/assets/js/ckeditor/ckeditor.js',
                                '/assets/js/library/jquery.fileupload/jquery.ui.widget.js',
                                '/assets/js/library/jquery.fileupload/jquery.fileupload.js',
                                '/assets/js/library/binaryajax.js',
                                '/assets/js/library/exif.js',
                                '/assets/js/library/bootstrap-fileinput.js',
                                '/assets/js/sitejs/canvasResize.js',
                                '/assets/js/sitejs/jquery-ui-1.9.2.custom.min.js',
                                '/assets/js/sitejs/jquery.ui.touch-punch.min.js'
                                ))->withFullUrl()}}
    <script src="{{asset('/assets/js/ckeditor/ckeditor.js')}}" defer></script>
    <script>
        window.ImageFileAllowedMessage ="{{ trans('messages.ImageFileAllowedMessage')}}";
        window.ConfirmUploadMessage ="{{ trans('messages.ConfirmUploadMessage')}}";
        window.DefaultUploadPhotoHeight='<?php echo Constants::$DefaultUploadProfileHeight;?>';
        window.DefaultUploadPhotoWidth='<?php echo Constants::$DefaultUploadProfileWidth?>';
        window.NoImagePath = '<?php echo asset('/assets/images/no-user.png') ?>';
        window.ProfileImage = "{{ trans('messages.ProfileImage')}}";
        window.AgentType = "{{ trans('messages.AgentType')}}";
        window.AgentProfileImageType='<?php echo Constants::$AgentProfileImageType;?>';
        window.AgentSmallerImageType='<?php echo Constants::$AgentSmallerImageType;?>';
        window.MercerVineSiteID='<?php echo Constants::$MercerVineSiteID;?>';
    </script>
@stop