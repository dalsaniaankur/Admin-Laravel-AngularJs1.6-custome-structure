<?php
use Infrastructure\Constants;
$minify = new \CeesVanEgmond\Minify\Facades\Minify;
?>
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html  lang="en" ng-app="App">
<!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
    <meta charset="utf-8" />
    <title><?php echo Constants::$projectNameTitle;?>@yield('Title')</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta content="" name="description" />
    <meta content="" name="author" />

    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />
    <link href="<?php echo asset('/assets/fonts/font-awesome/css/font-awesome.min.css');?>" rel="stylesheet" type='text/css'>

    {{ $minify::stylesheet(array('/assets/js/library/simple-line-icons/simple-line-icons.min.css',
                                 '/assets/js/library/bootstrap/css/bootstrap.min.css',
                                 '/assets/js/library/uniform/css/uniform.default.css',
                                 '/assets/css/msgbox/msgGrowl.css',
                                 '/assets/css/components-md.min.css',
                                 '/assets/css/plugins-md.min.css',
                                 '/assets/css/layout.min.css',
                                 '/assets/css/default.min.css',
                                 '/assets/css/custom.css'))->withFullUrl()}}

    <link rel="icon" href="<?php echo asset('/assets/images/favicon.ico');?>" type="image/x-icon" />
    @yield('css')
</head>

<body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white page-md">

<span data-us-spinner="{radius:30, width:8, length: 16,scale:0.5}" class="loading-ui-block"> </span>
<!-- BEGIN HEADER -->
<div class="page-header navbar navbar-fixed-top">
    <!-- BEGIN HEADER INNER -->
    <div class="page-header-inner ">
        <!-- BEGIN LOGO -->
        <div class="page-logo">
            <a href="#">
                <img src="<?php echo asset('/assets/images/wb_logo.png'); ?>" alt="logo" class="logo-default" /> </a>

        </div>
        <!-- END LOGO -->

        <!-- BEGIN TOP NAVIGATION MENU -->
        <div class="top-menu">
            <ul class="nav navbar-nav pull-right">

                <!-- BEGIN USER LOGIN DROPDOWN -->
                <!-- DOC: Apply "dropdown-dark" class after below "dropdown-extended" to change the dropdown styte -->
                <li class="dropdown dropdown-user">
                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                        <!--<img alt="" class="img-circle" src="<?php echo asset('/assets/images/avatar3_small.jpg'); ?>" />-->
                        <span class="username">{{ @Auth::User()->FirstName }}</span>
                        <i class="fa fa-angle-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-default">
                        <li>
                            <a href="<?php echo URL::to('/updateprofile'); ?>">
                                <i class="icon-user"></i> My Profile </a>
                        </li>

                        <!--<li class="divider"> </li>-->

                        <li>
                            <a href="<?php echo URL::to('/').'/logout'; ?>">
                                <i class="icon-key"></i> Log Out </a>
                        </li>
                    </ul>
                </li>
                <!-- END USER LOGIN DROPDOWN -->
            </ul>
        </div>
        <!-- END TOP NAVIGATION MENU -->
    </div>
    <!-- END HEADER INNER -->
</div>
<!-- END HEADER -->
<!-- BEGIN HEADER & CONTENT DIVIDER -->
<div class="clearfix"> </div>
<!-- END HEADER & CONTENT DIVIDER -->
<!-- BEGIN HEADER & CONTENT DIVIDER -->
<div class="clearfix"> </div>
<!-- END HEADER & CONTENT DIVIDER -->
<!-- BEGIN CONTAINER -->
<div class="page-container">
    <!-- BEGIN SIDEBAR -->
    <!-- END SIDEBAR -->
    <!-- BEGIN CONTENT -->
    <div class="">
        @yield('content')
    </div>
    <!-- END CONTENT -->
</div>
<!-- END CONTAINER -->
<!-- BEGIN FOOTER -->
<div class="page-footer ">
    <div class="page-footer-inner"><?php echo Constants::$footerText;?>
    </div>
    <div class="scroll-to-top">
        <i class="icon-arrow-up"></i>
    </div>
</div>
<!-- END FOOTER -->

<script type="text/javascript">
    window.baseUrl = "<?php echo URL::to('/')?>";
</script>

<!--[if lt IE 9]>
{{ $minify::javascript(array('/assets/js/library/respond.min.js',
                             '/assets/js/library/excanvas.min.js'))->withFullUrl()}}
<![endif]-->

{{ $minify::javascript(array('/assets/js/library/jquery.min.js',
                             '/assets/js/library/bootstrap/js/bootstrap.min.js',
                             '/assets/js/sitejs/global_app.min.js',
                             '/assets/js/sitejs/layout.min.js',
                             '/assets/js/sitejs/demo.min.js',
                             '/assets/js/library/quick-sidebar.min.js',
                             '/assets/js/sitejs/jquery.cookie.js',
                             '/assets/js/sitejs/moment.js',
                             '/assets/js/library/datetimepicker/bootstrap-datetimepicker.js',
                             '/assets/js/library/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js',
                             '/assets/js/library/jquery-slimscroll/jquery.slimscroll.min.js',
                             '/assets/js/library/jquery.blockui.min.js',
                             '/assets/js/library/uniform/jquery.uniform.min.js',
                             '/assets/js/sitejs/msgGrowl.js',
                             '/assets/js/sitejs/angularjs/angular.min.js',
                             '/assets/js/library/dirPagination.js',
                             '/assets/js/sitejs/ng-tags-input.min.js',
                             '/assets/js/sitejs/angularjs/app.js',
                             '/assets/js/sitejs/angularjs/angular-loading-spinner.js',
                             '/assets/js/sitejs/angularjs/angular-spinner.js',
                             '/assets/js/sitejs/angularjs/spin.js',
                             '/assets/js/library/bootstrap-dialog.js',
                             '/assets/js/viewjs/common.js'))->withFullUrl()}}
                             {{ $minify::javascript(array('/assets/js/sitejs/angularjs/clipboard.min.js','/assets/js/sitejs/angularjs/ngclipboard.min.js'))->withFullUrl()}}

{{ $minify::javascript(array('/assets/js/viewjs/directive.js'))->withFullUrl()}}

<script type="text/javascript">
    window.ConfirmDialogTitle ="{{ trans('messages.ConfirmDialogTitle')}}";
    window.Confirmdialogmessage ="{{ trans('messages.Confirmdialogmessage')}}";
    window.ConfirmDialogSomethingWrong ="{{ trans('messages.ConfirmDialogSomethingWrong')}}";
    window.PageSize = "<?php echo Constants::$UserPagerSize; ?>";
    $(window).load(function(){
        $('.page-footer').show();
    });

</script>
<!-- footer error section start -->
<?php $showFooterError = Config::get('config.ShowFooterError');
if($showFooterError){ ?>
@yield('footer_error')
<?php } ?>
        <!-- footer error section stop -->
@yield('script')

</body>
</html>
