<?php
use Infrastructure\Constants; // For get value of Pagination PageSize and set per page records from server side when page load
$minify = new \CeesVanEgmond\Minify\Facades\Minify;
?>

<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en" ng-app="App">
<!--<![endif]-->
<!-- BEGIN HEAD -->

<head>
    <meta charset="utf-8" />
    <title> <?Php echo Constants::$projectNameTitle;?> | @yield('Title')</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta content="" name="description" />
    <meta content="" name="author" />

    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />

    <link href="<?php echo asset('/assets/fonts/font-awesome/css/font-awesome.min.css');?>" rel="stylesheet" type='text/css'>
    <link href="<?php echo asset('/assets/fonts/simple-line-icons/simple-line-icons.min.css');?>" rel="stylesheet" type='text/css'>

    {{ $minify::stylesheet(array('/assets/js/library/simple-line-icons/simple-line-icons.min.css',
                                 '/assets/js/library/bootstrap/css/bootstrap.min.css',
                                 '/assets/js/library/uniform/css/uniform.default.css',
                                 '/assets/js/library/bootstrap-switch/css/bootstrap-switch.min.css',
                                 '/assets/css/msgbox/msgGrowl.css',
                                 '/assets/css/components-md.min.css',
                                 '/assets/css/plugins-md.min.css',
                                 '/assets/css/login.min.css',
                                 '/assets/css/custom.css'))->withFullUrl()}}

    <!-- BEGIN PAGE LEVEL PLUGINS
    <link href="<?php echo asset('/assets/global/plugins/select2/css/select2.min.css" rel="stylesheet');?>" type="text/css" />
    <link href="<?php echo asset('/assets/global/plugins/select2/css/select2-bootstrap.min.css');?>" rel="stylesheet" type="text/css" />-->
    <!-- END PAGE LEVEL PLUGINS -->

    <link rel="icon" href="<?php echo asset('/assets/images/favicon.ico');?>" type="image/x-icon" />
    </head>
<!-- END HEAD -->

<body class=" login">
<span data-us-spinner="{radius:30, width:8, length: 16,scale:0.5}" class="loading-ui-block"> </span>
<!-- BEGIN LOGO -->
<div class="logo">
    <a href="#">
        <img src="<?php echo asset('/assets/images/woodbridge-logo-login-page.png'); ?>" alt="logo"/> </a>
</div>
<!-- END LOGO -->

<!-- BEGIN LOGIN -->
<div class="content page-content">
    <div>
    @yield('content')
    </div>
</div>

<div class="copyright lithyem-logo"><?php echo Constants::$footerText;?></div>
<div class="lithyem-logo"><a href="http://lithyem.net" target="_blank"><img src="{{asset('assets/images/lithyem-logo.png')}}"></a></div>

<!--[if lt IE 9]>
{{ $minify::javascript(array('/assets/js/library/respond.min.js',
                            '/assets/js/library/excanvas.min.js'))->withFullUrl()}}
<![endif]-->

<script type="text/javascript">
    window.baseUrl = "<?php echo URL::to('/')?>";
</script>

{{ $minify::javascript(array('/assets/js/library/jquery.min.js',
                             '/assets/js/library/bootstrap/js/bootstrap.min.js',
                             '/assets/js/sitejs/jquery.cookie.js',
                             '/assets/js/sitejs/moment.js',
                             '/assets/js/library/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js',
                             '/assets/js/library/jquery-slimscroll/jquery.slimscroll.min.js',
                             '/assets/js/library/jquery.blockui.min.js',
                             '/assets/js/library/uniform/jquery.uniform.min.js',
                             '/assets/js/sitejs/msgGrowl.js',
                             '/assets/js/sitejs/angularjs/angular.min.js',
                             '/assets/js/sitejs/angularjs/applogin.js',
                             '/assets/js/sitejs/angularjs/angular-loading-spinner.js',
                             '/assets/js/sitejs/angularjs/angular-spinner.js',
                             '/assets/js/sitejs/angularjs/spin.js',
                             '/assets/js/library/bootstrap-dialog.js',
                             '/assets/js/viewjs/common.js'))->withFullUrl()}}

<!--<script src="//ajax.googleapis.com/ajax/libs/angularjs/1.5.0/angular-messages.js"></script>-->

<script type="text/javascript">
    window.ConfirmDialogTitle ="{{ trans('messages.ConfirmDialogTitle')}}";
    window.Confirmdialogmessage ="{{ trans('messages.Confirmdialogmessage')}}";
    window.ConfirmDialogSomethingWrong ="{{ trans('messages.ConfirmDialogSomethingWrong')}}";
    window.PageSize = "<?php echo Constants::$UserPagerSize; ?>";
</script>
<!-- footer error section start -->
<?php $showFooterError = Config::get('config.ShowFooterError');
if($showFooterError){ ?>
@yield('footer_error')
<?php } ?>
<!-- footer error section stop -->
@yield('script')
</body>
</html>