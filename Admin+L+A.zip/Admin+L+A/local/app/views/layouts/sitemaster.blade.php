<?php
use Infrastructure\Constants;
use ViewModels\SessionHelper;
use Infrastructure\Common;
use BaseController as BA;
$minify = new \CeesVanEgmond\Minify\Facades\Minify;
$siteID = SessionHelper::getSelectedSiteID();
$roleID = SessionHelper::getSelectedRoleID();
if(!isset($encryptedSiteID)){
$encryptedSiteID = Common::getEncryptedValue(Constants::$QueryStringSiteID.'='.$siteID);
}
?>

<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->

<html  lang="en" ng-app="App">
<!--<![endif]-->
<!-- BEGIN HEAD -->

<head>
    <meta charset="utf-8" />
    <title><?php echo Constants::$projectNameTitle;?> | @yield('Title')</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta content="" name="description" />
    <meta content="" name="author" />

    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />
    {{ $minify::stylesheet(array('/assets/js/library/simple-line-icons/simple-line-icons.min.css'))->withFullUrl()}}
    <link href="<?php echo asset('/assets/js/library/bootstrap/css/bootstrap.min.css');?>" rel="stylesheet" type='text/css'>
    {{ $minify::stylesheet(array('/assets/js/library/uniform/css/uniform.default.css',
                                 '/assets/css/datepicker/bootstrap-datepicker3.min.css',
                                 '/assets/css/msgbox/msgGrowl.css',
                                 '/assets/css/components-md.min.css',
                                 '/assets/css/plugins-md.min.css',
                                 '/assets/css/layout.min.css',
                                 '/assets/css/default.min.css',
                                 '/assets/css/plugins.min.css',
                                 '/assets/css/datatables.min.css'))->withFullUrl()}}

    {{ $minify::stylesheet(array('/assets/css/angular-ui-tree.css',
                                '/assets/css/tree.css'))->withFullUrl()}}

    {{ $minify::stylesheet(array('/assets/css/custom.css','/assets/css/responsive.css'))->withFullUrl()}}
    <link href="<?php echo asset('/assets/fonts/font-awesome/css/font-awesome.min.css');?>" rel="stylesheet" type='text/css'>
    <link href="<?php echo asset('/assets/fonts/simple-line-icons/simple-line-icons.min.css');?>" rel="stylesheet" type='text/css'>
    <link rel="icon" href="<?php echo asset('/assets/images/favicon.ico');?>" type="image/x-icon" />

    @yield('css')
</head>

<body class="page-header-fixed page-sidebar-closed-hide-logologo page-content-white page-md">
<span data-us-spinner="{radius:30, width:8, length: 16,scale:0.5}" class="loading-ui-block"> </span>

<!-- BEGIN HEADER -->
<div class="page-header navbar navbar-fixed-top">
    <!-- BEGIN HEADER INNER -->
    <div class="page-header-inner ">
        <!-- BEGIN LOGO -->
        <div class="page-logo">
            <?php if(isset($encryptedSiteID)){?>
            <a href="<?php echo URL::to('/dashboard/'.$encryptedSiteID) ?>">
                <img src="<?php echo asset('/assets/images/wb_logo.png'); ?>" alt="logo" class="logo-default" /> </a>
            <?php } ?>
            <?php if(!isset($encryptedSiteID)){?>
            <a href="<?php echo URL::to('/choosesite/') ?>">
                <img src="<?php echo asset('/assets/images/wb_logo.png'); ?>" alt="logo" class="logo-default" /> </a>
            <?php } ?>
            <div class="menu-toggler sidebar-toggler"> </div>
        </div>
        <!-- END LOGO -->
        <!-- BEGIN RESPONSIVE MENU TOGGLER -->
        <a href="javascript:void(0);" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse"> </a>
        <!-- END RESPONSIVE MENU TOGGLER -->
        <!-- BEGIN TOP NAVIGATION MENU -->
        <div class="top-menu">
            <ul class="nav navbar-nav pull-right">
                <!-- BEGIN USER LOGIN DROPDOWN -->
                <!-- DOC: Apply "dropdown-dark" class after below "dropdown-extended" to change the dropdown styte -->
                <li class="dropdown dropdown-user">
                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                        <!--<img alt="" class="img-circle" src="<?php echo asset('/assets/imgages/avatar3_small.jpg'); ?>" />-->
                        <span class="username ">{{ @Auth::User()->FirstName }}</span>
                        <i class="fa fa-angle-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-default">
                        <li>
                            <a href="<?php echo URL::to('/updateprofile'); ?>">
                                <i class="icon-user"></i> My Profile </a>
                        </li>

                        <li>
                            <a href="<?php echo URL::to('/').'/logout'; ?>">
                                <i class="icon-key"></i> Log Out </a>
                        </li>
                    </ul>
                </li>
                <!-- END USER LOGIN DROPDOWN -->
            </ul>

            <ul class="nav navbar-nav pull-right"  ng-controller = "SwitchToSiteController">
                <li class="dropdown dropdown-user">
                     <?php if(isset($UserSiteList) && sizeof($UserSiteList)==0){?>
                        <a href="javascript:void(0);" class="dropdown-toggle"  data-close-others="true">
                        <span class="username "><?php if(isset($selectedSiteName)){ echo $selectedSiteName;} ?></span>
                    </a>
                    <?php } ?>
                     <?php if(isset($UserSiteList) && sizeof($UserSiteList)>=1){?>
                     <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                         <span class="username "><?php if(isset($selectedSiteName)){ echo $selectedSiteName;} ?></span>
                         <i class="fa fa-angle-down" ></i>
                     </a>
                     <?php } ?>
                    <ul class="dropdown-menu dropdown-menu-default" style="width: 210px;">
                        <?php if(isset($UserSiteList)){
                        foreach($UserSiteList as $userSiteList){?>
                        <li><a ng-click="SelectSite(<?php echo $userSiteList->SiteID ;?>)">Switch to <?php echo $userSiteList->SiteName ;?></a></li>
                        <?php } }?>
                    </ul>
                </li>
            </ul>
            <?php if($siteID==Constants::$MercerVineSiteID || $siteID==Constants::$RiverDaleFundingSiteID || $siteID==Constants::$ColoradoSiteID) {?>
            <ul class="nav navbar-nav pull-right" data-ng-controller="CacheController">
                <li class="dropdown dropdown-user">
                    <button type="button"   class="btn btn-danger btn-sm margin8p" data-ng-click="ClearCache(<?php echo $siteID; ?>)">Clear (Flush) Cache</button>
                </li>
            </ul>
            <?php }?>

        </div>
        <!-- END TOP NAVIGATION MENU -->
    </div>
    <!-- END HEADER INNER -->
</div>
<!-- END HEADER -->
<!-- BEGIN HEADER & CONTENT DIVIDER -->
<div class="clearfix"> </div>
<!-- END HEADER & CONTENT DIVIDER -->
<!-- BEGIN HEADER & CONTENT DIVIDER -->
<div class="clearfix"> </div>
<!-- END HEADER & CONTENT DIVIDER -->
<!-- BEGIN CONTAINER -->
<div class="page-container">

    <!-- BEGIN SIDEBAR -->
    <div class="page-sidebar-wrapper">
        <!-- BEGIN SIDEBAR -->
        <!-- DOC: Set data-auto-scroll="false" to disable the sidebar from auto scrolling/focusing -->
        <!-- DOC: Change data-auto-speed="200" to adjust the sub menu slide up/down speed -->
        <div class="page-sidebar navbar-collapse collapse">
            <!-- BEGIN SIDEBAR MENU -->
            <!-- DOC: Apply "page-sidebar-menu-light" class right after "page-sidebar-menu" to enable light sidebar menu style(without borders) -->
            <!-- DOC: Apply "page-sidebar-menu-hover-submenu" class right after "page-sidebar-menu" to enable hoverable(hover vs accordion) sub menu mode -->
            <!-- DOC: Apply "page-sidebar-menu-closed" class right after "page-sidebar-menu" to collapse("page-sidebar-closed" class must be applied to the body element) the sidebar sub menu mode -->
            <!-- DOC: Set data-auto-scroll="false" to disable the sidebar from auto scrolling/focusing -->
            <!-- DOC: Set data-keep-expand="true" to keep the submenues expanded -->
            <!-- DOC: Set data-auto-speed="200" to adjust the sub menu slide up/down speed -->
            <ul class="page-sidebar-menu  page-header-fixed " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px">
                <!-- DOC: To remove the sidebar toggler from the sidebar you just need to completely remove the below "sidebar-toggler-wrapper" LI element -->
                <li class="sidebar-toggler-wrapper hide">
                    <!-- BEGIN SIDEBAR TOGGLER BUTTON -->
                    <div class="sidebar-toggler"> </div>
                    <!-- END SIDEBAR TOGGLER BUTTON -->
                </li>
                <!-- DOC: To remove the search box from the sidebar you just need to completely remove the below "sidebar-search-wrapper" LI element -->
                <?php if(empty($siteID)) {?>
                <li id="dashboard" class="nav-item start">
                    <a href="<?php echo URL::to('/choosesite'); ?>" class="nav-link nav-toggle">
                        <i class=""></i>
                        <span class="title">Choose Site</span>
                        <span class="selected"></span>
                    </a>
                </li>
                <?php } ?>
                <?php if(isset($encryptedSiteID)){?>
                <li id="dashboard" class="nav-item start">
                    <a href="<?php echo URL::to('/dashboard'); ?>" class="nav-link nav-toggle">
                        <i class="icon-home"></i>
                        <span class="title">Dashboard</span>
                        <span class="selected"></span>
                    </a>
                </li>

                <li class="heading">
                    <h3 class="uppercase">CMS</h3>
                </li>
                <?php if(BA::CheckRoleSitePermission(Constants::$RoleITAdmin,Common::getAllSiteArray())) {?>
                <li class="nav-item" id="home-page">
                    <a href="<?php echo URL::to('/home/'.$encryptedSiteID) ?>" class="nav-link ">
                        <i class="fa fa-pagelines"></i>
                        <span class="title">Home Page</span>
                    </a>
                </li>
                <?php } ?>
                <?php if(BA::CheckRoleSitePermission(Constants::$RoleITAdmin,Common::getSiteColoradoWW())) {?>
                <li class="nav-item" id="landingpage">
                    <a href="<?php echo URL::to('/headerimg/'.$encryptedSiteID) ?>" class="nav-link ">
                        <i class="fa fa-picture-o"></i>
                        <span class="title">Landing Page</span>
                    </a>
                </li>
                <?php } ?>
                <?php if(BA::CheckRoleSitePermission(Common::getRoleMDITAdminSEOLegal(),Common::getAllSiteArray())) {?>
                <li class="nav-item" id="manage-pages">
                    <a href="javascript:void(0);" class="nav-link nav-toggle">
                        <i class="fa fa-sticky-note"></i>
                        <span class="title">Pages</span>
                        <span class="arrow"></span>
                    </a>
                    <ul class="sub-menu" >
                        <li class="nav-item" id="pages">
                            <a href="<?php echo URL::to('/pages/'.$encryptedSiteID) ?>" class="nav-link ">
                                <span class="title">List Pages</span>
                            </a>
                        </li>
                        <?php if(BA::CheckRoleSitePermission(Common::getRoleMDITAdminSEO(),Common::getAllSiteArray())) {?>
                        <li class="nav-item" id="add-page">
                            <a href="<?php echo URL::to('/addpage/'.$encryptedSiteID) ?>" class="nav-link ">
                                <span class="title">Add Page</span>
                            </a>
                        </li>
                        <?php } ?>
                    </ul>
                </li>
                <?php } ?>
                <?php if(BA::CheckRoleSitePermission(Common::getRoleITAdminAndAgent(),Common::getSiteMercerVine())){ ?>
                <li class="nav-item" id="manage-developments">
                    <a href="javascript:void(0);" class="nav-link nav-toggle">
                        <i class="icon-diamond"></i>
                        <span class="title">Developments</span>
                        <span class="arrow"></span>
                    </a>
                    <ul class="sub-menu">
                        <li  class="nav-item" id="developments">
                            <a href="<?php echo URL::to('/developments/'.$encryptedSiteID) ?>" class="nav-link ">
                                <span class="title">List Developments</span>
                            </a>
                        </li>
                        <li id="adddevelopment" class="nav-item">
                            <a href="<?php echo URL::to('/adddevelopment/'.$encryptedSiteID) ?>" class="nav-link ">
                                <span class="title">Add Development</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php } ?>
                <?php if(BA::CheckRoleSitePermission(Common::getRoleMDITAdminSEO(),Constants::$MercerVineSiteID)) {?>
                <li class="nav-item" id="manage-videos">
                    <a href="javascript:void(0);" class="nav-link nav-toggle">
                        <i class="fa fa-video-camera"></i>
                        <span class="title">Videos</span>
                        <span class="arrow"></span>
                    </a>
                    <ul class="sub-menu" >
                        <li class="nav-item" id="videos-list">
                            <a href="<?php echo URL::to('/videolist/'.$encryptedSiteID) ?>" class="nav-link ">
                                <span class="title">List Videos</span>
                            </a>
                        </li>
                        <li class="nav-item" id="add-videos">
                            <a href="<?php echo URL::to('/addvideo/'.$encryptedSiteID) ?>" class="nav-link ">
                                <span class="title">Add Video</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php } ?>
                <?php if(BA::CheckRoleSitePermission(Common::getRoleBloggerMDITSEOAgentLegal(),Common::getAllSiteArray())) {?>
                <li class="nav-item" id="blog">
                    <a href="javascript:void(0);" class="nav-link nav-toggle">
                        <i class="fa fa-rss-square"></i>
                        <span class="title"> Blog Posts</span>
                        <span class="arrow"></span>
                    </a>
                    <ul class="sub-menu" >
                        <li class="nav-item" id="post-list">
                            <a href="<?php echo URL::to('/blogposts/'.$encryptedSiteID) ?>" class="nav-link ">
                                <span class="title">List Blog Posts</span>
                            </a>
                        </li>
                        <?php if(BA::CheckRoleSitePermission(Common::getRoleBloggerMDITSEOAgent(),Common::getAllSiteArray())) {?>
                        <li class="nav-item" id="add-blog">
                            <a href="<?php echo URL::to('/addblog/'.$encryptedSiteID) ?>" class="nav-link ">
                                <span class="title">Add Blog Post</span>
                            </a>
                        </li>
                        <?php } ?>
                        <?php if(BA::CheckRoleSitePermission(Common::getRoleITAdminMDAgentBloggerSEO(),Common::getAllSiteArray())) {?>
                        <li class="nav-item" id="category">
                            <a href="<?php echo URL::to('/category/'.$encryptedSiteID) ?>" class="nav-link ">
                                <span class="title">Categories & Tags</span>
                            </a>
                        </li>
                        <?php } ?>
                    </ul>
                </li>
                <?php } ?>
                <?php if(BA::CheckRoleSitePermission(Common::getRoleITAdminMD(),Common::getSiteMercerVineColorado())){?>
                <li class="nav-item" id="manage-agents">
                    <a href="javascript:void(0);" class="nav-link nav-toggle">
                        <i class="icon-users"></i>
                        <span class="title">Agents</span>
                        <span class="arrow"></span>
                    </a>
                    <ul class="sub-menu">
                        <?php if(BA::CheckRoleSitePermission(Common::getRoleITAdminMD(),Common::getSiteMercerVineColorado())){?>
                        <li class="nav-item" id="agents">
                            <a href="<?php echo URL::to('/agents/'.$encryptedSiteID) ?>" class="nav-link ">
                                <span class="title">List Agents</span>
                            </a>
                        </li>
                        <?php } ?>
                        <?php if(BA::CheckRoleSitePermission(Common::getRoleITAdminMD(),Common::getSiteMercerVineWoodbridgeColorado())){?>
                        <li class="nav-item" id="add-agent">
                            <a href="<?php echo URL::to('/addagent/'.$encryptedSiteID); ?>" class="nav-link ">
                                <span class="title">Add Agent</span>
                            </a>
                        </li>
                        <?php } ?>

                    </ul>
                </li>
                <?php } ?>
                <?php if(BA::CheckRoleSitePermission(Common::getRoleITAdminAndAgent(),Common::getSiteMercerVineColorado())) {?>
                <li class="nav-item" id="manage-propertys">
                    <a href="javascript:void(0);" class="nav-link nav-toggle">
                        <i class="fa fa-map-marker"></i>
                        <span class="title">Listings</span>
                        <span class="arrow"></span>
                    </a>
                    <ul class="sub-menu" >
                        <li class="nav-item" id="propertys">
                            <a href="<?php echo URL::to('/listing/'.$encryptedSiteID) ?>" class="nav-link ">
                                <span class="title">List Listings</span>
                            </a>
                        </li>
                       <!-- <li class="nav-item" id="propertysNew">
                            <a href="<?php //echo URL::to('/listingnew/'.$encryptedSiteID) ?>" class="nav-link ">
                                <span class="title">List Listings New</span>
                            </a>
                        </li>-->
                        <li class="nav-item" id="add-property">
                            <a href="<?php echo URL::to('/addlisting/'.$encryptedSiteID) ?>" class="nav-link ">
                                <span class="title">Add Listings</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php } ?>
                <?php if(BA::CheckRoleSitePermission(Constants::$RoleITAdmin,Common::getAllSiteArray())) {?>
                <li class="nav-item" id="menu-items">
                    <a href="<?php echo URL::to('/navigation/'.$encryptedSiteID) ?>" class="nav-link ">
                        <i class="fa fa-bars"></i>
                        <span class="title">Navigation</span>
                    </a>
                </li>
                <?php } ?>
                <?php if(BA::CheckRoleSitePermission(Common::getRoleMDITAdminSEO(),Common::getAllSiteArray())) {?>
                <li class="nav-item" id="manage-faq">
                    <a href="javascript:void(0);" class="nav-link nav-toggle">
                        <i class="icon-question"></i>
                        <span class="title">FAQs</span>
                        <span class="arrow"></span>
                    </a>
                    <ul class="sub-menu" >
                        <li class="nav-item" id="faq-list">
                            <a href="<?php echo URL::to('/faqlist/'.$encryptedSiteID) ?>" class="nav-link ">
                                <span class="title">List FAQs</span>
                            </a>
                        </li>
                        <li class="nav-item" id="add-faq">
                            <a href="<?php echo URL::to('/addfaq/'.$encryptedSiteID) ?>" class="nav-link ">
                                <span class="title">Add FAQ </span>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php } ?>
                <?php if(BA::CheckRoleSitePermission(Common::getRoleITAdminProcesing(),Common::getSiteRiverdale())) {?>
                <li class="nav-item" id="manage-faq">
                    <a href="javascript:void(0);" class="nav-link nav-toggle">
                        <i class="fa fa-money"></i>
                        <span class="title">Loans Closed</span>
                        <span class="arrow"></span>
                    </a>
                    <ul class="sub-menu" >
                        <li class="nav-item" id="loan-list">
                            <a href="<?php echo URL::to('/loans/'.$encryptedSiteID) ?>" class="nav-link ">
                                <span class="title">List Loans Closed</span>
                            </a>
                        </li>
                        <li class="nav-item" id="add-loan">
                            <a href="<?php echo URL::to('/addloan/'.$encryptedSiteID) ?>" class="nav-link ">
                                <span class="title">Add Loan Closed</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php } ?>

                 <?php if(BA::CheckRoleSitePermission(Common::getRoleITAdminMD(),Common::getSiteRiverDaleColoradoWW())) {?>
                <li class="nav-item" id="site-testimonials">
                    <a href="<?php echo URL::to('/sitetestimonials/'.$encryptedSiteID) ?>" class="nav-link ">
                        <i class="fa fa-user"></i>
                        <span class="title">Site Testimonials</span>
                    </a>
                </li>
                <?php } ?>

                <?php if(BA::CheckRoleSitePermission(Constants::$RoleITAdmin,Common::getAllSiteArray())){?>
                <li class="heading">
                    <h3 class="uppercase">Admin</h3>
                </li>
                <li class="nav-item" id="manage-users">
                    <a href="javascript:void(0);" class="nav-link nav-toggle">
                        <i class="icon-user"></i>
                        <span class="title">Users</span>
                        <span class="arrow"></span>
                        <span class="selected"></span>
                    </a>
                    <ul class="sub-menu">
                        <li class="nav-item" id="users">
                            <a href="<?php echo URL::to('/users/'.$encryptedSiteID); ?>" class="nav-link ">
                                <span class="title">List Users</span>
                            </a>
                        </li>
                        <li class="nav-item " id="addusers">
                            <a href="<?php echo URL::to('/adduser/'.$encryptedSiteID); ?>" class="nav-link ">
                                <span class="title">Add User</span>
                            </a>
                        </li>
                    </ul>
                    <?php }?>
                </li>
                <?php } ?>
                <?php if(BA::CheckRoleSitePermission(Constants::$RoleITAdmin,Common::getAllSiteArray())) {?>
                <li class="nav-item" id="site-configuration">
                    <a href="<?php echo URL::to('/configuration/'.$encryptedSiteID) ?>" class="nav-link ">
                        <i class="fa fa-cog"></i>
                        <span class="title">Site Configuration</span>
                    </a>
                </li>
                <?php } ?>
            </ul>
            <!-- END SIDEBAR MENU -->
            <!-- END SIDEBAR MENU -->
            <div class="lithyem-logo-sitemaster"><a href="http://lithyem.net" target="_blank"><img src="{{asset('assets/images/lithyem-logo.png')}}"></a></div>
        </div>
        <!-- END SIDEBAR -->
    </div>

    <!-- END SIDEBAR -->
    <!-- BEGIN CONTENT -->
    <div class="page-content-wrapper">
        @yield('content')
    </div>
    <!-- END CONTENT -->
</div>
<!-- END CONTAINER -->
<!-- BEGIN FOOTER -->
<div class="page-footer">
    <!-- <div class="lithyem-logo-sitemaster"><img src="{{asset('assets/images/lithyem-logo.png')}}"></div> -->
    <div class="page-footer-inner"><?php echo Constants::$footerText;?></div>
    <div class="scroll-to-top">
        <i class="icon-arrow-up"></i>
    </div>
</div>
<!-- END FOOTER -->

<script type="text/javascript">
    window.baseUrl = "<?php echo URL::to('/')?>";
    window.activeMenuID = "<?php if(isset($activeMenuID)){echo $activeMenuID;} ?>";
</script>

<!--[if lt IE 9]>
{{ $minify::javascript(array('/assets/js/library/respond.min.js',
                                '/assets/js/library/excanvas.min.js'))->withFullUrl()}}
<![endif]-->

<!-- BEGIN CORE PLUGINS -->
{{ $minify::javascript(array('/assets/js/library/jquery.min.js',
                             '/assets/js/library/bootstrap/js/bootstrap.min.js',
                              '/assets/js/library/datepicker/bootstrap-datepicker.min.js',
                             '/assets/js/sitejs/global_app.js',
                             '/assets/js/sitejs/layout.min.js',
                             '/assets/js/sitejs/demo.min.js',
                             '/assets/js/library/quick-sidebar.min.js',
                             '/assets/js/sitejs/jquery.cookie.js',
                             '/assets/js/library/jquery.history.js',
                             '/assets/js/sitejs/moment.js',
                             '/assets/js/library/datetimepicker/bootstrap-datetimepicker.js',
                             '/assets/js/library/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js',
                             '/assets/js/library/jquery-slimscroll/jquery.slimscroll.min.js',
                             '/assets/js/library/jquery.blockui.min.js',
                             '/assets/js/library/uniform/jquery.uniform.min.js',
                             '/assets/js/sitejs/msgGrowl.js',
                             '/assets/js/sitejs/angularjs/angular.min.js',
                             '/assets/js/library/dirPagination.js',
                             '/assets/js/sitejs/ng-tags-input.min.js',
                             '/assets/js/sitejs/angularjs/app.js',
                             '/assets/js/sitejs/angularjs/angular-loading-spinner.js',
                             '/assets/js/sitejs/angularjs/angular-spinner.js',
                             '/assets/js/sitejs/angularjs/spin.js',
                             '/assets/js/library/bootstrap-dialog.js',
                             '/assets/js/viewjs/common.js',
                             //'/assets/js/viewjs/directive.js',
                             '/assets/js/sitejs/datatable.js',
                             '/assets/js/library/ngMask.min.js'))->withFullUrl()}}
                             
{{ $minify::javascript(array('/assets/js/sitejs/angularjs/clipboard.min.js','/assets/js/sitejs/angularjs/ngclipboard.js'))->withFullUrl()}}

{{ $minify::javascript(array('/assets/js/viewjs/directive.js'))->withFullUrl()}}


{{ $minify::javascript(array('/assets/js/sitejs/angularjs/angular-route.min.js',
                            '/assets/js/library/treeview/ui-bootstrap-tpls.js',
                            '/assets/js/library/treeview/main.js',
                            '/assets/js/library/treeview/handleCtrl.js',
                            '/assets/js/library/treeview/nodeCtrl.js',
                            '/assets/js/library/treeview/nodesCtrl.js',
                            '/assets/js/library/treeview/treeCtrl.js',
                            '/assets/js/library/treeview/uiTree.js',
                            '/assets/js/library/treeview/uiTreeHandle.js',
                            '/assets/js/library/treeview/uiTreeNode.js',
                            '/assets/js/library/treeview/uiTreeNodes.js',
                            '/assets/js/library/treeview/helper.js'))->withFullUrl()}}

{{ $minify::javascript(array('/assets/js/viewjs/cache/clearcache.js'))->withFullUrl()}}

<script type="text/javascript">
    window.ConfirmDialogTitle ="{{ trans('messages.ConfirmDialogTitle')}}";
    window.Confirmdialogmessage ="{{ trans('messages.Confirmdialogmessage')}}";
    window.ConfirmDialogSomethingWrong ="{{ trans('messages.ConfirmDialogSomethingWrong')}}";

    $(document).ready(function () {
        if(window.activeMenuID != undefined && window.activeMenuID.length > 0) {
            $('#' + window.activeMenuID).addClass("active");
            $('#' + window.activeMenuID).parent('ul.sub-menu').parent('li.nav-item').addClass("active open");
        }
    });

</script>
{{ $minify::javascript(array('/assets/js/viewjs/security/switchtosite.js'))->withFullUrl()}}
<!-- footer error section start -->
<?php $showFooterError = Config::get('config.ShowFooterError');
if($showFooterError){ ?>
@yield('footer_error')
<?php } ?>
<!-- footer error section stop -->
@yield('script')  

</body>
</html>
