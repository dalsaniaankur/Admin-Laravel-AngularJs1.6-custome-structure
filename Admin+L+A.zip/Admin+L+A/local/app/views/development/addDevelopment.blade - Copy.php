<?php
$minify = new \CeesVanEgmond\Minify\Facades\Minify;
use \Infrastructure\Constants;
?>
@extends('layouts.sitemaster')
@section('Title')
    <?php if ($DevelopmentModel->DevDetails->DevelopmentID > 0) {
        print 'Edit Development';
    } else {
        print 'Add Development';
    } ?>
@stop
@section('css')
    {{ $minify::stylesheet(array('/assets/css/dropzone/dropzone.css'))->withFullUrl()}}
@stop
@section('content')
    <main id="main" role="main" data-ng-controller="DevelopmentController">
        <?php echo Form::hidden('DevelopmentModel', htmlspecialchars(json_encode($DevelopmentModel), ENT_QUOTES, 'UTF-8'), $attributes = array('id' => 'DevelopmentModel')); ?>
                <!-- BEGIN CONTENT BODY -->
        <div class="page-content">
            <!-- BEGIN PAGE HEADER-->
            <!-- BEGIN PAGE BAR -->
            <div class="page-bar">
                <ul class="page-breadcrumb">
                    <li>
                        <a href="<?php echo URL::to('/dashboard/' . $encryptedSiteID) ?>">Home</a>
                        <i class="fa fa-circle"></i>
                    </li>
                    <li>
                        <a href="<?php echo URL::to('/developments/' . $encryptedSiteID) ?>">Developments</a>
                        <i class="fa fa-circle"></i>
                    </li>
                    <li>
                        <span><?php if ($DevelopmentModel->DevDetails->DevelopmentID > 0) {
                                print 'Edit Development';
                            } else {
                                print 'Add Development';
                            }?></span>
                    </li>
                </ul>
                <div class="page-toolbar">
                    <div class="btn-group pull-right" ng-cloak>
                        <input id="delete" name="delete" type="button" value="Delete"
                               class="btn btn-danger btn-sm btn-outline " data-ng-click="DeleteDevelopment()"
                               ng-show="DevelopmentModel.DevelopmentID > 0 && (DevelopmentModel.LoggedInUserRoleID== <?php echo Constants::$RoleITAdmin;?> || DevelopmentModel.LoggedInUserRoleID== <?php echo Constants::$RoleAgent;?> )">
                    </div>
                </div>
            </div>
            <h3 class="page-title"><?php if ($DevelopmentModel->DevDetails->DevelopmentID > 0) {
                    print 'Edit Development';
                } else {
                    print 'Add Development';
                }?></h3>
            <div class="portlet-body">
                <?php if($DevelopmentModel->DevDetails->DevelopmentID > 0) { ?>
                <ul class="nav nav-tabs development">
                    <li class="active">
                        <a href="#tab_1_1" data-toggle="tab" aria-expanded="true" data-ng-click="getTab({{1}},$event)">Overview</a>
                    </li>
                    <li class="">
                        <a href="#tab_1_2" data-toggle="tab" aria-expanded="false" data-ng-click="getTab({{0}},$event)">Case
                            Studies</a>
                    </li>
                    <li class="">
                        <a href="#tab_1_3" data-toggle="tab" aria-expanded="false" data-ng-click="getTab({{0}},$event)">Services/Results</a>
                    </li>
                    <li class="">
                        <a href="#tab_1_4" data-toggle="tab" aria-expanded="false" data-ng-click="getTab({{0}},$event)">Videos</a>
                    </li>
                    <li class="">
                        <a href="#tab_1_5" data-toggle="tab" aria-expanded="false" data-ng-click="getTab({{0}},$event)">Listings</a>
                    </li>
                </ul>
                <?php } ?>
                        <!-- END PAGE BAR -->
                <!-- END PAGE HEADER-->
                <!-- BEGIN Form Design-->
                    <div class="row">
                        <div class="col-md-12 ">
                            <form name="DevelopmentForm" id="DevelopmentForm" role="form" novalidate>
                                <div class="form-body" ng-cloak>

                                        <div class="col-md-12 no-padding">
                                            <div class="tab-content">

                                                <div class="tab-pane active" id="tab_1_1">
                                                    <div class="portlet box blue-hoki" ng-cloak>
                                                        <div class="portlet-title" collapse>
                                                            <div class="caption">
                                                                <i class=""></i>Details</div>
                                                            <div class="tools">
                                                                <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                                            </div>
                                                        </div>
                                                        <div class="portlet-body">
                                                            <div class="row">
                                                                <div class="col-md-12 no-padding">
                                                                    <div class="form-body" >
                                                                        <div class="col-md-12 no-padding">

                                                                            <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 no-padding">
                                                                                <div class="form-group col-md-6"
                                                                                     ng-class="{ 'has-error' : (DevelopmentForm.$submitted) && DevelopmentForm.Name.$invalid}">
                                                                                    <label for="Name" class="control-label">Name</label>
                                                                                    <input class="form-control" type="text" name="Name" maxlength="100"
                                                                                           data-ng-model="DevelopmentModel.Name"
                                                                                           data-ng-class="{'has-submitted' : DevelopmentForm.$submitted }"
                                                                                           required/>
                                                                                    <span class="error-text-color" ng-show="DevelopmentForm.$submitted">
                                                                                        <span ng-show="DevelopmentForm.Name.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Name'))}}</span>
                                                                                    </span>
                                                                                </div>
                                                                                <div class="form-group col-md-6">
                                                                                    <label for="ShortDescription" class="control-label">Short Description</label>
                                                                                  <textarea class="form-control" name="ShortDescription"
                                                                                            data-ng-model="DevelopmentModel.ShortDescription" rows="5"
                                                                                            cols="100"></textarea>
                                                                                </div>
                                                                                <div class="form-group col-md-6">
                                                                                    <label for="Address" class="control-label">Address</label>
                                                                                    <input class="form-control" type="text" name="Address"
                                                                                           data-ng-model="DevelopmentModel.Address"/>
                                                                                </div>
                                                                                <div class="form-group col-md-6">
                                                                                    <label for="City" class="control-label">City</label>
                                                                                    <input class="form-control" type="text" name="City"
                                                                                           data-ng-model="DevelopmentModel.City"/>
                                                                                </div>
                                                                            </div>
                                                                            <div class="form-group col-md-6">
                                                                                <label for="State" class="control-label">State</label>
                                                                                <select class="form-control" ng-model="DevelopmentModel.StateID"
                                                                                        ng-options="state.StateID as state.StateName for state in DevelopmentModel.StateListArray"
                                                                                        id="State" name="State"
                                                                                        ng-class="{ 'has-submitted' : DevelopmentForm.$submitted }"
                                                                                        required>
                                                                                    <option value="">-- select --</option>
                                                                                </select>
                                                                            </div>

                                                                            <div class="form-group col-md-6"
                                                                                 ng-class="{ 'has-error' : (DevelopmentForm.$submitted) && DevelopmentForm.Zip.$invalid}">
                                                                                <label for="Zip" class="control-label">Zip</label>
                                                                                <input class="form-control" type="text" name="Zip"
                                                                                       data-ng-model="DevelopmentModel.Zip"
                                                                                       data-ng-pattern="<?php echo Constants::$zipRegex; ?>"
                                                                                       ng-class="{ 'has-submitted' : AgentForm.$submitted }"
                                                                                       intype="digit" maxlength="9" ng-required/>
                                                                                    <span class="help-block"
                                                                                          ng-show="(DevelopmentForm.Zip !='') && ( DevelopmentForm.$submitted )">
                                                                                        <span ng-show="DevelopmentForm.$dirty && DevelopmentForm.Zip.$invalid && DevelopmentModel.Zip != ''">{{ trans('messages.InvalidZipCode')}}</span>
                                                                                    </span>
                                                                            </div>


                                                                            <div class="form-group col-md-6">
                                                                                <label for="Latitude" class="control-label">Latitude</label>
                                                                                <input class="form-control" type="text" name="Latitude"
                                                                                       data-ng-model="DevelopmentModel.Latitude"/>
                                                                            </div>
                                                                            <div class="form-group col-md-6">
                                                                                <label for="Longitude" class="control-label">Longitude</label>
                                                                                <input class="form-control" type="text" name="Longitude"
                                                                                       data-ng-model="DevelopmentModel.Longitude"/>
                                                                            </div>
                                                                            <div class="form-group col-md-12"
                                                                                 ng-class="{ 'has-error' : (DevelopmentForm.$submitted) && DevelopmentForm.Description.$invalid}">
                                                                                <label for="Description" class="control-label">Description</label>
                                                                                      <textarea id="Description" name="Description"
                                                                                                data-ng-model="DevelopmentModel.Description" ck-editor
                                                                                                data-ng-class="{'has-submitted' : DevelopmentForm.$submitted }"
                                                                                                required></textarea>
                                                                                    <span class="error-text-color" ng-show="DevelopmentForm.$submitted">
                                                                                        <span ng-show="DevelopmentForm.Description.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Description'))}}</span>
                                                                                    </span>
                                                                            </div>

                                                                            <!-- For File Upload Start -->
                                                                            <h3 class="caption-subject form-section uppercase col-md-12">Images</h3>
                                                                            <div class="form-group col-md-12 dropZoneOuter">
                                                                                <form></form>
                                                                                <form action="" class="dropzone" drop-zone="" id="file-dropzone"
                                                                                      on-file="OnFileAdded"
                                                                                      ng-aws-settings-model="DevelopmentModel.FileUploadSettings"
                                                                                      success-callback="PushFilesToUploadArray"
                                                                                      remove-file="RemoveFile"
                                                                                      upload-file="DevelopmentModel.UploadFilesArray"
                                                                                      ext-type="DevelopmentModel.ImageExtensionType"
                                                                                      max-files="DevelopmentModel.maxFiles"
                                                                                      request-counter="DevelopmentModel.requestCounter"
                                                                                      response-counter="DevelopmentModel.responseCounter"
                                                                                      enabled-button="DevelopmentModel.EnableSubmitButton"
                                                                                      upload-complete="UploadComplete"
                                                                                      uploaded-file="DevelopmentModel.UploadedFileArray"
                                                                                      file-size-exceeds="{{ trans('messages.NoMoreImages')}}"
                                                                                      invalid-file-format="{{trans('messages.InvalidImageTypeFormat')}}"
                                                                                      radio-select-value="DevelopmentModel.IsDefaultImage"
                                                                                      on-file-load="OnDefaultFileLoad"
                                                                                      allow-order="DevelopmentModel.IsAllowStoreOrder"
                                                                                      file-name="DevelopmentModel.ImagesNameModel">

                                                                                    <div class="dz-preview dz-file-preview margin-10p"
                                                                                         id="template">
                                                                                        <div class="dz-details">
                                                                                            <div class="dz-filename"><span data-dz-name></span>
                                                                                            </div>
                                                                                            <div class="dz-size" data-dz-size></div>
                                                                                            <div><span class="dz-remove"></span></div>
                                                                                            <img data-dz-thumbnail/>
                                                                                        </div>
                                                                                        <br/>
                                                                                        <div class="progress progress-striped active"
                                                                                             id="totalprogressbar" role="progressbar"
                                                                                             aria-valuemin='0' aria-valuemax='100'
                                                                                             aria-valuenow='0'>
                                                                                            <div class="progress-bar progress-bar-success bar width-none"
                                                                                                 data-dz-uploadprogress></div>
                                                                                        </div>
                                                                                        <div class="dz-success-mark"><span>✔</span></div>
                                                                                        <div class="dz-error-mark"><span>✘</span></div>
                                                                                        <div class="file-error-message"><strong
                                                                                                    class="error text-danger"
                                                                                                    data-dz-errormessage></strong></div>
                                                                                        <button data-dz-remove
                                                                                                class="btn btn-danger delete cancel btn-xs margin-left12pr">
                                                                                            <i class="glyphicon glyphicon-trash padding-top-bottom"></i>
                                                                                            <span>Delete &nbsp;</span></button>
                                                                                        <div class="margin-top4p">

                                                                                            <label class="radio-inline">
                                                                                                <input type="radio" name="IsDefaultImage"
                                                                                                       class="IsDefaultImage"
                                                                                                       data-ng-model="DevelopmentModel.IsDefaultImage"
                                                                                                       ng-bind="DevelopmentModel.IsDefaultImage"
                                                                                                       value=""> Is Default
                                                                                            </label>
                                                                                        </div>
                                                                                    </div>
                                                                                </form>
                                                                            </div>
                                                                            <!-- For File Upload End -->

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>





                                                    <!-- For Development Features File Upload End -->
                                                    <div class="clearboth"></div>
                                                    <div class="portlet box blue-hoki" ng-cloak>
                                                        <div class="portlet-title" collapse>
                                                            <div class="caption">
                                                                <i class=""></i>PROPERTY FEATURES</div>
                                                            <div class="tools">
                                                                <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                                            </div>
                                                        </div>
                                                        <div class="portlet-body">
                                                            <div class="row">
                                                                <div class="col-md-12 no-padding">
                                                                    <div class="form-body" >
                                                                        <div class="col-md-12 no-padding">
                                                                            <div class="form-group col-md-12 dropZoneOuter drop-property">
                                                                                <form></form>
                                                                                <br/><h3>DEVELOPMENT FEATURES</h3>
                                                                                <form action="" class="dropzone" drop-zone-with-extra-fields="" id="file-dropzone"
                                                                                      ng-aws-settings-model="DevelopmentModel.FileUploadSettings" success-callback="PushFilesToUploadArrayOfDevelopmentFeatures" remove-file="RemoveDevelopmentFeaturesFiles"
                                                                                      upload-file="DevelopmentModel.ListingModel.ImagesModelOfDevelopmentFeatures"  ext-type="DevelopmentModel.ImageExtensionTypeOfDevelopmentFeatures"
                                                                                      max-files="DevelopmentModel.maxFilesOfDevelopmentFeatures" request-counter="DevelopmentModel.requestCounterOfDevelopmentFeatures" response-counter="DevelopmentModel.responseCounterOfDevelopmentFeatures"
                                                                                      upload-complete="UploadCompleteOfDevelopmentFeatures" uploaded-file="DevelopmentModel.ListingModel.UploadedFileOfDevelopmentFeatures" file-size-exceeds="{{ trans('messages.NoMoreDevelopmentFeaturesImages')}}"
                                                                                      invalid-file-format="{{trans('messages.InvalidImageTypeFormat')}}"  error-array="ErrorArray"
                                                                                      allow-order="DevelopmentModel.IsAllowStoreOrder"  file-order-name="DevelopmentModel.ListingModel.DevelopmentImagesNameModel">

                                                                                    <div class="dz-preview dz-file-preview margin-10p width-97pr property-features" id="template">
                                                                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding-0">
                                                                                            <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
                                                                                                <div class="dz-details">
                                                                                                    <div class="dz-filename"><span data-dz-name></span></div>
                                                                                                    <div class="dz-size" data-dz-size></div>
                                                                                                    <div><span class="dz-remove"></span></div>
                                                                                                    <img class="img-thumbnail opacity-none" data-dz-thumbnail/><br/>

                                                                                                </div><br/>
                                                                                                <div class="progress progress-striped active width-65pr" id="totalprogressbar"  role="progressbar" aria-valuemin='0' aria-valuemax='100' aria-valuenow='0'> <div class="progress-bar progress-bar-success bar width-none" data-dz-uploadprogress></div> </div>
                                                                                                <div class="file-error-message"><strong class="error text-danger" data-dz-errormessage></strong></div>

                                                                                            </div>
                                                                                            <div class="col-lg-4 col-md-3 col-sm-3 col-xs-12">
                                                                                                <div  id="PropertyFeaturesTitle" class="padding-10pr">
                                                                                                    <label for="Title" class="control-label">Title</label>
                                                                                                    <input  class="form-control" id="PFTitle"  onblur="checkValidation(this)" />
                                                                                                    <span class="validationMessage positionInherit display-none">{{ trans('messages.PropertyRequired',array('attribute'=>'Title'))}}</span>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div class="col-lg-4 col-md-3 col-sm-3 col-xs-12">
                                                                                                <div  id="PropertyFeaturesDescriptions" class="padding-10pr">
                                                                                                    <label for="Descriptions" class="control-label">Description</label>
                                                                                                    <textarea class="form-control" id="PFDescription" rows="3"  onblur="checkValidation(this)"></textarea>
                                                                                                    <span class="validationMessage positionInherit display-none">{{ trans('messages.PropertyRequired',array('attribute'=>'Descriptions'))}}</span>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12 padding-0">
                                                                                                <div class="padding-35pr"><button data-dz-remove class="btn btn-danger delete cancel btn-xs margin-left12pr">
                                                                                                        <i class="glyphicon glyphicon-trash padding-top-bottom"></i> <span>Delete &nbsp;</span></button></div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </form>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>





                                                    <div class="col-md-12 no-padding">
                                                        <input id="submit" name="submit" type="submit" value="Save"
                                                               class="btn blue save-button btn-submit" id="btn-submit" data-ng-click="Save()"
                                                               ng-disabled="!UploadComplete || (responseCounter != requestCounter) || DisableButtons">
                                                        <button type="button" id="cancel" class="btn default"
                                                                data-ng-click="Cancel()" ng-disabled="!UploadComplete || (responseCounter != requestCounter) || DisableButtons">
                                                            Cancel
                                                        </button>
                                                    </div>

                                                </div>
                                                <?php if($DevelopmentModel->DevDetails->DevelopmentID > 0) { ?>
                                                <div class="form-group col-md-12 tab-pane fade no-padding" id="tab_1_2">
                                                    <h3 class="page-title">Case Studies</h3>
                                                    <div class="portlet box blue-hoki" ng-cloak>
                                                        <div class="portlet-title" collapse>
                                                            <div class="caption">
                                                                <i class=""></i>Details</div>
                                                            <div class="tools">
                                                                <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                                            </div>
                                                        </div>
                                                        <div class="portlet-body">
                                                            <div class="row">
                                                                <div class="col-md-12 no-padding">
                                                                    <div class="form-body" >
                                                                        <div class="col-md-12 no-padding">
                                                                            <div class="col-md-9">
                                                                                <label for="CaseStudies" class="control-label">Case Studies</label>
                                                    <textarea name="CaseStudies"
                                                              data-ng-model="DevelopmentModel.CaseStudies"
                                                              ck-editor></textarea>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 no-padding">
                                                        <input id="submit" name="submit" type="submit" value="Save"
                                                               class="btn blue save-button" data-ng-click="Save()"
                                                               ng-disabled="!UploadComplete">
                                                        <button type="button" id="cancel" class="btn default"
                                                                data-ng-click="Cancel()" ng-disabled="!UploadComplete">
                                                            Cancel
                                                        </button>
                                                    </div>

                                                </div>
                                                <div class="form-group col-md-12 tab-pane fade no-padding" id="tab_1_3">
                                                    <h3 class="page-title">Services/Results</h3>
                                                    <div class="portlet box blue-hoki" ng-cloak>
                                                        <div class="portlet-title" collapse>
                                                            <div class="caption">
                                                                <i class=""></i>Details</div>
                                                            <div class="tools">
                                                                <a href="javascript:void(0);" class="collapse" data-original-title="" title=""> </a>
                                                            </div>
                                                        </div>
                                                        <div class="portlet-body">
                                                            <div class="row">
                                                                <div class="col-md-12 no-padding">
                                                                    <div class="form-body" >
                                                                        <div class="col-md-12 no-padding">
                                                                            <div class="col-md-9">
                                                                                <label for="ServiceResults" class="control-label">Services/Results</label>
                                                          <textarea name="ServiceResults"
                                                                    data-ng-model="DevelopmentModel.ServiceResults"
                                                                    ck-editor></textarea>
                                                                                <br/>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 no-padding">
                                                        <input id="submit" name="submit" type="submit" value="Save"
                                                               class="btn blue save-button" data-ng-click="Save()"
                                                               ng-disabled="!UploadComplete">
                                                        <button type="button" id="cancel" class="btn default"
                                                                data-ng-click="Cancel()" ng-disabled="!UploadComplete">
                                                            Cancel
                                                        </button>
                                                    </div>

                                                </div>
                                                <div class="form-group col-md-12 tab-pane fade no-padding" id="tab_1_4">
                                                    <h3 class="page-title">Videos</h3>
                                                    <div data-ng-controller="DevelopmentVideoController">
                                                        <div data-ng-if="DevelopmentVideoList.length > 0"
                                                             class="table-responsive col-md-12">
                                                            <table class="table dataTable table-striped table-bordered table-hover">
                                                                <thead class="site-footer">
                                                                <tr>
                                                                    <th class="vertical-align col-md-1"><span
                                                                                class="anchor_color">Image</span></th>
                                                                    <th class="sorting"
                                                                        data-ng-click="ListPager.sortColumn('Title')"
                                                                        data-ng-class="{sorting_desc: (ListPager.sortIndex === 'Title' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'Title' && !ListPager.reverse)}">
                                                                        Title
                                                                    </th>
                                                                    <th class="sorting"
                                                                        data-ng-click="ListPager.sortColumn('Category')"
                                                                        data-ng-class="{sorting_desc: (ListPager.sortIndex === 'Category' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'Category' && !ListPager.reverse)}">
                                                                        Category
                                                                    </th>
                                                                    <th class="col-md-1">Action</th>
                                                                </tr>
                                                                </thead>
                                                                <tbody dir-paginate="data in DevelopmentVideoList | itemsPerPage:ListPager.pageSize"
                                                                       total-items="ListPager.totalRecords"
                                                                       current-page="ListPager.currentPage"
                                                                       pagination-id="VideoID">
                                                                <tr>
                                                                    <td class="vertical-align"><img
                                                                                src="@{{data.ThumbnailImageURL ? data.ThumbnailImageURL : DevelopmentModel.NoImagePath}}"
                                                                                class="dev-thumb-img"></td>
                                                                    <td>@{{data.Title}}</td>
                                                                    <td>@{{data.Category}}</td>
                                                                    <td>
                                                                        <div>
                                                                            <a ng-click="DeleteDevelopmentVideo(data)"
                                                                               title="Delete Video"><i
                                                                                        class="fa fa-trash-o text-danger"></i></a>
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                                </tbody>
                                                            </table>

                                                            <div class="col-md-12"
                                                                 data-ng-if="DevelopmentVideoList.length > 0">
                                                                <dir-pagination-controls boundary-links="true"
                                                                                         on-page-change="ListPager.pageChanged(newPageNumber)"
                                                                                         pagination-id="VideoID">
                                                                </dir-pagination-controls>
                                                            </div>

                                                        </div>
                                                        <div class="form-group col-md-12 display-none" align="center"
                                                             id="nodata">
                                                            <b>No Videos found. To select a video for this development,
                                                                please <a
                                                                        href="<?php echo URL::to('/addvideo/' . $encryptedSiteID); ?>">add/edit</a>
                                                                a video and select this development.</b>
                                                        </div>

                                                    </div>
                                                </div>
                                                <div class="form-group col-md-12 tab-pane fade no-padding" id="tab_1_5">
                                                    <h3 class="page-title">Listings</h3>
                                                    <div data-ng-controller="DevelopmentListingController">
                                                        <form>
                                                            <div class="form-body" ng-cloak>
                                                                <div class="form-group col-md-2">
                                                                    <label for="MLSNo" class="control-label">MLS#</label>
                                                                    <input type="text" class="form-control"
                                                                           data-ng-model="DevelopmentListModel.frontSearchModel.MLSNo"
                                                                           id="MLSNo" name="MLSNo" maxlength="20">
                                                                </div>
                                                                <div class="form-group col-md-2">
                                                                    <div class="search-label-hidden"><label
                                                                                class="control-label">&nbsp;</label></div>
                                                                    <button data-ng-click="SearchDevelopmentPropertyRecords()"
                                                                            class="btn blue btn-search">Search
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </form>
                                                        <div data-ng-if="DevelopmentPropertyList.length > 0"
                                                             class="table-responsive col-md-12" ng-cloak>
                                                            <table class="table dataTable table-striped table-bordered table-hover">
                                                                <thead class="site-footer">
                                                                <tr>

                                                                    <th class="sorting"
                                                                        data-ng-click="ListPagerListing.sortColumn('MLSNo')"
                                                                        data-ng-class="{sorting_desc: (ListPagerListing.sortIndex === 'MLSNo' && ListPagerListing.reverse), sorting_asc: (ListPagerListing.sortIndex === 'MLSNo' && !ListPagerListing.reverse)}">
                                                                        MLS#
                                                                    </th>
                                                                    <th class="sorting"
                                                                        data-ng-click="ListPagerListing.sortColumn('SquareFeet')"
                                                                        data-ng-class="{sorting_desc: (ListPagerListing.sortIndex === 'SquareFeet' && ListPagerListing.reverse), sorting_asc: (ListPagerListing.sortIndex === 'SquareFeet' && !ListPagerListing.reverse)}">
                                                                        Square Feet
                                                                    </th>
                                                                    <th class="sorting"
                                                                        data-ng-click="ListPagerListing.sortColumn('NoOfBeds')"
                                                                        data-ng-class="{sorting_desc: (ListPagerListing.sortIndex === 'NoOfBeds' && ListPagerListing.reverse), sorting_asc: (ListPagerListing.sortIndex === 'NoOfBeds' && !ListPagerListing.reverse)}">
                                                                        Beds
                                                                    </th>

                                                                    <th class="sorting"
                                                                        data-ng-click="ListPagerListing.sortColumn('NoOfFullBaths')"
                                                                        data-ng-class="{sorting_desc: (ListPagerListing.sortIndex === 'NoOfFullBaths' && ListPagerListing.reverse), sorting_asc: (ListPagerListing.sortIndex === 'NoOfFullBaths' && !ListPagerListing.reverse)}">
                                                                        Baths
                                                                    </th>
                                                                    <th class="sorting"
                                                                        data-ng-click="ListPagerListing.sortColumn('Price')"
                                                                        data-ng-class="{sorting_desc: (ListPagerListing.sortIndex === 'Price' && ListPagerListing.reverse), sorting_asc: (ListPagerListing.sortIndex === 'Price' && !ListPagerListing.reverse)}">
                                                                        Price
                                                                    </th>
                                                                    <th class="sorting"
                                                                        data-ng-click="ListPagerListing.sortColumn('AgentName')"
                                                                        data-ng-class="{sorting_desc: (ListPagerListing.sortIndex === 'AgentName' && ListPagerListing.reverse), sorting_asc: (ListPagerListing.sortIndex === 'AgentName' && !ListPagerListing.reverse)}">
                                                                        Listing Agent
                                                                    </th>
                                                                    <th class="sorting"
                                                                        data-ng-click="ListPagerListing.sortColumn('StatusID')"
                                                                        data-ng-class="{sorting_desc: (ListPagerListing.sortIndex === 'StatusID' && ListPagerListing.reverse), sorting_asc: (ListPagerListing.sortIndex === 'StatusID' && !ListPagerListing.reverse)}">
                                                                        Status
                                                                    </th>
                                                                    <th>Action</th>
                                                                </tr>
                                                                </thead>
                                                                <tbody dir-paginate="data in DevelopmentPropertyList | itemsPerPage:ListPagerListing.pageSize"
                                                                       total-items="ListPagerListing.totalRecords"
                                                                       current-page="ListPagerListing.currentPage"
                                                                       pagination-id="ListingID">
                                                                <tr>
                                                                    <td>@{{data.MLSNo}}</td>
                                                                    <td>@{{data.SquareFeet}}</td>
                                                                    <td>@{{data.NoOfBeds}}</td>
                                                                    <td>@{{data.NoOfFullBaths}}</td>
                                                                    <td>@{{data.Price}}</td>
                                                                    <td>@{{data.AgentName}}</td>
                                                                    <td>@{{data.Status}}</td>
                                                                    <td>
                                                                        <div>
                                                                            <a ng-click="DeleteDevelopmentListing(data)"
                                                                               title="Delete Property"><i
                                                                                        class="fa fa-trash-o text-danger"></i></a>
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                                </tbody>
                                                            </table>

                                                            <div class="col-md-12"
                                                                 data-ng-if="DevelopmentPropertyList.length > 0">
                                                                <dir-pagination-controls boundary-links="true"
                                                                                         on-page-change="ListPagerListing.pageChanged(newPageNumber)"
                                                                                         pagination-id="ListingID">
                                                                </dir-pagination-controls>
                                                            </div>

                                                        </div>
                                                        <div class="form-group col-md-12 display-none" align="center"
                                                             id="nodata1">
                                                            <b>No Listings found. To select a listing for this development,
                                                                please <a
                                                                        href="<?php echo URL::to('/addlisting/' . $encryptedSiteID); ?>">add/edit</a>
                                                                a listing and select this development.</b>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php } ?>

                                            </div>
                                        </div>

                                </div>
                            </form>
                        </div>
                    </div>
                <!-- END DASHBOARD STATS 1-->
            </div>

        </div>
        <!-- END CONTENT BODY -->
    </main>
@stop
@section('script')

    {{$minify::javascript(array('/assets/js/viewjs/development/addDevelopment.js','/assets/js/ckeditor/ckeditor.js','/assets/js/sitejs/dropzone.js'))->withFullUrl()}}

    {{ $minify::javascript(array('/assets/js/sitejs/jquery-ui-1.9.2.custom.min.js',
                                   '/assets/js/sitejs/jquery.ui.touch-punch.min.js'))->withFullUrl()}}
    <script type="text/javascript">
        window.NoImagePath = '<?php echo asset('/assets/images/Samplephoto.png') ?>';
        window.DevelopmentImage = "{{ trans('messages.DevelopmentImage')}}";
        window.DefaultDevelopmentImage = "{{ trans('messages.DefaultDevelopmentImage')}}";
    </script>

@stop