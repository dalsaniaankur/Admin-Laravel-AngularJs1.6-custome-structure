<?php
    $minify = new \CeesVanEgmond\Minify\Facades\Minify;
    use Infrastructure\Common;
    use BaseController as BA;
?>
@extends('layouts.sitemaster')
@section('Title','Developments')
@stop
@section('content')
    <?php echo Form::hidden('ListModel', json_encode($ListModel), $attributes = array('id' => 'ListModel'));?>

    <!-- BEGIN CONTENT BODY -->
    <div class="page-content" data-ng-controller = "DevelopmentListController">
        <!-- BEGIN PAGE HEADER-->
        <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo URL::to('/dashboard/'.$encryptedSiteID) ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Developments</span>
                </li>
            </ul>
            <div class="page-toolbar">
                <div class="btn-group pull-right">
                    <a href="<?php echo URL::to('/adddevelopment/'.$encryptedSiteID); ?>" class="btn btn-primary btn-sm btn-outline"> Add Development</a>
                </div>
            </div>
        </div>
        <!-- END PAGE BAR -->
        <!-- BEGIN PAGE TITLE-->
        <h3 class="page-title">
            Developments
        </h3>
        <!-- END PAGE TITLE-->
        <!-- END PAGE HEADER-->

        <!-- BEGIN Form Design-->
        <div class="row">
            <div class="col-md-12">
                <form>
                    <div class="form-body" ng-cloak>
                        <div class="form-group col-md-3">
                            <label for="Name" class="control-label">Name</label>
                            <input type="text" class="form-control" data-ng-model="ListModel.frontSearchModel.Name" id="Name" name="Name" />
                        </div>
                        <div class="form-group col-md-2">
                            <div class="search-label-hidden"><label class="control-label">&nbsp;</label></div>
                            <button data-ng-click="SearchDevelopmentRecords()" class="btn blue btn-search button-font">Search</button>
                        </div>
                    </div>
                </form>

                <div data-ng-if="DevelopmentList.length > 0" class="table-responsive col-md-12" ng-cloak>
                    <table class="table dataTable table-striped table-bordered table-hover">
                        <thead class="site-footer">
                        <tr>
                            <th class="col-md-1">Image</th>
                            <th class="sorting" data-ng-click="ListPager.sortColumn('Name')" data-ng-class="{sorting_desc: (ListPager.sortIndex === 'Name' && ListPager.reverse), sorting_asc: (ListPager.sortIndex === 'Name' && !ListPager.reverse)}" >
                                Name
                            </th>
                            <th class="col-md-1">Action</th>
                        </tr>
                        </thead>
                        <tbody dir-paginate="data in DevelopmentList | itemsPerPage:ListPager.pageSize" total-items="ListPager.totalRecords" current-page="ListPager.currentPage" pagination-id="DevelopmentID">
                        <tr>
                            <td class="vertical-align"><img src="@{{data.ImageURL ? data.ImageURL : ListModel.NoImagePath}}" class="dev-thumb-img"></td>
                            <td class="vertical-align"><a ng-click="EditDevelopment(data)" title="Edit Development" >@{{data.Name}}</a></td>
                            <td class="faq-action-part vertical-align">
                                <div>
                                    <a ng-click="EditDevelopment(data)" title="Edit Development" ><i class="fa fa-pencil text-default" ></i></a>
                                    &nbsp;
                                    <?php if(BA::CheckRoleSitePermission(Common::getRoleITAdminAndAgent(),Common::getSiteMercerVineColorado())) {?>
                                    <a ng-click="DeleteDevelopment(data)" title="Delete Development"><i class="fa fa-trash-o text-danger"></i></a>
                                    <?php } ?>
                                </div>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                <div class="col-md-12" data-ng-if="DevelopmentList.length > 0">
                    <dir-pagination-controls boundary-links="true"  on-page-change="ListPager.pageChanged(newPageNumber)" pagination-id="DevelopmentID">
                    </dir-pagination-controls>
                </div>

                </div>
                <div class="form-group col-md-12 display-none"  align="center" id="nodata">
                    <b>{{ trans('messages.NoDevelopmentRecordFound')}}</b>
                </div>
            </div>
        </div>
        <!-- END DASHBOARD STATS 1-->
    </div>
    <!-- END CONTENT BODY -->
@stop

@section('script')
    {{ $minify::javascript(array('/assets/js/viewjs/development/developments.js',))->withFullUrl()}}
    <script>
        window.NoImagePath = '<?php echo asset('/assets/images/Samplephoto.png') ?>';
    </script>
@stop
