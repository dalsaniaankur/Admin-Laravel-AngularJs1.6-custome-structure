<?php
    $minify = new \CeesVanEgmond\Minify\Facades\Minify;
?>
@extends('layouts.sitemaster')
@section('Title')
    Manage Navigation
@stop
@section('css')

@stop
@section('content')
<main id="main" role="main">

    <div class="page-content">
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo URL::to('/dashboard/'.$encryptedSiteID) ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>Navigation</span>
                </li>
            </ul>
        </div>

        <div class="row">
            <div  class="col-md-12" ng-controller = "HeaderNavigationController" ng-cloak>
                <h3 class="page-title"> Header Navigation </h3>
                <div class="form-group col-md-12 no-padding">
                    <div class="note note-info help box navigation" ng-show="HeaderNavigationModel.MenuID == 0">
                        <h4 class="block">Tip</h4>
                        <p> {{ trans('messages.NavigationHeaderMenuQueue')}}</p>
                    </div>
                    <div class="note note-info help box navigation" ng-show="HeaderNavigationModel.MenuID == 1">
                        <h4 class="block">Tip</h4>
                        <p> {{ trans('messages.NavigationFooterMenuQueue')}}</p>
                    </div>
                </div>
                <div class="form-group col-md-12 no-padding">
                    <div class="form-group col-md-2 no-padding">
                        <label for="Category" class="control-label">Menu</label>
                        <select class="form-control" id="MenuID" name="Name" ng-model="HeaderNavigationModel.MenuID" ng-options="Menu.MenuID as Menu.Name for Menu in MenuArray" data-ng-change="ChangeMenu()">
                            <option value="">Please select menu</option>
                        </select>
                    </div>
                </div>
                <div ng-show="AjaxRunning">
                    <div class="form-group col-md-4 no-padding">
                        <form name="HeaderNavigationMenuForm" id="HeaderNavigationMenuForm" role="form" novalidate>
                            <div class="form-body" ng-cloak >
                                <div class="col-md-12 no-padding">
                                    <h3>Content</h3>
                                </div>
                                <div class="form-group col-md-9 no-padding">
                                    <select class="form-control pages-list" multiple="multiple"
                                            ng-model="HeaderNavigationModel.Pages"
                                            ng-options="HeaderPageList as HeaderPageList.Name group by HeaderPageList.Type for HeaderPageList in HeaderPagesArray | orderBy:['-Type','Name']:false"
                                            id="Pages"
                                            name="Pages" ng-change="IsSelect()">
                                    </select>
                                </div>

                                <div class="form-actions col-md-12 no-padding">
                                    <input id="submit" name="submit" type="submit" value="add" class="btn blue" data-ng-click="AddMenu()" ng-disabled="(HeaderPagesArray.length == 0 || !IsSelected)">
                                </div>
                            </div>

                        </form>
                        <form name="CustomNavigationMenuForm" id="CustomNavigationMenuForm" role="form" novalidate>
                            <div class="form-body" ng-cloak >
                                <div class="col-md-12 no-padding">
                                    <h3>Add Custom Menu</h3>
                                </div>
                                <div class="form-group col-md-11 no-padding" ng-class="{'has-error' : (CustomNavigationMenuForm.$submitted) && CustomNavigationMenuForm.DisplayName.$invalid}">
                                    <label for="Menu Title" class="control-label">Menu Title</label>
                                    <input class="form-control"  type="text" name="DisplayName" ng-model="CustomNavigationMenu.DisplayName" ng-class="{ 'has-submitted' : CustomNavigationMenuForm.$submitted}"  required />
                                    <span class="error-text-color" ng-show="CustomNavigationMenuForm.$submitted">
                                        <span ng-show="CustomNavigationMenuForm.DisplayName.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Display Name'))}}</span>

                                    </span>
                                </div>
                                <div class="form-group col-md-11 no-padding" ng-class="{'has-error' : (CustomNavigationMenuForm.$submitted) && CustomNavigationMenuForm.CustomURL.$invalid}">
                                    <label for="URL" class="control-label">URL</label>
                                    <input class="form-control"  type="text" name="CustomURL" ng-model="CustomNavigationMenu.CustomURL" ng-class="{ 'has-submitted' : CustomNavigationMenuForm.$submitted}" pattern="<?php echo \Infrastructure\Constants::$WebsiteBaseURLRegex;?>" required />
                                    <span class="error-text-color" ng-show="CustomNavigationMenuForm.$submitted">
                                        <span ng-show="CustomNavigationMenuForm.CustomURL.$error.required">{{ trans('messages.PropertyRequired',array('attribute'=>'Custom URL'))}}</span>
                                        <span ng-show="CustomNavigationMenuForm.CustomURL.$error.pattern">{{ trans('messages.InvalidCustomURL')}}</span>
                                    </span>
                                </div>
                                <div class="form-group col-md-11 no-padding" ng-class="{'has-error' : (CustomNavigationMenuForm.$submitted) && CustomNavigationMenuForm.CustomURL.$invalid}">
                                    <input type="checkbox" ng-model="CustomNavigationMenu.IsOpenNewTab"
                                           ng-true-value="1" ng-false-value="0" id="Open in new Tab?">
                                    <label for="Open in new Tab?" class="control-label">Open in new Tab?</label>
                                </div>
                                <div class="form-actions col-md-12 no-padding">
                                    <input id="submit" name="submit" type="submit" value="add" class="btn blue" ng-disabled="CustomNavigationMenuForm.$invalid" data-ng-click="AddCustomMenu()">
                                    <button type="button" class="btn default" ng-click="ClearCustomNavigationMenuForm()">Cancel</button>
                                </div>
                            </div>
                        </form>
                    </div>

                    <div class="col-md-6 no-padding" >
                        <form name="HeaderNavigationTreeForm" id="HeaderNavigationTreeForm" role="form" novalidate>
                            <div class="col-md-12" >
                                <h3>Site Structure </h3>
                            </div>
                            <div class="form-body navigation-tree" ng-cloak data-ng-if="tree.length > 0">

                            <!-- Nested node template start -->
                                <script type="text/ng-template" id="nodes_menu">
                                    <div class="tree-node " ng-class="{ 'node-except-last-one' : !$last}">
                                        <div class="tree-node-content">

                                            <a data-nodrag ng-click="toggle(this)" ng-show="node.nodes != ''">
                                                <i class="tree-view-icon" ng-class="{'tree-view-plus': collapsed,'tree-view-minus': !collapsed}"></i>
                                            </a>

                                            <i class="last-nodes" ng-show="node.nodes == ''"></i>

                                            <i ng-show="node.nodes != ''" class="fa fa-folder icon-state-warning" role="presentation"></i>
                                            <i ng-show="node.nodes == ''" class="fa fa-file icon-state-warning" role="presentation"></i>

                                            <input type="text" ng-model="node.DisplayName" class="tree-input" name="DisplayName" required ng-class="{'tree-error': (node.DisplayName == null)}">

                                            <a ng-hide="node.ItemLevel == 1 && !IsFooterMenu" class="pull-right" data-nodrag data-ng-click="RemovePage(node,this)">
                                                <i class="fa fa-trash-o text-danger"></i>
                                            </a>

                                            <div class="pull-left tree-handle" ui-tree-handle ng-hide="node.ItemLevel == 1 && !IsFooterMenu">
                                                 <span class="fa fa-bars draggable-icon tree"></span>
                                            </div>

                                        </div>
                                    </div>
                                    <ol ui-tree-nodes="" ng-model="node.nodes" ng-class="{hidden: collapsed}" class="parent-nodes">
                                        <li ng-repeat="node in node.nodes" ui-tree-node  ng-include="'nodes_menu'" ng-class="{'background-none-last-node': $last}"></li>
                                    </ol>
                                </script>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div ui-tree id="tree-root" data-clone-enabled="false" >
                                            <ol ui-tree-nodes="" ng-model="tree" class="tree-parent" data-nodrop-enabled ng-hide="IsFooterMenu" >
                                                <li ng-repeat="node in tree" ui-tree-node ng-include="'nodes_menu'" ng-class="{'background-none-last-node': $last}"></li>
                                            </ol>
                                            <ol ui-tree-nodes="" ng-model="tree" class="tree-parent" ng-hide="!IsFooterMenu" >
                                                <li ng-repeat="node in tree" ui-tree-node ng-include="'nodes_menu'" ng-class="{'background-none-last-node': $last}"></li>
                                            </ol>
                                        </div>

                                    </div>
                                </div>
                                <!-- Nested node template end-->
                            </div>
                            <div class="form-body navigation-tree" ng-cloak  align="center" data-ng-if="tree.length == 0">
                                <b>{{ trans('messages.NoNavigationRecordFound') }}</b>
                            </div>

                            <div class="form-actions col-md-12 no-padding">
                                <input id="submit" name="submit" type="submit" value="Save" class="btn blue save-button" data-ng-click="SaveMenu()" ng-disabled="((tree.length == 0) && (IsPageLoad))">
                                <button type="button" id="cancel" class="btn default" data-ng-click="Cancel()" >Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
@stop

@section('script')
    {{ $minify::javascript(array('/assets/js/viewjs/navigation/navigation.js'))->withFullUrl()}}
    <script>
        window.InvalidNavigation = '<?php echo \Infrastructure\Constants::$InvalidNavigation;?>';
    </script>

@stop